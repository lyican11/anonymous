#include <setjmp.h>

extern int f(void);
extern int g(int);
extern jmp_buf jb;

int f(void)
{
    int j;

    j = 0;
    if( !setjmp(jb) ) {
        g(j);
    }
    else {
        j = -1;
    }

    return j;
}
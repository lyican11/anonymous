#include <stddef.h>     /* size_t */
#include <sys/cdefs.h>  /* __THROWNL */

/* From <stdio.h> */
extern int snprintf (char *__restrict __s, size_t __maxlen,
                     const char *__restrict __format, ...)
__THROWNL __attribute__ ((__format__ (__printf__, 3, 4)));

typedef struct am_option
{
    /* Removing any element reduces the size of the overflow */
    char    am_field01[128+1];
    char    am_field02[256+1];
    char    am_field03[64+1];
    char    common01[2048+1];
    char    am_field04[2048+1];
} awsc_t;

typedef struct az_option
{
    char    az_field11[128+1];
    /* Removing az_field12 changes size from 8837 to 8877 */
    char    az_field12[36+1];
    /* Removing az_field13 changes size from 8837 to 8901 */
    char    az_field13[64+1];
    /* Removing az_field14 changes size from 8837 to 8877 */
    char    az_field14[36+1];
    /* Removing az_field15 changes size from 8837 to 8849 */
    char   *az_field15;
    char    common01[160+1];
} azrc_t;

typedef struct unified
{
    int         flags;
    union alternatives
    {
        awsc_t  variant01;
        azrc_t  variant02;
    } variant;
} mz_unity;

typedef struct MZ_CB
{
    char         mz_url[512+1];
    mz_unity     *mz_creds;
} mz_cb;

extern void mz_format(mz_cb *rcb);

void mz_format(mz_cb *rcb)
{
    mz_unity *ocred = rcb->mz_creds;
    mz_unity  ncred = *ocred;
    mz_unity *rcred = &ncred;

    snprintf(rcb->mz_url, sizeof(rcb->mz_url), "%s/name/%s/abc1234",
             rcred->variant.variant02.az_field11,
             rcred->variant.variant02.common01);
}
class a {
public:
    int b();
};
unsigned long long c;
struct B {
    double d();
    a *e[];
};
double B::d() {
    int f = e[0]->b();
    return f > c ? 0 : c - f;
}


int foo(int i)
{
    switch (i) {
        case 1:
            i = 0;
        default:
            break;
    }
    return i;
}
#include <stdio.h>
#include <string.h>

struct S
{
    char str[20];
    char out[10];
};

void test(S* s)
{
    if (strlen(s->str) < sizeof(s->out) - 2)
        snprintf(s->out, sizeof(s->out), "[%s]", s->str);
}
typedef struct {
    double a[4];
} b;
int c, e;
b *d;
float truncf(float);
void f() {
    for (unsigned g = 0; g < c; g++) {
        double a = truncf(d[1].a[g]);
        e = a;
    }
}
#include <stdio.h>
int main(int argc, char **argv) {
    switch (argc) {
        int v;
        case 1:
            v = 2;
        default:
            printf("v(%p): %x\n", &v, v);
    }
    return 0;
}
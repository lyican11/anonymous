# 0 "asmgoto.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "asmgoto.c"
void foo()
{
    int dummy;

    __asm__ goto(
    "jmp %l[jmp_target]\n"
    : "=r"(dummy)
    :
    :
    : jmp_target);

    jmp_target:
    return;
}
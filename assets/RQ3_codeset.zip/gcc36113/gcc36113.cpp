#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <inttypes.h>

int main(void) {
    enum {
        dummy = (1ULL<<63),
        SomeConstant = 0x1
    } MyEnum;

#define MY_MACRO(value) ((value) << 60)

    printf("MY_MACRO(SomeConstant) == 0x%llx.\n", MY_MACRO(SomeConstant));

    return 0;
}
#include <stdio.h>
void alienware_zone_init(unsigned char num_zones)
{
    unsigned char zone;
    char buffer[10];

    for (zone = 0; zone < num_zones; zone++)
        sprintf(buffer, "zone%02X", zone);
}
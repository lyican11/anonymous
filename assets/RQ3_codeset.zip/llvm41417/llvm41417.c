void c(_Bool *);
void a() {
    _Bool b;
    c(&b);
}
const struct {
    int d;
    int (*e)();
} f[] = {};
int h(void);
int AVI_ChunkRead_p_chk() {
    int g = h();
    if (g)
        return f[g].e(0, 0);
    a();
    return 0;
}
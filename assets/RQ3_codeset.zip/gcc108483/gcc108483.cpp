#include <stddef.h>
#define ARRAY_SIZE_MAYBENULL(x)  (__builtin_types_compatible_p(typeof(x), void*) ? 0 : (sizeof(x)/sizeof(*x)))
int x = ARRAY_SIZE_MAYBENULL(NULL) + 1;
typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;
typedef _Bool bool;
static inline void _ether_addr_copy(u8 *dst, const u8 *src)
{
    *(u32 *)dst = *(const u32 *)src;
    *(u16 *)(dst + 4) = *(const u16 *)(src + 4);
}
struct _ieee80211_hdr {
    u8 addr1[6];
};
struct _haddr_pair {
    u8 h_dest[6];
};
struct _ath_dyn_txbuf {
    u16 t_rb;
    struct _haddr_pair addr[64];
};
struct _ath_dynack {
    bool enabled;
    struct _ath_dyn_txbuf st_rbf;
};
struct _ath_hw {
    int reg_ops;
    struct _ath_dynack dynack;
};
void _ath_dynack_sample_tx_ts(struct _ath_hw *ah, struct _ieee80211_hdr *hdr)
{
    struct _ath_dynack *da = &ah->dynack;
    struct _haddr_pair *addr;

    if (!da->enabled)
        return;

    addr = &da->st_rbf.addr[da->st_rbf.t_rb];
    _ether_addr_copy(addr->h_dest, hdr->addr1);
}
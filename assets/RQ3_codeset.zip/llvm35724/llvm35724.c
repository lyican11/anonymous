class a {
        public:
        int b;
};
class c : public a {};
class d {
        public:
        c f;
};

int fn1(d *e) { return (&(e->f))->b == 0; }
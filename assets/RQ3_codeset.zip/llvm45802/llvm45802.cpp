int m;
typedef unsigned long size_t;
void *c(void *dest, const void *src, size_t n) __asm__("memcpy");
extern inline __attribute__((gnu_inline)) void *memcpy(void *dest, const void *src, size_t n) { return c(dest, src, n); }
void d();
static void ad(unsigned long long *a, unsigned long long *b) {
    long e[] = {0, a[1], a[2], a[3], a[4]};
    long k = a[1];
    __uint128_t f[5];
    __uint128_t *g = f;
    unsigned long long *h = b;
    g += g[1] = (unsigned long)e * b[0];
    g += h[3] += b[0];
    g[4] = a[4];
    g += a[1];
    g[1] += k;
    g += h[13] += b[1];
    g += 4 * b[1];
    d();
    long l = *e;
    g[1] = (__uint128_t)l * b[2];
    g += b[2];
    g[1] += (unsigned long)e * b[3];
}
static void j(unsigned long long *a, unsigned long long *b) { a[5] = b[5]; }
void ap() {
    long ai[15] = {};
    unsigned long long am[40];
    unsigned long long *ag = am + 10;
    int i;
    while (i--)
        while (m) {
            j(am + 5, ag + 5);
            unsigned long long *o = am + 5, *n = ag + 5;
            unsigned long long ai[40];
            ad(ag, o);
            ad(am, n);
            unsigned long long *aj = ai + 5;
            d(aj);
        }
    memcpy(ai, am, *am);
}
static inline bool bio_flagged(struct bio *bio, unsigned int bit)
{
    return (bio->bi_flags & (1U << bit)) != 0;
}

void bio_release_pages(struct bio *bio, bool mark_dirty)
{
    if (bio_flagged(bio, BIO_PAGE_REFFED) ||
        bio_flagged(bio, BIO_PAGE_PINNED))
        __bio_release_pages(bio, mark_dirty);
}
int a;
typedef struct {
    int b;
} c;
char d;
void e() {
    c *f = (c *)1;
    int g;
    if (d & 1)
        f = 0;
    if (d & 2)
        f[1].b = d & 1;
    a = 0;
}
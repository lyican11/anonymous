#define __diag_str1(s) #s
#define __diag_str(s) __diag_str1(s)
#define __diag(s) _Pragma(__diag_str(GCC diagnostic s))

#define __diag_push()           __diag(push)
#define __diag_ignore(option)   __diag(ignored option)
#define __diag_pop()            __diag(pop)

#define DEFALIAS(x, name, ...)                   				\
        __diag_push()                            				\
        __diag_ignore("-Wattribute-alias")       				\
        __diag_ignore("-Wuninitialized")         				\
        long compat_sys(char c) __attribute__((alias("compat_SyS")));		\
	struct s;								\
	static long compat_SyS(int c)						\
	{ int uninitialized; return uninitialized;};				\
        __diag_pop()								\

DEFALIAS(1, testb, int, c)
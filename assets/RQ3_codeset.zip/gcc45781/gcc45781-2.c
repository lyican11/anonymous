typedef union tree_node *tree;
struct tree_exp { tree operands[1]; };
union tree_node { struct tree_exp exp; };
static unsigned char init_target_chars (void);
static unsigned long long target_newline;



tree rewrite_call_expr()
{
    return 0;
}

tree fold_builtin_snprintf_chk (tree exp)
{
    tree len, fmt;
    if (exp->exp.operands[0] < 5)              return (tree) ((void *)0);
    if (!validate_arg (len, 0))                return (tree) ((void *)0);
    if (!validate_arg (fmt, 1))                return (tree) ((void *)0);
    if (!init_target_chars ())                 return (tree) ((void *)0);
    return rewrite_call_expr ();
}
static unsigned char init_target_chars (void) {
    static unsigned char init;
    if (!init) { target_newline = foo ('\n'); }
}
tree gimple_fold_builtin_snprintf_chk (void)
{
    tree size, fmt;
    if (!validate_arg (size, 0))               return (tree) ((void *)0);
    if (!validate_arg (fmt, 1))                return (tree) ((void *)0);
    if (!host_integerp (size, 1))              return (tree) ((void *)0);
    if (!init_target_chars ())                 return (tree) ((void *)0);
    return gimple_rewrite_call_expr ();
}
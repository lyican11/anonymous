/* SPDX-License-Identifier: GPL-2.0-only */

/* amisound.c */
void amiga_init_sound(void);
void amiga_mksound(unsigned int hz, unsigned int ticks);

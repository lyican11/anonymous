struct T { const char *p; };
struct S { T a, b, c; unsigned d; };
void bar (const T &, const T &);

void
foo (S &s, T e)
{
    const char *a = e.p;
    const char *b = s.b.p;
    __asm__ volatile ("/* %0 %1 */" : : "rm" (a), "rm" (b));
    bar (e, s.b);
}
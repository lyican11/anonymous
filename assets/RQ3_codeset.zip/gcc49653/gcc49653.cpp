inline long trouble(long a, long b)
 {
    return a + b;
  }

  long two = 2;

  int main()
  {
      long result = trouble(two, two);
      return (int)result;
  }
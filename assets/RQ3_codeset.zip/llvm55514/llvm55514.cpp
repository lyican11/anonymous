void foo (void) {
    int bar;
    asm("# foo":"+r"(bar) : "0"(bar));
}
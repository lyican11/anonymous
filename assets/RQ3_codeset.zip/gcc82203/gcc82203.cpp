int f(void);
int mlx5_fpga_mem_read_i2c(int count)
{
    int i, err;

    for (i = 0; i < count; i++) {
        err = f();
        if (err)
            break;
    }

    return err;
}
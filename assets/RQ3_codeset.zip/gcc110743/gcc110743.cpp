struct spi_mem_op {
    struct {
        int a : 1;
    };
    struct {
        char b : 1;
        long c;
    };
};
void spi_nor_read_any_reg(struct spi_mem_op *);
void s25fs256t_post_bfpt_fixup_nor(void) {
    struct spi_mem_op op;
    spi_nor_read_any_reg(&op);
}
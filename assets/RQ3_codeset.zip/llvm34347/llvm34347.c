#include <atomic>

struct AM {
    int f1;
    int f2;
};

std::atomic<AM> ip3{AM()};
std::atomic<AM> ip4{AM()};

void foo() {
    auto val = ip4.load(std::memory_order_relaxed);
    ip3.store(val, std::memory_order_relaxed);
}
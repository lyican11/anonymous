struct a {
    unsigned long long b;
};
struct c {
    void d(const a &) const;
    template <class e> void f(const a &, e) const;
    double g;
    double h;
    double i;
    double j;
} k;
template <class e> void c::f(const a &l, e) const {
auto &m = k;
m.g /= l.b;
m.h /= l.b;
m.i /= l.b;
m.j /= l.b;
}
void c::d(const a &l) const {
f(l, [] {});
}
#include <stdio.h>

int func1( ) { return 42; }
__attribute__((weak, alias("func1")))  int func2( );

int main( )
{
    printf("%d\n", func2());
    return 0;
}
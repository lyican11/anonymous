template <unsigned inline_capacity> struct ByteBuffer {
    static ByteBuffer create_uninitialized();
    static void copy() {
        auto new_buf = create_uninitialized();
        new_buf.data();
    }
    char *data() { return m_inline ? m_inline_buffer : m_outline_buffer; }
    union {
        char m_inline_buffer[inline_capacity];
        char *m_outline_buffer;
    };
    bool m_inline;
};

void test()  {
    ByteBuffer<56> buf1;
    buf1.data();
    ByteBuffer<2>::copy();
}
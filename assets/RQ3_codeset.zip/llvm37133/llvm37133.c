int a, b;
unsigned long long c;
void e() {
    long long d;
    b = 33;
    d = a;
    if (c < a) {
        b = 32;
        d = c;
    }
    if (d)
        b = 2;
}
template <class T> class A {
public:
    A(short,short a=0) {}
    A<T>(short b) {}
};
void __detected_overflow(int, int) __attribute__((__warning__("detected overflow")));

union diffsize {
    int lg;
    char sm;
};

static void do_wipe(union diffsize *info)
{
    if (__builtin_object_size(&info->sm, 1) < sizeof(info->sm))
        __detected_overflow(__builtin_object_size(&info->sm, 1), sizeof(info->sm));
    __builtin_memset(&info->sm, 0, sizeof(info->sm));

    if (__builtin_object_size(&info->lg, 1) < sizeof(info->lg))
        __detected_overflow(__builtin_object_size(&info->lg, 1), sizeof(info->lg));
    __builtin_memset(&info->lg, 0, sizeof(info->lg));
}

void loops(union diffsize *info)
{
    int i, j;

    for (i = 0; i < 1; i++) {
        do_wipe(info);

        for (j = 0; j < 2; j++) {
            asm volatile("");
        }
    }
}
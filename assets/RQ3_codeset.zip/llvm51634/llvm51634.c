enum { false, true };

typedef struct {
  int counter;
} atomic_t;

typedef struct refcount_struct {
  atomic_t refs;
} refcount_t;

struct kref {
  refcount_t refcount;
};

struct list_head {
  struct list_head *next, *prev;
};

struct klist_node {
  void *n_klist;
  struct list_head n_node;
  struct kref n_ref;
};

typedef struct qspinlock {
  union {
    atomic_t val;

    struct {
      unsigned char locked;
      unsigned char pending;
    };
    struct {
      unsigned short locked_pending;
      unsigned short tail;
    };
  };
} arch_spinlock_t;

typedef struct raw_spinlock {
  arch_spinlock_t raw_lock;
} raw_spinlock_t;

typedef struct spinlock {
  union {
    struct raw_spinlock rlock;
  };
} spinlock_t;

struct klist {
  spinlock_t k_lock;
  struct list_head k_list;
  void (*get)(struct klist_node *);
  void (*put)(struct klist_node *);
} __attribute__((aligned(sizeof(void *))));

struct bug_entry {
  signed int bug_addr_disp;
  signed int file_disp;
  unsigned short line;
  unsigned short flags;
};

static _Bool knode_dead(struct klist_node *knode) {
  return (unsigned long)knode->n_klist & 1LU;
}

void knode_set_klist(struct klist_node *knode, struct klist *klist) {
  knode->n_klist = klist;

  ({
    _Bool __ret_warn_on = false;
    do {
      if (__builtin_constant_p((knode_dead(knode)))) {
        if (!(knode_dead(knode)))
          break;
        do {
          __label__ __label_warn_on;
          asm goto("1:	"
                   "twi 31, 0, 0"
                   "\n"
                   ".section __ex_table,\"a\";"
                   " "
                   ".balign 4;"
                   " "
                   ".long (1b) - . ;"
                   " "
                   ".long (%l[__label_warn_on]) - . ;"
                   " "
                   ".previous"
                   " "
                   ".section __bug_table,\"aw\"\n"
                   "2:\t.4byte 1b - 2b, %0 - 2b\n"
                   "\t.short %1, %2\n"
                   ".org 2b+%3\n"
                   ".previous\n"
                   :
                   : "i"("lib/klist.c"), "i"(62), "i"((1 << 0) | (((9) << 8))),
                     "i"(sizeof(struct bug_entry))
                   :
                   : __label_warn_on);
          do {
            ;
            __builtin_unreachable();
          } while (0);
        __label_warn_on:
          break;
        } while (0);
        __ret_warn_on = true;
      } else {
        __label__ __label_warn_on;
        asm goto("1:	"
                 "tdnei"
                 " "
                 " %4, 0"
                 "\n"
                 ".section __ex_table,\"a\";"
                 " "
                 ".balign 4;"
                 " "
                 ".long (1b) - . ;"
                 " "
                 ".long (%l[__label_warn_on]) - . ;"
                 " "
                 ".previous"
                 " "
                 ".section __bug_table,\"aw\"\n"
                 "2:\t.4byte 1b - 2b, %0 - 2b\n"
                 "\t.short %1, %2\n"
                 ".org 2b+%3\n"
                 ".previous\n"
                 :
                 : "i"("lib/klist.c"), "i"(62), "i"((1 << 0) | ((9) << 8)),
                   "i"(sizeof(struct bug_entry)), "r"(knode_dead(knode))
                 :
                 : __label_warn_on);
        break;
      __label_warn_on:
        __ret_warn_on = true;
      }
    } while (0);
    __builtin_expect(!!(__ret_warn_on), 0);
  });
}

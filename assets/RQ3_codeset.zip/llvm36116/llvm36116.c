struct {
    unsigned char *a[];
} b;
unsigned char c;
int d;
void e() {
    d = 0;
    for (; d < 32; d++)
        b.a[d] = &c + ((d & 16) << 1);
}
#include <span>

template<typename T, size_t N>
struct my_array {
    T m_data[N];
    operator std::span<T>() { return { m_data, N }; }
};

struct base {
    std::span<int> m_values;
};

template<typename... Args>
struct storage : base {
    storage(Args const&... args)
            : m_data({ args... })
    {
        m_values = m_data;
    }
    my_array<int, sizeof...(Args)> m_data;
};

int main() {
    storage<> bug_struct;
}
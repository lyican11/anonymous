class a {
        public:
        using b = int;
        int operator[](b) const;
};
struct c {
    int e : 32;
    int d : 31;
    int g : 1;
    int : 31;
    int f;
    c() : e(f), d(), g(1) {}
    c(int p1) : e(p1) {}
};
struct h {
    using i = a;
    c j(const i &, unsigned &);
};
c h::j(const i &p1, unsigned &k) {
int l = p1[1];
if (l)
return c();
return k;
}
void foo(void) {
    asm volatile("tlbilxlpid");
}
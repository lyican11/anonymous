extern void* memcpy (void*, const void*, __SIZE_TYPE__);

inline void bar (void *d, void *s, unsigned N)
{
    if (s != d)
        memcpy (d, s, N);
}

void foo (void* src)
{
    bar (src, src, 1);
}
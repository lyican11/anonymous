struct example {
    int foo[2];
};

int main()
{
    struct example ex = {0};
}
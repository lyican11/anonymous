typedef struct _FOO
{
    unsigned int f1:24;
    unsigned int f2:8;
} FOO;

extern void DoSomething(void* p);

int
main(int argc, const char * argv[])
{
    FOO foo;

    if (argc <= 2)
    {
        DoSomething(&foo);
        foo.f1 = 0;
    }
    else
    {
        foo.f1 = 2;
    }

    return foo.f1;
}
#include <string.h>

struct utmp { char ut_user[32]; } u;
static char const prefix[] = "user=";

int
main (void)
{
    char buf[sizeof prefix + sizeof u.ut_user];
    strcpy (buf, prefix);
    strncat (buf, u.ut_user, sizeof u.ut_user);
    return strlen (buf);
}
int main(int argc, char * argv[])
{
    int i = 0;

    scanf("%s",arr1);
    scanf("%s",arr2);
    while ((arr1[i] != arr2[i]) && i <= ARR_SIZE) /* Array bounds violation */
    {
        i++;
    }

    if (i == ARR_SIZE)
    {
        return 0xaa55;
    }

    return 0;
}

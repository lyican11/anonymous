template <typename> struct c;
template <typename b> struct j : c<b> {
    j(int);
    b *aa() { return d; }
    b e() { return *d; }
    b *d;
};
typedef struct {
    struct {
        union {
            int f;
            int *ab;
        } g;
    } h;
} i;
struct n {
    int *k() { return ac.h.g.ab; }
    int l() { return ac.h.g.f; }
    i ac;
};
template <class m> struct p {
    int ad();
    int *k() {
        n o = *static_cast<m *>(this)->ae();
        return o.k();
    }
};
template <> struct c<n> : p<j<n>> {
    n *ae() { return static_cast<j<n> *>(this)->aa(); }
};
void fn1(bool *);
bool q;
int r;
void u() {
    void *a[]{&&s, &&t};
    t:
    fn1(&q);
    goto *a[r];
    s:;
}
int v(j<n> w, j<n> x, bool *y) {
    if (w.ad()) {
        *y = w.k() == x.k();
        return 0;
    }
    *y = w.e().l() == x.e().l();
    return 0;
}
void fn1(bool *w) { v(0, 0, w); }
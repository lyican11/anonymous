struct {
    long b, c;
} d;
long e(unsigned char *f) {
    return (long)f[0] << 56 | (long)f[1] << 48 | (long)f[2] << 40 |
           (long)f[3] << 32 | (long)f[4] << 24 | f[5] << 16 | f[6] << 8 | f[7];
}
void g(void) {
    d.c = e((unsigned char *)g + 8);
    d.b = e((unsigned char *)g);
}
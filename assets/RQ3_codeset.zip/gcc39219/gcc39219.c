enum __attribute__ ((deprecated)) E { e };
struct S { enum __attribute__ ((deprecated)) F { f = e }; };
int main () {
      E x;
      x = e;

      S::F y;
      y = S::f;

      return x + y;
}
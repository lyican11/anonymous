#include <stdio.h>
struct {int i; char c[5];} s = {0, {0, 0x42, 0xf6, 0xe9, 0x79}};
int main() {
    union {float f; int i;} u;
    u.i = (s.c[1]<<24) + (s.c[2]<<16) + (s.c[3]<<8) + s.c[4];
    printf("%g\n", u.f);
}
#include <bit>
#include <type_traits>

template <typename Derived, typename Type>
struct alignas(sizeof(Type)) bit_field
{
};

struct S : bit_field<S, int>
{
    bool a : 1;

    constexpr S() noexcept = default;
    constexpr S(int i) noexcept: S( std::bit_cast<S>( i ) ) {}
};

static_assert(sizeof(S) == sizeof(int));
static_assert(std::is_trivially_copyable_v<S>);
static_assert(std::is_trivially_copyable_v<int>);

constexpr S sa = 0x00000001; // <source>(21)
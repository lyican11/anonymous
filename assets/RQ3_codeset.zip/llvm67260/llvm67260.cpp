template <typename T, T...> struct IntegerSequence;
template <unsigned... Indices>
using IndexSequence = IntegerSequence<unsigned, Indices...>;
template <unsigned N>
using MakeIndexSequence = __make_integer_seq<IntegerSequence, unsigned, N>;
template <typename T, typename> struct VariantConstructors {
    VariantConstructors(int t)
    requires(requires { T(t); });
};
template <typename> struct ParameterPack;
template <unsigned, typename...> struct InheritFromUniqueEntries;
template <unsigned I, typename... Ts, unsigned... Js, typename... Qs>
struct InheritFromUniqueEntries<I, ParameterPack<Ts...>, IndexSequence<Js...>,
        Qs...> : Ts... {};
template <typename...> struct InheritFromPacks;
template <unsigned... Is, typename... Ps>
struct InheritFromPacks<IndexSequence<Is...>, Ps...>
        : InheritFromUniqueEntries<Is, Ps, IndexSequence<>>... {};
template <typename... Ps>
using MergeAndDeduplicatePacks =
        InheritFromPacks<MakeIndexSequence<sizeof...(Ps)>, ParameterPack<Ps>...>;
template <typename... Ts>
struct Variant
        : MergeAndDeduplicatePacks<VariantConstructors<Ts, Variant<Ts>>...> {
    using MergeAndDeduplicatePacks<
            VariantConstructors<Ts, Variant>...>::MergeAndDeduplicatePacks;
};
Variant<int> get_number_option(int);
template <typename Callback> void for_each_calendar_field(Callback callback) {
    callback(0);
}
void create_date_time_format() {
    for_each_calendar_field(
            [&](auto property) -> void { get_number_option(property); });
}
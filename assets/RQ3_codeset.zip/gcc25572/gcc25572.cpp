int per_cpu__kstat;

int *f()
{
    int *__ptr;
    asm volatile(";%0":"=g"(__ptr):"0"(&per_cpu__kstat));
    return __ptr;
}
double a;
b() {
    long c = (unsigned long)a;
    d(c * 1e6);
}
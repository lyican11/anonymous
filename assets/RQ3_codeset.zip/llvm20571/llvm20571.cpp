int bsr(unsigned v) {
    int ret;
    __asm__("bsr %1, %0" : "=&r"(ret) : "rm"(v) : "cc");
    return ret;
}
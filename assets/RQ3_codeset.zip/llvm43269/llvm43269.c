struct b {
    int c;
    int d;
    int e;
    int ecm;
};
struct f {
    struct b g[1024];
} h(), j;
struct k {
    struct f l;
    void *m[1];
    int n;
};
int o, p;
int q();
void r();
void *s();
int t() {
    int i;
    struct k *a = s();
    if (o)
        goto bad;
    if (a->n)
        q(0, p, 0, h, 0, &j, a->m);
    else
        q(0, p, 0, h, 0, &j, &a->m[i]);
    if (q())
        r();
    if (a->n)
        r(0, p, a->m[0]);
    else
        for (i = 0; i < 1; i++)
            r(0, p, a->m[i]);
    bad:
    return 0;
}
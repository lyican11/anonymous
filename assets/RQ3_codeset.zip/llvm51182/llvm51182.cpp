consteval int f(int) { return 1; }

template
consteval bool g(T a)
{
    int n = f(a); // error here
    return true;
}

static_assert(g(2));


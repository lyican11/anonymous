#include <stdint.h>
#include <string.h>
#include <stdio.h>

#define show(expr) printf("%s: %zu\n", #expr, expr)

struct object {
    int a;
    char buf[7];
    int c;
};

static inline void func_inline(const char *ptr)
{
    puts("func_inline");
    show(__builtin_object_size(ptr, 0));
    show(__builtin_object_size(ptr, 1));
}

void __attribute__ ((noinline)) func(const char *ptr)
{
    puts("func");
    show(__builtin_object_size(ptr, 0));
    show(__builtin_object_size(ptr, 1));
}

int main(void)
{
    struct object instance;

    puts("main");
    show(__builtin_object_size(instance.buf, 0));
    show(__builtin_object_size(instance.buf, 1));

    func_inline(instance.buf);

    func(instance.buf);

    return 0;
}
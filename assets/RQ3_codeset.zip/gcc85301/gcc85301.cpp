struct tick_sched {
#ifdef USE_BITFIELD
    unsigned int tick_stopped : 1;
  unsigned int idle_active : 1;
#else
    int tick_stopped;
    int idle_active;
#endif
};
long ktime_get();
void __tick_nohz_idle_restart_tick(long);
struct tick_sched tick_nohz_idle_exit_ts;
void tick_nohz_idle_exit(void) {
    long now;
    if (tick_nohz_idle_exit_ts.idle_active || tick_nohz_idle_exit_ts.tick_stopped)
        now = ktime_get();
    if (tick_nohz_idle_exit_ts.tick_stopped)
        __tick_nohz_idle_restart_tick(now);
}
typedef __SIZE_TYPE__ size_t;

void *memcpy(void *restrict d, const void *restrict s, size_t n)
{
    const char *s8 = s;
    char *d8 = d;

    while (n--)
        *(d8++) = *(s8++);

    return d;
}

long double __attribute__((noinline)) rem_pio2l_min(long double z)
{
    int i;
    double tx[2];

    for (i = 0; i < 2; ++i) {
        tx[i] = (double)((int)(z));
        z = (z - tx[i]) * 1.6777216e+07;
    }

    return z;
}

int main(void)
{
    const long double test1 = 0x1.b2f3ee96e7600326p+23L;
    const long double check1 = 0x1.93p+16;
    long double res;

    res = rem_pio2l_min(test1);

    return res == check1 ? 0 : 1;
}
#define NSIG_WORDS	1

typedef struct {
	unsigned long sig[NSIG_WORDS];
} sigset_t;

int handle_rt_signal32_bad(sigset_t *);
int handle_rt_signal32_bad(sigset_t *oldset)
{
	switch (NSIG_WORDS) {
	case 4:
		__asm__ goto("" : : "r"(oldset->sig[3] >> 32) : : failed);
		__asm__ goto("" : : "r"(oldset->sig[3]) : : failed);
		__attribute__((fallthrough));
	case 3:
		__asm__ goto("" : : "r"(oldset->sig[2] >> 32) : : failed);
		__asm__ goto("" : : "r"(oldset->sig[2]) : : failed);
		__attribute__((fallthrough));
	case 2:
		__asm__ goto("" : : "r"(oldset->sig[1] >> 32) : : failed);
		__asm__ goto("" : : "r"(oldset->sig[1]) : : failed);
		__attribute__((fallthrough));
	case 1:
		__asm__ goto("" : : "r"(oldset->sig[0] >> 32) : : failed);
		__asm__ goto("" : : "r"(oldset->sig[0]) : : failed);
	}

    return 0;
failed:
    return 1;
}

void normal_array_access(unsigned long);
int handle_rt_signal32_good(sigset_t *);
int handle_rt_signal32_good(sigset_t *oldset)
{
	switch (NSIG_WORDS) {
	case 4:
		normal_array_access(oldset->sig[3] >> 32);
		normal_array_access(oldset->sig[3]);
		__attribute__((fallthrough));
	case 3:
		normal_array_access(oldset->sig[2] >> 32);
		normal_array_access(oldset->sig[2]);
		__attribute__((fallthrough));
	case 2:
		normal_array_access(oldset->sig[1] >> 32);
		normal_array_access(oldset->sig[1]);
		__attribute__((fallthrough));
	case 1:
		normal_array_access(oldset->sig[0] >> 32);
		normal_array_access(oldset->sig[0]);
	}

    return 0;
}

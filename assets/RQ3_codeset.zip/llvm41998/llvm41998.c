#include <stdio.h>

__attribute__((__noinline__)) void parse_pre(const char *dataptr) {
    int col;
    char line[1024];
    char *lineptr;

    for (col = 0, lineptr = line; *dataptr != '\0'; dataptr++) {
        printf("before inner loop: col=%d, diff=%td\n", col, lineptr - line);
        do {
            printf("inside inner loop: col=%d, diff=%td\n", col, lineptr - line);
            *lineptr++ = ' ';
            col++;
        } while (col & 7);
    }
}

int main(void) {
    parse_pre("a");

    return 0;
}
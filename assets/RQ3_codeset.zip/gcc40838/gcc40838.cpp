/*
 * A valid code that crashes when compiled with gcc 4.4.1 and
 * linked with Debian Lenny glibc 2.7
 *
 * Compile with -O3 -march=pentium3
 *
 * GCC assumes that stack frames are aligned on 16 bytes, but for this
 * libc, it isn't true.
 */

#include <stdio.h>
#include <stdlib.h>
#include <obstack.h>

static void *my_alloc(long size)
{
    float array[128];
    int i;
    fprintf(stderr, "pointer: %p\n", array);
    for (i = 0; i < sizeof(array) / sizeof(*array); i++)
        array[i] = 1;
    for (i = 0; i < sizeof(array) / sizeof(*array); i++)
        array[i] *= 2;
    write(1, array, 0); /* prevent the optimizer from throwing it away */
    return malloc(size);
}

static void my_free(void *ptr)
{
    free(ptr);
}

#define obstack_chunk_alloc	my_alloc
#define obstack_chunk_free	my_free

static struct obstack ob;

int main()
{
    obstack_init(&ob);
    return 0;
}
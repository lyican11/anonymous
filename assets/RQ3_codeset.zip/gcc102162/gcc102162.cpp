// hppa-linux-gnu-gcc -O2 -c c.c
// hppa-linux-gnu-objdump -d c.o | vi -

typedef unsigned int u32;

// extern u32  output_len __attribute__((__aligned__(1)));
extern char output_len;


static inline u32 get_unaligned_le32(const void *p)
{
    return ( ({ const struct { u32 x; } __attribute__((__packed__)) *__pptr = (typeof(__pptr))(p); __pptr->x; }));
}

int test(void)
{
    return get_unaligned_le32(&output_len);
}
typedef unsigned long size_t;

#define __cold __attribute__((cold))
#define __noreturn __attribute__((noreturn))
#define __compiletime_error(message) __attribute__((error(message)))

#define I2C_NAME_SIZE 20
struct i2c_board_info {
    char type[I2C_NAME_SIZE];
    char pad[100];
};

#define __constant_argument(arg) (__builtin_constant_p(arg) ? (arg) : 0)

#ifdef NONORETURN
void fortify_panic(const char *name) __cold;
#else
void fortify_panic(const char *name) __noreturn __cold;
#endif

extern size_t __real_strnlen(const char *, size_t) __asm__("strnlen");

static inline size_t strnlen(const char *p, size_t maxlen)
{
    size_t p_size = __builtin_object_size(p, 0);
    size_t ret = __real_strnlen(p, maxlen < p_size ? maxlen : p_size);
    if (p_size <= ret && maxlen != ret)
        fortify_panic(__func__);
    return ret;
}

static inline size_t strlen(const char *p)
{
    size_t ret;
    size_t p_size = __builtin_object_size(p, 0);
    if (p_size == (size_t)-1)
        return __builtin_strlen(p);
    ret = strnlen(p, p_size);
    if (p_size <= ret)
        fortify_panic(__func__);
    return ret;
}

void __write_overflow(void) __compiletime_error("detected write beyond size of object passed as 1st parameter");
extern size_t __real_strlcpy(char *, const char *, size_t) asm("strlcpy");

static inline size_t strlcpy(char *p, const char *q, size_t size)
{
    size_t ret;
    size_t p_size = __builtin_object_size(p, 0);
    size_t q_size = __builtin_object_size(q, 0);
    if (p_size == (size_t)-1 && q_size == (size_t)-1)
        return __real_strlcpy(p, q, size);
    ret = strlen(q);
    if (size) {
        size_t len = (ret >= size) ? size - 1 : ret;
        size_t constlen = __constant_argument(len);
        if (constlen >= p_size)
            __write_overflow();
        if (len >= p_size)
            fortify_panic(__func__);
        __builtin_memcpy(p, q, len);
        p[len] = '\0';
    }
    return ret;
}


void i2c_new_device(struct i2c_board_info *);
int em28xx_dvb_init(void *bus, int model)
{
    switch (model) {
        case 1:{
            struct i2c_board_info info = {};
            strlcpy(info.type, "tda1071", sizeof(info.type));
            i2c_new_device(&info);
            break;
        }
        case 2:{
            struct i2c_board_info info = {};
            strlcpy(info.type, "tda10071", sizeof(info.type));
            i2c_new_device(&info);
            break;
        }
        case 3:{
            struct i2c_board_info info = { };
            strlcpy(info.type, "lgdt3306a", sizeof(info.type));
            i2c_new_device(&info);
            break;
        }
        case 4:{
            struct i2c_board_info info = { };
            strlcpy(info.type, "lgdt3306a", sizeof(info.type));
            i2c_new_device(&info);
            break;
        }
    }
    return 0;
}
# 1 "hoisting.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 31 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 32 "<command-line>" 2
# 1 "hoisting.c"


int a, b;

void foo(void)
{
    if (a) {
        b = 1;
        asm goto ("call 0x0\n\t" : : : : next1);
        next1:;
    } else {
        b = 1;
        asm goto ("call 0x1\n\t" : : : : next2);
        next2:;
    }
}
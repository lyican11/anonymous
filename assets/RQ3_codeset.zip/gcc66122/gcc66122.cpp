# 1 "kernel/locking/mutex.c"
# 1 "<command-line>"
# 1 "././include/linux/kconfig.h" 1



# 1 "include/generated/autoconf.h" 1
# 5 "././include/linux/kconfig.h" 2
# 1 "<command-line>" 2
# 1 "kernel/locking/mutex.c"
# 20 "kernel/locking/mutex.c"
# 1 "include/linux/mutex.h" 1
# 13 "include/linux/mutex.h"
# 1 "./arch/x86/include/asm/current.h" 1



# 1 "include/linux/compiler.h" 1
# 54 "include/linux/compiler.h"
# 1 "include/linux/compiler-gcc.h" 1
# 121 "include/linux/compiler-gcc.h"
# 1 "include/linux/compiler-gcc4.h" 1
# 122 "include/linux/compiler-gcc.h" 2
# 55 "include/linux/compiler.h" 2
# 83 "include/linux/compiler.h"
struct ftrace_branch_data {
    const char *func;
    const char *file;
    unsigned line;
    union {
        struct {
            unsigned long correct;
            unsigned long incorrect;
        };
        struct {
            unsigned long miss;
            unsigned long hit;
        };
        unsigned long miss_hit[2];
    };
};
# 197 "include/linux/compiler.h"
# 1 "include/uapi/linux/types.h" 1



# 1 "./arch/x86/include/uapi/asm/types.h" 1



# 1 "./include/uapi/asm-generic/types.h" 1





# 1 "include/asm-generic/int-ll64.h" 1
# 10 "include/asm-generic/int-ll64.h"
# 1 "include/uapi/asm-generic/int-ll64.h" 1
# 11 "include/uapi/asm-generic/int-ll64.h"
# 1 "./arch/x86/include/uapi/asm/bitsperlong.h" 1
# 10 "./arch/x86/include/uapi/asm/bitsperlong.h"
# 1 "include/asm-generic/bitsperlong.h" 1



# 1 "include/uapi/asm-generic/bitsperlong.h" 1
# 5 "include/asm-generic/bitsperlong.h" 2
# 11 "./arch/x86/include/uapi/asm/bitsperlong.h" 2
# 12 "include/uapi/asm-generic/int-ll64.h" 2







typedef __signed__ char __s8;
typedef unsigned char __u8;

typedef __signed__ short __s16;
typedef unsigned short __u16;

typedef __signed__ int __s32;
typedef unsigned int __u32;


__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
# 11 "include/asm-generic/int-ll64.h" 2




typedef signed char s8;
typedef unsigned char u8;

typedef signed short s16;
typedef unsigned short u16;

typedef signed int s32;
typedef unsigned int u32;

typedef signed long long s64;
typedef unsigned long long u64;
# 7 "./include/uapi/asm-generic/types.h" 2
# 5 "./arch/x86/include/uapi/asm/types.h" 2
# 5 "include/uapi/linux/types.h" 2
# 13 "include/uapi/linux/types.h"
# 1 "./include/uapi/linux/posix_types.h" 1



# 1 "include/linux/stddef.h" 1



# 1 "include/uapi/linux/stddef.h" 1
# 1 "include/linux/compiler.h" 1
# 1 "include/uapi/linux/stddef.h" 2
# 5 "include/linux/stddef.h" 2





enum {
    false = 0,
    true = 1
};
# 5 "./include/uapi/linux/posix_types.h" 2
# 24 "./include/uapi/linux/posix_types.h"
typedef struct {
    unsigned long fds_bits[1024 / (8 * sizeof(long))];
} __kernel_fd_set;


typedef void (*__kernel_sighandler_t)(int);


typedef int __kernel_key_t;
typedef int __kernel_mqd_t;

# 1 "./arch/x86/include/asm/posix_types.h" 1



# 1 "./arch/x86/include/uapi/asm/posix_types_64.h" 1
# 10 "./arch/x86/include/uapi/asm/posix_types_64.h"
typedef unsigned short __kernel_old_uid_t;
typedef unsigned short __kernel_old_gid_t;


typedef unsigned long __kernel_old_dev_t;


# 1 "./include/uapi/asm-generic/posix_types.h" 1
# 14 "./include/uapi/asm-generic/posix_types.h"
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;



typedef __kernel_ulong_t __kernel_ino_t;



typedef unsigned int __kernel_mode_t;



typedef int __kernel_pid_t;



typedef int __kernel_ipc_pid_t;



typedef unsigned int __kernel_uid_t;
typedef unsigned int __kernel_gid_t;



typedef __kernel_long_t __kernel_suseconds_t;



typedef int __kernel_daddr_t;



typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
# 71 "./include/uapi/asm-generic/posix_types.h"
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_ptrdiff_t;




typedef struct {
    int val[2];
} __kernel_fsid_t;





typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef __kernel_long_t __kernel_time_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef char * __kernel_caddr_t;
typedef unsigned short __kernel_uid16_t;
typedef unsigned short __kernel_gid16_t;
# 18 "./arch/x86/include/uapi/asm/posix_types_64.h" 2
# 5 "./arch/x86/include/asm/posix_types.h" 2
# 36 "./include/uapi/linux/posix_types.h" 2
# 14 "include/uapi/linux/types.h" 2
# 32 "include/uapi/linux/types.h"
typedef __u16 __le16;
typedef __u16 __be16;
typedef __u32 __le32;
typedef __u32 __be32;
typedef __u64 __le64;
typedef __u64 __be64;

typedef __u16 __sum16;
typedef __u32 __wsum;
# 198 "include/linux/compiler.h" 2

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void __read_once_size(const volatile void *p, void *res, int size)
{
    switch (size) {
        case 1: *(__u8 *)res = *(volatile __u8 *)p; break;
        case 2: *(__u16 *)res = *(volatile __u16 *)p; break;
        case 4: *(__u32 *)res = *(volatile __u32 *)p; break;
        case 8: *(__u64 *)res = *(volatile __u64 *)p; break;
        default:
            __asm__ __volatile__("": : :"memory");
            __builtin_memcpy((void *)res, (const void *)p, size);
            __asm__ __volatile__("": : :"memory");
    }
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void __write_once_size(volatile void *p, void *res, int size)
{
    switch (size) {
        case 1: *(volatile __u8 *)p = *(__u8 *)res; break;
        case 2: *(volatile __u16 *)p = *(__u16 *)res; break;
        case 4: *(volatile __u32 *)p = *(__u32 *)res; break;
        case 8: *(volatile __u64 *)p = *(__u64 *)res; break;
        default:
            __asm__ __volatile__("": : :"memory");
            __builtin_memcpy((void *)p, (const void *)res, size);
            __asm__ __volatile__("": : :"memory");
    }
}
# 5 "./arch/x86/include/asm/current.h" 2
# 1 "./arch/x86/include/asm/percpu.h" 1
# 44 "./arch/x86/include/asm/percpu.h"
# 1 "include/linux/kernel.h" 1




# 1 "/usr/lib/gcc/x86_64-redhat-linux/4.7.2/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/x86_64-redhat-linux/4.7.2/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 102 "/usr/lib/gcc/x86_64-redhat-linux/4.7.2/include/stdarg.h" 3 4
typedef __gnuc_va_list va_list;
# 6 "include/linux/kernel.h" 2
# 1 "include/linux/linkage.h" 1




# 1 "include/linux/stringify.h" 1
# 6 "include/linux/linkage.h" 2
# 1 "include/linux/export.h" 1
# 26 "include/linux/export.h"
struct kernel_symbol
{
    unsigned long value;
    const char *name;
};
# 7 "include/linux/linkage.h" 2
# 1 "./arch/x86/include/asm/linkage.h" 1
# 8 "include/linux/linkage.h" 2
# 7 "include/linux/kernel.h" 2
# 1 "include/linux/stddef.h" 1
# 8 "include/linux/kernel.h" 2
# 1 "include/linux/types.h" 1
# 12 "include/linux/types.h"
typedef __u32 __kernel_dev_t;

typedef __kernel_fd_set fd_set;
typedef __kernel_dev_t dev_t;
typedef __kernel_ino_t ino_t;
typedef __kernel_mode_t mode_t;
typedef unsigned short umode_t;
typedef __u32 nlink_t;
typedef __kernel_off_t off_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_daddr_t daddr_t;
typedef __kernel_key_t key_t;
typedef __kernel_suseconds_t suseconds_t;
typedef __kernel_timer_t timer_t;
typedef __kernel_clockid_t clockid_t;
typedef __kernel_mqd_t mqd_t;

typedef _Bool bool;

typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_uid16_t uid16_t;
typedef __kernel_gid16_t gid16_t;

typedef unsigned long uintptr_t;



typedef __kernel_old_uid_t old_uid_t;
typedef __kernel_old_gid_t old_gid_t;



typedef __kernel_loff_t loff_t;
# 54 "include/linux/types.h"
typedef __kernel_size_t size_t;




typedef __kernel_ssize_t ssize_t;




typedef __kernel_ptrdiff_t ptrdiff_t;




typedef __kernel_time_t time_t;




typedef __kernel_clock_t clock_t;




typedef __kernel_caddr_t caddr_t;



typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;


typedef unsigned char unchar;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long ulong;




typedef __u8 u_int8_t;
typedef __s8 int8_t;
typedef __u16 u_int16_t;
typedef __s16 int16_t;
typedef __u32 u_int32_t;
typedef __s32 int32_t;



typedef __u8 uint8_t;
typedef __u16 uint16_t;
typedef __u32 uint32_t;


typedef __u64 uint64_t;
typedef __u64 u_int64_t;
typedef __s64 int64_t;
# 133 "include/linux/types.h"
typedef unsigned long sector_t;
typedef unsigned long blkcnt_t;
# 144 "include/linux/types.h"
typedef u64 dma_addr_t;




typedef unsigned gfp_t;
typedef unsigned fmode_t;
typedef unsigned oom_flags_t;


typedef u64 phys_addr_t;




typedef phys_addr_t resource_size_t;





typedef unsigned long irq_hw_number_t;

typedef struct {
    int counter;
} atomic_t;


typedef struct {
    long counter;
} atomic64_t;


struct list_head {
    struct list_head *next, *prev;
};

struct hlist_head {
    struct hlist_node *first;
};

struct hlist_node {
    struct hlist_node *next, **pprev;
};

struct ustat {
    __kernel_daddr_t f_tfree;
    __kernel_ino_t f_tinode;
    char f_fname[6];
    char f_fpack[6];
};






struct callback_head {
    struct callback_head *next;
    void (*func)(struct callback_head *head);
};



typedef u64 cycle_t;
# 9 "include/linux/kernel.h" 2

# 1 "include/linux/bitops.h" 1
# 27 "include/linux/bitops.h"
extern unsigned int __sw_hweight8(unsigned int w);
extern unsigned int __sw_hweight16(unsigned int w);
extern unsigned int __sw_hweight32(unsigned int w);
extern unsigned long __sw_hweight64(__u64 w);





# 1 "./arch/x86/include/asm/bitops.h" 1
# 16 "./arch/x86/include/asm/bitops.h"
# 1 "./arch/x86/include/asm/alternative.h" 1




# 1 "include/linux/stddef.h" 1
# 6 "./arch/x86/include/asm/alternative.h" 2

# 1 "./arch/x86/include/asm/asm.h" 1
# 8 "./arch/x86/include/asm/alternative.h" 2
# 1 "./arch/x86/include/asm/ptrace.h" 1



# 1 "./arch/x86/include/asm/segment.h" 1



# 1 "./include/uapi/linux/const.h" 1
# 5 "./arch/x86/include/asm/segment.h" 2
# 155 "./arch/x86/include/asm/segment.h"
# 1 "./arch/x86/include/asm/cache.h" 1
# 156 "./arch/x86/include/asm/segment.h" 2
# 236 "./arch/x86/include/asm/segment.h"
extern const char early_idt_handlers[32][2+2+5];
# 5 "./arch/x86/include/asm/ptrace.h" 2
# 1 "./arch/x86/include/asm/page_types.h" 1
# 42 "./arch/x86/include/asm/page_types.h"
# 1 "./arch/x86/include/asm/page_64_types.h" 1
# 43 "./arch/x86/include/asm/page_types.h" 2
# 51 "./arch/x86/include/asm/page_types.h"
extern int devmem_is_allowed(unsigned long pagenr);

extern unsigned long max_low_pfn_mapped;
extern unsigned long max_pfn_mapped;

static inline __attribute__((no_instrument_function)) phys_addr_t get_max_mapped(void)
{
    return (phys_addr_t)max_pfn_mapped << 12;
}

bool pfn_range_is_mapped(unsigned long start_pfn, unsigned long end_pfn);

extern unsigned long init_memory_mapping(unsigned long start,
                                         unsigned long end);

extern void initmem_init(void);
# 6 "./arch/x86/include/asm/ptrace.h" 2
# 1 "./arch/x86/include/uapi/asm/ptrace.h" 1




# 1 "./arch/x86/include/uapi/asm/ptrace-abi.h" 1
# 6 "./arch/x86/include/uapi/asm/ptrace.h" 2
# 1 "./arch/x86/include/asm/processor-flags.h" 1



# 1 "./arch/x86/include/uapi/asm/processor-flags.h" 1
# 5 "./arch/x86/include/asm/processor-flags.h" 2
# 7 "./arch/x86/include/uapi/asm/ptrace.h" 2
# 7 "./arch/x86/include/asm/ptrace.h" 2
# 33 "./arch/x86/include/asm/ptrace.h"
struct pt_regs {




    unsigned long r15;
    unsigned long r14;
    unsigned long r13;
    unsigned long r12;
    unsigned long bp;
    unsigned long bx;

    unsigned long r11;
    unsigned long r10;
    unsigned long r9;
    unsigned long r8;
    unsigned long ax;
    unsigned long cx;
    unsigned long dx;
    unsigned long si;
    unsigned long di;




    unsigned long orig_ax;

    unsigned long ip;
    unsigned long cs;
    unsigned long flags;
    unsigned long sp;
    unsigned long ss;

};







struct cpuinfo_x86;
struct task_struct;

extern unsigned long profile_pc(struct pt_regs *regs);


extern unsigned long
convert_ip_to_linear(struct task_struct *child, struct pt_regs *regs);
extern void send_sigtrap(struct task_struct *tsk, struct pt_regs *regs,
                         int error_code, int si_code);


extern unsigned long syscall_trace_enter_phase1(struct pt_regs *, u32 arch);
extern long syscall_trace_enter_phase2(struct pt_regs *, u32 arch,
                                       unsigned long phase1_result);

extern long syscall_trace_enter(struct pt_regs *);
extern void syscall_trace_leave(struct pt_regs *);

static inline __attribute__((no_instrument_function)) unsigned long regs_return_value(struct pt_regs *regs)
{
    return regs->ax;
}
# 107 "./arch/x86/include/asm/ptrace.h"
static inline __attribute__((no_instrument_function)) int user_mode(struct pt_regs *regs)
{



    return !!(regs->cs & 3);

}

static inline __attribute__((no_instrument_function)) int v8086_mode(struct pt_regs *regs)
{



    return 0;

}


static inline __attribute__((no_instrument_function)) bool user_64bit_mode(struct pt_regs *regs)
{





    return regs->cs == (6*8 + 3);




}
# 147 "./arch/x86/include/asm/ptrace.h"
static inline __attribute__((no_instrument_function)) unsigned long kernel_stack_pointer(struct pt_regs *regs)
{
    return regs->sp;
}






# 1 "include/asm-generic/ptrace.h" 1
# 22 "include/asm-generic/ptrace.h"
static inline __attribute__((no_instrument_function)) unsigned long instruction_pointer(struct pt_regs *regs)
{
    return ((regs)->ip);
}
static inline __attribute__((no_instrument_function)) void instruction_pointer_set(struct pt_regs *regs,
                                                                                   unsigned long val)
{
    (((regs)->ip) = (val));
}
# 44 "include/asm-generic/ptrace.h"
static inline __attribute__((no_instrument_function)) unsigned long user_stack_pointer(struct pt_regs *regs)
{
    return ((regs)->sp);
}
static inline __attribute__((no_instrument_function)) void user_stack_pointer_set(struct pt_regs *regs,
                                                                                  unsigned long val)
{
    (((regs)->sp) = (val));
}
# 62 "include/asm-generic/ptrace.h"
static inline __attribute__((no_instrument_function)) unsigned long frame_pointer(struct pt_regs *regs)
{
    return ((regs)->bp);
}
static inline __attribute__((no_instrument_function)) void frame_pointer_set(struct pt_regs *regs,
                                                                             unsigned long val)
{
    (((regs)->bp) = (val));
}
# 158 "./arch/x86/include/asm/ptrace.h" 2


extern int regs_query_register_offset(const char *name);
extern const char *regs_query_register_name(unsigned int offset);
# 173 "./arch/x86/include/asm/ptrace.h"
static inline __attribute__((no_instrument_function)) unsigned long regs_get_register(struct pt_regs *regs,
                                                                                      unsigned int offset)
{
    if (__builtin_expect(!!(offset > (__builtin_offsetof(struct pt_regs,ss))), 0))
    return 0;
# 187 "./arch/x86/include/asm/ptrace.h"
    return *(unsigned long *)((unsigned long)regs + offset);
}
# 198 "./arch/x86/include/asm/ptrace.h"
static inline __attribute__((no_instrument_function)) int regs_within_kernel_stack(struct pt_regs *regs,
                                                                                   unsigned long addr)
{
    return ((addr & ~((((1UL) << 12) << (2 + 0)) - 1)) ==
            (kernel_stack_pointer(regs) & ~((((1UL) << 12) << (2 + 0)) - 1)));
}
# 214 "./arch/x86/include/asm/ptrace.h"
static inline __attribute__((no_instrument_function)) unsigned long regs_get_kernel_stack_nth(struct pt_regs *regs,
                                                                                              unsigned int n)
{
    unsigned long *addr = (unsigned long *)kernel_stack_pointer(regs);
    addr += n;
    if (regs_within_kernel_stack(regs, (unsigned long)addr))
        return *addr;
    else
        return 0;
}
# 250 "./arch/x86/include/asm/ptrace.h"
struct user_desc;
extern int do_get_thread_area(struct task_struct *p, int idx,
                              struct user_desc *info);
extern int do_set_thread_area(struct task_struct *p, int idx,
                              struct user_desc *info, int can_allocate);
# 9 "./arch/x86/include/asm/alternative.h" 2
# 46 "./arch/x86/include/asm/alternative.h"
struct alt_instr {
    s32 instr_offset;
    s32 repl_offset;
    u16 cpuid;
    u8 instrlen;
    u8 replacementlen;
    u8 padlen;
} __attribute__((packed));

extern void alternative_instructions(void);
extern void apply_alternatives(struct alt_instr *start, struct alt_instr *end);

struct module;


extern void alternatives_smp_module_add(struct module *mod, char *name,
                                        void *locks, void *locks_end,
                                        void *text, void *text_end);
extern void alternatives_smp_module_del(struct module *mod);
extern void alternatives_enable_smp(void);
extern int alternatives_text_reserved(void *start, void *end);
extern bool skip_smp_alternatives;
# 152 "./arch/x86/include/asm/alternative.h"
# 1 "./arch/x86/include/asm/cpufeature.h" 1







# 1 "./arch/x86/include/asm/required-features.h" 1
# 9 "./arch/x86/include/asm/cpufeature.h" 2



# 1 "./arch/x86/include/asm/disabled-features.h" 1
# 13 "./arch/x86/include/asm/cpufeature.h" 2
# 273 "./arch/x86/include/asm/cpufeature.h"
# 1 "include/linux/bitops.h" 1
# 274 "./arch/x86/include/asm/cpufeature.h" 2


extern const char * const x86_cap_flags[13*32];
extern const char * const x86_power_flags[32];
# 289 "./arch/x86/include/asm/cpufeature.h"
extern const char * const x86_bug_flags[1*32];
# 406 "./arch/x86/include/asm/cpufeature.h"
extern void warn_pre_alternatives(void);
extern bool __static_cpu_has_safe(u16 bit);






static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) __attribute__((pure)) bool __static_cpu_has(u16 bit)
{
# 439 "./arch/x86/include/asm/cpufeature.h"
    do { asm goto("1: jmp %l[t_no]\n" "2:\n" ".section .altinstructions,\"a\"\n" " .long 1b - .\n" " .long 0\n" " .word %P0\n" " .byte 2b - 1b\n" " .byte 0\n" " .byte 0\n" ".previous\n" : : "i" (bit) : : t_no); asm (""); } while (0)
# 450 "./arch/x86/include/asm/cpufeature.h"
            ;
    return true;
    t_no:
    return false;
# 486 "./arch/x86/include/asm/cpufeature.h"
}
# 497 "./arch/x86/include/asm/cpufeature.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) __attribute__((pure)) bool _static_cpu_has_safe(u16 bit)
{

    do { asm goto("1: jmp %l[t_dynamic]\n" "2:\n" ".skip -(((5f-4f) - (2b-1b)) > 0) * " "((5f-4f) - (2b-1b)),0x90\n" "3:\n" ".section .altinstructions,\"a\"\n" " .long 1b - .\n" " .long 4f - .\n" " .word %P1\n" " .byte 3b - 1b\n" " .byte 5f - 4f\n" " .byte 3b - 2b\n" ".previous\n" ".section .altinstr_replacement,\"ax\"\n" "4: jmp %l[t_no]\n" "5:\n" ".previous\n" ".section .altinstructions,\"a\"\n" " .long 1b - .\n" " .long 0\n" " .word %P0\n" " .byte 3b - 1b\n" " .byte 0\n" " .byte 0\n" ".previous\n" : : "i" (bit), "i" (( 3*32+21)) : : t_dynamic, t_no); asm (""); } while (0)
# 526 "./arch/x86/include/asm/cpufeature.h"
            ;
    return true;
    t_no:
    return false;
    t_dynamic:
    return __static_cpu_has_safe(bit);
# 571 "./arch/x86/include/asm/cpufeature.h"
}
# 153 "./arch/x86/include/asm/alternative.h" 2
# 236 "./arch/x86/include/asm/alternative.h"
struct paravirt_patch_site;




static inline __attribute__((no_instrument_function)) void apply_paravirt(struct paravirt_patch_site *start,
                                                                          struct paravirt_patch_site *end)
{}




extern void *text_poke_early(void *addr, const void *opcode, size_t len);
# 264 "./arch/x86/include/asm/alternative.h"
extern void *text_poke(void *addr, const void *opcode, size_t len);
extern int poke_int3_handler(struct pt_regs *regs);
extern void *text_poke_bp(void *addr, const void *opcode, size_t len, void *handler);
# 17 "./arch/x86/include/asm/bitops.h" 2
# 1 "./arch/x86/include/asm/rmwcc.h" 1
# 18 "./arch/x86/include/asm/bitops.h" 2
# 1 "./arch/x86/include/asm/barrier.h" 1




# 1 "./arch/x86/include/asm/nops.h" 1
# 142 "./arch/x86/include/asm/nops.h"
extern const unsigned char * const *ideal_nops;
extern void arch_init_ideal_nops(void);
# 6 "./arch/x86/include/asm/barrier.h" 2
# 99 "./arch/x86/include/asm/barrier.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void rdtsc_barrier(void)
{
    asm volatile("661:\n\t" "" "\n662:\n" ".skip -((" "((" "665""1""f-""664""1""f" ") ^ (((" "665""1""f-""664""1""f" ") ^ (" "665""2""f-""664""2""f" ")) & -(-((" "665""1""f-""664""1""f" ") - (" "665""2""f-""664""2""f" ")))))" " - (" "662b-661b" ")) > 0) * " "(" "((" "665""1""f-""664""1""f" ") ^ (((" "665""1""f-""664""1""f" ") ^ (" "665""2""f-""664""2""f" ")) & -(-((" "665""1""f-""664""1""f" ") - (" "665""2""f-""664""2""f" ")))))" " - (" "662b-661b" ")), 0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 3*32+17)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" " .long 661b - .\n" " .long " "664""2""f - .\n" " .word " "( 3*32+18)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""2""f-""664""2""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" "mfence" "\n" "665""1" ":\n\t" "664""2"":\n\t" "lfence" "\n" "665""2" ":\n\t" ".popsection" ::: "memory")
            ;
}
# 19 "./arch/x86/include/asm/bitops.h" 2
# 71 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void
set_bit(long nr, volatile unsigned long *addr)
{
    if ((__builtin_constant_p(nr))) {
        asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "orb %1,%0"
                : "+m" (*(volatile long *) ((void *)(addr) + ((nr)>>3)))
                : "iq" ((u8)(1 << ((nr) & 7)))
                : "memory");
    } else {
        asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "bts %1,%0"
                : "+m" (*(volatile long *) (addr)) : "Ir" (nr) : "memory");
    }
}
# 94 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) void __set_bit(long nr, volatile unsigned long *addr)
{
    asm volatile("bts %1,%0" : "+m" (*(volatile long *) (addr)) : "Ir" (nr) : "memory");
}
# 109 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void
clear_bit(long nr, volatile unsigned long *addr)
{
    if ((__builtin_constant_p(nr))) {
        asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "andb %1,%0"
                : "+m" (*(volatile long *) ((void *)(addr) + ((nr)>>3)))
                : "iq" ((u8)~(1 << ((nr) & 7))));
    } else {
        asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "btr %1,%0"
                : "+m" (*(volatile long *) (addr))
                : "Ir" (nr));
    }
}
# 131 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) void clear_bit_unlock(long nr, volatile unsigned long *addr)
{
    __asm__ __volatile__("": : :"memory");
    clear_bit(nr, addr);
}

static inline __attribute__((no_instrument_function)) void __clear_bit(long nr, volatile unsigned long *addr)
{
    asm volatile("btr %1,%0" : "+m" (*(volatile long *) (addr)) : "Ir" (nr));
}
# 154 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) void __clear_bit_unlock(long nr, volatile unsigned long *addr)
{
    __asm__ __volatile__("": : :"memory");
    __clear_bit(nr, addr);
}
# 169 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) void __change_bit(long nr, volatile unsigned long *addr)
{
    asm volatile("btc %1,%0" : "+m" (*(volatile long *) (addr)) : "Ir" (nr));
}
# 183 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) void change_bit(long nr, volatile unsigned long *addr)
{
    if ((__builtin_constant_p(nr))) {
        asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xorb %1,%0"
                : "+m" (*(volatile long *) ((void *)(addr) + ((nr)>>3)))
                : "iq" ((u8)(1 << ((nr) & 7))));
    } else {
        asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "btc %1,%0"
                : "+m" (*(volatile long *) (addr))
                : "Ir" (nr));
    }
}
# 204 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) int test_and_set_bit(long nr, volatile unsigned long *addr)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "bts" " %1, " "%0" "; j" "c" " %l[cc_label]" : : "m" (*addr), "Ir" (nr) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 216 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) int
test_and_set_bit_lock(long nr, volatile unsigned long *addr)
{
    return test_and_set_bit(nr, addr);
}
# 231 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) int __test_and_set_bit(long nr, volatile unsigned long *addr)
{
    int oldbit;

    asm("bts %2,%1\n\t"
        "sbb %0,%0"
            : "=r" (oldbit), "+m" (*(volatile long *) (addr))
            : "Ir" (nr));
    return oldbit;
}
# 250 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) int test_and_clear_bit(long nr, volatile unsigned long *addr)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "btr" " %1, " "%0" "; j" "c" " %l[cc_label]" : : "m" (*addr), "Ir" (nr) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 271 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) int __test_and_clear_bit(long nr, volatile unsigned long *addr)
{
    int oldbit;

    asm volatile("btr %2,%1\n\t"
                 "sbb %0,%0"
            : "=r" (oldbit), "+m" (*(volatile long *) (addr))
            : "Ir" (nr));
    return oldbit;
}


static inline __attribute__((no_instrument_function)) int __test_and_change_bit(long nr, volatile unsigned long *addr)
{
    int oldbit;

    asm volatile("btc %2,%1\n\t"
                 "sbb %0,%0"
            : "=r" (oldbit), "+m" (*(volatile long *) (addr))
            : "Ir" (nr) : "memory");

    return oldbit;
}
# 303 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) int test_and_change_bit(long nr, volatile unsigned long *addr)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "btc" " %1, " "%0" "; j" "c" " %l[cc_label]" : : "m" (*addr), "Ir" (nr) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) int constant_test_bit(long nr, const volatile unsigned long *addr)
{
    return ((1UL << (nr & (64 -1))) &
            (addr[nr >> 6])) != 0;
}

static inline __attribute__((no_instrument_function)) int variable_test_bit(long nr, volatile const unsigned long *addr)
{
    int oldbit;

    asm volatile("bt %2,%1\n\t"
                 "sbb %0,%0"
            : "=r" (oldbit)
            : "m" (*(unsigned long *)addr), "Ir" (nr));

    return oldbit;
}
# 346 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) unsigned long __ffs(unsigned long word)
{
    asm("rep; bsf %1,%0"
            : "=r" (word)
            : "rm" (word));
    return word;
}







static inline __attribute__((no_instrument_function)) unsigned long ffz(unsigned long word)
{
    asm("rep; bsf %1,%0"
            : "=r" (word)
            : "r" (~word));
    return word;
}







static inline __attribute__((no_instrument_function)) unsigned long __fls(unsigned long word)
{
    asm("bsr %1,%0"
            : "=r" (word)
            : "rm" (word));
    return word;
}
# 396 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) int ffs(int x)
{
    int r;
# 410 "./arch/x86/include/asm/bitops.h"
    asm("bsfl %1,%0"
            : "=r" (r)
            : "rm" (x), "0" (-1));
# 423 "./arch/x86/include/asm/bitops.h"
    return r + 1;
}
# 437 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) int fls(int x)
{
    int r;
# 451 "./arch/x86/include/asm/bitops.h"
    asm("bsrl %1,%0"
            : "=r" (r)
            : "rm" (x), "0" (-1));
# 464 "./arch/x86/include/asm/bitops.h"
    return r + 1;
}
# 479 "./arch/x86/include/asm/bitops.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) int fls64(__u64 x)
{
int bitpos = -1;





asm("bsrq %1,%q0"
        : "+r" (bitpos)
        : "rm" (x));
return bitpos + 1;
}




# 1 "include/asm-generic/bitops/find.h" 1
# 14 "include/asm-generic/bitops/find.h"
extern unsigned long find_next_bit(const unsigned long *addr, unsigned long
size, unsigned long offset);
# 28 "include/asm-generic/bitops/find.h"
extern unsigned long find_next_zero_bit(const unsigned long *addr, unsigned
long size, unsigned long offset);
# 42 "include/asm-generic/bitops/find.h"
extern unsigned long find_first_bit(const unsigned long *addr,
                                    unsigned long size);
# 53 "include/asm-generic/bitops/find.h"
extern unsigned long find_first_zero_bit(const unsigned long *addr,
                                         unsigned long size);
# 497 "./arch/x86/include/asm/bitops.h" 2

# 1 "include/asm-generic/bitops/sched.h" 1
# 12 "include/asm-generic/bitops/sched.h"
static inline __attribute__((no_instrument_function)) int sched_find_first_bit(const unsigned long *b)
{

    if (b[0])
        return __ffs(b[0]);
    return __ffs(b[1]) + 64;
# 29 "include/asm-generic/bitops/sched.h"
}
# 499 "./arch/x86/include/asm/bitops.h" 2

# 1 "./arch/x86/include/asm/arch_hweight.h" 1
# 24 "./arch/x86/include/asm/arch_hweight.h"
static inline __attribute__((no_instrument_function)) unsigned int __arch_hweight32(unsigned int w)
{
    unsigned int res = 0;

    asm ("661:\n\t" "call __sw_hweight32" "\n662:\n" ".skip -(((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")) > 0) * " "((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")),0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 4*32+23)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" ".byte 0xf3,0x40,0x0f,0xb8,0xc7" "\n" "665""1" ":\n\t" ".popsection"
            : "=""a" (res)
    : "D" (w));

    return res;
}

static inline __attribute__((no_instrument_function)) unsigned int __arch_hweight16(unsigned int w)
{
    return __arch_hweight32(w & 0xffff);
}

static inline __attribute__((no_instrument_function)) unsigned int __arch_hweight8(unsigned int w)
{
    return __arch_hweight32(w & 0xff);
}

static inline __attribute__((no_instrument_function)) unsigned long __arch_hweight64(__u64 w)
{
unsigned long res = 0;





asm ("661:\n\t" "call __sw_hweight64" "\n662:\n" ".skip -(((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")) > 0) * " "((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")),0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 4*32+23)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" ".byte 0xf3,0x48,0x0f,0xb8,0xc7" "\n" "665""1" ":\n\t" ".popsection"
        : "=""a" (res)
: "D" (w));


return res;
}
# 501 "./arch/x86/include/asm/bitops.h" 2

# 1 "include/asm-generic/bitops/const_hweight.h" 1
# 503 "./arch/x86/include/asm/bitops.h" 2

# 1 "include/asm-generic/bitops/le.h" 1




# 1 "./arch/x86/include/uapi/asm/byteorder.h" 1



# 1 "include/linux/byteorder/little_endian.h" 1



# 1 "include/uapi/linux/byteorder/little_endian.h" 1
# 12 "include/uapi/linux/byteorder/little_endian.h"
# 1 "include/linux/swab.h" 1



# 1 "include/uapi/linux/swab.h" 1





# 1 "./arch/x86/include/uapi/asm/swab.h" 1






static inline __attribute__((no_instrument_function)) __attribute__((__const__)) __u32 __arch_swab32(__u32 val)
{
    asm("bswapl %0" : "=r" (val) : "0" (val));
    return val;
}


static inline __attribute__((no_instrument_function)) __attribute__((__const__)) __u64 __arch_swab64(__u64 val)
{
# 30 "./arch/x86/include/uapi/asm/swab.h"
asm("bswapq %0" : "=r" (val) : "0" (val));
return val;

}
# 7 "include/uapi/linux/swab.h" 2
# 46 "include/uapi/linux/swab.h"
static inline __attribute__((no_instrument_function)) __attribute__((__const__)) __u16 __fswab16(__u16 val)
{





    return ((__u16)( (((__u16)(val) & (__u16)0x00ffU) << 8) | (((__u16)(val) & (__u16)0xff00U) >> 8)));

}

static inline __attribute__((no_instrument_function)) __attribute__((__const__)) __u32 __fswab32(__u32 val)
{

    return __builtin_bswap32(val);





}

static inline __attribute__((no_instrument_function)) __attribute__((__const__)) __u64 __fswab64(__u64 val)
{

return __builtin_bswap64(val);
# 81 "include/uapi/linux/swab.h"
}

static inline __attribute__((no_instrument_function)) __attribute__((__const__)) __u32 __fswahw32(__u32 val)
{



    return ((__u32)( (((__u32)(val) & (__u32)0x0000ffffUL) << 16) | (((__u32)(val) & (__u32)0xffff0000UL) >> 16)));

}

static inline __attribute__((no_instrument_function)) __attribute__((__const__)) __u32 __fswahb32(__u32 val)
{



    return ((__u32)( (((__u32)(val) & (__u32)0x00ff00ffUL) << 8) | (((__u32)(val) & (__u32)0xff00ff00UL) >> 8)));

}
# 154 "include/uapi/linux/swab.h"
static inline __attribute__((no_instrument_function)) __u16 __swab16p(const __u16 *p)
{



    return (__builtin_constant_p((__u16)(*p)) ? ((__u16)( (((__u16)(*p) & (__u16)0x00ffU) << 8) | (((__u16)(*p) & (__u16)0xff00U) >> 8))) : __fswab16(*p));

}





static inline __attribute__((no_instrument_function)) __u32 __swab32p(const __u32 *p)
{



    return (__builtin_constant_p((__u32)(*p)) ? ((__u32)( (((__u32)(*p) & (__u32)0x000000ffUL) << 24) | (((__u32)(*p) & (__u32)0x0000ff00UL) << 8) | (((__u32)(*p) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(*p) & (__u32)0xff000000UL) >> 24))) : __fswab32(*p));

}





static inline __attribute__((no_instrument_function)) __u64 __swab64p(const __u64 *p)
{



    return (__builtin_constant_p((__u64)(*p)) ? ((__u64)( (((__u64)(*p) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(*p) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(*p) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(*p) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(*p) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(*p) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(*p) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(*p) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(*p));

}







static inline __attribute__((no_instrument_function)) __u32 __swahw32p(const __u32 *p)
{



    return (__builtin_constant_p((__u32)(*p)) ? ((__u32)( (((__u32)(*p) & (__u32)0x0000ffffUL) << 16) | (((__u32)(*p) & (__u32)0xffff0000UL) >> 16))) : __fswahw32(*p));

}







static inline __attribute__((no_instrument_function)) __u32 __swahb32p(const __u32 *p)
{



    return (__builtin_constant_p((__u32)(*p)) ? ((__u32)( (((__u32)(*p) & (__u32)0x00ff00ffUL) << 8) | (((__u32)(*p) & (__u32)0xff00ff00UL) >> 8))) : __fswahb32(*p));

}





static inline __attribute__((no_instrument_function)) void __swab16s(__u16 *p)
{



    *p = __swab16p(p);

}




static inline __attribute__((no_instrument_function)) void __swab32s(__u32 *p)
{



    *p = __swab32p(p);

}





static inline __attribute__((no_instrument_function)) void __swab64s(__u64 *p)
{



    *p = __swab64p(p);

}







static inline __attribute__((no_instrument_function)) void __swahw32s(__u32 *p)
{



    *p = __swahw32p(p);

}







static inline __attribute__((no_instrument_function)) void __swahb32s(__u32 *p)
{



    *p = __swahb32p(p);

}
# 5 "include/linux/swab.h" 2
# 13 "include/uapi/linux/byteorder/little_endian.h" 2
# 43 "include/uapi/linux/byteorder/little_endian.h"
static inline __attribute__((no_instrument_function)) __le64 __cpu_to_le64p(const __u64 *p)
{
    return ( __le64)*p;
}
static inline __attribute__((no_instrument_function)) __u64 __le64_to_cpup(const __le64 *p)
{
    return ( __u64)*p;
}
static inline __attribute__((no_instrument_function)) __le32 __cpu_to_le32p(const __u32 *p)
{
    return ( __le32)*p;
}
static inline __attribute__((no_instrument_function)) __u32 __le32_to_cpup(const __le32 *p)
{
    return ( __u32)*p;
}
static inline __attribute__((no_instrument_function)) __le16 __cpu_to_le16p(const __u16 *p)
{
    return ( __le16)*p;
}
static inline __attribute__((no_instrument_function)) __u16 __le16_to_cpup(const __le16 *p)
{
    return ( __u16)*p;
}
static inline __attribute__((no_instrument_function)) __be64 __cpu_to_be64p(const __u64 *p)
{
    return ( __be64)__swab64p(p);
}
static inline __attribute__((no_instrument_function)) __u64 __be64_to_cpup(const __be64 *p)
{
    return __swab64p((__u64 *)p);
}
static inline __attribute__((no_instrument_function)) __be32 __cpu_to_be32p(const __u32 *p)
{
    return ( __be32)__swab32p(p);
}
static inline __attribute__((no_instrument_function)) __u32 __be32_to_cpup(const __be32 *p)
{
    return __swab32p((__u32 *)p);
}
static inline __attribute__((no_instrument_function)) __be16 __cpu_to_be16p(const __u16 *p)
{
    return ( __be16)__swab16p(p);
}
static inline __attribute__((no_instrument_function)) __u16 __be16_to_cpup(const __be16 *p)
{
    return __swab16p((__u16 *)p);
}
# 5 "include/linux/byteorder/little_endian.h" 2

# 1 "include/linux/byteorder/generic.h" 1
# 143 "include/linux/byteorder/generic.h"
static inline __attribute__((no_instrument_function)) void le16_add_cpu(__le16 *var, u16 val)
{
    *var = (( __le16)(__u16)((( __u16)(__le16)(*var)) + val));
}

static inline __attribute__((no_instrument_function)) void le32_add_cpu(__le32 *var, u32 val)
{
    *var = (( __le32)(__u32)((( __u32)(__le32)(*var)) + val));
}

static inline __attribute__((no_instrument_function)) void le64_add_cpu(__le64 *var, u64 val)
{
    *var = (( __le64)(__u64)((( __u64)(__le64)(*var)) + val));
}

static inline __attribute__((no_instrument_function)) void be16_add_cpu(__be16 *var, u16 val)
{
    *var = (( __be16)(__builtin_constant_p((__u16)(((__builtin_constant_p((__u16)(( __u16)(__be16)(*var))) ? ((__u16)( (((__u16)(( __u16)(__be16)(*var)) & (__u16)0x00ffU) << 8) | (((__u16)(( __u16)(__be16)(*var)) & (__u16)0xff00U) >> 8))) : __fswab16(( __u16)(__be16)(*var))) + val))) ? ((__u16)( (((__u16)(((__builtin_constant_p((__u16)(( __u16)(__be16)(*var))) ? ((__u16)( (((__u16)(( __u16)(__be16)(*var)) & (__u16)0x00ffU) << 8) | (((__u16)(( __u16)(__be16)(*var)) & (__u16)0xff00U) >> 8))) : __fswab16(( __u16)(__be16)(*var))) + val)) & (__u16)0x00ffU) << 8) | (((__u16)(((__builtin_constant_p((__u16)(( __u16)(__be16)(*var))) ? ((__u16)( (((__u16)(( __u16)(__be16)(*var)) & (__u16)0x00ffU) << 8) | (((__u16)(( __u16)(__be16)(*var)) & (__u16)0xff00U) >> 8))) : __fswab16(( __u16)(__be16)(*var))) + val)) & (__u16)0xff00U) >> 8))) : __fswab16(((__builtin_constant_p((__u16)(( __u16)(__be16)(*var))) ? ((__u16)( (((__u16)(( __u16)(__be16)(*var)) & (__u16)0x00ffU) << 8) | (((__u16)(( __u16)(__be16)(*var)) & (__u16)0xff00U) >> 8))) : __fswab16(( __u16)(__be16)(*var))) + val))));
}

static inline __attribute__((no_instrument_function)) void be32_add_cpu(__be32 *var, u32 val)
{
    *var = (( __be32)(__builtin_constant_p((__u32)(((__builtin_constant_p((__u32)(( __u32)(__be32)(*var))) ? ((__u32)( (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x000000ffUL) << 24) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0xff000000UL) >> 24))) : __fswab32(( __u32)(__be32)(*var))) + val))) ? ((__u32)( (((__u32)(((__builtin_constant_p((__u32)(( __u32)(__be32)(*var))) ? ((__u32)( (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x000000ffUL) << 24) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0xff000000UL) >> 24))) : __fswab32(( __u32)(__be32)(*var))) + val)) & (__u32)0x000000ffUL) << 24) | (((__u32)(((__builtin_constant_p((__u32)(( __u32)(__be32)(*var))) ? ((__u32)( (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x000000ffUL) << 24) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0xff000000UL) >> 24))) : __fswab32(( __u32)(__be32)(*var))) + val)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(((__builtin_constant_p((__u32)(( __u32)(__be32)(*var))) ? ((__u32)( (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x000000ffUL) << 24) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0xff000000UL) >> 24))) : __fswab32(( __u32)(__be32)(*var))) + val)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(((__builtin_constant_p((__u32)(( __u32)(__be32)(*var))) ? ((__u32)( (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x000000ffUL) << 24) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0xff000000UL) >> 24))) : __fswab32(( __u32)(__be32)(*var))) + val)) & (__u32)0xff000000UL) >> 24))) : __fswab32(((__builtin_constant_p((__u32)(( __u32)(__be32)(*var))) ? ((__u32)( (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x000000ffUL) << 24) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(( __u32)(__be32)(*var)) & (__u32)0xff000000UL) >> 24))) : __fswab32(( __u32)(__be32)(*var))) + val))));
}

static inline __attribute__((no_instrument_function)) void be64_add_cpu(__be64 *var, u64 val)
{
    *var = (( __be64)(__builtin_constant_p((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val))) ? ((__u64)( (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(((__builtin_constant_p((__u64)(( __u64)(__be64)(*var))) ? ((__u64)( (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(( __u64)(__be64)(*var)) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(( __u64)(__be64)(*var))) + val))));
}
# 7 "include/linux/byteorder/little_endian.h" 2
# 5 "./arch/x86/include/uapi/asm/byteorder.h" 2
# 6 "include/asm-generic/bitops/le.h" 2





static inline __attribute__((no_instrument_function)) unsigned long find_next_zero_bit_le(const void *addr,
                                                                                          unsigned long size, unsigned long offset)
{
    return find_next_zero_bit(addr, size, offset);
}

static inline __attribute__((no_instrument_function)) unsigned long find_next_bit_le(const void *addr,
                                                                                     unsigned long size, unsigned long offset)
{
    return find_next_bit(addr, size, offset);
}

static inline __attribute__((no_instrument_function)) unsigned long find_first_zero_bit_le(const void *addr,
                                                                                           unsigned long size)
{
    return find_first_zero_bit(addr, size);
}
# 52 "include/asm-generic/bitops/le.h"
static inline __attribute__((no_instrument_function)) int test_bit_le(int nr, const void *addr)
{
    return (__builtin_constant_p((nr ^ 0)) ? constant_test_bit((nr ^ 0), (addr)) : variable_test_bit((nr ^ 0), (addr)));
}

static inline __attribute__((no_instrument_function)) void set_bit_le(int nr, void *addr)
{
    set_bit(nr ^ 0, addr);
}

static inline __attribute__((no_instrument_function)) void clear_bit_le(int nr, void *addr)
{
    clear_bit(nr ^ 0, addr);
}

static inline __attribute__((no_instrument_function)) void __set_bit_le(int nr, void *addr)
{
    __set_bit(nr ^ 0, addr);
}

static inline __attribute__((no_instrument_function)) void __clear_bit_le(int nr, void *addr)
{
    __clear_bit(nr ^ 0, addr);
}

static inline __attribute__((no_instrument_function)) int test_and_set_bit_le(int nr, void *addr)
{
    return test_and_set_bit(nr ^ 0, addr);
}

static inline __attribute__((no_instrument_function)) int test_and_clear_bit_le(int nr, void *addr)
{
    return test_and_clear_bit(nr ^ 0, addr);
}

static inline __attribute__((no_instrument_function)) int __test_and_set_bit_le(int nr, void *addr)
{
    return __test_and_set_bit(nr ^ 0, addr);
}

static inline __attribute__((no_instrument_function)) int __test_and_clear_bit_le(int nr, void *addr)
{
    return __test_and_clear_bit(nr ^ 0, addr);
}
# 505 "./arch/x86/include/asm/bitops.h" 2

# 1 "include/asm-generic/bitops/ext2-atomic-setbit.h" 1
# 507 "./arch/x86/include/asm/bitops.h" 2
# 37 "include/linux/bitops.h" 2
# 60 "include/linux/bitops.h"
static __inline__ __attribute__((no_instrument_function)) int get_bitmask_order(unsigned int count)
{
    int order;

    order = fls(count);
    return order;
}

static __inline__ __attribute__((no_instrument_function)) int get_count_order(unsigned int count)
{
    int order;

    order = fls(count) - 1;
    if (count & (count - 1))
        order++;
    return order;
}

static inline __attribute__((no_instrument_function)) unsigned long hweight_long(unsigned long w)
{
    return sizeof(w) == 4 ? (__builtin_constant_p(w) ? ((((unsigned int) ((!!((w) & (1ULL << 0))) + (!!((w) & (1ULL << 1))) + (!!((w) & (1ULL << 2))) + (!!((w) & (1ULL << 3))) + (!!((w) & (1ULL << 4))) + (!!((w) & (1ULL << 5))) + (!!((w) & (1ULL << 6))) + (!!((w) & (1ULL << 7))))) + ((unsigned int) ((!!(((w) >> 8) & (1ULL << 0))) + (!!(((w) >> 8) & (1ULL << 1))) + (!!(((w) >> 8) & (1ULL << 2))) + (!!(((w) >> 8) & (1ULL << 3))) + (!!(((w) >> 8) & (1ULL << 4))) + (!!(((w) >> 8) & (1ULL << 5))) + (!!(((w) >> 8) & (1ULL << 6))) + (!!(((w) >> 8) & (1ULL << 7)))))) + (((unsigned int) ((!!(((w) >> 16) & (1ULL << 0))) + (!!(((w) >> 16) & (1ULL << 1))) + (!!(((w) >> 16) & (1ULL << 2))) + (!!(((w) >> 16) & (1ULL << 3))) + (!!(((w) >> 16) & (1ULL << 4))) + (!!(((w) >> 16) & (1ULL << 5))) + (!!(((w) >> 16) & (1ULL << 6))) + (!!(((w) >> 16) & (1ULL << 7))))) + ((unsigned int) ((!!((((w) >> 16) >> 8) & (1ULL << 0))) + (!!((((w) >> 16) >> 8) & (1ULL << 1))) + (!!((((w) >> 16) >> 8) & (1ULL << 2))) + (!!((((w) >> 16) >> 8) & (1ULL << 3))) + (!!((((w) >> 16) >> 8) & (1ULL << 4))) + (!!((((w) >> 16) >> 8) & (1ULL << 5))) + (!!((((w) >> 16) >> 8) & (1ULL << 6))) + (!!((((w) >> 16) >> 8) & (1ULL << 7))))))) : __arch_hweight32(w)) : (__builtin_constant_p(w) ? (((((unsigned int) ((!!((w) & (1ULL << 0))) + (!!((w) & (1ULL << 1))) + (!!((w) & (1ULL << 2))) + (!!((w) & (1ULL << 3))) + (!!((w) & (1ULL << 4))) + (!!((w) & (1ULL << 5))) + (!!((w) & (1ULL << 6))) + (!!((w) & (1ULL << 7))))) + ((unsigned int) ((!!(((w) >> 8) & (1ULL << 0))) + (!!(((w) >> 8) & (1ULL << 1))) + (!!(((w) >> 8) & (1ULL << 2))) + (!!(((w) >> 8) & (1ULL << 3))) + (!!(((w) >> 8) & (1ULL << 4))) + (!!(((w) >> 8) & (1ULL << 5))) + (!!(((w) >> 8) & (1ULL << 6))) + (!!(((w) >> 8) & (1ULL << 7)))))) + (((unsigned int) ((!!(((w) >> 16) & (1ULL << 0))) + (!!(((w) >> 16) & (1ULL << 1))) + (!!(((w) >> 16) & (1ULL << 2))) + (!!(((w) >> 16) & (1ULL << 3))) + (!!(((w) >> 16) & (1ULL << 4))) + (!!(((w) >> 16) & (1ULL << 5))) + (!!(((w) >> 16) & (1ULL << 6))) + (!!(((w) >> 16) & (1ULL << 7))))) + ((unsigned int) ((!!((((w) >> 16) >> 8) & (1ULL << 0))) + (!!((((w) >> 16) >> 8) & (1ULL << 1))) + (!!((((w) >> 16) >> 8) & (1ULL << 2))) + (!!((((w) >> 16) >> 8) & (1ULL << 3))) + (!!((((w) >> 16) >> 8) & (1ULL << 4))) + (!!((((w) >> 16) >> 8) & (1ULL << 5))) + (!!((((w) >> 16) >> 8) & (1ULL << 6))) + (!!((((w) >> 16) >> 8) & (1ULL << 7))))))) + ((((unsigned int) ((!!(((w) >> 32) & (1ULL << 0))) + (!!(((w) >> 32) & (1ULL << 1))) + (!!(((w) >> 32) & (1ULL << 2))) + (!!(((w) >> 32) & (1ULL << 3))) + (!!(((w) >> 32) & (1ULL << 4))) + (!!(((w) >> 32) & (1ULL << 5))) + (!!(((w) >> 32) & (1ULL << 6))) + (!!(((w) >> 32) & (1ULL << 7))))) + ((unsigned int) ((!!((((w) >> 32) >> 8) & (1ULL << 0))) + (!!((((w) >> 32) >> 8) & (1ULL << 1))) + (!!((((w) >> 32) >> 8) & (1ULL << 2))) + (!!((((w) >> 32) >> 8) & (1ULL << 3))) + (!!((((w) >> 32) >> 8) & (1ULL << 4))) + (!!((((w) >> 32) >> 8) & (1ULL << 5))) + (!!((((w) >> 32) >> 8) & (1ULL << 6))) + (!!((((w) >> 32) >> 8) & (1ULL << 7)))))) + (((unsigned int) ((!!((((w) >> 32) >> 16) & (1ULL << 0))) + (!!((((w) >> 32) >> 16) & (1ULL << 1))) + (!!((((w) >> 32) >> 16) & (1ULL << 2))) + (!!((((w) >> 32) >> 16) & (1ULL << 3))) + (!!((((w) >> 32) >> 16) & (1ULL << 4))) + (!!((((w) >> 32) >> 16) & (1ULL << 5))) + (!!((((w) >> 32) >> 16) & (1ULL << 6))) + (!!((((w) >> 32) >> 16) & (1ULL << 7))))) + ((unsigned int) ((!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 0))) + (!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 1))) + (!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 2))) + (!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 3))) + (!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 4))) + (!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 5))) + (!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 6))) + (!!(((((w) >> 32) >> 16) >> 8) & (1ULL << 7)))))))) : __arch_hweight64(w));
}






static inline __attribute__((no_instrument_function)) __u64 rol64(__u64 word, unsigned int shift)
{
return (word << shift) | (word >> (64 - shift));
}






static inline __attribute__((no_instrument_function)) __u64 ror64(__u64 word, unsigned int shift)
{
return (word >> shift) | (word << (64 - shift));
}






static inline __attribute__((no_instrument_function)) __u32 rol32(__u32 word, unsigned int shift)
{
    return (word << shift) | (word >> (32 - shift));
}






static inline __attribute__((no_instrument_function)) __u32 ror32(__u32 word, unsigned int shift)
{
    return (word >> shift) | (word << (32 - shift));
}






static inline __attribute__((no_instrument_function)) __u16 rol16(__u16 word, unsigned int shift)
{
    return (word << shift) | (word >> (16 - shift));
}






static inline __attribute__((no_instrument_function)) __u16 ror16(__u16 word, unsigned int shift)
{
    return (word >> shift) | (word << (16 - shift));
}






static inline __attribute__((no_instrument_function)) __u8 rol8(__u8 word, unsigned int shift)
{
    return (word << shift) | (word >> (8 - shift));
}






static inline __attribute__((no_instrument_function)) __u8 ror8(__u8 word, unsigned int shift)
{
    return (word >> shift) | (word << (8 - shift));
}






static inline __attribute__((no_instrument_function)) __s32 sign_extend32(__u32 value, int index)
{
    __u8 shift = 31 - index;
    return (__s32)(value << shift) >> shift;
}

static inline __attribute__((no_instrument_function)) unsigned fls_long(unsigned long l)
{
    if (sizeof(l) == 4)
        return fls(l);
    return fls64(l);
}
# 189 "include/linux/bitops.h"
static inline __attribute__((no_instrument_function)) unsigned long __ffs64(u64 word)
{






    return __ffs((unsigned long)word);
}
# 225 "include/linux/bitops.h"
extern unsigned long find_last_bit(const unsigned long *addr,
                                   unsigned long size);
# 11 "include/linux/kernel.h" 2
# 1 "include/linux/log2.h" 1
# 21 "include/linux/log2.h"
extern __attribute__((const, noreturn))
int ____ilog2_NaN(void);
# 31 "include/linux/log2.h"
static inline __attribute__((no_instrument_function)) __attribute__((const))
int __ilog2_u32(u32 n)
{
    return fls(n) - 1;
}



static inline __attribute__((no_instrument_function)) __attribute__((const))
int __ilog2_u64(u64 n)
{
    return fls64(n) - 1;
}







static inline __attribute__((no_instrument_function)) __attribute__((const))
bool is_power_of_2(unsigned long n)
{
    return (n != 0 && ((n & (n - 1)) == 0));
}




static inline __attribute__((no_instrument_function)) __attribute__((const))
unsigned long __roundup_pow_of_two(unsigned long n)
{
    return 1UL << fls_long(n - 1);
}




static inline __attribute__((no_instrument_function)) __attribute__((const))
unsigned long __rounddown_pow_of_two(unsigned long n)
{
    return 1UL << (fls_long(n) - 1);
}
# 12 "include/linux/kernel.h" 2
# 1 "include/linux/typecheck.h" 1
# 13 "include/linux/kernel.h" 2
# 1 "include/linux/printk.h" 1




# 1 "include/linux/init.h" 1
# 135 "include/linux/init.h"
typedef int (*initcall_t)(void);
typedef void (*exitcall_t)(void);

extern initcall_t __con_initcall_start[], __con_initcall_end[];
extern initcall_t __security_initcall_start[], __security_initcall_end[];


typedef void (*ctor_fn_t)(void);


extern int do_one_initcall(initcall_t fn);
extern char __attribute__ ((__section__(".init.data"))) boot_command_line[];
extern char *saved_command_line;
extern unsigned int reset_devices;


void setup_arch(char **);
void prepare_namespace(void);
void __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) load_default_modules(void);
int __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) init_rootfs(void);

extern void (*late_time_init)(void);

extern bool initcall_debug;
# 243 "include/linux/init.h"
struct obs_kernel_param {
    const char *str;
    int (*setup_func)(char *);
    int early;
};
# 292 "include/linux/init.h"
void __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) parse_early_param(void);
void __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) parse_early_options(char *cmdline);
# 6 "include/linux/printk.h" 2
# 1 "include/linux/kern_levels.h" 1
# 7 "include/linux/printk.h" 2

# 1 "include/linux/cache.h" 1



# 1 "include/uapi/linux/kernel.h" 1



# 1 "./include/uapi/linux/sysinfo.h" 1






struct sysinfo {
    __kernel_long_t uptime;
    __kernel_ulong_t loads[3];
    __kernel_ulong_t totalram;
    __kernel_ulong_t freeram;
    __kernel_ulong_t sharedram;
    __kernel_ulong_t bufferram;
    __kernel_ulong_t totalswap;
    __kernel_ulong_t freeswap;
    __u16 procs;
    __u16 pad;
    __kernel_ulong_t totalhigh;
    __kernel_ulong_t freehigh;
    __u32 mem_unit;
    char _f[20-2*sizeof(__kernel_ulong_t)-sizeof(__u32)];
};
# 5 "include/uapi/linux/kernel.h" 2
# 5 "include/linux/cache.h" 2
# 9 "include/linux/printk.h" 2

extern const char linux_banner[];
extern const char linux_proc_banner[];

static inline __attribute__((no_instrument_function)) int printk_get_level(const char *buffer)
{
    if (buffer[0] == '\001' && buffer[1]) {
        switch (buffer[1]) {
            case '0' ... '7':
            case 'd':
                return buffer[1];
        }
    }
    return 0;
}

static inline __attribute__((no_instrument_function)) const char *printk_skip_level(const char *buffer)
{
    if (printk_get_level(buffer))
        return buffer + 2;

    return buffer;
}
# 44 "include/linux/printk.h"
extern int console_printk[];






static inline __attribute__((no_instrument_function)) void console_silent(void)
{
    (console_printk[0]) = 0;
}

static inline __attribute__((no_instrument_function)) void console_verbose(void)
{
    if ((console_printk[0]))
        (console_printk[0]) = 15;
}

struct va_format {
    const char *fmt;
    va_list *va;
};
# 109 "include/linux/printk.h"
static inline __attribute__((no_instrument_function)) __attribute__((format(printf, 1, 2)))
int no_printk(const char *fmt, ...)
{
    return 0;
}


extern __attribute__((format(printf, 1, 2)))
void early_printk(const char *fmt, ...);





typedef int(*printk_func_t)(const char *fmt, va_list args);


__attribute__((format(printf, 5, 0)))
int vprintk_emit(int facility, int level,
                 const char *dict, size_t dictlen,
                 const char *fmt, va_list args);

__attribute__((format(printf, 1, 0)))
int vprintk(const char *fmt, va_list args);

__attribute__((format(printf, 5, 6))) __attribute__((__cold__))
int printk_emit(int facility, int level,
                const char *dict, size_t dictlen,
                const char *fmt, ...);

__attribute__((format(printf, 1, 2))) __attribute__((__cold__))
int printk(const char *fmt, ...);




__attribute__((format(printf, 1, 2))) __attribute__((__cold__)) int printk_deferred(const char *fmt, ...);






extern int __printk_ratelimit(const char *func);

extern bool printk_timed_ratelimit(unsigned long *caller_jiffies,
                                   unsigned int interval_msec);

extern int printk_delay_msec;
extern int dmesg_restrict;
extern int kptr_restrict;

extern void wake_up_klogd(void);

char *log_buf_addr_get(void);
u32 log_buf_len_get(void);
void log_buf_kexec_setup(void);
void __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) setup_log_buf(int early);
void dump_stack_set_arch_desc(const char *fmt, ...);
void dump_stack_print_info(const char *log_lvl);
void show_regs_print_info(const char *log_lvl);
# 231 "include/linux/printk.h"
extern void dump_stack(void) __attribute__((__cold__));
# 275 "include/linux/printk.h"
# 1 "include/linux/dynamic_debug.h" 1
# 9 "include/linux/dynamic_debug.h"
struct _ddebug {




    const char *modname;
    const char *function;
    const char *filename;
    const char *format;
    unsigned int lineno:18;
# 35 "include/linux/dynamic_debug.h"
    unsigned int flags:8;
} __attribute__((aligned(8)));


int ddebug_add_module(struct _ddebug *tab, unsigned int n,
                      const char *modname);
# 111 "include/linux/dynamic_debug.h"
# 1 "include/linux/string.h" 1






# 1 "include/linux/stddef.h" 1
# 8 "include/linux/string.h" 2

# 1 "include/uapi/linux/string.h" 1
# 10 "include/linux/string.h" 2

extern char *strndup_user(const char *, long);
extern void *memdup_user(const void *, size_t);




# 1 "./arch/x86/include/asm/string.h" 1



# 1 "./arch/x86/include/asm/string_64.h" 1
# 9 "./arch/x86/include/asm/string_64.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void *__inline_memcpy(void *to, const void *from, size_t n)
{
    unsigned long d0, d1, d2;
    asm volatile("rep ; movsl\n\t"
                 "testb $2,%b4\n\t"
                 "je 1f\n\t"
                 "movsw\n"
                 "1:\ttestb $1,%b4\n\t"
                 "je 2f\n\t"
                 "movsb\n"
                 "2:"
            : "=&c" (d0), "=&D" (d1), "=&S" (d2)
            : "0" (n / 4), "q" (n), "1" ((long)to), "2" ((long)from)
            : "memory");
    return to;
}





extern void *__memcpy(void *to, const void *from, size_t len);



extern void *memcpy(void *to, const void *from, size_t len);
# 56 "./arch/x86/include/asm/string_64.h"
void *memset(void *s, int c, size_t n);
void *__memset(void *s, int c, size_t n);


void *memmove(void *dest, const void *src, size_t count);
void *__memmove(void *dest, const void *src, size_t count);

int memcmp(const void *cs, const void *ct, size_t count);
size_t strlen(const char *s);
char *strcpy(char *dest, const char *src);
char *strcat(char *dest, const char *src);
int strcmp(const char *cs, const char *ct);
# 5 "./arch/x86/include/asm/string.h" 2
# 18 "include/linux/string.h" 2


extern char * strcpy(char *,const char *);


extern char * strncpy(char *,const char *, __kernel_size_t);


size_t strlcpy(char *, const char *, size_t);


extern char * strcat(char *, const char *);


extern char * strncat(char *, const char *, __kernel_size_t);


extern size_t strlcat(char *, const char *, __kernel_size_t);


extern int strcmp(const char *,const char *);


extern int strncmp(const char *,const char *,__kernel_size_t);


extern int strcasecmp(const char *s1, const char *s2);


extern int strncasecmp(const char *s1, const char *s2, size_t n);


extern char * strchr(const char *,int);


extern char * strchrnul(const char *,int);


extern char * strnchr(const char *, size_t, int);


extern char * strrchr(const char *,int);

extern char * __attribute__((warn_unused_result)) skip_spaces(const char *);

extern char *strim(char *);

static inline __attribute__((no_instrument_function)) __attribute__((warn_unused_result)) char *strstrip(char *str)
{
    return strim(str);
}


extern char * strstr(const char *, const char *);


extern char * strnstr(const char *, const char *, size_t);


extern __kernel_size_t strlen(const char *);


extern __kernel_size_t strnlen(const char *,__kernel_size_t);


extern char * strpbrk(const char *,const char *);


extern char * strsep(char **,const char *);


extern __kernel_size_t strspn(const char *,const char *);


extern __kernel_size_t strcspn(const char *,const char *);
# 105 "include/linux/string.h"
extern void * memscan(void *,int,__kernel_size_t);


extern int memcmp(const void *,const void *,__kernel_size_t);


extern void * memchr(const void *,int,__kernel_size_t);

void *memchr_inv(const void *s, int c, size_t n);

extern void kfree_const(const void *x);

extern char *kstrdup(const char *s, gfp_t gfp);
extern const char *kstrdup_const(const char *s, gfp_t gfp);
extern char *kstrndup(const char *s, size_t len, gfp_t gfp);
extern void *kmemdup(const void *src, size_t len, gfp_t gfp);

extern char **argv_split(gfp_t gfp, const char *str, int *argcp);
extern void argv_free(char **argv);

extern bool sysfs_streq(const char *s1, const char *s2);
extern int strtobool(const char *s, bool *res);


int vbin_printf(u32 *bin_buf, size_t size, const char *fmt, va_list args);
int bstr_printf(char *buf, size_t size, const char *fmt, const u32 *bin_buf);
int bprintf(u32 *bin_buf, size_t size, const char *fmt, ...) __attribute__((format(printf, 3, 4)));


extern ssize_t memory_read_from_buffer(void *to, size_t count, loff_t *ppos,
                                       const void *from, size_t available);






static inline __attribute__((no_instrument_function)) bool strstarts(const char *str, const char *prefix)
{
    return strncmp(str, prefix, strlen(prefix)) == 0;
}

size_t memweight(const void *ptr, size_t bytes);
void memzero_explicit(void *s, size_t count);






static inline __attribute__((no_instrument_function)) const char *kbasename(const char *path)
{
    const char *tail = strrchr(path, '/');
    return tail ? tail + 1 : path;
}
# 112 "include/linux/dynamic_debug.h" 2
# 1 "include/linux/errno.h" 1



# 1 "include/uapi/linux/errno.h" 1
# 1 "./arch/x86/include/uapi/asm/errno.h" 1
# 1 "./include/uapi/asm-generic/errno.h" 1



# 1 "./include/uapi/asm-generic/errno-base.h" 1
# 5 "./include/uapi/asm-generic/errno.h" 2
# 1 "./arch/x86/include/uapi/asm/errno.h" 2
# 1 "include/uapi/linux/errno.h" 2
# 5 "include/linux/errno.h" 2
# 113 "include/linux/dynamic_debug.h" 2

static inline __attribute__((no_instrument_function)) int ddebug_remove_module(const char *mod)
{
    return 0;
}

static inline __attribute__((no_instrument_function)) int ddebug_dyndbg_module_param_cb(char *param, char *val,
                                                                                        const char *modname)
{
    if (strstr(param, "dyndbg")) {

        printk("\001" "4" "dyndbg param is supported only in "
               "CONFIG_DYNAMIC_DEBUG builds\n");
        return 0;
    }
    return -22;
}
# 276 "include/linux/printk.h" 2
# 418 "include/linux/printk.h"
extern const struct file_operations kmsg_fops;

enum {
    DUMP_PREFIX_NONE,
    DUMP_PREFIX_ADDRESS,
    DUMP_PREFIX_OFFSET
};
extern int hex_dump_to_buffer(const void *buf, size_t len, int rowsize,
                              int groupsize, char *linebuf, size_t linebuflen,
                              bool ascii);

extern void print_hex_dump(const char *level, const char *prefix_str,
                           int prefix_type, int rowsize, int groupsize,
                           const void *buf, size_t len, bool ascii);




extern void print_hex_dump_bytes(const char *prefix_str, int prefix_type,
                                 const void *buf, size_t len);
# 14 "include/linux/kernel.h" 2
# 165 "include/linux/kernel.h"
struct completion;
struct pt_regs;
struct user;


extern int _cond_resched(void);
# 193 "include/linux/kernel.h"
static inline __attribute__((no_instrument_function)) void ___might_sleep(const char *file, int line,
                                                                          int preempt_offset) { }
static inline __attribute__((no_instrument_function)) void __might_sleep(const char *file, int line,
                                                                         int preempt_offset) { }
# 240 "include/linux/kernel.h"
static inline __attribute__((no_instrument_function)) u32 reciprocal_scale(u32 val, u32 ep_ro)
{
    return (u32)(((u64) val * ep_ro) >> 32);
}





static inline __attribute__((no_instrument_function)) void might_fault(void) { }


extern struct atomic_notifier_head panic_notifier_list;
extern long (*panic_blink)(int state);
__attribute__((format(printf, 1, 2)))
void panic(const char *fmt, ...)
__attribute__((noreturn)) __attribute__((__cold__));
extern void oops_enter(void);
extern void oops_exit(void);
void print_oops_end_marker(void);
extern int oops_may_print(void);
void do_exit(long error_code)
__attribute__((noreturn));
void complete_and_exit(struct completion *, long)
__attribute__((noreturn));


int __attribute__((warn_unused_result)) _kstrtoul(const char *s, unsigned int base, unsigned long *res);
int __attribute__((warn_unused_result)) _kstrtol(const char *s, unsigned int base, long *res);

int __attribute__((warn_unused_result)) kstrtoull(const char *s, unsigned int base, unsigned long long *res);
int __attribute__((warn_unused_result)) kstrtoll(const char *s, unsigned int base, long long *res);
# 289 "include/linux/kernel.h"
static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtoul(const char *s, unsigned int base, unsigned long *res)
{




    if (sizeof(unsigned long) == sizeof(unsigned long long) &&
        __alignof__(unsigned long) == __alignof__(unsigned long long))
        return kstrtoull(s, base, (unsigned long long *)res);
    else
        return _kstrtoul(s, base, res);
}
# 318 "include/linux/kernel.h"
static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtol(const char *s, unsigned int base, long *res)
{




    if (sizeof(long) == sizeof(long long) &&
        __alignof__(long) == __alignof__(long long))
        return kstrtoll(s, base, (long long *)res);
    else
        return _kstrtol(s, base, res);
}

int __attribute__((warn_unused_result)) kstrtouint(const char *s, unsigned int base, unsigned int *res);
int __attribute__((warn_unused_result)) kstrtoint(const char *s, unsigned int base, int *res);

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtou64(const char *s, unsigned int base, u64 *res)
{
    return kstrtoull(s, base, res);
}

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtos64(const char *s, unsigned int base, s64 *res)
{
    return kstrtoll(s, base, res);
}

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtou32(const char *s, unsigned int base, u32 *res)
{
    return kstrtouint(s, base, res);
}

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtos32(const char *s, unsigned int base, s32 *res)
{
    return kstrtoint(s, base, res);
}

int __attribute__((warn_unused_result)) kstrtou16(const char *s, unsigned int base, u16 *res);
int __attribute__((warn_unused_result)) kstrtos16(const char *s, unsigned int base, s16 *res);
int __attribute__((warn_unused_result)) kstrtou8(const char *s, unsigned int base, u8 *res);
int __attribute__((warn_unused_result)) kstrtos8(const char *s, unsigned int base, s8 *res);

int __attribute__((warn_unused_result)) kstrtoull_from_user(const char *s, size_t count, unsigned int base, unsigned long long *res);
int __attribute__((warn_unused_result)) kstrtoll_from_user(const char *s, size_t count, unsigned int base, long long *res);
int __attribute__((warn_unused_result)) kstrtoul_from_user(const char *s, size_t count, unsigned int base, unsigned long *res);
int __attribute__((warn_unused_result)) kstrtol_from_user(const char *s, size_t count, unsigned int base, long *res);
int __attribute__((warn_unused_result)) kstrtouint_from_user(const char *s, size_t count, unsigned int base, unsigned int *res);
int __attribute__((warn_unused_result)) kstrtoint_from_user(const char *s, size_t count, unsigned int base, int *res);
int __attribute__((warn_unused_result)) kstrtou16_from_user(const char *s, size_t count, unsigned int base, u16 *res);
int __attribute__((warn_unused_result)) kstrtos16_from_user(const char *s, size_t count, unsigned int base, s16 *res);
int __attribute__((warn_unused_result)) kstrtou8_from_user(const char *s, size_t count, unsigned int base, u8 *res);
int __attribute__((warn_unused_result)) kstrtos8_from_user(const char *s, size_t count, unsigned int base, s8 *res);

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtou64_from_user(const char *s, size_t count, unsigned int base, u64 *res)
{
    return kstrtoull_from_user(s, count, base, res);
}

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtos64_from_user(const char *s, size_t count, unsigned int base, s64 *res)
{
    return kstrtoll_from_user(s, count, base, res);
}

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtou32_from_user(const char *s, size_t count, unsigned int base, u32 *res)
{
    return kstrtouint_from_user(s, count, base, res);
}

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) kstrtos32_from_user(const char *s, size_t count, unsigned int base, s32 *res)
{
    return kstrtoint_from_user(s, count, base, res);
}



extern unsigned long simple_strtoul(const char *,char **,unsigned int);
extern long simple_strtol(const char *,char **,unsigned int);
extern unsigned long long simple_strtoull(const char *,char **,unsigned int);
extern long long simple_strtoll(const char *,char **,unsigned int);

extern int num_to_str(char *buf, int size, unsigned long long num);



extern __attribute__((format(printf, 2, 3))) int sprintf(char *buf, const char * fmt, ...);
extern __attribute__((format(printf, 2, 0))) int vsprintf(char *buf, const char *, va_list);
extern __attribute__((format(printf, 3, 4)))
int snprintf(char *buf, size_t size, const char *fmt, ...);
extern __attribute__((format(printf, 3, 0)))
int vsnprintf(char *buf, size_t size, const char *fmt, va_list args);
extern __attribute__((format(printf, 3, 4)))
int scnprintf(char *buf, size_t size, const char *fmt, ...);
extern __attribute__((format(printf, 3, 0)))
int vscnprintf(char *buf, size_t size, const char *fmt, va_list args);
extern __attribute__((format(printf, 2, 3)))
char *kasprintf(gfp_t gfp, const char *fmt, ...);
extern char *kvasprintf(gfp_t gfp, const char *fmt, va_list args);

extern __attribute__((format(scanf, 2, 3)))
int sscanf(const char *, const char *, ...);
extern __attribute__((format(scanf, 2, 0)))
int vsscanf(const char *, const char *, va_list);

extern int get_option(char **str, int *pint);
extern char *get_options(const char *str, int nints, int *ints);
extern unsigned long long memparse(const char *ptr, char **retptr);
extern bool parse_option_str(const char *str, const char *option);

extern int core_kernel_text(unsigned long addr);
extern int core_kernel_data(unsigned long addr);
extern int __kernel_text_address(unsigned long addr);
extern int kernel_text_address(unsigned long addr);
extern int func_ptr_is_kernel_text(void *ptr);

unsigned long int_sqrt(unsigned long);

extern void bust_spinlocks(int yes);
extern int oops_in_progress;
extern int panic_timeout;
extern int panic_on_oops;
extern int panic_on_unrecovered_nmi;
extern int panic_on_io_nmi;
extern int panic_on_warn;
extern int sysctl_panic_on_stackoverflow;




static inline __attribute__((no_instrument_function)) void set_arch_panic_timeout(int timeout, int arch_default_timeout)
{
    if (panic_timeout == arch_default_timeout)
        panic_timeout = timeout;
}
extern const char *print_tainted(void);
enum lockdep_ok {
    LOCKDEP_STILL_OK,
    LOCKDEP_NOW_UNRELIABLE
};
extern void add_taint(unsigned flag, enum lockdep_ok);
extern int test_taint(unsigned flag);
extern unsigned long get_taint(void);
extern int root_mountflags;

extern bool early_boot_irqs_disabled;


extern enum system_states {
    SYSTEM_BOOTING,
    SYSTEM_RUNNING,
    SYSTEM_HALT,
    SYSTEM_POWER_OFF,
    SYSTEM_RESTART,
} system_state;
# 488 "include/linux/kernel.h"
extern const char hex_asc[];



static inline __attribute__((no_instrument_function)) char *hex_byte_pack(char *buf, u8 byte)
{
    *buf++ = hex_asc[((byte) & 0xf0) >> 4];
    *buf++ = hex_asc[((byte) & 0x0f)];
    return buf;
}

extern const char hex_asc_upper[];



static inline __attribute__((no_instrument_function)) char *hex_byte_pack_upper(char *buf, u8 byte)
{
    *buf++ = hex_asc_upper[((byte) & 0xf0) >> 4];
    *buf++ = hex_asc_upper[((byte) & 0x0f)];
    return buf;
}

extern int hex_to_bin(char ch);
extern int __attribute__((warn_unused_result)) hex2bin(u8 *dst, const char *src, size_t count);
extern char *bin2hex(char *dst, const void *src, size_t count);

bool mac_pton(const char *s, u8 *mac);
# 537 "include/linux/kernel.h"
void tracing_off_permanent(void);




enum ftrace_dump_mode {
    DUMP_NONE,
    DUMP_ALL,
    DUMP_ORIG,
};


void tracing_on(void);
void tracing_off(void);
int tracing_is_on(void);
void tracing_snapshot(void);
void tracing_snapshot_alloc(void);

extern void tracing_start(void);
extern void tracing_stop(void);

static inline __attribute__((no_instrument_function)) __attribute__((format(printf, 1, 2)))
void ____trace_printk_check_format(const char *fmt, ...)
{
}
# 621 "include/linux/kernel.h"
extern __attribute__((format(printf, 2, 3)))
int __trace_bprintk(unsigned long ip, const char *fmt, ...);

extern __attribute__((format(printf, 2, 3)))
int __trace_printk(unsigned long ip, const char *fmt, ...);
# 662 "include/linux/kernel.h"
extern int __trace_bputs(unsigned long ip, const char *str);
extern int __trace_puts(unsigned long ip, const char *str, int size);

extern void trace_dump_stack(int skip);
# 684 "include/linux/kernel.h"
extern int
__ftrace_vbprintk(unsigned long ip, const char *fmt, va_list ap);

extern int
__ftrace_vprintk(unsigned long ip, const char *fmt, va_list ap);

extern void ftrace_dump(enum ftrace_dump_mode oops_dump_mode);
# 45 "./arch/x86/include/asm/percpu.h" 2
# 87 "./arch/x86/include/asm/percpu.h"
extern void __bad_percpu_size(void);
# 520 "./arch/x86/include/asm/percpu.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) int x86_this_cpu_constant_test_bit(unsigned int nr,
                                                                                                                        const unsigned long *addr)
{
    unsigned long *a = (unsigned long *)addr + nr / 64;


    return ((1UL << (nr % 64)) & ({ typeof(*a) pfo_ret__; switch (sizeof(*a)) { case 1: asm("mov" "b ""%%""gs"":" "%" "1"",%0" : "=q" (pfo_ret__) : "m" (*a)); break; case 2: asm("mov" "w ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (*a)); break; case 4: asm("mov" "l ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (*a)); break; case 8: asm("mov" "q ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (*a)); break; default: __bad_percpu_size(); } pfo_ret__; })) != 0;



}

static inline __attribute__((no_instrument_function)) int x86_this_cpu_variable_test_bit(int nr,
                                                                                         const unsigned long *addr)
{
    int oldbit;

    asm volatile("bt ""%%""gs"":" "%" "2"",%1\n\t"
                 "sbb %0,%0"
            : "=r" (oldbit)
            : "m" (*(unsigned long *)addr), "Ir" (nr));

    return oldbit;
}







# 1 "include/asm-generic/percpu.h" 1




# 1 "include/linux/threads.h" 1
# 6 "include/asm-generic/percpu.h" 2
# 1 "include/linux/percpu-defs.h" 1
# 295 "include/linux/percpu-defs.h"
extern void __bad_size_call_parameter(void);




static inline __attribute__((no_instrument_function)) void __this_cpu_preempt_check(const char *op) { }
# 7 "include/asm-generic/percpu.h" 2
# 18 "include/asm-generic/percpu.h"
extern unsigned long __per_cpu_offset[64];
# 47 "include/asm-generic/percpu.h"
extern void setup_per_cpu_areas(void);
# 552 "./arch/x86/include/asm/percpu.h" 2


extern __attribute__((section(".data..percpu" "..read_mostly"))) __typeof__(unsigned long) this_cpu_off;
# 6 "./arch/x86/include/asm/current.h" 2


struct task_struct;

extern __attribute__((section(".data..percpu" ""))) __typeof__(struct task_struct *) current_task;

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) struct task_struct *get_current(void)
{
    return ({ typeof(current_task) pfo_ret__; switch (sizeof(current_task)) { case 1: asm("mov" "b ""%%""gs"":" "%" "P1"",%0" : "=q" (pfo_ret__) : "p" (&(current_task))); break; case 2: asm("mov" "w ""%%""gs"":" "%" "P1"",%0" : "=r" (pfo_ret__) : "p" (&(current_task))); break; case 4: asm("mov" "l ""%%""gs"":" "%" "P1"",%0" : "=r" (pfo_ret__) : "p" (&(current_task))); break; case 8: asm("mov" "q ""%%""gs"":" "%" "P1"",%0" : "=r" (pfo_ret__) : "p" (&(current_task))); break; default: __bad_percpu_size(); } pfo_ret__; });
}
# 14 "include/linux/mutex.h" 2
# 1 "include/linux/list.h" 1




# 1 "include/linux/stddef.h" 1
# 6 "include/linux/list.h" 2
# 1 "include/linux/poison.h" 1
# 7 "include/linux/list.h" 2
# 25 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void INIT_LIST_HEAD(struct list_head *list)
{
    list->next = list;
    list->prev = list;
}
# 38 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void __list_add(struct list_head *new,
struct list_head *prev,
struct list_head *next)
{
next->prev = new;
new->next = next;
new->prev = prev;
prev->next = new;
}
# 61 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void list_add(struct list_head *new, struct list_head *head)
{
__list_add(new, head, head->next);
}
# 75 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void list_add_tail(struct list_head *new, struct list_head *head)
{
__list_add(new, head->prev, head);
}
# 87 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void __list_del(struct list_head * prev, struct list_head * next)
{
    next->prev = prev;
    prev->next = next;
}
# 100 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void __list_del_entry(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
}

static inline __attribute__((no_instrument_function)) void list_del(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
    entry->next = ((void *) 0x00100100 + (0xdead000000000000UL));
    entry->prev = ((void *) 0x00200200 + (0xdead000000000000UL));
}
# 123 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void list_replace(struct list_head *old,
                                                                        struct list_head *new)
{
new->next = old->next;
new->next->prev = new;
new->prev = old->prev;
new->prev->next = new;
}

static inline __attribute__((no_instrument_function)) void list_replace_init(struct list_head *old,
                                                                             struct list_head *new)
{
list_replace(old, new);
INIT_LIST_HEAD(old);
}





static inline __attribute__((no_instrument_function)) void list_del_init(struct list_head *entry)
{
    __list_del_entry(entry);
    INIT_LIST_HEAD(entry);
}






static inline __attribute__((no_instrument_function)) void list_move(struct list_head *list, struct list_head *head)
{
    __list_del_entry(list);
    list_add(list, head);
}






static inline __attribute__((no_instrument_function)) void list_move_tail(struct list_head *list,
                                                                          struct list_head *head)
{
    __list_del_entry(list);
    list_add_tail(list, head);
}






static inline __attribute__((no_instrument_function)) int list_is_last(const struct list_head *list,
                                                                       const struct list_head *head)
{
    return list->next == head;
}





static inline __attribute__((no_instrument_function)) int list_empty(const struct list_head *head)
{
    return head->next == head;
}
# 205 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) int list_empty_careful(const struct list_head *head)
{
    struct list_head *next = head->next;
    return (next == head) && (next == head->prev);
}





static inline __attribute__((no_instrument_function)) void list_rotate_left(struct list_head *head)
{
    struct list_head *first;

    if (!list_empty(head)) {
        first = head->next;
        list_move_tail(first, head);
    }
}





static inline __attribute__((no_instrument_function)) int list_is_singular(const struct list_head *head)
{
    return !list_empty(head) && (head->next == head->prev);
}

static inline __attribute__((no_instrument_function)) void __list_cut_position(struct list_head *list,
                                                                               struct list_head *head, struct list_head *entry)
{
    struct list_head *new_first = entry->next;
    list->next = head->next;
    list->next->prev = list;
    list->prev = entry;
    entry->next = list;
    head->next = new_first;
    new_first->prev = head;
}
# 260 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void list_cut_position(struct list_head *list,
                                                                             struct list_head *head, struct list_head *entry)
{
    if (list_empty(head))
        return;
    if (list_is_singular(head) &&
        (head->next != entry && head != entry))
        return;
    if (entry == head)
        INIT_LIST_HEAD(list);
    else
        __list_cut_position(list, head, entry);
}

static inline __attribute__((no_instrument_function)) void __list_splice(const struct list_head *list,
                                                                         struct list_head *prev,
                                                                         struct list_head *next)
{
    struct list_head *first = list->next;
    struct list_head *last = list->prev;

    first->prev = prev;
    prev->next = first;

    last->next = next;
    next->prev = last;
}






static inline __attribute__((no_instrument_function)) void list_splice(const struct list_head *list,
                                                                       struct list_head *head)
{
    if (!list_empty(list))
        __list_splice(list, head, head->next);
}






static inline __attribute__((no_instrument_function)) void list_splice_tail(struct list_head *list,
                                                                            struct list_head *head)
{
    if (!list_empty(list))
        __list_splice(list, head->prev, head);
}
# 319 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void list_splice_init(struct list_head *list,
                                                                            struct list_head *head)
{
    if (!list_empty(list)) {
        __list_splice(list, head, head->next);
        INIT_LIST_HEAD(list);
    }
}
# 336 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void list_splice_tail_init(struct list_head *list,
                                                                                 struct list_head *head)
{
    if (!list_empty(list)) {
        __list_splice(list, head->prev, head);
        INIT_LIST_HEAD(list);
    }
}
# 598 "include/linux/list.h"
static inline __attribute__((no_instrument_function)) void INIT_HLIST_NODE(struct hlist_node *h)
{
    h->next = ((void *)0);
    h->pprev = ((void *)0);
}

static inline __attribute__((no_instrument_function)) int hlist_unhashed(const struct hlist_node *h)
{
    return !h->pprev;
}

static inline __attribute__((no_instrument_function)) int hlist_empty(const struct hlist_head *h)
{
    return !h->first;
}

static inline __attribute__((no_instrument_function)) void __hlist_del(struct hlist_node *n)
{
    struct hlist_node *next = n->next;
    struct hlist_node **pprev = n->pprev;
    *pprev = next;
    if (next)
        next->pprev = pprev;
}

static inline __attribute__((no_instrument_function)) void hlist_del(struct hlist_node *n)
{
    __hlist_del(n);
    n->next = ((void *) 0x00100100 + (0xdead000000000000UL));
    n->pprev = ((void *) 0x00200200 + (0xdead000000000000UL));
}

static inline __attribute__((no_instrument_function)) void hlist_del_init(struct hlist_node *n)
{
    if (!hlist_unhashed(n)) {
        __hlist_del(n);
        INIT_HLIST_NODE(n);
    }
}

static inline __attribute__((no_instrument_function)) void hlist_add_head(struct hlist_node *n, struct hlist_head *h)
{
    struct hlist_node *first = h->first;
    n->next = first;
    if (first)
        first->pprev = &n->next;
    h->first = n;
    n->pprev = &h->first;
}


static inline __attribute__((no_instrument_function)) void hlist_add_before(struct hlist_node *n,
                                                                            struct hlist_node *next)
{
    n->pprev = next->pprev;
    n->next = next;
    next->pprev = &n->next;
    *(n->pprev) = n;
}

static inline __attribute__((no_instrument_function)) void hlist_add_behind(struct hlist_node *n,
                                                                            struct hlist_node *prev)
{
    n->next = prev->next;
    prev->next = n;
    n->pprev = &prev->next;

    if (n->next)
        n->next->pprev = &n->next;
}


static inline __attribute__((no_instrument_function)) void hlist_add_fake(struct hlist_node *n)
{
    n->pprev = &n->next;
}





static inline __attribute__((no_instrument_function)) void hlist_move_list(struct hlist_head *old,
                                                                           struct hlist_head *new)
{
new->first = old->first;
if (new->first)
new->first->pprev = &new->first;
old->first = ((void *)0);
}
# 15 "include/linux/mutex.h" 2
# 1 "include/linux/spinlock_types.h" 1
# 13 "include/linux/spinlock_types.h"
# 1 "./arch/x86/include/asm/spinlock_types.h" 1
# 15 "./arch/x86/include/asm/spinlock_types.h"
typedef u8 __ticket_t;
typedef u16 __ticketpair_t;
# 26 "./arch/x86/include/asm/spinlock_types.h"
typedef struct arch_spinlock {
    union {
        __ticketpair_t head_tail;
        struct __raw_tickets {
            __ticket_t head, tail;
        } tickets;
    };
} arch_spinlock_t;



# 1 "include/asm-generic/qrwlock_types.h" 1




# 1 "./arch/x86/include/asm/spinlock_types.h" 1
# 6 "include/asm-generic/qrwlock_types.h" 2





typedef struct qrwlock {
    atomic_t cnts;
    arch_spinlock_t lock;
} arch_rwlock_t;
# 38 "./arch/x86/include/asm/spinlock_types.h" 2
# 14 "include/linux/spinlock_types.h" 2




# 1 "include/linux/lockdep.h" 1
# 12 "include/linux/lockdep.h"
struct task_struct;
struct lockdep_map;


extern int prove_locking;
extern int lock_stat;
# 373 "include/linux/lockdep.h"
static inline __attribute__((no_instrument_function)) void lockdep_off(void)
{
}

static inline __attribute__((no_instrument_function)) void lockdep_on(void)
{
}
# 414 "include/linux/lockdep.h"
struct lock_class_key { };
# 469 "include/linux/lockdep.h"
static inline __attribute__((no_instrument_function)) void print_irqtrace_events(struct task_struct *curr)
{
}
# 537 "include/linux/lockdep.h"
static inline __attribute__((no_instrument_function)) void
lockdep_rcu_suspicious(const char *file, const int line, const char *s)
{
}
# 19 "include/linux/spinlock_types.h" 2

typedef struct raw_spinlock {
    arch_spinlock_t raw_lock;
# 32 "include/linux/spinlock_types.h"
} raw_spinlock_t;
# 64 "include/linux/spinlock_types.h"
typedef struct spinlock {
    union {
        struct raw_spinlock rlock;
# 75 "include/linux/spinlock_types.h"
    };
} spinlock_t;
# 86 "include/linux/spinlock_types.h"
# 1 "include/linux/rwlock_types.h" 1
# 11 "include/linux/rwlock_types.h"
typedef struct {
    arch_rwlock_t raw_lock;
# 23 "include/linux/rwlock_types.h"
} rwlock_t;
# 87 "include/linux/spinlock_types.h" 2
# 16 "include/linux/mutex.h" 2


# 1 "include/linux/atomic.h" 1



# 1 "./arch/x86/include/asm/atomic.h" 1





# 1 "./arch/x86/include/asm/processor.h" 1






struct task_struct;
struct mm_struct;

# 1 "./arch/x86/include/asm/vm86.h" 1





# 1 "./arch/x86/include/uapi/asm/vm86.h" 1
# 62 "./arch/x86/include/uapi/asm/vm86.h"
struct vm86_regs {



    long ebx;
    long ecx;
    long edx;
    long esi;
    long edi;
    long ebp;
    long eax;
    long __null_ds;
    long __null_es;
    long __null_fs;
    long __null_gs;
    long orig_eax;
    long eip;
    unsigned short cs, __csh;
    long eflags;
    long esp;
    unsigned short ss, __ssh;



    unsigned short es, __esh;
    unsigned short ds, __dsh;
    unsigned short fs, __fsh;
    unsigned short gs, __gsh;
};

struct revectored_struct {
    unsigned long __map[8];
};

struct vm86_struct {
    struct vm86_regs regs;
    unsigned long flags;
    unsigned long screen_bitmap;
    unsigned long cpu_type;
    struct revectored_struct int_revectored;
    struct revectored_struct int21_revectored;
};






struct vm86plus_info_struct {
    unsigned long force_return_for_pic:1;
    unsigned long vm86dbg_active:1;
    unsigned long vm86dbg_TFpendig:1;
    unsigned long unused:28;
    unsigned long is_vm86pus:1;
    unsigned char vm86dbg_intxxtab[32];
};
struct vm86plus_struct {
    struct vm86_regs regs;
    unsigned long flags;
    unsigned long screen_bitmap;
    unsigned long cpu_type;
    struct revectored_struct int_revectored;
    struct revectored_struct int21_revectored;
    struct vm86plus_info_struct vm86plus;
};
# 7 "./arch/x86/include/asm/vm86.h" 2
# 17 "./arch/x86/include/asm/vm86.h"
struct kernel_vm86_regs {



    struct pt_regs pt;



    unsigned short es, __esh;
    unsigned short ds, __dsh;
    unsigned short fs, __fsh;
    unsigned short gs, __gsh;
};

struct kernel_vm86_struct {
    struct kernel_vm86_regs regs;
# 42 "./arch/x86/include/asm/vm86.h"
    unsigned long flags;
    unsigned long screen_bitmap;
    unsigned long cpu_type;
    struct revectored_struct int_revectored;
    struct revectored_struct int21_revectored;
    struct vm86plus_info_struct vm86plus;
    struct pt_regs *regs32;
# 59 "./arch/x86/include/asm/vm86.h"
};
# 75 "./arch/x86/include/asm/vm86.h"
static inline __attribute__((no_instrument_function)) int handle_vm86_trap(struct kernel_vm86_regs *a, long b, int c)
{
    return 0;
}
# 11 "./arch/x86/include/asm/processor.h" 2
# 1 "./arch/x86/include/asm/math_emu.h" 1
# 11 "./arch/x86/include/asm/math_emu.h"
struct math_emu_info {
    long ___orig_eip;
    union {
        struct pt_regs *regs;
        struct kernel_vm86_regs *vm86;
    };
};
# 12 "./arch/x86/include/asm/processor.h" 2


# 1 "./arch/x86/include/asm/sigcontext.h" 1



# 1 "./arch/x86/include/uapi/asm/sigcontext.h" 1
# 23 "./arch/x86/include/uapi/asm/sigcontext.h"
struct _fpx_sw_bytes {
    __u32 magic1;
    __u32 extended_size;


    __u64 xstate_bv;




    __u32 xstate_size;




    __u32 padding[7];
};
# 136 "./arch/x86/include/uapi/asm/sigcontext.h"
struct _fpstate {
    __u16 cwd;
    __u16 swd;
    __u16 twd;

    __u16 fop;
    __u64 rip;
    __u64 rdp;
    __u32 mxcsr;
    __u32 mxcsr_mask;
    __u32 st_space[32];
    __u32 xmm_space[64];
    __u32 reserved2[12];
    union {
        __u32 reserved3[12];
        struct _fpx_sw_bytes sw_reserved;

    };
};
# 212 "./arch/x86/include/uapi/asm/sigcontext.h"
struct _xsave_hdr {
    __u64 xstate_bv;
    __u64 reserved1[2];
    __u64 reserved2[5];
};

struct _ymmh_state {

    __u32 ymmh_space[64];
};







struct _xstate {
    struct _fpstate fpstate;
    struct _xsave_hdr xstate_hdr;
    struct _ymmh_state ymmh;

};
# 5 "./arch/x86/include/asm/sigcontext.h" 2
# 40 "./arch/x86/include/asm/sigcontext.h"
struct sigcontext {
    unsigned long r8;
    unsigned long r9;
    unsigned long r10;
    unsigned long r11;
    unsigned long r12;
    unsigned long r13;
    unsigned long r14;
    unsigned long r15;
    unsigned long di;
    unsigned long si;
    unsigned long bp;
    unsigned long bx;
    unsigned long dx;
    unsigned long ax;
    unsigned long cx;
    unsigned long sp;
    unsigned long ip;
    unsigned long flags;
    unsigned short cs;
    unsigned short __pad2;
    unsigned short __pad1;
    unsigned short ss;
    unsigned long err;
    unsigned long trapno;
    unsigned long oldmask;
    unsigned long cr2;
# 75 "./arch/x86/include/asm/sigcontext.h"
    void *fpstate;
    unsigned long reserved1[8];
};
# 15 "./arch/x86/include/asm/processor.h" 2


# 1 "./arch/x86/include/asm/page.h" 1
# 11 "./arch/x86/include/asm/page.h"
# 1 "./arch/x86/include/asm/page_64.h" 1
# 9 "./arch/x86/include/asm/page_64.h"
extern unsigned long max_pfn;
extern unsigned long phys_base;

static inline __attribute__((no_instrument_function)) unsigned long __phys_addr_nodebug(unsigned long x)
{
    unsigned long y = x - (0xffffffff80000000UL);


    x = y + ((x > y) ? phys_base : ((0xffffffff80000000UL) - ((unsigned long)(0xffff880000000000UL))));

    return x;
}
# 37 "./arch/x86/include/asm/page_64.h"
void clear_page(void *page);
void copy_page(void *to, void *from);
# 12 "./arch/x86/include/asm/page.h" 2






struct page;

# 1 "include/linux/range.h" 1



struct range {
    u64 start;
    u64 end;
};

int add_range(struct range *range, int az, int nr_range,
              u64 start, u64 end);


int add_range_with_merge(struct range *range, int az, int nr_range,
                         u64 start, u64 end);

void subtract_range(struct range *range, int az, u64 start, u64 end);

int clean_sort_range(struct range *range, int az);

void sort_range(struct range *range, int nr_range);


static inline __attribute__((no_instrument_function)) resource_size_t cap_resource(u64 val)
{
    if (val > ((resource_size_t)~0))
        return ((resource_size_t)~0);

    return val;
}
# 21 "./arch/x86/include/asm/page.h" 2
extern struct range pfn_mapped[];
extern int nr_pfn_mapped;

static inline __attribute__((no_instrument_function)) void clear_user_page(void *page, unsigned long vaddr,
                                                                           struct page *pg)
{
    clear_page(page);
}

static inline __attribute__((no_instrument_function)) void copy_user_page(void *to, void *from, unsigned long vaddr,
                                                                          struct page *topage)
{
    copy_page(to, from);
}
# 65 "./arch/x86/include/asm/page.h"
extern bool __virt_addr_valid(unsigned long kaddr);




# 1 "include/asm-generic/memory_model.h" 1
# 71 "./arch/x86/include/asm/page.h" 2
# 1 "include/asm-generic/getorder.h" 1
# 12 "include/asm-generic/getorder.h"
static inline __attribute__((no_instrument_function)) __attribute__((__const__))
int __get_order(unsigned long size)
{
    int order;

    size--;
    size >>= 12;



    order = fls64(size);

    return order;
}
# 72 "./arch/x86/include/asm/page.h" 2
# 18 "./arch/x86/include/asm/processor.h" 2
# 1 "./arch/x86/include/asm/pgtable_types.h" 1
# 114 "./arch/x86/include/asm/pgtable_types.h"
enum page_cache_mode {
    _PAGE_CACHE_MODE_WB = 0,
    _PAGE_CACHE_MODE_WC = 1,
    _PAGE_CACHE_MODE_UC_MINUS = 2,
    _PAGE_CACHE_MODE_UC = 3,
    _PAGE_CACHE_MODE_WT = 4,
    _PAGE_CACHE_MODE_WP = 5,
    _PAGE_CACHE_MODE_NUM = 8
};
# 205 "./arch/x86/include/asm/pgtable_types.h"
# 1 "./arch/x86/include/asm/pgtable_64_types.h" 1



# 1 "./arch/x86/include/asm/sparsemem.h" 1
# 5 "./arch/x86/include/asm/pgtable_64_types.h" 2







typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;

typedef struct { pteval_t pte; } pte_t;
# 206 "./arch/x86/include/asm/pgtable_types.h" 2
# 218 "./arch/x86/include/asm/pgtable_types.h"
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;

typedef struct { pgdval_t pgd; } pgd_t;

static inline __attribute__((no_instrument_function)) pgd_t native_make_pgd(pgdval_t val)
{
    return (pgd_t) { val };
}

static inline __attribute__((no_instrument_function)) pgdval_t native_pgd_val(pgd_t pgd)
{
    return pgd.pgd;
}

static inline __attribute__((no_instrument_function)) pgdval_t pgd_flags(pgd_t pgd)
{
    return native_pgd_val(pgd) & (~((pteval_t)(((signed long)(~(((1UL) << 12)-1))) & ((phys_addr_t)((1ULL << 46) - 1)))));
}


typedef struct { pudval_t pud; } pud_t;

static inline __attribute__((no_instrument_function)) pud_t native_make_pud(pmdval_t val)
{
    return (pud_t) { val };
}

static inline __attribute__((no_instrument_function)) pudval_t native_pud_val(pud_t pud)
{
    return pud.pud;
}
# 259 "./arch/x86/include/asm/pgtable_types.h"
typedef struct { pmdval_t pmd; } pmd_t;

static inline __attribute__((no_instrument_function)) pmd_t native_make_pmd(pmdval_t val)
{
    return (pmd_t) { val };
}

static inline __attribute__((no_instrument_function)) pmdval_t native_pmd_val(pmd_t pmd)
{
    return pmd.pmd;
}
# 279 "./arch/x86/include/asm/pgtable_types.h"
static inline __attribute__((no_instrument_function)) pudval_t pud_flags(pud_t pud)
{
    return native_pud_val(pud) & (~((pteval_t)(((signed long)(~(((1UL) << 12)-1))) & ((phys_addr_t)((1ULL << 46) - 1)))));
}

static inline __attribute__((no_instrument_function)) pmdval_t pmd_flags(pmd_t pmd)
{
    return native_pmd_val(pmd) & (~((pteval_t)(((signed long)(~(((1UL) << 12)-1))) & ((phys_addr_t)((1ULL << 46) - 1)))));
}

static inline __attribute__((no_instrument_function)) pte_t native_make_pte(pteval_t val)
{
    return (pte_t) { .pte = val };
}

static inline __attribute__((no_instrument_function)) pteval_t native_pte_val(pte_t pte)
{
    return pte.pte;
}

static inline __attribute__((no_instrument_function)) pteval_t pte_flags(pte_t pte)
{
    return native_pte_val(pte) & (~((pteval_t)(((signed long)(~(((1UL) << 12)-1))) & ((phys_addr_t)((1ULL << 46) - 1)))));
}




extern uint16_t __cachemode2pte_tbl[_PAGE_CACHE_MODE_NUM];
extern uint8_t __pte2cachemode_tbl[8];
# 319 "./arch/x86/include/asm/pgtable_types.h"
static inline __attribute__((no_instrument_function)) unsigned long cachemode2protval(enum page_cache_mode pcm)
{
    if (__builtin_expect(!!(pcm == 0), 1))
        return 0;
    return __cachemode2pte_tbl[pcm];
}
static inline __attribute__((no_instrument_function)) pgprot_t cachemode2pgprot(enum page_cache_mode pcm)
{
    return ((pgprot_t) { (cachemode2protval(pcm)) } );
}
static inline __attribute__((no_instrument_function)) enum page_cache_mode pgprot2cachemode(pgprot_t pgprot)
{
    unsigned long masked;

    masked = ((pgprot).pgprot) & ((((pteval_t)(1)) << 7) | (((pteval_t)(1)) << 4) | (((pteval_t)(1)) << 3));
    if (__builtin_expect(!!(masked == 0), 1))
        return 0;
    return __pte2cachemode_tbl[((((masked) >> (7 - 2)) & 4) | (((masked) >> (4 - 1)) & 2) | (((masked) >> 3) & 1))];
}
static inline __attribute__((no_instrument_function)) pgprot_t pgprot_4k_2_large(pgprot_t pgprot)
{
    pgprot_t new;
    unsigned long val;

    val = ((pgprot).pgprot);
    ((new).pgprot) = (val & ~((((pteval_t)(1)) << 7) | (((pteval_t)(1)) << 12))) |
                     ((val & (((pteval_t)(1)) << 7)) << (12 - 7));
    return new;
}
static inline __attribute__((no_instrument_function)) pgprot_t pgprot_large_2_4k(pgprot_t pgprot)
{
    pgprot_t new;
    unsigned long val;

    val = ((pgprot).pgprot);
    ((new).pgprot) = (val & ~((((pteval_t)(1)) << 7) | (((pteval_t)(1)) << 12))) |
                     ((val & (((pteval_t)(1)) << 12)) >>
                                                      (12 - 7));
    return new;
}


typedef struct page *pgtable_t;

extern pteval_t __supported_pte_mask;
extern void set_nx(void);
extern int nx_enabled;


extern pgprot_t pgprot_writecombine(pgprot_t prot);





struct file;
pgprot_t phys_mem_access_prot(struct file *file, unsigned long pfn,
                              unsigned long size, pgprot_t vma_prot);
int phys_mem_access_prot_allowed(struct file *file, unsigned long pfn,
                                 unsigned long size, pgprot_t *vma_prot);


void set_pte_vaddr(unsigned long vaddr, pte_t pte);







struct seq_file;
extern void arch_report_meminfo(struct seq_file *m);

enum pg_level {
    PG_LEVEL_NONE,
    PG_LEVEL_4K,
    PG_LEVEL_2M,
    PG_LEVEL_1G,
    PG_LEVEL_NUM
};


extern void update_page_count(int level, unsigned long pages);
# 412 "./arch/x86/include/asm/pgtable_types.h"
extern pte_t *lookup_address(unsigned long address, unsigned int *level);
extern pte_t *lookup_address_in_pgd(pgd_t *pgd, unsigned long address,
                                    unsigned int *level);
extern pmd_t *lookup_pmd_address(unsigned long address);
extern phys_addr_t slow_virt_to_phys(void *__address);
extern int kernel_map_pages_in_pgd(pgd_t *pgd, u64 pfn, unsigned long address,
                                   unsigned numpages, unsigned long page_flags);
void kernel_unmap_pages_in_pgd(pgd_t *root, unsigned long address,
                               unsigned numpages);
# 19 "./arch/x86/include/asm/processor.h" 2

# 1 "./arch/x86/include/asm/msr.h" 1



# 1 "./arch/x86/include/uapi/asm/msr.h" 1



# 1 "./arch/x86/include/uapi/asm/msr-index.h" 1
# 5 "./arch/x86/include/uapi/asm/msr.h" 2




# 1 "./include/uapi/linux/ioctl.h" 1



# 1 "./arch/x86/include/uapi/asm/ioctl.h" 1
# 1 "include/asm-generic/ioctl.h" 1



# 1 "include/uapi/asm-generic/ioctl.h" 1
# 5 "include/asm-generic/ioctl.h" 2





extern unsigned int __invalid_size_argument_for_IOC;
# 1 "./arch/x86/include/uapi/asm/ioctl.h" 2
# 5 "./include/uapi/linux/ioctl.h" 2
# 10 "./arch/x86/include/uapi/asm/msr.h" 2
# 5 "./arch/x86/include/asm/msr.h" 2




# 1 "./arch/x86/include/uapi/asm/errno.h" 1
# 10 "./arch/x86/include/asm/msr.h" 2
# 1 "./arch/x86/include/asm/cpumask.h" 1



# 1 "include/linux/cpumask.h" 1
# 11 "include/linux/cpumask.h"
# 1 "include/linux/bitmap.h" 1
# 90 "include/linux/bitmap.h"
extern int __bitmap_empty(const unsigned long *bitmap, unsigned int nbits);
extern int __bitmap_full(const unsigned long *bitmap, unsigned int nbits);
extern int __bitmap_equal(const unsigned long *bitmap1,
                          const unsigned long *bitmap2, unsigned int nbits);
extern void __bitmap_complement(unsigned long *dst, const unsigned long *src,
                                unsigned int nbits);
extern void __bitmap_shift_right(unsigned long *dst, const unsigned long *src,
                                 unsigned int shift, unsigned int nbits);
extern void __bitmap_shift_left(unsigned long *dst, const unsigned long *src,
                                unsigned int shift, unsigned int nbits);
extern int __bitmap_and(unsigned long *dst, const unsigned long *bitmap1,
                        const unsigned long *bitmap2, unsigned int nbits);
extern void __bitmap_or(unsigned long *dst, const unsigned long *bitmap1,
                        const unsigned long *bitmap2, unsigned int nbits);
extern void __bitmap_xor(unsigned long *dst, const unsigned long *bitmap1,
                         const unsigned long *bitmap2, unsigned int nbits);
extern int __bitmap_andnot(unsigned long *dst, const unsigned long *bitmap1,
                           const unsigned long *bitmap2, unsigned int nbits);
extern int __bitmap_intersects(const unsigned long *bitmap1,
                               const unsigned long *bitmap2, unsigned int nbits);
extern int __bitmap_subset(const unsigned long *bitmap1,
                           const unsigned long *bitmap2, unsigned int nbits);
extern int __bitmap_weight(const unsigned long *bitmap, unsigned int nbits);

extern void bitmap_set(unsigned long *map, unsigned int start, int len);
extern void bitmap_clear(unsigned long *map, unsigned int start, int len);

extern unsigned long bitmap_find_next_zero_area_off(unsigned long *map,
                                                    unsigned long size,
                                                    unsigned long start,
                                                    unsigned int nr,
                                                    unsigned long align_mask,
                                                    unsigned long align_offset);
# 136 "include/linux/bitmap.h"
static inline __attribute__((no_instrument_function)) unsigned long
bitmap_find_next_zero_area(unsigned long *map,
                           unsigned long size,
                           unsigned long start,
                           unsigned int nr,
                           unsigned long align_mask)
{
    return bitmap_find_next_zero_area_off(map, size, start, nr,
                                          align_mask, 0);
}

extern int __bitmap_parse(const char *buf, unsigned int buflen, int is_user,
                          unsigned long *dst, int nbits);
extern int bitmap_parse_user(const char *ubuf, unsigned int ulen,
                             unsigned long *dst, int nbits);
extern int bitmap_parselist(const char *buf, unsigned long *maskp,
                            int nmaskbits);
extern int bitmap_parselist_user(const char *ubuf, unsigned int ulen,
                                 unsigned long *dst, int nbits);
extern void bitmap_remap(unsigned long *dst, const unsigned long *src,
                         const unsigned long *old, const unsigned long *new, unsigned int nbits);
extern int bitmap_bitremap(int oldbit,
                           const unsigned long *old, const unsigned long *new, int bits);
extern void bitmap_onto(unsigned long *dst, const unsigned long *orig,
                        const unsigned long *relmap, unsigned int bits);
extern void bitmap_fold(unsigned long *dst, const unsigned long *orig,
                        unsigned int sz, unsigned int nbits);
extern int bitmap_find_free_region(unsigned long *bitmap, unsigned int bits, int order);
extern void bitmap_release_region(unsigned long *bitmap, unsigned int pos, int order);
extern int bitmap_allocate_region(unsigned long *bitmap, unsigned int pos, int order);





extern unsigned int bitmap_ord_to_pos(const unsigned long *bitmap, unsigned int ord, unsigned int nbits);
extern int bitmap_print_to_pagebuf(bool list, char *buf,
                                   const unsigned long *maskp, int nmaskbits);







static inline __attribute__((no_instrument_function)) void bitmap_zero(unsigned long *dst, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        *dst = 0UL;
    else {
        unsigned int len = (((nbits) + (8 * sizeof(long)) - 1) / (8 * sizeof(long))) * sizeof(unsigned long);
        memset(dst, 0, len);
    }
}

static inline __attribute__((no_instrument_function)) void bitmap_fill(unsigned long *dst, unsigned int nbits)
{
    unsigned int nlongs = (((nbits) + (8 * sizeof(long)) - 1) / (8 * sizeof(long)));
    if (!(__builtin_constant_p(nbits) && (nbits) <= 64)) {
        unsigned int len = (nlongs - 1) * sizeof(unsigned long);
        memset(dst, 0xff, len);
    }
    dst[nlongs - 1] = (~0UL >> (-(nbits) & (64 - 1)));
}

static inline __attribute__((no_instrument_function)) void bitmap_copy(unsigned long *dst, const unsigned long *src,
                                                                       unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        *dst = *src;
    else {
        unsigned int len = (((nbits) + (8 * sizeof(long)) - 1) / (8 * sizeof(long))) * sizeof(unsigned long);
        memcpy(dst, src, len);
    }
}

static inline __attribute__((no_instrument_function)) int bitmap_and(unsigned long *dst, const unsigned long *src1,
                                                                     const unsigned long *src2, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return (*dst = *src1 & *src2 & (~0UL >> (-(nbits) & (64 - 1)))) != 0;
    return __bitmap_and(dst, src1, src2, nbits);
}

static inline __attribute__((no_instrument_function)) void bitmap_or(unsigned long *dst, const unsigned long *src1,
                                                                     const unsigned long *src2, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        *dst = *src1 | *src2;
    else
        __bitmap_or(dst, src1, src2, nbits);
}

static inline __attribute__((no_instrument_function)) void bitmap_xor(unsigned long *dst, const unsigned long *src1,
                                                                      const unsigned long *src2, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        *dst = *src1 ^ *src2;
    else
        __bitmap_xor(dst, src1, src2, nbits);
}

static inline __attribute__((no_instrument_function)) int bitmap_andnot(unsigned long *dst, const unsigned long *src1,
                                                                        const unsigned long *src2, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return (*dst = *src1 & ~(*src2) & (~0UL >> (-(nbits) & (64 - 1)))) != 0;
    return __bitmap_andnot(dst, src1, src2, nbits);
}

static inline __attribute__((no_instrument_function)) void bitmap_complement(unsigned long *dst, const unsigned long *src,
                                                                             unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        *dst = ~(*src);
    else
        __bitmap_complement(dst, src, nbits);
}

static inline __attribute__((no_instrument_function)) int bitmap_equal(const unsigned long *src1,
                                                                       const unsigned long *src2, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return ! ((*src1 ^ *src2) & (~0UL >> (-(nbits) & (64 - 1))));
    else
        return __bitmap_equal(src1, src2, nbits);
}

static inline __attribute__((no_instrument_function)) int bitmap_intersects(const unsigned long *src1,
                                                                            const unsigned long *src2, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return ((*src1 & *src2) & (~0UL >> (-(nbits) & (64 - 1)))) != 0;
    else
        return __bitmap_intersects(src1, src2, nbits);
}

static inline __attribute__((no_instrument_function)) int bitmap_subset(const unsigned long *src1,
                                                                        const unsigned long *src2, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return ! ((*src1 & ~(*src2)) & (~0UL >> (-(nbits) & (64 - 1))));
    else
        return __bitmap_subset(src1, src2, nbits);
}

static inline __attribute__((no_instrument_function)) int bitmap_empty(const unsigned long *src, unsigned nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return ! (*src & (~0UL >> (-(nbits) & (64 - 1))));

    return find_first_bit(src, nbits) == nbits;
}

static inline __attribute__((no_instrument_function)) int bitmap_full(const unsigned long *src, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return ! (~(*src) & (~0UL >> (-(nbits) & (64 - 1))));

    return find_first_zero_bit(src, nbits) == nbits;
}

static inline __attribute__((no_instrument_function)) int bitmap_weight(const unsigned long *src, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        return hweight_long(*src & (~0UL >> (-(nbits) & (64 - 1))));
    return __bitmap_weight(src, nbits);
}

static inline __attribute__((no_instrument_function)) void bitmap_shift_right(unsigned long *dst, const unsigned long *src,
                                                                              unsigned int shift, int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        *dst = (*src & (~0UL >> (-(nbits) & (64 - 1)))) >> shift;
    else
        __bitmap_shift_right(dst, src, shift, nbits);
}

static inline __attribute__((no_instrument_function)) void bitmap_shift_left(unsigned long *dst, const unsigned long *src,
                                                                             unsigned int shift, unsigned int nbits)
{
    if ((__builtin_constant_p(nbits) && (nbits) <= 64))
        *dst = (*src << shift) & (~0UL >> (-(nbits) & (64 - 1)));
    else
        __bitmap_shift_left(dst, src, shift, nbits);
}

static inline __attribute__((no_instrument_function)) int bitmap_parse(const char *buf, unsigned int buflen,
                                                                       unsigned long *maskp, int nmaskbits)
{
    return __bitmap_parse(buf, buflen, 0, maskp, nmaskbits);
}
# 12 "include/linux/cpumask.h" 2
# 1 "include/linux/bug.h" 1



# 1 "./arch/x86/include/asm/bug.h" 1
# 35 "./arch/x86/include/asm/bug.h"
# 1 "include/asm-generic/bug.h" 1
# 18 "include/asm-generic/bug.h"
struct bug_entry {



    signed int bug_addr_disp;





    signed int file_disp;

    unsigned short line;

    unsigned short flags;
};
# 65 "include/asm-generic/bug.h"
extern __attribute__((format(printf, 3, 4)))
void warn_slowpath_fmt(const char *file, const int line,
                       const char *fmt, ...);
extern __attribute__((format(printf, 4, 5)))
void warn_slowpath_fmt_taint(const char *file, const int line, unsigned taint,
                             const char *fmt, ...);
extern void warn_slowpath_null(const char *file, const int line);
# 36 "./arch/x86/include/asm/bug.h" 2
# 5 "include/linux/bug.h" 2


enum bug_trap_type {
    BUG_TRAP_TYPE_NONE = 0,
    BUG_TRAP_TYPE_WARN = 1,
    BUG_TRAP_TYPE_BUG = 2,
};

struct pt_regs;
# 91 "include/linux/bug.h"
static inline __attribute__((no_instrument_function)) int is_warning_bug(const struct bug_entry *bug)
{
    return bug->flags & (1 << 0);
}

const struct bug_entry *find_bug(unsigned long bugaddr);

enum bug_trap_type report_bug(unsigned long bug_addr, struct pt_regs *regs);


int is_valid_bugaddr(unsigned long addr);
# 13 "include/linux/cpumask.h" 2


typedef struct cpumask { unsigned long bits[(((64) + (8 * sizeof(long)) - 1) / (8 * sizeof(long)))]; } cpumask_t;
# 37 "include/linux/cpumask.h"
extern int nr_cpu_ids;
# 88 "include/linux/cpumask.h"
extern const struct cpumask *const cpu_possible_mask;
extern const struct cpumask *const cpu_online_mask;
extern const struct cpumask *const cpu_present_mask;
extern const struct cpumask *const cpu_active_mask;
# 114 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) unsigned int cpumask_check(unsigned int cpu)
{



    return cpu;
}
# 174 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) unsigned int cpumask_first(const struct cpumask *srcp)
{
    return find_first_bit(((srcp)->bits), 64);
}
# 186 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) unsigned int cpumask_next(int n, const struct cpumask *srcp)
{

    if (n != -1)
        cpumask_check(n);
    return find_next_bit(((srcp)->bits), 64, n+1);
}
# 201 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) unsigned int cpumask_next_zero(int n, const struct cpumask *srcp)
{

    if (n != -1)
        cpumask_check(n);
    return find_next_zero_bit(((srcp)->bits), 64, n+1);
}

int cpumask_next_and(int n, const struct cpumask *, const struct cpumask *);
int cpumask_any_but(const struct cpumask *mask, unsigned int cpu);
int cpumask_set_cpu_local_first(int i, int numa_node, cpumask_t *dstp);
# 272 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) void cpumask_set_cpu(unsigned int cpu, struct cpumask *dstp)
{
    set_bit(cpumask_check(cpu), ((dstp)->bits));
}






static inline __attribute__((no_instrument_function)) void cpumask_clear_cpu(int cpu, struct cpumask *dstp)
{
    clear_bit(cpumask_check(cpu), ((dstp)->bits));
}
# 294 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_test_cpu(int cpu, const struct cpumask *cpumask)
{
    return (__builtin_constant_p((cpumask_check(cpu))) ? constant_test_bit((cpumask_check(cpu)), ((((cpumask))->bits))) : variable_test_bit((cpumask_check(cpu)), ((((cpumask))->bits))));
}
# 308 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_test_and_set_cpu(int cpu, struct cpumask *cpumask)
{
    return test_and_set_bit(cpumask_check(cpu), ((cpumask)->bits));
}
# 322 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_test_and_clear_cpu(int cpu, struct cpumask *cpumask)
{
    return test_and_clear_bit(cpumask_check(cpu), ((cpumask)->bits));
}





static inline __attribute__((no_instrument_function)) void cpumask_setall(struct cpumask *dstp)
{
    bitmap_fill(((dstp)->bits), 64);
}





static inline __attribute__((no_instrument_function)) void cpumask_clear(struct cpumask *dstp)
{
    bitmap_zero(((dstp)->bits), 64);
}
# 353 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_and(struct cpumask *dstp,
                                                                      const struct cpumask *src1p,
                                                                      const struct cpumask *src2p)
{
    return bitmap_and(((dstp)->bits), ((src1p)->bits),
                      ((src2p)->bits), 64);
}







static inline __attribute__((no_instrument_function)) void cpumask_or(struct cpumask *dstp, const struct cpumask *src1p,
                                                                      const struct cpumask *src2p)
{
    bitmap_or(((dstp)->bits), ((src1p)->bits),
              ((src2p)->bits), 64);
}







static inline __attribute__((no_instrument_function)) void cpumask_xor(struct cpumask *dstp,
                                                                       const struct cpumask *src1p,
                                                                       const struct cpumask *src2p)
{
    bitmap_xor(((dstp)->bits), ((src1p)->bits),
               ((src2p)->bits), 64);
}
# 396 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_andnot(struct cpumask *dstp,
                                                                         const struct cpumask *src1p,
                                                                         const struct cpumask *src2p)
{
    return bitmap_andnot(((dstp)->bits), ((src1p)->bits),
                         ((src2p)->bits), 64);
}






static inline __attribute__((no_instrument_function)) void cpumask_complement(struct cpumask *dstp,
                                                                              const struct cpumask *srcp)
{
    bitmap_complement(((dstp)->bits), ((srcp)->bits),
                      64);
}






static inline __attribute__((no_instrument_function)) bool cpumask_equal(const struct cpumask *src1p,
                                                                         const struct cpumask *src2p)
{
    return bitmap_equal(((src1p)->bits), ((src2p)->bits),
                        64);
}






static inline __attribute__((no_instrument_function)) bool cpumask_intersects(const struct cpumask *src1p,
                                                                              const struct cpumask *src2p)
{
    return bitmap_intersects(((src1p)->bits), ((src2p)->bits),
                             64);
}
# 447 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_subset(const struct cpumask *src1p,
                                                                         const struct cpumask *src2p)
{
    return bitmap_subset(((src1p)->bits), ((src2p)->bits),
                         64);
}





static inline __attribute__((no_instrument_function)) bool cpumask_empty(const struct cpumask *srcp)
{
    return bitmap_empty(((srcp)->bits), 64);
}





static inline __attribute__((no_instrument_function)) bool cpumask_full(const struct cpumask *srcp)
{
    return bitmap_full(((srcp)->bits), 64);
}





static inline __attribute__((no_instrument_function)) unsigned int cpumask_weight(const struct cpumask *srcp)
{
    return bitmap_weight(((srcp)->bits), 64);
}







static inline __attribute__((no_instrument_function)) void cpumask_shift_right(struct cpumask *dstp,
                                                                               const struct cpumask *srcp, int n)
{
    bitmap_shift_right(((dstp)->bits), ((srcp)->bits), n,
                       64);
}







static inline __attribute__((no_instrument_function)) void cpumask_shift_left(struct cpumask *dstp,
                                                                              const struct cpumask *srcp, int n)
{
    bitmap_shift_left(((dstp)->bits), ((srcp)->bits), n,
                      64);
}






static inline __attribute__((no_instrument_function)) void cpumask_copy(struct cpumask *dstp,
                                                                        const struct cpumask *srcp)
{
    bitmap_copy(((dstp)->bits), ((srcp)->bits), 64);
}
# 558 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_parse_user(const char *buf, int len,
                                                                             struct cpumask *dstp)
{
    return bitmap_parse_user(buf, len, ((dstp)->bits), nr_cpu_ids);
}
# 572 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_parselist_user(const char *buf, int len,
                                                                                 struct cpumask *dstp)
{
    return bitmap_parselist_user(buf, len, ((dstp)->bits),
                                 nr_cpu_ids);
}
# 586 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpumask_parse(const char *buf, struct cpumask *dstp)
{
    char *nl = strchr(buf, '\n');
    unsigned int len = nl ? (unsigned int)(nl - buf) : strlen(buf);

    return bitmap_parse(buf, len, ((dstp)->bits), nr_cpu_ids);
}
# 601 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int cpulist_parse(const char *buf, struct cpumask *dstp)
{
    return bitmap_parselist(buf, ((dstp)->bits), nr_cpu_ids);
}






static inline __attribute__((no_instrument_function)) size_t cpumask_size(void)
{
    return (((64) + (8 * sizeof(long)) - 1) / (8 * sizeof(long))) * sizeof(long);
}
# 667 "include/linux/cpumask.h"
typedef struct cpumask cpumask_var_t[1];



static inline __attribute__((no_instrument_function)) bool alloc_cpumask_var(cpumask_var_t *mask, gfp_t flags)
{
    return true;
}

static inline __attribute__((no_instrument_function)) bool alloc_cpumask_var_node(cpumask_var_t *mask, gfp_t flags,
                                                                                  int node)
{
    return true;
}

static inline __attribute__((no_instrument_function)) bool zalloc_cpumask_var(cpumask_var_t *mask, gfp_t flags)
{
    cpumask_clear(*mask);
    return true;
}

static inline __attribute__((no_instrument_function)) bool zalloc_cpumask_var_node(cpumask_var_t *mask, gfp_t flags,
                                                                                   int node)
{
    cpumask_clear(*mask);
    return true;
}

static inline __attribute__((no_instrument_function)) void alloc_bootmem_cpumask_var(cpumask_var_t *mask)
{
}

static inline __attribute__((no_instrument_function)) void free_cpumask_var(cpumask_var_t mask)
{
}

static inline __attribute__((no_instrument_function)) void free_bootmem_cpumask_var(cpumask_var_t mask)
{
}




extern const unsigned long cpu_all_bits[(((64) + (8 * sizeof(long)) - 1) / (8 * sizeof(long)))];
# 721 "include/linux/cpumask.h"
void set_cpu_possible(unsigned int cpu, bool possible);
void set_cpu_present(unsigned int cpu, bool present);
void set_cpu_online(unsigned int cpu, bool online);
void set_cpu_active(unsigned int cpu, bool active);
void init_cpu_present(const struct cpumask *src);
void init_cpu_possible(const struct cpumask *src);
void init_cpu_online(const struct cpumask *src);
# 743 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) int __check_is_bitmap(const unsigned long *bitmap)
{
    return 1;
}
# 755 "include/linux/cpumask.h"
extern const unsigned long
        cpu_bit_bitmap[64 +1][(((64) + (8 * sizeof(long)) - 1) / (8 * sizeof(long)))];

static inline __attribute__((no_instrument_function)) const struct cpumask *get_cpu_mask(unsigned int cpu)
{
    const unsigned long *p = cpu_bit_bitmap[1 + cpu % 64];
    p -= cpu / 64;
    return ((struct cpumask *)(1 ? (p) : (void *)sizeof(__check_is_bitmap(p))));
}
# 792 "include/linux/cpumask.h"
static inline __attribute__((no_instrument_function)) ssize_t
cpumap_print_to_pagebuf(bool list, char *buf, const struct cpumask *mask)
{
    return bitmap_print_to_pagebuf(list, buf, ((mask)->bits),
                                   nr_cpu_ids);
}
# 5 "./arch/x86/include/asm/cpumask.h" 2

extern cpumask_var_t cpu_callin_mask;
extern cpumask_var_t cpu_callout_mask;
extern cpumask_var_t cpu_initialized_mask;
extern cpumask_var_t cpu_sibling_setup_mask;

extern void setup_cpu_local_masks(void);
# 11 "./arch/x86/include/asm/msr.h" 2

struct msr {
    union {
        struct {
            u32 l;
            u32 h;
        };
        u64 q;
    };
};

struct msr_info {
    u32 msr_no;
    struct msr reg;
    struct msr *msrs;
    int err;
};

struct msr_regs_info {
    u32 *regs;
    int err;
};

static inline __attribute__((no_instrument_function)) unsigned long long native_read_tscp(unsigned int *aux)
{
    unsigned long low, high;
    asm volatile(".byte 0x0f,0x01,0xf9"
            : "=a" (low), "=d" (high), "=c" (*aux));
    return low | ((u64)high << 32);
}
# 60 "./arch/x86/include/asm/msr.h"
static inline __attribute__((no_instrument_function)) unsigned long long native_read_msr(unsigned int msr)
{
    unsigned low, high;

    asm volatile("rdmsr" : "=a" (low), "=d" (high) : "c" (msr));
    return ((low) | ((u64)(high) << 32));
}

static inline __attribute__((no_instrument_function)) unsigned long long native_read_msr_safe(unsigned int msr,
                                                                                              int *err)
{
    unsigned low, high;

    asm volatile("2: rdmsr ; xor %[err],%[err]\n"
                 "1:\n\t"
                 ".section .fixup,\"ax\"\n\t"
                 "3:  mov %[fault],%[err] ; jmp 1b\n\t"
                 ".previous\n\t"
                 " .pushsection \"__ex_table\",\"a\"\n" " .balign 8\n" " .long (" "2b" ") - .\n" " .long (" "3b" ") - .\n" " .popsection\n"
            : [err] "=r" (*err), "=a" (low), "=d" (high)
    : "c" (msr), [fault] "i" (-5));
    return ((low) | ((u64)(high) << 32));
}

static inline __attribute__((no_instrument_function)) void native_write_msr(unsigned int msr,
                                                                            unsigned low, unsigned high)
{
    asm volatile("wrmsr" : : "c" (msr), "a"(low), "d" (high) : "memory");
}


__attribute__((no_instrument_function)) static inline __attribute__((no_instrument_function)) int native_write_msr_safe(unsigned int msr,
                                                                                                                        unsigned low, unsigned high)
{
    int err;
    asm volatile("2: wrmsr ; xor %[err],%[err]\n"
                 "1:\n\t"
                 ".section .fixup,\"ax\"\n\t"
                 "3:  mov %[fault],%[err] ; jmp 1b\n\t"
                 ".previous\n\t"
                 " .pushsection \"__ex_table\",\"a\"\n" " .balign 8\n" " .long (" "2b" ") - .\n" " .long (" "3b" ") - .\n" " .popsection\n"
            : [err] "=a" (err)
    : "c" (msr), "0" (low), "d" (high),
    [fault] "i" (-5)
    : "memory");
    return err;
}

extern unsigned long long native_read_tsc(void);

extern int rdmsr_safe_regs(u32 regs[8]);
extern int wrmsr_safe_regs(u32 regs[8]);

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) unsigned long long __native_read_tsc(void)
{
    unsigned low, high;

    asm volatile("rdtsc" : "=a" (low), "=d" (high));

    return ((low) | ((u64)(high) << 32));
}

static inline __attribute__((no_instrument_function)) unsigned long long native_read_pmc(int counter)
{
    unsigned low, high;

    asm volatile("rdpmc" : "=a" (low), "=d" (high) : "c" (counter));
    return ((low) | ((u64)(high) << 32));
}
# 147 "./arch/x86/include/asm/msr.h"
static inline __attribute__((no_instrument_function)) void wrmsr(unsigned msr, unsigned low, unsigned high)
{
    native_write_msr(msr, low, high);
}
# 159 "./arch/x86/include/asm/msr.h"
static inline __attribute__((no_instrument_function)) int wrmsr_safe(unsigned msr, unsigned low, unsigned high)
{
    return native_write_msr_safe(msr, low, high);
}
# 174 "./arch/x86/include/asm/msr.h"
static inline __attribute__((no_instrument_function)) int rdmsrl_safe(unsigned msr, unsigned long long *p)
{
    int err;

    *p = native_read_msr_safe(msr, &err);
    return err;
}
# 215 "./arch/x86/include/asm/msr.h"
struct msr *msrs_alloc(void);
void msrs_free(struct msr *msrs);
int msr_set_bit(u32 msr, u8 bit);
int msr_clear_bit(u32 msr, u8 bit);


int rdmsr_on_cpu(unsigned int cpu, u32 msr_no, u32 *l, u32 *h);
int wrmsr_on_cpu(unsigned int cpu, u32 msr_no, u32 l, u32 h);
int rdmsrl_on_cpu(unsigned int cpu, u32 msr_no, u64 *q);
int wrmsrl_on_cpu(unsigned int cpu, u32 msr_no, u64 q);
void rdmsr_on_cpus(const struct cpumask *mask, u32 msr_no, struct msr *msrs);
void wrmsr_on_cpus(const struct cpumask *mask, u32 msr_no, struct msr *msrs);
int rdmsr_safe_on_cpu(unsigned int cpu, u32 msr_no, u32 *l, u32 *h);
int wrmsr_safe_on_cpu(unsigned int cpu, u32 msr_no, u32 l, u32 h);
int rdmsrl_safe_on_cpu(unsigned int cpu, u32 msr_no, u64 *q);
int wrmsrl_safe_on_cpu(unsigned int cpu, u32 msr_no, u64 q);
int rdmsr_safe_regs_on_cpu(unsigned int cpu, u32 regs[8]);
int wrmsr_safe_regs_on_cpu(unsigned int cpu, u32 regs[8]);
# 21 "./arch/x86/include/asm/processor.h" 2
# 1 "./arch/x86/include/asm/desc_defs.h" 1
# 22 "./arch/x86/include/asm/desc_defs.h"
struct desc_struct {
    union {
        struct {
            unsigned int a;
            unsigned int b;
        };
        struct {
            u16 limit0;
            u16 base0;
            unsigned base1: 8, type: 4, s: 1, dpl: 2, p: 1;
            unsigned limit: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
        };
    };
} __attribute__((packed));







enum {
    GATE_INTERRUPT = 0xE,
    GATE_TRAP = 0xF,
    GATE_CALL = 0xC,
    GATE_TASK = 0x5,
};


struct gate_struct64 {
    u16 offset_low;
    u16 segment;
    unsigned ist : 3, zero0 : 5, type : 5, dpl : 2, p : 1;
    u16 offset_middle;
    u32 offset_high;
    u32 zero1;
} __attribute__((packed));





enum {
    DESC_TSS = 0x9,
    DESC_LDT = 0x2,
    DESCTYPE_S = 0x10,
};


struct ldttss_desc64 {
    u16 limit0;
    u16 base0;
    unsigned base1 : 8, type : 5, dpl : 2, p : 1;
    unsigned limit1 : 4, zero0 : 3, g : 1, base2 : 8;
    u32 base3;
    u32 zero1;
} __attribute__((packed));


typedef struct gate_struct64 gate_desc;
typedef struct ldttss_desc64 ldt_desc;
typedef struct ldttss_desc64 tss_desc;
# 94 "./arch/x86/include/asm/desc_defs.h"
struct desc_ptr {
    unsigned short size;
    unsigned long address;
} __attribute__((packed)) ;
# 22 "./arch/x86/include/asm/processor.h" 2

# 1 "./arch/x86/include/asm/special_insns.h" 1
# 9 "./arch/x86/include/asm/special_insns.h"
static inline __attribute__((no_instrument_function)) void native_clts(void)
{
    asm volatile("clts");
}
# 21 "./arch/x86/include/asm/special_insns.h"
extern unsigned long __force_order;

static inline __attribute__((no_instrument_function)) unsigned long native_read_cr0(void)
{
    unsigned long val;
    asm volatile("mov %%cr0,%0\n\t" : "=r" (val), "=m" (__force_order));
    return val;
}

static inline __attribute__((no_instrument_function)) void native_write_cr0(unsigned long val)
{
    asm volatile("mov %0,%%cr0": : "r" (val), "m" (__force_order));
}

static inline __attribute__((no_instrument_function)) unsigned long native_read_cr2(void)
{
    unsigned long val;
    asm volatile("mov %%cr2,%0\n\t" : "=r" (val), "=m" (__force_order));
    return val;
}

static inline __attribute__((no_instrument_function)) void native_write_cr2(unsigned long val)
{
    asm volatile("mov %0,%%cr2": : "r" (val), "m" (__force_order));
}

static inline __attribute__((no_instrument_function)) unsigned long native_read_cr3(void)
{
    unsigned long val;
    asm volatile("mov %%cr3,%0\n\t" : "=r" (val), "=m" (__force_order));
    return val;
}

static inline __attribute__((no_instrument_function)) void native_write_cr3(unsigned long val)
{
    asm volatile("mov %0,%%cr3": : "r" (val), "m" (__force_order));
}

static inline __attribute__((no_instrument_function)) unsigned long native_read_cr4(void)
{
    unsigned long val;
    asm volatile("mov %%cr4,%0\n\t" : "=r" (val), "=m" (__force_order));
    return val;
}

static inline __attribute__((no_instrument_function)) unsigned long native_read_cr4_safe(void)
{
    unsigned long val;
# 77 "./arch/x86/include/asm/special_insns.h"
    val = native_read_cr4();

    return val;
}

static inline __attribute__((no_instrument_function)) void native_write_cr4(unsigned long val)
{
    asm volatile("mov %0,%%cr4": : "r" (val), "m" (__force_order));
}


static inline __attribute__((no_instrument_function)) unsigned long native_read_cr8(void)
{
    unsigned long cr8;
    asm volatile("movq %%cr8,%0" : "=r" (cr8));
    return cr8;
}

static inline __attribute__((no_instrument_function)) void native_write_cr8(unsigned long val)
{
    asm volatile("movq %0,%%cr8" :: "r" (val) : "memory");
}


static inline __attribute__((no_instrument_function)) void native_wbinvd(void)
{
    asm volatile("wbinvd": : :"memory");
}

extern void native_load_gs_index(unsigned);





static inline __attribute__((no_instrument_function)) unsigned long read_cr0(void)
{
    return native_read_cr0();
}

static inline __attribute__((no_instrument_function)) void write_cr0(unsigned long x)
{
    native_write_cr0(x);
}

static inline __attribute__((no_instrument_function)) unsigned long read_cr2(void)
{
    return native_read_cr2();
}

static inline __attribute__((no_instrument_function)) void write_cr2(unsigned long x)
{
    native_write_cr2(x);
}

static inline __attribute__((no_instrument_function)) unsigned long read_cr3(void)
{
    return native_read_cr3();
}

static inline __attribute__((no_instrument_function)) void write_cr3(unsigned long x)
{
    native_write_cr3(x);
}

static inline __attribute__((no_instrument_function)) unsigned long __read_cr4(void)
{
    return native_read_cr4();
}

static inline __attribute__((no_instrument_function)) unsigned long __read_cr4_safe(void)
{
    return native_read_cr4_safe();
}

static inline __attribute__((no_instrument_function)) void __write_cr4(unsigned long x)
{
    native_write_cr4(x);
}

static inline __attribute__((no_instrument_function)) void wbinvd(void)
{
    native_wbinvd();
}



static inline __attribute__((no_instrument_function)) unsigned long read_cr8(void)
{
    return native_read_cr8();
}

static inline __attribute__((no_instrument_function)) void write_cr8(unsigned long x)
{
    native_write_cr8(x);
}

static inline __attribute__((no_instrument_function)) void load_gs_index(unsigned selector)
{
    native_load_gs_index(selector);
}




static inline __attribute__((no_instrument_function)) void clts(void)
{
    native_clts();
}





static inline __attribute__((no_instrument_function)) void clflush(volatile void *__p)
{
    asm volatile("clflush %0" : "+m" (*(volatile char *)__p));
}

static inline __attribute__((no_instrument_function)) void clflushopt(volatile void *__p)
{
    asm volatile ("661:\n\t" ".byte " "0x3e" "; clflush %P0" "\n662:\n" ".skip -(((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")) > 0) * " "((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")),0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 9*32+23)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" ".byte 0x66; clflush %P0" "\n" "665""1" ":\n\t" ".popsection" : "+m" (*(volatile char *)__p) : "i" (0))


            ;
}

static inline __attribute__((no_instrument_function)) void clwb(volatile void *__p)
{
    volatile struct { char x[64]; } *p = __p;

    asm volatile("661:\n\t" ".byte " "0x3e" "; clflush (%[pax])" "\n662:\n" ".skip -((" "((" "665""1""f-""664""1""f" ") ^ (((" "665""1""f-""664""1""f" ") ^ (" "665""2""f-""664""2""f" ")) & -(-((" "665""1""f-""664""1""f" ") - (" "665""2""f-""664""2""f" ")))))" " - (" "662b-661b" ")) > 0) * " "(" "((" "665""1""f-""664""1""f" ") ^ (((" "665""1""f-""664""1""f" ") ^ (" "665""2""f-""664""2""f" ")) & -(-((" "665""1""f-""664""1""f" ") - (" "665""2""f-""664""2""f" ")))))" " - (" "662b-661b" ")), 0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 9*32+23)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" " .long 661b - .\n" " .long " "664""2""f - .\n" " .word " "( 9*32+24)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""2""f-""664""2""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" ".byte 0x66; clflush (%[pax])" "\n" "665""1" ":\n\t" "664""2"":\n\t" ".byte 0x66, 0x0f, 0xae, 0x30" "\n" "665""2" ":\n\t" ".popsection"





            : [p] "+m" (*p)
    : [pax] "a" (p));
}

static inline __attribute__((no_instrument_function)) void pcommit_sfence(void)
{
    asm volatile ("661:\n\t" ".byte " "0x66,0x66,0x66,0x90,0x66,0x66,0x90" "\n" "\n662:\n" ".skip -(((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")) > 0) * " "((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")),0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 9*32+22)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" ".byte 0x66, 0x0f, 0xae, 0xf8\n\t" "sfence" "\n" "665""1" ":\n\t" ".popsection" : : : "memory")


            ;
}
# 24 "./arch/x86/include/asm/processor.h" 2

# 1 "include/linux/personality.h" 1



# 1 "include/uapi/linux/personality.h" 1
# 10 "include/uapi/linux/personality.h"
enum {
    UNAME26 = 0x0020000,
    ADDR_NO_RANDOMIZE = 0x0040000,
    FDPIC_FUNCPTRS = 0x0080000,


    MMAP_PAGE_ZERO = 0x0100000,
    ADDR_COMPAT_LAYOUT = 0x0200000,
    READ_IMPLIES_EXEC = 0x0400000,
    ADDR_LIMIT_32BIT = 0x0800000,
    SHORT_INODE = 0x1000000,
    WHOLE_SECONDS = 0x2000000,
    STICKY_TIMEOUTS = 0x4000000,
    ADDR_LIMIT_3GB = 0x8000000,
};
# 41 "include/uapi/linux/personality.h"
enum {
    PER_LINUX = 0x0000,
    PER_LINUX_32BIT = 0x0000 | ADDR_LIMIT_32BIT,
    PER_LINUX_FDPIC = 0x0000 | FDPIC_FUNCPTRS,
    PER_SVR4 = 0x0001 | STICKY_TIMEOUTS | MMAP_PAGE_ZERO,
    PER_SVR3 = 0x0002 | STICKY_TIMEOUTS | SHORT_INODE,
    PER_SCOSVR3 = 0x0003 | STICKY_TIMEOUTS |
                  WHOLE_SECONDS | SHORT_INODE,
    PER_OSR5 = 0x0003 | STICKY_TIMEOUTS | WHOLE_SECONDS,
    PER_WYSEV386 = 0x0004 | STICKY_TIMEOUTS | SHORT_INODE,
    PER_ISCR4 = 0x0005 | STICKY_TIMEOUTS,
    PER_BSD = 0x0006,
    PER_SUNOS = 0x0006 | STICKY_TIMEOUTS,
    PER_XENIX = 0x0007 | STICKY_TIMEOUTS | SHORT_INODE,
    PER_LINUX32 = 0x0008,
    PER_LINUX32_3GB = 0x0008 | ADDR_LIMIT_3GB,
    PER_IRIX32 = 0x0009 | STICKY_TIMEOUTS,
    PER_IRIXN32 = 0x000a | STICKY_TIMEOUTS,
    PER_IRIX64 = 0x000b | STICKY_TIMEOUTS,
    PER_RISCOS = 0x000c,
    PER_SOLARIS = 0x000d | STICKY_TIMEOUTS,
    PER_UW7 = 0x000e | STICKY_TIMEOUTS | MMAP_PAGE_ZERO,
    PER_OSF4 = 0x000f,
    PER_HPUX = 0x0010,
    PER_MASK = 0x00ff,
};
# 5 "include/linux/personality.h" 2
# 26 "./arch/x86/include/asm/processor.h" 2



# 1 "include/linux/math64.h" 1




# 1 "./arch/x86/include/asm/div64.h" 1
# 63 "./arch/x86/include/asm/div64.h"
# 1 "include/asm-generic/div64.h" 1
# 64 "./arch/x86/include/asm/div64.h" 2
# 6 "include/linux/math64.h" 2
# 18 "include/linux/math64.h"
static inline __attribute__((no_instrument_function)) u64 div_u64_rem(u64 dividend, u32 divisor, u32 *remainder)
{
    *remainder = dividend % divisor;
    return dividend / divisor;
}




static inline __attribute__((no_instrument_function)) s64 div_s64_rem(s64 dividend, s32 divisor, s32 *remainder)
{
    *remainder = dividend % divisor;
    return dividend / divisor;
}




static inline __attribute__((no_instrument_function)) u64 div64_u64_rem(u64 dividend, u64 divisor, u64 *remainder)
{
    *remainder = dividend % divisor;
    return dividend / divisor;
}




static inline __attribute__((no_instrument_function)) u64 div64_u64(u64 dividend, u64 divisor)
{
    return dividend / divisor;
}




static inline __attribute__((no_instrument_function)) s64 div64_s64(s64 dividend, s64 divisor)
{
    return dividend / divisor;
}
# 97 "include/linux/math64.h"
static inline __attribute__((no_instrument_function)) u64 div_u64(u64 dividend, u32 divisor)
{
    u32 remainder;
    return div_u64_rem(dividend, divisor, &remainder);
}






static inline __attribute__((no_instrument_function)) s64 div_s64(s64 dividend, s32 divisor)
{
    s32 remainder;
    return div_s64_rem(dividend, divisor, &remainder);
}


u32 iter_div_u64_rem(u64 dividend, u32 divisor, u64 *remainder);

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) u32
__iter_div_u64_rem(u64 dividend, u32 divisor, u64 *remainder)
{
    u32 ret = 0;

    while (dividend >= divisor) {


        asm("" : "+rm"(dividend));

        dividend -= divisor;
        ret++;
    }

    *remainder = dividend;

    return ret;
}




static inline __attribute__((no_instrument_function)) u64 mul_u64_u32_shr(u64 a, u32 mul, unsigned int shift)
{
    return (u64)(((unsigned __int128)a * mul) >> shift);
}
# 30 "./arch/x86/include/asm/processor.h" 2
# 1 "include/linux/err.h" 1






# 1 "./arch/x86/include/uapi/asm/errno.h" 1
# 8 "include/linux/err.h" 2
# 23 "include/linux/err.h"
static inline __attribute__((no_instrument_function)) void * __attribute__((warn_unused_result)) ERR_PTR(long error)
{
    return (void *) error;
}

static inline __attribute__((no_instrument_function)) long __attribute__((warn_unused_result)) PTR_ERR( const void *ptr)
{
    return (long) ptr;
}

static inline __attribute__((no_instrument_function)) bool __attribute__((warn_unused_result)) IS_ERR( const void *ptr)
{
    return __builtin_expect(!!(((unsigned long)ptr) >= (unsigned long)-4095), 0);
}

static inline __attribute__((no_instrument_function)) bool __attribute__((warn_unused_result)) IS_ERR_OR_NULL( const void *ptr)
{
    return !ptr || __builtin_expect(!!(((unsigned long)ptr) >= (unsigned long)-4095), 0);
}
# 50 "include/linux/err.h"
static inline __attribute__((no_instrument_function)) void * __attribute__((warn_unused_result)) ERR_CAST( const void *ptr)
{

    return (void *) ptr;
}

static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) PTR_ERR_OR_ZERO( const void *ptr)
{
    if (IS_ERR(ptr))
        return PTR_ERR(ptr);
    else
        return 0;
}
# 31 "./arch/x86/include/asm/processor.h" 2
# 1 "include/linux/irqflags.h" 1
# 15 "include/linux/irqflags.h"
# 1 "./arch/x86/include/asm/irqflags.h" 1
# 11 "./arch/x86/include/asm/irqflags.h"
static inline __attribute__((no_instrument_function)) unsigned long native_save_fl(void)
{
    unsigned long flags;






    asm volatile("# __raw_save_flags\n\t"
                 "pushf ; pop %0"
            : "=rm" (flags)
            :
            : "memory");

    return flags;
}

static inline __attribute__((no_instrument_function)) void native_restore_fl(unsigned long flags)
{
    asm volatile("push %0 ; popf"
            :
            :"g" (flags)
            :"memory", "cc");
}

static inline __attribute__((no_instrument_function)) void native_irq_disable(void)
{
    asm volatile("cli": : :"memory");
}

static inline __attribute__((no_instrument_function)) void native_irq_enable(void)
{
    asm volatile("sti": : :"memory");
}

static inline __attribute__((no_instrument_function)) void native_safe_halt(void)
{
    asm volatile("sti; hlt": : :"memory");
}

static inline __attribute__((no_instrument_function)) void native_halt(void)
{
    asm volatile("hlt": : :"memory");
}
# 65 "./arch/x86/include/asm/irqflags.h"
static inline __attribute__((no_instrument_function)) __attribute__((no_instrument_function)) unsigned long arch_local_save_flags(void)
{
    return native_save_fl();
}

static inline __attribute__((no_instrument_function)) __attribute__((no_instrument_function)) void arch_local_irq_restore(unsigned long flags)
{
    native_restore_fl(flags);
}

static inline __attribute__((no_instrument_function)) __attribute__((no_instrument_function)) void arch_local_irq_disable(void)
{
    native_irq_disable();
}

static inline __attribute__((no_instrument_function)) __attribute__((no_instrument_function)) void arch_local_irq_enable(void)
{
    native_irq_enable();
}





static inline __attribute__((no_instrument_function)) void arch_safe_halt(void)
{
    native_safe_halt();
}





static inline __attribute__((no_instrument_function)) void halt(void)
{
    native_halt();
}




static inline __attribute__((no_instrument_function)) __attribute__((no_instrument_function)) unsigned long arch_local_irq_save(void)
{
    unsigned long flags = arch_local_save_flags();
    arch_local_irq_disable();
    return flags;
}
# 151 "./arch/x86/include/asm/irqflags.h"
static inline __attribute__((no_instrument_function)) int arch_irqs_disabled_flags(unsigned long flags)
{
    return !(flags & ((1UL) << (9)));
}

static inline __attribute__((no_instrument_function)) int arch_irqs_disabled(void)
{
    unsigned long flags = arch_local_save_flags();

    return arch_irqs_disabled_flags(flags);
}
# 16 "include/linux/irqflags.h" 2
# 32 "./arch/x86/include/asm/processor.h" 2
# 46 "./arch/x86/include/asm/processor.h"
static inline __attribute__((no_instrument_function)) void *current_text_addr(void)
{
    void *pc;

    asm volatile("mov $1f, %0; 1:":"=r" (pc));

    return pc;
}
# 63 "./arch/x86/include/asm/processor.h"
enum tlb_infos {
    ENTRIES,
    NR_INFO
};

extern u16 __attribute__((__section__(".data..read_mostly"))) tlb_lli_4k[NR_INFO];
extern u16 __attribute__((__section__(".data..read_mostly"))) tlb_lli_2m[NR_INFO];
extern u16 __attribute__((__section__(".data..read_mostly"))) tlb_lli_4m[NR_INFO];
extern u16 __attribute__((__section__(".data..read_mostly"))) tlb_lld_4k[NR_INFO];
extern u16 __attribute__((__section__(".data..read_mostly"))) tlb_lld_2m[NR_INFO];
extern u16 __attribute__((__section__(".data..read_mostly"))) tlb_lld_4m[NR_INFO];
extern u16 __attribute__((__section__(".data..read_mostly"))) tlb_lld_1g[NR_INFO];







struct cpuinfo_x86 {
    __u8 x86;
    __u8 x86_vendor;
    __u8 x86_model;
    __u8 x86_mask;
# 96 "./arch/x86/include/asm/processor.h"
    int x86_tlbsize;

    __u8 x86_virt_bits;
    __u8 x86_phys_bits;

    __u8 x86_coreid_bits;

    __u32 extended_cpuid_level;

    int cpuid_level;
    __u32 x86_capability[13 + 1];
    char x86_vendor_id[16];
    char x86_model_id[64];

    int x86_cache_size;
    int x86_cache_alignment;

    int x86_cache_max_rmid;
    int x86_cache_occ_scale;
    int x86_power;
    unsigned long loops_per_jiffy;

    u16 x86_max_cores;
    u16 apicid;
    u16 initial_apicid;
    u16 x86_clflush_size;

    u16 booted_cores;

    u16 phys_proc_id;

    u16 cpu_core_id;

    u8 compute_unit_id;

    u16 cpu_index;
    u32 microcode;
};
# 149 "./arch/x86/include/asm/processor.h"
extern struct cpuinfo_x86 boot_cpu_data;
extern struct cpuinfo_x86 new_cpu_data;

extern struct tss_struct doublefault_tss;
extern __u32 cpu_caps_cleared[13];
extern __u32 cpu_caps_set[13];


extern __attribute__((section(".data..percpu" "..read_mostly"))) __typeof__(struct cpuinfo_x86) cpu_info;






extern const struct seq_operations cpuinfo_op;



extern void cpu_detect(struct cpuinfo_x86 *c);
extern void fpu_detect(struct cpuinfo_x86 *c);

extern void early_cpu_init(void);
extern void identify_boot_cpu(void);
extern void identify_secondary_cpu(struct cpuinfo_x86 *);
extern void print_cpu_info(struct cpuinfo_x86 *);
void print_cpu_msr(struct cpuinfo_x86 *);
extern void init_scattered_cpuid_features(struct cpuinfo_x86 *c);
extern unsigned int init_intel_cacheinfo(struct cpuinfo_x86 *c);
extern void init_amd_cacheinfo(struct cpuinfo_x86 *c);

extern void detect_extended_topology(struct cpuinfo_x86 *c);
extern void detect_ht(struct cpuinfo_x86 *c);




static inline __attribute__((no_instrument_function)) int have_cpuid_p(void)
{
    return 1;
}

static inline __attribute__((no_instrument_function)) void native_cpuid(unsigned int *eax, unsigned int *ebx,
                                                                        unsigned int *ecx, unsigned int *edx)
{

    asm volatile("cpuid"
            : "=a" (*eax),
    "=b" (*ebx),
    "=c" (*ecx),
    "=d" (*edx)
            : "0" (*eax), "2" (*ecx)
            : "memory");
}

static inline __attribute__((no_instrument_function)) void load_cr3(pgd_t *pgdir)
{
    write_cr3(__phys_addr_nodebug((unsigned long)(pgdir)));
}
# 258 "./arch/x86/include/asm/processor.h"
struct x86_hw_tss {
    u32 reserved1;
    u64 sp0;
    u64 sp1;
    u64 sp2;
    u64 reserved2;
    u64 ist[7];
    u32 reserved3;
    u32 reserved4;
    u16 reserved5;
    u16 io_bitmap_base;

} __attribute__((packed)) __attribute__((__aligned__((1 << (6)))));
# 282 "./arch/x86/include/asm/processor.h"
struct tss_struct {



    struct x86_hw_tss x86_tss;







    unsigned long io_bitmap[((65536/8)/sizeof(long)) + 1];




    unsigned long SYSENTER_stack[64];

} __attribute__((__aligned__((1 << (6)))));

extern __attribute__((section(".data..percpu" "..shared_aligned"))) __typeof__(struct tss_struct) cpu_tss __attribute__((__aligned__((1 << (6)))));
# 312 "./arch/x86/include/asm/processor.h"
struct orig_ist {
    unsigned long ist[7];
};



struct i387_fsave_struct {
    u32 cwd;
    u32 swd;
    u32 twd;
    u32 fip;
    u32 fcs;
    u32 foo;
    u32 fos;


    u32 st_space[20];


    u32 status;
};

struct i387_fxsave_struct {
    u16 cwd;
    u16 swd;
    u16 twd;
    u16 fop;
    union {
        struct {
            u64 rip;
            u64 rdp;
        };
        struct {
            u32 fip;
            u32 fcs;
            u32 foo;
            u32 fos;
        };
    };
    u32 mxcsr;
    u32 mxcsr_mask;


    u32 st_space[32];


    u32 xmm_space[64];

    u32 padding[12];

    union {
        u32 padding1[12];
        u32 sw_reserved[12];
    };

} __attribute__((aligned(16)));

struct i387_soft_struct {
    u32 cwd;
    u32 swd;
    u32 twd;
    u32 fip;
    u32 fcs;
    u32 foo;
    u32 fos;

    u32 st_space[20];
    u8 ftop;
    u8 changed;
    u8 lookahead;
    u8 no_update;
    u8 rm;
    u8 alimit;
    struct math_emu_info *info;
    u32 entry_eip;
};

struct ymmh_struct {

    u32 ymmh_space[64];
};


struct lwp_struct {
    u8 reserved[128];
};

struct bndreg {
    u64 lower_bound;
    u64 upper_bound;
} __attribute__((packed));

struct bndcsr {
    u64 bndcfgu;
    u64 bndstatus;
} __attribute__((packed));

struct xsave_hdr_struct {
    u64 xstate_bv;
    u64 xcomp_bv;
    u64 reserved[6];
} __attribute__((packed));

struct xsave_struct {
    struct i387_fxsave_struct i387;
    struct xsave_hdr_struct xsave_hdr;
    struct ymmh_struct ymmh;
    struct lwp_struct lwp;
    struct bndreg bndreg[4];
    struct bndcsr bndcsr;

} __attribute__ ((packed, aligned (64)));

union thread_xstate {
    struct i387_fsave_struct fsave;
    struct i387_fxsave_struct fxsave;
    struct i387_soft_struct soft;
    struct xsave_struct xsave;
};

struct fpu {
    unsigned int last_cpu;
    unsigned int has_fpu;
    union thread_xstate *state;
};


extern __attribute__((section(".data..percpu" ""))) __typeof__(struct orig_ist) orig_ist;

union irq_stack_union {
    char irq_stack[(((1UL) << 12) << (2 + 0))];





    struct {
        char gs_base[40];
        unsigned long stack_canary;
    };
};

extern __attribute__((section(".data..percpu" "..first"))) __typeof__(union irq_stack_union) irq_stack_union __attribute__((externally_visible));
extern typeof(irq_stack_union) init_per_cpu__irq_stack_union;

extern __attribute__((section(".data..percpu" ""))) __typeof__(char *) irq_stack_ptr;
extern __attribute__((section(".data..percpu" ""))) __typeof__(unsigned int) irq_count;
extern void ignore_sysret(void);
# 485 "./arch/x86/include/asm/processor.h"
extern unsigned int xstate_size;
extern void free_thread_xstate(struct task_struct *);
extern struct kmem_cache *task_xstate_cachep;

struct perf_event;

struct thread_struct {

    struct desc_struct tls_array[3];
    unsigned long sp0;
    unsigned long sp;



    unsigned short es;
    unsigned short ds;
    unsigned short fsindex;
    unsigned short gsindex;





    unsigned long fs;

    unsigned long gs;

    struct perf_event *ptrace_bps[4];

    unsigned long debugreg6;

    unsigned long ptrace_dr7;

    unsigned long cr2;
    unsigned long trap_nr;
    unsigned long error_code;

    struct fpu fpu;
# 534 "./arch/x86/include/asm/processor.h"
    unsigned long *io_bitmap_ptr;
    unsigned long iopl;

    unsigned io_bitmap_max;
# 546 "./arch/x86/include/asm/processor.h"
    unsigned char fpu_counter;
};




static inline __attribute__((no_instrument_function)) void native_set_iopl_mask(unsigned mask)
{
# 566 "./arch/x86/include/asm/processor.h"
}

static inline __attribute__((no_instrument_function)) void
native_load_sp0(struct tss_struct *tss, struct thread_struct *thread)
{
    tss->x86_tss.sp0 = thread->sp0;







}

static inline __attribute__((no_instrument_function)) void native_swapgs(void)
{

    asm volatile("swapgs" ::: "memory");

}

static inline __attribute__((no_instrument_function)) unsigned long current_top_of_stack(void)
{

    return ({ typeof(cpu_tss.x86_tss.sp0) pfo_ret__; switch (sizeof(cpu_tss.x86_tss.sp0)) { case 1: asm("mov" "b ""%%""gs"":" "%" "P1"",%0" : "=q" (pfo_ret__) : "p" (&(cpu_tss.x86_tss.sp0))); break; case 2: asm("mov" "w ""%%""gs"":" "%" "P1"",%0" : "=r" (pfo_ret__) : "p" (&(cpu_tss.x86_tss.sp0))); break; case 4: asm("mov" "l ""%%""gs"":" "%" "P1"",%0" : "=r" (pfo_ret__) : "p" (&(cpu_tss.x86_tss.sp0))); break; case 8: asm("mov" "q ""%%""gs"":" "%" "P1"",%0" : "=r" (pfo_ret__) : "p" (&(cpu_tss.x86_tss.sp0))); break; default: __bad_percpu_size(); } pfo_ret__; });




}







static inline __attribute__((no_instrument_function)) void load_sp0(struct tss_struct *tss,
                                                                    struct thread_struct *thread)
{
    native_load_sp0(tss, thread);
}




typedef struct {
    unsigned long seg;
} mm_segment_t;



extern void release_thread(struct task_struct *);

unsigned long get_wchan(struct task_struct *p);






static inline __attribute__((no_instrument_function)) void cpuid(unsigned int op,
                                                                 unsigned int *eax, unsigned int *ebx,
                                                                 unsigned int *ecx, unsigned int *edx)
{
    *eax = op;
    *ecx = 0;
    native_cpuid(eax, ebx, ecx, edx);
}


static inline __attribute__((no_instrument_function)) void cpuid_count(unsigned int op, int count,
                                                                       unsigned int *eax, unsigned int *ebx,
                                                                       unsigned int *ecx, unsigned int *edx)
{
    *eax = op;
    *ecx = count;
    native_cpuid(eax, ebx, ecx, edx);
}




static inline __attribute__((no_instrument_function)) unsigned int cpuid_eax(unsigned int op)
{
    unsigned int eax, ebx, ecx, edx;

    cpuid(op, &eax, &ebx, &ecx, &edx);

    return eax;
}

static inline __attribute__((no_instrument_function)) unsigned int cpuid_ebx(unsigned int op)
{
    unsigned int eax, ebx, ecx, edx;

    cpuid(op, &eax, &ebx, &ecx, &edx);

    return ebx;
}

static inline __attribute__((no_instrument_function)) unsigned int cpuid_ecx(unsigned int op)
{
    unsigned int eax, ebx, ecx, edx;

    cpuid(op, &eax, &ebx, &ecx, &edx);

    return ecx;
}

static inline __attribute__((no_instrument_function)) unsigned int cpuid_edx(unsigned int op)
{
    unsigned int eax, ebx, ecx, edx;

    cpuid(op, &eax, &ebx, &ecx, &edx);

    return edx;
}


static inline __attribute__((no_instrument_function)) void rep_nop(void)
{
    asm volatile("rep; nop" ::: "memory");
}

static inline __attribute__((no_instrument_function)) void cpu_relax(void)
{
    rep_nop();
}




static inline __attribute__((no_instrument_function)) void sync_core(void)
{
    int tmp;
# 722 "./arch/x86/include/asm/processor.h"
    asm volatile("cpuid"
            : "=a" (tmp)
            : "0" (1)
            : "ebx", "ecx", "edx", "memory");

}

extern void select_idle_routine(const struct cpuinfo_x86 *c);
extern void init_amd_e400_c1e_mask(void);

extern unsigned long boot_option_idle_override;
extern bool amd_e400_c1e_detected;

enum idle_boot_override {IDLE_NO_OVERRIDE=0, IDLE_HALT, IDLE_NOMWAIT,
    IDLE_POLL};

extern void enable_sep_cpu(void);
extern int sysenter_setup(void);

extern void early_trap_init(void);
void early_trap_pf_init(void);


extern struct desc_ptr early_gdt_descr;

extern void cpu_set_gdt(int);
extern void switch_to_new_gdt(int);
extern void load_percpu_segment(int);
extern void cpu_init(void);

static inline __attribute__((no_instrument_function)) unsigned long get_debugctlmsr(void)
{
    unsigned long debugctlmsr = 0;





    ((debugctlmsr) = native_read_msr((0x000001d9)));

    return debugctlmsr;
}

static inline __attribute__((no_instrument_function)) void update_debugctlmsr(unsigned long debugctlmsr)
{




    native_write_msr((0x000001d9), (u32)((u64)(debugctlmsr)), (u32)((u64)(debugctlmsr) >> 32));
}

extern void set_task_blockstep(struct task_struct *task, bool on);





extern unsigned int machine_id;
extern unsigned int machine_submodel_id;
extern unsigned int BIOS_revision;


extern int bootloader_type;
extern int bootloader_version;

extern char ignore_fpu_irq;
# 807 "./arch/x86/include/asm/processor.h"
static inline __attribute__((no_instrument_function)) void prefetch(const void *x)
{
    asm volatile ("661:\n\t" "prefetcht0 %P1" "\n662:\n" ".skip -(((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")) > 0) * " "((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")),0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 0*32+25)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" "prefetchnta %P1" "\n" "665""1" ":\n\t" ".popsection" : : "i" (0), "m" (*(const char *)x))

            ;
}






static inline __attribute__((no_instrument_function)) void prefetchw(const void *x)
{
    asm volatile ("661:\n\t" "prefetcht0 %P1" "\n662:\n" ".skip -(((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")) > 0) * " "((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")),0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "( 6*32+ 8)" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" "prefetchw %P1" "\n" "665""1" ":\n\t" ".popsection" : : "i" (0), "m" (*(const char *)x))

            ;
}

static inline __attribute__((no_instrument_function)) void spin_lock_prefetch(const void *x)
{
    prefetchw(x);
}
# 908 "./arch/x86/include/asm/processor.h"
extern unsigned long KSTK_ESP(struct task_struct *task);



extern void start_thread(struct pt_regs *regs, unsigned long new_ip,
                         unsigned long new_sp);
# 927 "./arch/x86/include/asm/processor.h"
extern int get_tsc_mode(unsigned long adr);
extern int set_tsc_mode(unsigned int val);
# 938 "./arch/x86/include/asm/processor.h"
static inline __attribute__((no_instrument_function)) int mpx_enable_management(struct task_struct *tsk)
{
    return -22;
}
static inline __attribute__((no_instrument_function)) int mpx_disable_management(struct task_struct *tsk)
{
    return -22;
}


extern u16 amd_get_nb_id(int cpu);

static inline __attribute__((no_instrument_function)) uint32_t hypervisor_cpuid_base(const char *sig, uint32_t leaves)
{
    uint32_t base, eax, signature[3];

    for (base = 0x40000000; base < 0x40010000; base += 0x100) {
        cpuid(base, &eax, &signature[0], &signature[1], &signature[2]);

        if (!memcmp(sig, signature, 12) &&
            (leaves == 0 || ((eax - base) >= leaves)))
            return base;
    }

    return 0;
}

extern unsigned long arch_align_stack(unsigned long sp);
extern void free_init_pages(char *what, unsigned long begin, unsigned long end);

void default_idle(void);






void stop_this_cpu(void *dummy);
void df_debug(struct pt_regs *regs, long error_code);
# 7 "./arch/x86/include/asm/atomic.h" 2

# 1 "./arch/x86/include/asm/cmpxchg.h" 1
# 13 "./arch/x86/include/asm/cmpxchg.h"
extern void __xchg_wrong_size(void)
__attribute__((error("Bad argument size for xchg")));
extern void __cmpxchg_wrong_size(void)
__attribute__((error("Bad argument size for cmpxchg")));
extern void __xadd_wrong_size(void)
__attribute__((error("Bad argument size for xadd")));
extern void __add_wrong_size(void)
__attribute__((error("Bad argument size for add")));
# 145 "./arch/x86/include/asm/cmpxchg.h"
# 1 "./arch/x86/include/asm/cmpxchg_64.h" 1



static inline __attribute__((no_instrument_function)) void set_64bit(volatile u64 *ptr, u64 val)
{
    *ptr = val;
}
# 146 "./arch/x86/include/asm/cmpxchg.h" 2
# 9 "./arch/x86/include/asm/atomic.h" 2
# 25 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_read(const atomic_t *v)
{
    return (*({ __attribute__((unused)) typeof((v)->counter) __var = ( typeof((v)->counter)) 0; (volatile typeof((v)->counter) *)&((v)->counter); }));
}
# 37 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) void atomic_set(atomic_t *v, int i)
{
    v->counter = i;
}
# 49 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) void atomic_add(int i, atomic_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "addl %1,%0"
            : "+m" (v->counter)
            : "ir" (i));
}
# 63 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) void atomic_sub(int i, atomic_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "subl %1,%0"
            : "+m" (v->counter)
            : "ir" (i));
}
# 79 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_sub_and_test(int i, atomic_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "subl" " %1, " "%0" "; j" "e" " %l[cc_label]" : : "m" (v->counter), "er" (i) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}







static inline __attribute__((no_instrument_function)) void atomic_inc(atomic_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "incl %0"
            : "+m" (v->counter));
}







static inline __attribute__((no_instrument_function)) void atomic_dec(atomic_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "decl %0"
            : "+m" (v->counter));
}
# 116 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_dec_and_test(atomic_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "decl" " " "%0" "; j" "e" " %l[cc_label]" : : "m" (v->counter) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 129 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_inc_and_test(atomic_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "incl" " " "%0" "; j" "e" " %l[cc_label]" : : "m" (v->counter) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 143 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_add_negative(int i, atomic_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "addl" " %1, " "%0" "; j" "s" " %l[cc_label]" : : "m" (v->counter), "er" (i) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 155 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_add_return(int i, atomic_t *v)
{
    return i + ({ __typeof__ (*(((&v->counter)))) __ret = (((i))); switch (sizeof(*(((&v->counter))))) { case 1: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "b %b0, %1\n" : "+q" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; case 2: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "w %w0, %1\n" : "+r" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; case 4: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "l %0, %1\n" : "+r" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; case 8: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "q %q0, %1\n" : "+r" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; default: __xadd_wrong_size(); } __ret; });
}
# 167 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_sub_return(int i, atomic_t *v)
{
    return atomic_add_return(-i, v);
}




static inline __attribute__((no_instrument_function)) int atomic_cmpxchg(atomic_t *v, int old, int new)
{
return ({ __typeof__(*((&v->counter))) __ret; __typeof__(*((&v->counter))) __old = ((old)); __typeof__(*((&v->counter))) __new = ((new)); switch ((sizeof(*(&v->counter)))) { case 1: { volatile u8 *__ptr = (volatile u8 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgb %2,%1" : "=a" (__ret), "+m" (*__ptr) : "q" (__new), "0" (__old) : "memory"); break; } case 2: { volatile u16 *__ptr = (volatile u16 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgw %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 4: { volatile u32 *__ptr = (volatile u32 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgl %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 8: { volatile u64 *__ptr = (volatile u64 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgq %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } default: __cmpxchg_wrong_size(); } __ret; });
}

static inline __attribute__((no_instrument_function)) int atomic_xchg(atomic_t *v, int new)
{
return ({ __typeof__ (*((&v->counter))) __ret = ((new)); switch (sizeof(*((&v->counter)))) { case 1: asm volatile ("" "xchg" "b %b0, %1\n" : "+q" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; case 2: asm volatile ("" "xchg" "w %w0, %1\n" : "+r" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; case 4: asm volatile ("" "xchg" "l %0, %1\n" : "+r" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; case 8: asm volatile ("" "xchg" "q %q0, %1\n" : "+r" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; default: __xchg_wrong_size(); } __ret; });
}
# 194 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) int __atomic_add_unless(atomic_t *v, int a, int u)
{
    int c, old;
    c = atomic_read(v);
    for (;;) {
        if (__builtin_expect(!!(c == (u)), 0))
            break;
        old = atomic_cmpxchg((v), c, c + (a));
        if (__builtin_expect(!!(old == c), 1))
            break;
        c = old;
    }
    return c;
}
# 216 "./arch/x86/include/asm/atomic.h"
static inline __attribute__((no_instrument_function)) short int atomic_inc_short(short int *v)
{
    asm(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "addw $1, %0" : "+m" (*v));
    return *v;
}
# 235 "./arch/x86/include/asm/atomic.h"
# 1 "./arch/x86/include/asm/atomic64_64.h" 1
# 19 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) long atomic64_read(const atomic64_t *v)
{
    return (*({ __attribute__((unused)) typeof((v)->counter) __var = ( typeof((v)->counter)) 0; (volatile typeof((v)->counter) *)&((v)->counter); }));
}
# 31 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) void atomic64_set(atomic64_t *v, long i)
{
    v->counter = i;
}
# 43 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) void atomic64_add(long i, atomic64_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "addq %1,%0"
            : "=m" (v->counter)
            : "er" (i), "m" (v->counter));
}
# 57 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) void atomic64_sub(long i, atomic64_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "subq %1,%0"
            : "=m" (v->counter)
            : "er" (i), "m" (v->counter));
}
# 73 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) int atomic64_sub_and_test(long i, atomic64_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "subq" " %1, " "%0" "; j" "e" " %l[cc_label]" : : "m" (v->counter), "er" (i) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}







static inline __attribute__((no_instrument_function)) void atomic64_inc(atomic64_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "incq %0"
            : "=m" (v->counter)
            : "m" (v->counter));
}







static inline __attribute__((no_instrument_function)) void atomic64_dec(atomic64_t *v)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "decq %0"
            : "=m" (v->counter)
            : "m" (v->counter));
}
# 112 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) int atomic64_dec_and_test(atomic64_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "decq" " " "%0" "; j" "e" " %l[cc_label]" : : "m" (v->counter) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 125 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) int atomic64_inc_and_test(atomic64_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "incq" " " "%0" "; j" "e" " %l[cc_label]" : : "m" (v->counter) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 139 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) int atomic64_add_negative(long i, atomic64_t *v)
{
    do { do { asm goto(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "addq" " %1, " "%0" "; j" "s" " %l[cc_label]" : : "m" (v->counter), "er" (i) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}
# 151 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) long atomic64_add_return(long i, atomic64_t *v)
{
    return i + ({ __typeof__ (*(((&v->counter)))) __ret = (((i))); switch (sizeof(*(((&v->counter))))) { case 1: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "b %b0, %1\n" : "+q" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; case 2: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "w %w0, %1\n" : "+r" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; case 4: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "l %0, %1\n" : "+r" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; case 8: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "q %q0, %1\n" : "+r" (__ret), "+m" (*(((&v->counter)))) : : "memory", "cc"); break; default: __xadd_wrong_size(); } __ret; });
}

static inline __attribute__((no_instrument_function)) long atomic64_sub_return(long i, atomic64_t *v)
{
    return atomic64_add_return(-i, v);
}




static inline __attribute__((no_instrument_function)) long atomic64_cmpxchg(atomic64_t *v, long old, long new)
{
return ({ __typeof__(*((&v->counter))) __ret; __typeof__(*((&v->counter))) __old = ((old)); __typeof__(*((&v->counter))) __new = ((new)); switch ((sizeof(*(&v->counter)))) { case 1: { volatile u8 *__ptr = (volatile u8 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgb %2,%1" : "=a" (__ret), "+m" (*__ptr) : "q" (__new), "0" (__old) : "memory"); break; } case 2: { volatile u16 *__ptr = (volatile u16 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgw %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 4: { volatile u32 *__ptr = (volatile u32 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgl %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 8: { volatile u64 *__ptr = (volatile u64 *)((&v->counter)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgq %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } default: __cmpxchg_wrong_size(); } __ret; });
}

static inline __attribute__((no_instrument_function)) long atomic64_xchg(atomic64_t *v, long new)
{
return ({ __typeof__ (*((&v->counter))) __ret = ((new)); switch (sizeof(*((&v->counter)))) { case 1: asm volatile ("" "xchg" "b %b0, %1\n" : "+q" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; case 2: asm volatile ("" "xchg" "w %w0, %1\n" : "+r" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; case 4: asm volatile ("" "xchg" "l %0, %1\n" : "+r" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; case 8: asm volatile ("" "xchg" "q %q0, %1\n" : "+r" (__ret), "+m" (*((&v->counter))) : : "memory", "cc"); break; default: __xchg_wrong_size(); } __ret; });
}
# 183 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) int atomic64_add_unless(atomic64_t *v, long a, long u)
{
    long c, old;
    c = atomic64_read(v);
    for (;;) {
        if (__builtin_expect(!!(c == (u)), 0))
            break;
        old = atomic64_cmpxchg((v), c, c + (a));
        if (__builtin_expect(!!(old == c), 1))
            break;
        c = old;
    }
    return c != (u);
}
# 207 "./arch/x86/include/asm/atomic64_64.h"
static inline __attribute__((no_instrument_function)) long atomic64_dec_if_positive(atomic64_t *v)
{
    long c, old, dec;
    c = atomic64_read(v);
    for (;;) {
        dec = c - 1;
        if (__builtin_expect(!!(dec < 0), 0))
            break;
        old = atomic64_cmpxchg((v), c, dec);
        if (__builtin_expect(!!(old == c), 1))
            break;
        c = old;
    }
    return dec;
}
# 236 "./arch/x86/include/asm/atomic.h" 2
# 5 "include/linux/atomic.h" 2
# 15 "include/linux/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_add_unless(atomic_t *v, int a, int u)
{
    return __atomic_add_unless(v, a, u) != u;
}
# 44 "include/linux/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_inc_not_zero_hint(atomic_t *v, int hint)
{
    int val, c = hint;


    if (!hint)
        return atomic_add_unless((v), 1, 0);

    do {
        val = atomic_cmpxchg(v, c, c + 1);
        if (val == c)
            return 1;
        c = val;
    } while (c);

    return 0;
}



static inline __attribute__((no_instrument_function)) int atomic_inc_unless_negative(atomic_t *p)
{
    int v, v1;
    for (v = 0; v >= 0; v = v1) {
        v1 = atomic_cmpxchg(p, v, v + 1);
        if (__builtin_expect(!!(v1 == v), 1))
            return 1;
    }
    return 0;
}



static inline __attribute__((no_instrument_function)) int atomic_dec_unless_positive(atomic_t *p)
{
    int v, v1;
    for (v = 0; v <= 0; v = v1) {
        v1 = atomic_cmpxchg(p, v, v - 1);
        if (__builtin_expect(!!(v1 == v), 1))
            return 1;
    }
    return 0;
}
# 97 "include/linux/atomic.h"
static inline __attribute__((no_instrument_function)) int atomic_dec_if_positive(atomic_t *v)
{
    int c, old, dec;
    c = atomic_read(v);
    for (;;) {
        dec = c - 1;
        if (__builtin_expect(!!(dec < 0), 0))
            break;
        old = atomic_cmpxchg((v), c, dec);
        if (__builtin_expect(!!(old == c), 1))
            break;
        c = old;
    }
    return dec;
}



static inline __attribute__((no_instrument_function)) void atomic_or(int i, atomic_t *v)
{
    int old;
    int new;

    do {
        old = atomic_read(v);
        new = old | i;
    } while (atomic_cmpxchg(v, old, new) != old);
}


# 1 "include/asm-generic/atomic-long.h" 1
# 23 "include/asm-generic/atomic-long.h"
typedef atomic64_t atomic_long_t;



static inline __attribute__((no_instrument_function)) long atomic_long_read(atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return (long)atomic64_read(v);
}

static inline __attribute__((no_instrument_function)) void atomic_long_set(atomic_long_t *l, long i)
{
    atomic64_t *v = (atomic64_t *)l;

    atomic64_set(v, i);
}

static inline __attribute__((no_instrument_function)) void atomic_long_inc(atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    atomic64_inc(v);
}

static inline __attribute__((no_instrument_function)) void atomic_long_dec(atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    atomic64_dec(v);
}

static inline __attribute__((no_instrument_function)) void atomic_long_add(long i, atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    atomic64_add(i, v);
}

static inline __attribute__((no_instrument_function)) void atomic_long_sub(long i, atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    atomic64_sub(i, v);
}

static inline __attribute__((no_instrument_function)) int atomic_long_sub_and_test(long i, atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return atomic64_sub_and_test(i, v);
}

static inline __attribute__((no_instrument_function)) int atomic_long_dec_and_test(atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return atomic64_dec_and_test(v);
}

static inline __attribute__((no_instrument_function)) int atomic_long_inc_and_test(atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return atomic64_inc_and_test(v);
}

static inline __attribute__((no_instrument_function)) int atomic_long_add_negative(long i, atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return atomic64_add_negative(i, v);
}

static inline __attribute__((no_instrument_function)) long atomic_long_add_return(long i, atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return (long)atomic64_add_return(i, v);
}

static inline __attribute__((no_instrument_function)) long atomic_long_sub_return(long i, atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return (long)atomic64_sub_return(i, v);
}

static inline __attribute__((no_instrument_function)) long atomic_long_inc_return(atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return (long)(atomic64_add_return(1, (v)));
}

static inline __attribute__((no_instrument_function)) long atomic_long_dec_return(atomic_long_t *l)
{
    atomic64_t *v = (atomic64_t *)l;

    return (long)(atomic64_sub_return(1, (v)));
}

static inline __attribute__((no_instrument_function)) long atomic_long_add_unless(atomic_long_t *l, long a, long u)
{
    atomic64_t *v = (atomic64_t *)l;

    return (long)atomic64_add_unless(v, a, u);
}
# 128 "include/linux/atomic.h" 2
# 19 "include/linux/mutex.h" 2

# 1 "include/linux/osq_lock.h" 1







struct optimistic_spin_node {
    struct optimistic_spin_node *next, *prev;
    int locked;
    int cpu;
};

struct optimistic_spin_queue {




    atomic_t tail;
};






static inline __attribute__((no_instrument_function)) void osq_lock_init(struct optimistic_spin_queue *lock)
{
    atomic_set(&lock->tail, (0));
}

extern bool osq_lock(struct optimistic_spin_queue *lock);
extern void osq_unlock(struct optimistic_spin_queue *lock);
# 21 "include/linux/mutex.h" 2
# 50 "include/linux/mutex.h"
struct mutex {

    atomic_t count;
    spinlock_t wait_lock;
    struct list_head wait_list;

    struct task_struct *owner;


    struct optimistic_spin_queue osq;







};





struct mutex_waiter {
    struct list_head list;
    struct task_struct *task;



};
# 99 "include/linux/mutex.h"
static inline __attribute__((no_instrument_function)) void mutex_destroy(struct mutex *lock) {}
# 119 "include/linux/mutex.h"
extern void __mutex_init(struct mutex *lock, const char *name,
                         struct lock_class_key *key);







static inline __attribute__((no_instrument_function)) int mutex_is_locked(struct mutex *lock)
{
    return atomic_read(&lock->count) != 1;
}
# 157 "include/linux/mutex.h"
extern void mutex_lock(struct mutex *lock);
extern int __attribute__((warn_unused_result)) mutex_lock_interruptible(struct mutex *lock);
extern int __attribute__((warn_unused_result)) mutex_lock_killable(struct mutex *lock);
# 173 "include/linux/mutex.h"
extern int mutex_trylock(struct mutex *lock);
extern void mutex_unlock(struct mutex *lock);

extern int atomic_dec_and_mutex_lock(atomic_t *cnt, struct mutex *lock);
# 21 "kernel/locking/mutex.c" 2
# 1 "include/linux/ww_mutex.h" 1
# 19 "include/linux/ww_mutex.h"
struct ww_class {
    atomic_long_t stamp;
    struct lock_class_key acquire_key;
    struct lock_class_key mutex_key;
    const char *acquire_name;
    const char *mutex_name;
};

struct ww_acquire_ctx {
    struct task_struct *task;
    unsigned long stamp;
    unsigned acquired;
# 43 "include/linux/ww_mutex.h"
};

struct ww_mutex {
    struct mutex base;
    struct ww_acquire_ctx *ctx;



};
# 85 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) void ww_mutex_init(struct ww_mutex *lock,
                                                                         struct ww_class *ww_class)
{
    __mutex_init(&lock->base, ww_class->mutex_name, &ww_class->mutex_key);
    lock->ctx = ((void *)0);



}
# 119 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) void ww_acquire_init(struct ww_acquire_ctx *ctx,
                                                                           struct ww_class *ww_class)
{
    ctx->task = get_current();
    ctx->stamp = atomic_long_inc_return(&ww_class->stamp);
    ctx->acquired = 0;
# 140 "include/linux/ww_mutex.h"
}
# 153 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) void ww_acquire_done(struct ww_acquire_ctx *ctx)
{






}
# 170 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) void ww_acquire_fini(struct ww_acquire_ctx *ctx)
{
# 187 "include/linux/ww_mutex.h"
}

extern int __attribute__((warn_unused_result)) __ww_mutex_lock(struct ww_mutex *lock,
                                                               struct ww_acquire_ctx *ctx);
extern int __attribute__((warn_unused_result)) __ww_mutex_lock_interruptible(struct ww_mutex *lock,
                                                                             struct ww_acquire_ctx *ctx);
# 223 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) int ww_mutex_lock(struct ww_mutex *lock, struct ww_acquire_ctx *ctx)
{
    if (ctx)
        return __ww_mutex_lock(lock, ctx);

    mutex_lock(&lock->base);
    return 0;
}
# 262 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) ww_mutex_lock_interruptible(struct ww_mutex *lock,
                                                                                                                          struct ww_acquire_ctx *ctx)
{
    if (ctx)
        return __ww_mutex_lock_interruptible(lock, ctx);
    else
        return mutex_lock_interruptible(&lock->base);
}
# 294 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) void
ww_mutex_lock_slow(struct ww_mutex *lock, struct ww_acquire_ctx *ctx)
{
    int ret;



    ret = ww_mutex_lock(lock, ctx);
    (void)ret;
}
# 330 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result))
ww_mutex_lock_slow_interruptible(struct ww_mutex *lock,
                                 struct ww_acquire_ctx *ctx)
{



    return ww_mutex_lock_interruptible(lock, ctx);
}

extern void ww_mutex_unlock(struct ww_mutex *lock);
# 349 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) int __attribute__((warn_unused_result)) ww_mutex_trylock(struct ww_mutex *lock)
{
    return mutex_trylock(&lock->base);
}
# 362 "include/linux/ww_mutex.h"
static inline __attribute__((no_instrument_function)) void ww_mutex_destroy(struct ww_mutex *lock)
{
    mutex_destroy(&lock->base);
}







static inline __attribute__((no_instrument_function)) bool ww_mutex_is_locked(struct ww_mutex *lock)
{
    return mutex_is_locked(&lock->base);
}
# 22 "kernel/locking/mutex.c" 2
# 1 "include/linux/sched.h" 1



# 1 "include/uapi/linux/sched.h" 1
# 5 "include/linux/sched.h" 2

# 1 "include/linux/sched/prio.h" 1
# 47 "include/linux/sched/prio.h"
static inline __attribute__((no_instrument_function)) long nice_to_rlimit(long nice)
{
    return (19 - nice + 1);
}




static inline __attribute__((no_instrument_function)) long rlimit_to_nice(long prio)
{
    return (19 - prio + 1);
}
# 7 "include/linux/sched.h" 2


struct sched_param {
    int sched_priority;
};

# 1 "./arch/x86/include/uapi/asm/param.h" 1
# 1 "include/asm-generic/param.h" 1



# 1 "include/uapi/asm-generic/param.h" 1
# 5 "include/asm-generic/param.h" 2
# 1 "./arch/x86/include/uapi/asm/param.h" 2
# 14 "include/linux/sched.h" 2

# 1 "include/linux/capability.h" 1
# 15 "include/linux/capability.h"
# 1 "include/uapi/linux/capability.h" 1
# 18 "include/uapi/linux/capability.h"
struct task_struct;
# 40 "include/uapi/linux/capability.h"
typedef struct __user_cap_header_struct {
    __u32 version;
    int pid;
} *cap_user_header_t;

typedef struct __user_cap_data_struct {
    __u32 effective;
    __u32 permitted;
    __u32 inheritable;
} *cap_user_data_t;
# 69 "include/uapi/linux/capability.h"
struct vfs_cap_data {
    __le32 magic_etc;
    struct {
        __le32 permitted;
        __le32 inheritable;
    } data[2];
};
# 16 "include/linux/capability.h" 2





extern int file_caps_enabled;

typedef struct kernel_cap_struct {
    __u32 cap[2];
} kernel_cap_t;


struct cpu_vfs_cap_data {
    __u32 magic_etc;
    kernel_cap_t permitted;
    kernel_cap_t inheritable;
};





struct file;
struct inode;
struct dentry;
struct user_namespace;

struct user_namespace *current_user_ns(void);

extern const kernel_cap_t __cap_empty_set;
extern const kernel_cap_t __cap_init_eff_set;
# 117 "include/linux/capability.h"
static inline __attribute__((no_instrument_function)) kernel_cap_t cap_combine(const kernel_cap_t a,
                                                                               const kernel_cap_t b)
{
    kernel_cap_t dest;
    do { unsigned __capi; for (__capi = 0; __capi < 2; ++__capi) { dest.cap[__capi] = a.cap[__capi] | b.cap[__capi]; } } while (0);
    return dest;
}

static inline __attribute__((no_instrument_function)) kernel_cap_t cap_intersect(const kernel_cap_t a,
                                                                                 const kernel_cap_t b)
{
    kernel_cap_t dest;
    do { unsigned __capi; for (__capi = 0; __capi < 2; ++__capi) { dest.cap[__capi] = a.cap[__capi] & b.cap[__capi]; } } while (0);
    return dest;
}

static inline __attribute__((no_instrument_function)) kernel_cap_t cap_drop(const kernel_cap_t a,
                                                                            const kernel_cap_t drop)
{
    kernel_cap_t dest;
    do { unsigned __capi; for (__capi = 0; __capi < 2; ++__capi) { dest.cap[__capi] = a.cap[__capi] &~ drop.cap[__capi]; } } while (0);
    return dest;
}

static inline __attribute__((no_instrument_function)) kernel_cap_t cap_invert(const kernel_cap_t c)
{
    kernel_cap_t dest;
    do { unsigned __capi; for (__capi = 0; __capi < 2; ++__capi) { dest.cap[__capi] = ~ c.cap[__capi]; } } while (0);
    return dest;
}

static inline __attribute__((no_instrument_function)) int cap_isclear(const kernel_cap_t a)
{
    unsigned __capi;
    for (__capi = 0; __capi < 2; ++__capi) {
        if (a.cap[__capi] != 0)
            return 0;
    }
    return 1;
}
# 165 "include/linux/capability.h"
static inline __attribute__((no_instrument_function)) int cap_issubset(const kernel_cap_t a, const kernel_cap_t set)
{
    kernel_cap_t dest;
    dest = cap_drop(a, set);
    return cap_isclear(dest);
}



static inline __attribute__((no_instrument_function)) int cap_is_fs_cap(int cap)
{
    const kernel_cap_t __cap_fs_set = ((kernel_cap_t){{ ((1 << ((0) & 31)) | (1 << ((27) & 31)) | (1 << ((1) & 31)) | (1 << ((2) & 31)) | (1 << ((3) & 31)) | (1 << ((4) & 31))) | (1 << ((9) & 31)), ((1 << ((32) & 31))) } });
    return !!((1 << ((cap) & 31)) & __cap_fs_set.cap[((cap) >> 5)]);
}

static inline __attribute__((no_instrument_function)) kernel_cap_t cap_drop_fs_set(const kernel_cap_t a)
{
    const kernel_cap_t __cap_fs_set = ((kernel_cap_t){{ ((1 << ((0) & 31)) | (1 << ((27) & 31)) | (1 << ((1) & 31)) | (1 << ((2) & 31)) | (1 << ((3) & 31)) | (1 << ((4) & 31))) | (1 << ((9) & 31)), ((1 << ((32) & 31))) } });
    return cap_drop(a, __cap_fs_set);
}

static inline __attribute__((no_instrument_function)) kernel_cap_t cap_raise_fs_set(const kernel_cap_t a,
                                                                                    const kernel_cap_t permitted)
{
    const kernel_cap_t __cap_fs_set = ((kernel_cap_t){{ ((1 << ((0) & 31)) | (1 << ((27) & 31)) | (1 << ((1) & 31)) | (1 << ((2) & 31)) | (1 << ((3) & 31)) | (1 << ((4) & 31))) | (1 << ((9) & 31)), ((1 << ((32) & 31))) } });
    return cap_combine(a,
                       cap_intersect(permitted, __cap_fs_set));
}

static inline __attribute__((no_instrument_function)) kernel_cap_t cap_drop_nfsd_set(const kernel_cap_t a)
{
    const kernel_cap_t __cap_fs_set = ((kernel_cap_t){{ ((1 << ((0) & 31)) | (1 << ((27) & 31)) | (1 << ((1) & 31)) | (1 << ((2) & 31)) | (1 << ((3) & 31)) | (1 << ((4) & 31))) | (1 << ((24) & 31)), ((1 << ((32) & 31))) } });
    return cap_drop(a, __cap_fs_set);
}

static inline __attribute__((no_instrument_function)) kernel_cap_t cap_raise_nfsd_set(const kernel_cap_t a,
                                                                                      const kernel_cap_t permitted)
{
    const kernel_cap_t __cap_nfsd_set = ((kernel_cap_t){{ ((1 << ((0) & 31)) | (1 << ((27) & 31)) | (1 << ((1) & 31)) | (1 << ((2) & 31)) | (1 << ((3) & 31)) | (1 << ((4) & 31))) | (1 << ((24) & 31)), ((1 << ((32) & 31))) } });
    return cap_combine(a,
                       cap_intersect(permitted, __cap_nfsd_set));
}


extern bool has_capability(struct task_struct *t, int cap);
extern bool has_ns_capability(struct task_struct *t,
                              struct user_namespace *ns, int cap);
extern bool has_capability_noaudit(struct task_struct *t, int cap);
extern bool has_ns_capability_noaudit(struct task_struct *t,
                                      struct user_namespace *ns, int cap);
extern bool capable(int cap);
extern bool ns_capable(struct user_namespace *ns, int cap);
# 245 "include/linux/capability.h"
extern bool capable_wrt_inode_uidgid(const struct inode *inode, int cap);
extern bool file_ns_capable(const struct file *file, struct user_namespace *ns, int cap);


extern int get_vfs_caps_from_disk(const struct dentry *dentry, struct cpu_vfs_cap_data *cpu_caps);
# 16 "include/linux/sched.h" 2



# 1 "include/linux/timex.h" 1
# 56 "include/linux/timex.h"
# 1 "include/uapi/linux/timex.h" 1
# 56 "include/uapi/linux/timex.h"
# 1 "include/linux/time.h" 1




# 1 "include/linux/seqlock.h" 1
# 35 "include/linux/seqlock.h"
# 1 "include/linux/spinlock.h" 1
# 50 "include/linux/spinlock.h"
# 1 "include/linux/preempt.h" 1
# 18 "include/linux/preempt.h"
# 1 "./arch/x86/include/asm/preempt.h" 1





# 1 "include/linux/thread_info.h" 1
# 13 "include/linux/thread_info.h"
struct timespec;
struct compat_timespec;




struct restart_block {
    long (*fn)(struct restart_block *);
    union {

        struct {
            u32 *uaddr;
            u32 val;
            u32 flags;
            u32 bitset;
            u64 time;
            u32 *uaddr2;
        } futex;

        struct {
            clockid_t clockid;
            struct timespec *rmtp;

            struct compat_timespec *compat_rmtp;

            u64 expires;
        } nanosleep;

        struct {
            struct pollfd *ufds;
            int nfds;
            int has_timeout;
            unsigned long tv_sec;
            unsigned long tv_nsec;
        } poll;
    };
};

extern long do_no_restart_syscall(struct restart_block *parm);


# 1 "./arch/x86/include/asm/thread_info.h" 1
# 48 "./arch/x86/include/asm/thread_info.h"
struct task_struct;



struct thread_info {
    struct task_struct *task;
    __u32 flags;
    __u32 status;
    __u32 cpu;
    int saved_preempt_count;
    mm_segment_t addr_limit;
    void *sysenter_return;
    unsigned int sig_on_uaccess_error:1;
    unsigned int uaccess_err:1;
};
# 180 "./arch/x86/include/asm/thread_info.h"
extern __attribute__((section(".data..percpu" ""))) __typeof__(unsigned long) kernel_stack;

static inline __attribute__((no_instrument_function)) struct thread_info *current_thread_info(void)
{
    return (struct thread_info *)(current_top_of_stack() - (((1UL) << 12) << (2 + 0)));
}

static inline __attribute__((no_instrument_function)) unsigned long current_stack_pointer(void)
{
    unsigned long sp;

    asm("mov %%rsp,%0" : "=g" (sp));



    return sp;
}
# 246 "./arch/x86/include/asm/thread_info.h"
static inline __attribute__((no_instrument_function)) void set_restore_sigmask(void)
{
    struct thread_info *ti = current_thread_info();
    ti->status |= 0x0008;
    ({ int __ret_warn_on = !!(!(__builtin_constant_p((2)) ? constant_test_bit((2), ((unsigned long *)&ti->flags)) : variable_test_bit((2), ((unsigned long *)&ti->flags)))); if (__builtin_expect(!!(__ret_warn_on), 0)) warn_slowpath_null("./arch/x86/include/asm/thread_info.h", 250); __builtin_expect(!!(__ret_warn_on), 0); });
}
static inline __attribute__((no_instrument_function)) void clear_restore_sigmask(void)
{
    current_thread_info()->status &= ~0x0008;
}
static inline __attribute__((no_instrument_function)) bool test_restore_sigmask(void)
{
    return current_thread_info()->status & 0x0008;
}
static inline __attribute__((no_instrument_function)) bool test_and_clear_restore_sigmask(void)
{
    struct thread_info *ti = current_thread_info();
    if (!(ti->status & 0x0008))
        return false;
    ti->status &= ~0x0008;
    return true;
}

static inline __attribute__((no_instrument_function)) bool is_ia32_task(void)
{




    if (current_thread_info()->status & 0x0002)
        return true;

    return false;
}
# 293 "./arch/x86/include/asm/thread_info.h"
extern void arch_task_cache_init(void);
extern int arch_dup_task_struct(struct task_struct *dst, struct task_struct *src);
extern void arch_release_task_struct(struct task_struct *tsk);
# 55 "include/linux/thread_info.h" 2
# 69 "include/linux/thread_info.h"
static inline __attribute__((no_instrument_function)) void set_ti_thread_flag(struct thread_info *ti, int flag)
{
    set_bit(flag, (unsigned long *)&ti->flags);
}

static inline __attribute__((no_instrument_function)) void clear_ti_thread_flag(struct thread_info *ti, int flag)
{
    clear_bit(flag, (unsigned long *)&ti->flags);
}

static inline __attribute__((no_instrument_function)) int test_and_set_ti_thread_flag(struct thread_info *ti, int flag)
{
    return test_and_set_bit(flag, (unsigned long *)&ti->flags);
}

static inline __attribute__((no_instrument_function)) int test_and_clear_ti_thread_flag(struct thread_info *ti, int flag)
{
    return test_and_clear_bit(flag, (unsigned long *)&ti->flags);
}

static inline __attribute__((no_instrument_function)) int test_ti_thread_flag(struct thread_info *ti, int flag)
{
    return (__builtin_constant_p((flag)) ? constant_test_bit((flag), ((unsigned long *)&ti->flags)) : variable_test_bit((flag), ((unsigned long *)&ti->flags)));
}
# 7 "./arch/x86/include/asm/preempt.h" 2

extern __attribute__((section(".data..percpu" ""))) __typeof__(int) __preempt_count;
# 20 "./arch/x86/include/asm/preempt.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) int preempt_count(void)
{
    return ({ typeof(__preempt_count) pfo_ret__; switch (sizeof(__preempt_count)) { case 1: asm("mov" "b ""%%""gs"":" "%" "1"",%0" : "=q" (pfo_ret__) : "m" (__preempt_count)); break; case 2: asm("mov" "w ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; case 4: asm("mov" "l ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; case 8: asm("mov" "q ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; default: __bad_percpu_size(); } pfo_ret__; }) & ~0x80000000;
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void preempt_count_set(int pc)
{
    do { typedef typeof((__preempt_count)) pto_T__; if (0) { pto_T__ pto_tmp__; pto_tmp__ = (pc); (void)pto_tmp__; } switch (sizeof((__preempt_count))) { case 1: asm("mov" "b %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "qi" ((pto_T__)(pc))); break; case 2: asm("mov" "w %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pto_T__)(pc))); break; case 4: asm("mov" "l %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pto_T__)(pc))); break; case 8: asm("mov" "q %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "re" ((pto_T__)(pc))); break; default: __bad_percpu_size(); } } while (0);
}
# 51 "./arch/x86/include/asm/preempt.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void set_preempt_need_resched(void)
{
    do { typedef typeof((__preempt_count)) pto_T__; if (0) { pto_T__ pto_tmp__; pto_tmp__ = (~0x80000000); (void)pto_tmp__; } switch (sizeof((__preempt_count))) { case 1: asm("and" "b %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "qi" ((pto_T__)(~0x80000000))); break; case 2: asm("and" "w %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pto_T__)(~0x80000000))); break; case 4: asm("and" "l %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pto_T__)(~0x80000000))); break; case 8: asm("and" "q %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "re" ((pto_T__)(~0x80000000))); break; default: __bad_percpu_size(); } } while (0);
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void clear_preempt_need_resched(void)
{
    do { typedef typeof((__preempt_count)) pto_T__; if (0) { pto_T__ pto_tmp__; pto_tmp__ = (0x80000000); (void)pto_tmp__; } switch (sizeof((__preempt_count))) { case 1: asm("or" "b %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "qi" ((pto_T__)(0x80000000))); break; case 2: asm("or" "w %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pto_T__)(0x80000000))); break; case 4: asm("or" "l %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pto_T__)(0x80000000))); break; case 8: asm("or" "q %1,""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "re" ((pto_T__)(0x80000000))); break; default: __bad_percpu_size(); } } while (0);
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) bool test_preempt_need_resched(void)
{
    return !(({ typeof(__preempt_count) pfo_ret__; switch (sizeof(__preempt_count)) { case 1: asm("mov" "b ""%%""gs"":" "%" "1"",%0" : "=q" (pfo_ret__) : "m" (__preempt_count)); break; case 2: asm("mov" "w ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; case 4: asm("mov" "l ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; case 8: asm("mov" "q ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; default: __bad_percpu_size(); } pfo_ret__; }) & 0x80000000);
}





static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void __preempt_count_add(int val)
{
    do { typedef typeof((__preempt_count)) pao_T__; const int pao_ID__ = (__builtin_constant_p(val) && ((val) == 1 || (val) == -1)) ? (int)(val) : 0; if (0) { pao_T__ pao_tmp__; pao_tmp__ = (val); (void)pao_tmp__; } switch (sizeof((__preempt_count))) { case 1: if (pao_ID__ == 1) asm("incb ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decb ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addb %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "qi" ((pao_T__)(val))); break; case 2: if (pao_ID__ == 1) asm("incw ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decw ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addw %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pao_T__)(val))); break; case 4: if (pao_ID__ == 1) asm("incl ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decl ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addl %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pao_T__)(val))); break; case 8: if (pao_ID__ == 1) asm("incq ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decq ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addq %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "re" ((pao_T__)(val))); break; default: __bad_percpu_size(); } } while (0);
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void __preempt_count_sub(int val)
{
    do { typedef typeof((__preempt_count)) pao_T__; const int pao_ID__ = (__builtin_constant_p(-val) && ((-val) == 1 || (-val) == -1)) ? (int)(-val) : 0; if (0) { pao_T__ pao_tmp__; pao_tmp__ = (-val); (void)pao_tmp__; } switch (sizeof((__preempt_count))) { case 1: if (pao_ID__ == 1) asm("incb ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decb ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addb %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "qi" ((pao_T__)(-val))); break; case 2: if (pao_ID__ == 1) asm("incw ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decw ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addw %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pao_T__)(-val))); break; case 4: if (pao_ID__ == 1) asm("incl ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decl ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addl %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "ri" ((pao_T__)(-val))); break; case 8: if (pao_ID__ == 1) asm("incq ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else if (pao_ID__ == -1) asm("decq ""%%""gs"":" "%" "0" : "+m" ((__preempt_count))); else asm("addq %1, ""%%""gs"":" "%" "0" : "+m" ((__preempt_count)) : "re" ((pao_T__)(-val))); break; default: __bad_percpu_size(); } } while (0);
}






static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) bool __preempt_count_dec_and_test(void)
{
    do { do { asm goto("decl" " " "%%""gs"":" "%" "0" "; j" "e" " %l[cc_label]" : : "m" (__preempt_count) : "memory" : cc_label); asm (""); } while (0); return 0; cc_label: return 1; } while (0);
}




static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) bool should_resched(void)
{
    return __builtin_expect(!!(!({ typeof(__preempt_count) pfo_ret__; switch (sizeof(__preempt_count)) { case 1: asm("mov" "b ""%%""gs"":" "%" "1"",%0" : "=q" (pfo_ret__) : "m" (__preempt_count)); break; case 2: asm("mov" "w ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; case 4: asm("mov" "l ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; case 8: asm("mov" "q ""%%""gs"":" "%" "1"",%0" : "=r" (pfo_ret__) : "m" (__preempt_count)); break; default: __bad_percpu_size(); } pfo_ret__; })), 0);
}
# 19 "include/linux/preempt.h" 2
# 51 "include/linux/spinlock.h" 2






# 1 "include/linux/bottom_half.h" 1




# 1 "include/linux/preempt_mask.h" 1
# 6 "include/linux/bottom_half.h" 2




static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void __local_bh_disable_ip(unsigned long ip, unsigned int cnt)
{
    __preempt_count_add(cnt);
    __asm__ __volatile__("": : :"memory");
}


static inline __attribute__((no_instrument_function)) void local_bh_disable(void)
{
    __local_bh_disable_ip(({ __label__ __here; __here: (unsigned long)&&__here; }), (2 * (1UL << (0 + 8))));
}

extern void _local_bh_enable(void);
extern void __local_bh_enable_ip(unsigned long ip, unsigned int cnt);

static inline __attribute__((no_instrument_function)) void local_bh_enable_ip(unsigned long ip)
{
    __local_bh_enable_ip(ip, (2 * (1UL << (0 + 8))));
}

static inline __attribute__((no_instrument_function)) void local_bh_enable(void)
{
    __local_bh_enable_ip(({ __label__ __here; __here: (unsigned long)&&__here; }), (2 * (1UL << (0 + 8))));
}
# 58 "include/linux/spinlock.h" 2
# 87 "include/linux/spinlock.h"
# 1 "./arch/x86/include/asm/spinlock.h" 1



# 1 "include/linux/jump_label.h" 1
# 58 "include/linux/jump_label.h"
extern bool static_key_initialized;
# 76 "include/linux/jump_label.h"
struct static_key {
    atomic_t enabled;
};
# 88 "include/linux/jump_label.h"
enum jump_label_type {
    JUMP_LABEL_DISABLE = 0,
    JUMP_LABEL_ENABLE,
};

struct module;



static inline __attribute__((no_instrument_function)) int static_key_count(struct static_key *key)
{
    return atomic_read(&key->enabled);
}
# 157 "include/linux/jump_label.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void jump_label_init(void)
{
    static_key_initialized = true;
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) bool static_key_false(struct static_key *key)
{
    if (__builtin_expect(!!(static_key_count(key) > 0), 0))
        return true;
    return false;
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) bool static_key_true(struct static_key *key)
{
    if (__builtin_expect(!!(static_key_count(key) > 0), 1))
        return true;
    return false;
}

static inline __attribute__((no_instrument_function)) void static_key_slow_inc(struct static_key *key)
{
    ({ int __ret_warn_on = !!(!static_key_initialized); if (__builtin_expect(!!(__ret_warn_on), 0)) warn_slowpath_fmt("include/linux/jump_label.h", 178, "%s used before call to jump_label_init", __func__); __builtin_expect(!!(__ret_warn_on), 0); });
    atomic_inc(&key->enabled);
}

static inline __attribute__((no_instrument_function)) void static_key_slow_dec(struct static_key *key)
{
    ({ int __ret_warn_on = !!(!static_key_initialized); if (__builtin_expect(!!(__ret_warn_on), 0)) warn_slowpath_fmt("include/linux/jump_label.h", 184, "%s used before call to jump_label_init", __func__); __builtin_expect(!!(__ret_warn_on), 0); });
    atomic_dec(&key->enabled);
}

static inline __attribute__((no_instrument_function)) int jump_label_text_reserved(void *start, void *end)
{
    return 0;
}

static inline __attribute__((no_instrument_function)) void jump_label_lock(void) {}
static inline __attribute__((no_instrument_function)) void jump_label_unlock(void) {}

static inline __attribute__((no_instrument_function)) int jump_label_apply_nops(struct module *mod)
{
    return 0;
}
# 211 "include/linux/jump_label.h"
static inline __attribute__((no_instrument_function)) bool static_key_enabled(struct static_key *key)
{
    return static_key_count(key) > 0;
}
# 5 "./arch/x86/include/asm/spinlock.h" 2




# 1 "./arch/x86/include/asm/paravirt.h" 1
# 985 "./arch/x86/include/asm/paravirt.h"
static inline __attribute__((no_instrument_function)) void paravirt_arch_dup_mmap(struct mm_struct *oldmm,
                                                                                  struct mm_struct *mm)
{
}

static inline __attribute__((no_instrument_function)) void paravirt_arch_exit_mmap(struct mm_struct *mm)
{
}
# 10 "./arch/x86/include/asm/spinlock.h" 2
# 42 "./arch/x86/include/asm/spinlock.h"
extern struct static_key paravirt_ticketlocks_enabled;
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) bool static_key_false(struct static_key *key);
# 53 "./arch/x86/include/asm/spinlock.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void __ticket_lock_spinning(arch_spinlock_t *lock,
                                                                                                                 __ticket_t ticket)
{
}
static inline __attribute__((no_instrument_function)) void __ticket_unlock_kick(arch_spinlock_t *lock,
                                                                                __ticket_t ticket)
{
}


static inline __attribute__((no_instrument_function)) int __tickets_equal(__ticket_t one, __ticket_t two)
{
    return !((one ^ two) & ~((__ticket_t)0));
}

static inline __attribute__((no_instrument_function)) void __ticket_check_and_clear_slowpath(arch_spinlock_t *lock,
                                                                                             __ticket_t head)
{
    if (head & ((__ticket_t)0)) {
        arch_spinlock_t old, new;

        old.tickets.head = head;
        new.tickets.head = head & ~((__ticket_t)0);
        old.tickets.tail = new.tickets.head + ((__ticket_t)1);
        new.tickets.tail = old.tickets.tail;


        ({ __typeof__(*((&lock->head_tail))) __ret; __typeof__(*((&lock->head_tail))) __old = ((old.head_tail)); __typeof__(*((&lock->head_tail))) __new = ((new.head_tail)); switch ((sizeof(*(&lock->head_tail)))) { case 1: { volatile u8 *__ptr = (volatile u8 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgb %2,%1" : "=a" (__ret), "+m" (*__ptr) : "q" (__new), "0" (__old) : "memory"); break; } case 2: { volatile u16 *__ptr = (volatile u16 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgw %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 4: { volatile u32 *__ptr = (volatile u32 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgl %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 8: { volatile u64 *__ptr = (volatile u64 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgq %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } default: __cmpxchg_wrong_size(); } __ret; });
    }
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) int arch_spin_value_unlocked(arch_spinlock_t lock)
{
    return __tickets_equal(lock.tickets.head, lock.tickets.tail);
}
# 102 "./arch/x86/include/asm/spinlock.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void arch_spin_lock(arch_spinlock_t *lock)
{
    register struct __raw_tickets inc = { .tail = ((__ticket_t)1) };

    inc = ({ __typeof__ (*(((&lock->tickets)))) __ret = (((inc))); switch (sizeof(*(((&lock->tickets))))) { case 1: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "b %b0, %1\n" : "+q" (__ret), "+m" (*(((&lock->tickets)))) : : "memory", "cc"); break; case 2: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "w %w0, %1\n" : "+r" (__ret), "+m" (*(((&lock->tickets)))) : : "memory", "cc"); break; case 4: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "l %0, %1\n" : "+r" (__ret), "+m" (*(((&lock->tickets)))) : : "memory", "cc"); break; case 8: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "q %q0, %1\n" : "+r" (__ret), "+m" (*(((&lock->tickets)))) : : "memory", "cc"); break; default: __xadd_wrong_size(); } __ret; });
    if (__builtin_expect(!!(inc.head == inc.tail), 1))
        goto out;

    for (;;) {
        unsigned count = (1 << 15);

        do {
            inc.head = ({ union { typeof(lock->tickets.head) __val; char __c[1]; } __u; __read_once_size(&(lock->tickets.head), __u.__c, sizeof(lock->tickets.head)); __u.__val; });
            if (__tickets_equal(inc.head, inc.tail))
                goto clear_slowpath;
            cpu_relax();
        } while (--count);
        __ticket_lock_spinning(lock, inc.tail);
    }
    clear_slowpath:
    __ticket_check_and_clear_slowpath(lock, inc.head);
    out:
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) int arch_spin_trylock(arch_spinlock_t *lock)
{
    arch_spinlock_t old, new;

    old.tickets = ({ union { typeof(lock->tickets) __val; char __c[1]; } __u; __read_once_size(&(lock->tickets), __u.__c, sizeof(lock->tickets)); __u.__val; });
    if (!__tickets_equal(old.tickets.head, old.tickets.tail))
        return 0;

    new.head_tail = old.head_tail + (((__ticket_t)1) << (sizeof(__ticket_t) * 8));
    new.head_tail &= ~((__ticket_t)0);


    return ({ __typeof__(*((&lock->head_tail))) __ret; __typeof__(*((&lock->head_tail))) __old = ((old.head_tail)); __typeof__(*((&lock->head_tail))) __new = ((new.head_tail)); switch ((sizeof(*(&lock->head_tail)))) { case 1: { volatile u8 *__ptr = (volatile u8 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgb %2,%1" : "=a" (__ret), "+m" (*__ptr) : "q" (__new), "0" (__old) : "memory"); break; } case 2: { volatile u16 *__ptr = (volatile u16 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgw %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 4: { volatile u32 *__ptr = (volatile u32 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgl %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } case 8: { volatile u64 *__ptr = (volatile u64 *)((&lock->head_tail)); asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "cmpxchgq %2,%1" : "=a" (__ret), "+m" (*__ptr) : "r" (__new), "0" (__old) : "memory"); break; } default: __cmpxchg_wrong_size(); } __ret; }) == old.head_tail;
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void arch_spin_unlock(arch_spinlock_t *lock)
{
    if (((__ticket_t)0) &&
        static_key_false(&paravirt_ticketlocks_enabled)) {
        __ticket_t head;

        do { bool __cond = !(!(((__ticket_t)64) != 64)); extern void __compiletime_assert_148(void) __attribute__((error("BUILD_BUG_ON failed: " "((__ticket_t)NR_CPUS) != NR_CPUS"))); if (__cond) __compiletime_assert_148(); do { } while (0); } while (0);

        head = ({ __typeof__ (*(((&lock->tickets.head)))) __ret = (((((__ticket_t)1)))); switch (sizeof(*(((&lock->tickets.head))))) { case 1: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "b %b0, %1\n" : "+q" (__ret), "+m" (*(((&lock->tickets.head)))) : : "memory", "cc"); break; case 2: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "w %w0, %1\n" : "+r" (__ret), "+m" (*(((&lock->tickets.head)))) : : "memory", "cc"); break; case 4: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "l %0, %1\n" : "+r" (__ret), "+m" (*(((&lock->tickets.head)))) : : "memory", "cc"); break; case 8: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "q %q0, %1\n" : "+r" (__ret), "+m" (*(((&lock->tickets.head)))) : : "memory", "cc"); break; default: __xadd_wrong_size(); } __ret; });

        if (__builtin_expect(!!(head & ((__ticket_t)0)), 0)) {
            head &= ~((__ticket_t)0);
            __ticket_unlock_kick(lock, (head + ((__ticket_t)1)));
        }
    } else
        ({ __typeof__ (*(&lock->tickets.head)) __ret = (((__ticket_t)1)); switch (sizeof(*(&lock->tickets.head))) { case 1: asm volatile ( "addb %b1, %0\n" : "+m" (*(&lock->tickets.head)) : "qi" (((__ticket_t)1)) : "memory", "cc"); break; case 2: asm volatile ( "addw %w1, %0\n" : "+m" (*(&lock->tickets.head)) : "ri" (((__ticket_t)1)) : "memory", "cc"); break; case 4: asm volatile ( "addl %1, %0\n" : "+m" (*(&lock->tickets.head)) : "ri" (((__ticket_t)1)) : "memory", "cc"); break; case 8: asm volatile ( "addq %1, %0\n" : "+m" (*(&lock->tickets.head)) : "ri" (((__ticket_t)1)) : "memory", "cc"); break; default: __add_wrong_size(); } __ret; });
}

static inline __attribute__((no_instrument_function)) int arch_spin_is_locked(arch_spinlock_t *lock)
{
    struct __raw_tickets tmp = ({ union { typeof(lock->tickets) __val; char __c[1]; } __u; __read_once_size(&(lock->tickets), __u.__c, sizeof(lock->tickets)); __u.__val; });

    return !__tickets_equal(tmp.tail, tmp.head);
}

static inline __attribute__((no_instrument_function)) int arch_spin_is_contended(arch_spinlock_t *lock)
{
    struct __raw_tickets tmp = ({ union { typeof(lock->tickets) __val; char __c[1]; } __u; __read_once_size(&(lock->tickets), __u.__c, sizeof(lock->tickets)); __u.__val; });

    tmp.head &= ~((__ticket_t)0);
    return (__ticket_t)(tmp.tail - tmp.head) > ((__ticket_t)1);
}


static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void arch_spin_lock_flags(arch_spinlock_t *lock,
                                                                                                               unsigned long flags)
{
    arch_spin_lock(lock);
}

static inline __attribute__((no_instrument_function)) void arch_spin_unlock_wait(arch_spinlock_t *lock)
{
    __ticket_t head = ({ union { typeof(lock->tickets.head) __val; char __c[1]; } __u; __read_once_size(&(lock->tickets.head), __u.__c, sizeof(lock->tickets.head)); __u.__val; });

    for (;;) {
        struct __raw_tickets tmp = ({ union { typeof(lock->tickets) __val; char __c[1]; } __u; __read_once_size(&(lock->tickets), __u.__c, sizeof(lock->tickets)); __u.__val; });




        if (__tickets_equal(tmp.head, tmp.tail) ||
            !__tickets_equal(tmp.head, head))
            break;

        cpu_relax();
    }
}
# 214 "./arch/x86/include/asm/spinlock.h"
# 1 "./arch/x86/include/asm/qrwlock.h" 1







static inline __attribute__((no_instrument_function)) void queue_write_unlock(struct qrwlock *lock)
{
    __asm__ __volatile__("": : :"memory");
    (*({ __attribute__((unused)) typeof(*(u8 *)&lock->cnts) __var = ( typeof(*(u8 *)&lock->cnts)) 0; (volatile typeof(*(u8 *)&lock->cnts) *)&(*(u8 *)&lock->cnts); })) = 0;
}


# 1 "include/asm-generic/qrwlock.h" 1
# 39 "include/asm-generic/qrwlock.h"
extern void queue_read_lock_slowpath(struct qrwlock *lock);
extern void queue_write_lock_slowpath(struct qrwlock *lock);





static inline __attribute__((no_instrument_function)) int queue_read_can_lock(struct qrwlock *lock)
{
    return !(atomic_read(&lock->cnts) & 0xff);
}





static inline __attribute__((no_instrument_function)) int queue_write_can_lock(struct qrwlock *lock)
{
    return !atomic_read(&lock->cnts);
}






static inline __attribute__((no_instrument_function)) int queue_read_trylock(struct qrwlock *lock)
{
    u32 cnts;

    cnts = atomic_read(&lock->cnts);
    if (__builtin_expect(!!(!(cnts & 0xff)), 1)) {
        cnts = (u32)atomic_add_return((1U << 8), &lock->cnts);
        if (__builtin_expect(!!(!(cnts & 0xff)), 1))
            return 1;
        atomic_sub((1U << 8), &lock->cnts);
    }
    return 0;
}






static inline __attribute__((no_instrument_function)) int queue_write_trylock(struct qrwlock *lock)
{
    u32 cnts;

    cnts = atomic_read(&lock->cnts);
    if (__builtin_expect(!!(cnts), 0))
        return 0;

    return __builtin_expect(!!(atomic_cmpxchg(&lock->cnts, cnts, cnts | 0xff) == cnts), 1)
            ;
}




static inline __attribute__((no_instrument_function)) void queue_read_lock(struct qrwlock *lock)
{
    u32 cnts;

    cnts = atomic_add_return((1U << 8), &lock->cnts);
    if (__builtin_expect(!!(!(cnts & 0xff)), 1))
        return;


    queue_read_lock_slowpath(lock);
}





static inline __attribute__((no_instrument_function)) void queue_write_lock(struct qrwlock *lock)
{

    if (atomic_cmpxchg(&lock->cnts, 0, 0xff) == 0)
        return;

    queue_write_lock_slowpath(lock);
}





static inline __attribute__((no_instrument_function)) void queue_read_unlock(struct qrwlock *lock)
{



    __asm__ __volatile__("": : :"memory");
    atomic_sub((1U << 8), &lock->cnts);
}
# 16 "./arch/x86/include/asm/qrwlock.h" 2
# 215 "./arch/x86/include/asm/spinlock.h" 2
# 88 "include/linux/spinlock.h" 2
# 155 "include/linux/spinlock.h"
static inline __attribute__((no_instrument_function)) void do_raw_spin_lock(raw_spinlock_t *lock)
{
    (void)0;
    arch_spin_lock(&lock->raw_lock);
}

static inline __attribute__((no_instrument_function)) void
do_raw_spin_lock_flags(raw_spinlock_t *lock, unsigned long *flags)
{
    (void)0;
    arch_spin_lock_flags(&lock->raw_lock, *flags);
}

static inline __attribute__((no_instrument_function)) int do_raw_spin_trylock(raw_spinlock_t *lock)
{
    return arch_spin_trylock(&(lock)->raw_lock);
}

static inline __attribute__((no_instrument_function)) void do_raw_spin_unlock(raw_spinlock_t *lock)
{
    arch_spin_unlock(&lock->raw_lock);
    (void)0;
}
# 284 "include/linux/spinlock.h"
# 1 "include/linux/rwlock.h" 1
# 285 "include/linux/spinlock.h" 2





# 1 "include/linux/spinlock_api_smp.h" 1
# 18 "include/linux/spinlock_api_smp.h"
int in_lock_functions(unsigned long addr);



void __attribute__((section(".spinlock.text"))) _raw_spin_lock(raw_spinlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_spin_lock_nested(raw_spinlock_t *lock, int subclass)
;
void __attribute__((section(".spinlock.text"))) _raw_spin_lock_bh_nested(raw_spinlock_t *lock, int subclass)
;
void __attribute__((section(".spinlock.text")))
_raw_spin_lock_nest_lock(raw_spinlock_t *lock, struct lockdep_map *map)
;
void __attribute__((section(".spinlock.text"))) _raw_spin_lock_bh(raw_spinlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_spin_lock_irq(raw_spinlock_t *lock)
;

unsigned long __attribute__((section(".spinlock.text"))) _raw_spin_lock_irqsave(raw_spinlock_t *lock)
;
unsigned long __attribute__((section(".spinlock.text")))
_raw_spin_lock_irqsave_nested(raw_spinlock_t *lock, int subclass)
;
int __attribute__((section(".spinlock.text"))) _raw_spin_trylock(raw_spinlock_t *lock);
int __attribute__((section(".spinlock.text"))) _raw_spin_trylock_bh(raw_spinlock_t *lock);
void __attribute__((section(".spinlock.text"))) _raw_spin_unlock(raw_spinlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_spin_unlock_bh(raw_spinlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_spin_unlock_irq(raw_spinlock_t *lock) ;
void __attribute__((section(".spinlock.text")))
_raw_spin_unlock_irqrestore(raw_spinlock_t *lock, unsigned long flags)
;
# 88 "include/linux/spinlock_api_smp.h"
static inline __attribute__((no_instrument_function)) int __raw_spin_trylock(raw_spinlock_t *lock)
{
    __asm__ __volatile__("": : :"memory");
    if (do_raw_spin_trylock(lock)) {
        do { } while (0);
        return 1;
    }
    __asm__ __volatile__("": : :"memory");
    return 0;
}
# 106 "include/linux/spinlock_api_smp.h"
static inline __attribute__((no_instrument_function)) unsigned long __raw_spin_lock_irqsave(raw_spinlock_t *lock)
{
    unsigned long flags;

    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); flags = arch_local_irq_save(); } while (0); } while (0);
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
# 121 "include/linux/spinlock_api_smp.h"
    do_raw_spin_lock_flags(lock, &flags);

    return flags;
}

static inline __attribute__((no_instrument_function)) void __raw_spin_lock_irq(raw_spinlock_t *lock)
{
    do { arch_local_irq_disable(); } while (0);
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do_raw_spin_lock(lock);
}

static inline __attribute__((no_instrument_function)) void __raw_spin_lock_bh(raw_spinlock_t *lock)
{
    __local_bh_disable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
    do { } while (0);
    do_raw_spin_lock(lock);
}

static inline __attribute__((no_instrument_function)) void __raw_spin_lock(raw_spinlock_t *lock)
{
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do_raw_spin_lock(lock);
}



static inline __attribute__((no_instrument_function)) void __raw_spin_unlock(raw_spinlock_t *lock)
{
    do { } while (0);
    do_raw_spin_unlock(lock);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_spin_unlock_irqrestore(raw_spinlock_t *lock,
                                                                                        unsigned long flags)
{
    do { } while (0);
    do_raw_spin_unlock(lock);
    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); arch_local_irq_restore(flags); } while (0); } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_spin_unlock_irq(raw_spinlock_t *lock)
{
    do { } while (0);
    do_raw_spin_unlock(lock);
    do { arch_local_irq_enable(); } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_spin_unlock_bh(raw_spinlock_t *lock)
{
    do { } while (0);
    do_raw_spin_unlock(lock);
    __local_bh_enable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
}

static inline __attribute__((no_instrument_function)) int __raw_spin_trylock_bh(raw_spinlock_t *lock)
{
    __local_bh_disable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
    if (do_raw_spin_trylock(lock)) {
        do { } while (0);
        return 1;
    }
    __local_bh_enable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
    return 0;
}

# 1 "include/linux/rwlock_api_smp.h" 1
# 18 "include/linux/rwlock_api_smp.h"
void __attribute__((section(".spinlock.text"))) _raw_read_lock(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_write_lock(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_read_lock_bh(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_write_lock_bh(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_read_lock_irq(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_write_lock_irq(rwlock_t *lock) ;
unsigned long __attribute__((section(".spinlock.text"))) _raw_read_lock_irqsave(rwlock_t *lock)
;
unsigned long __attribute__((section(".spinlock.text"))) _raw_write_lock_irqsave(rwlock_t *lock)
;
int __attribute__((section(".spinlock.text"))) _raw_read_trylock(rwlock_t *lock);
int __attribute__((section(".spinlock.text"))) _raw_write_trylock(rwlock_t *lock);
void __attribute__((section(".spinlock.text"))) _raw_read_unlock(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_write_unlock(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_read_unlock_bh(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_write_unlock_bh(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_read_unlock_irq(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text"))) _raw_write_unlock_irq(rwlock_t *lock) ;
void __attribute__((section(".spinlock.text")))
_raw_read_unlock_irqrestore(rwlock_t *lock, unsigned long flags)
;
void __attribute__((section(".spinlock.text")))
_raw_write_unlock_irqrestore(rwlock_t *lock, unsigned long flags)
;
# 117 "include/linux/rwlock_api_smp.h"
static inline __attribute__((no_instrument_function)) int __raw_read_trylock(rwlock_t *lock)
{
    __asm__ __volatile__("": : :"memory");
    if (queue_read_trylock(&(lock)->raw_lock)) {
        do { } while (0);
        return 1;
    }
    __asm__ __volatile__("": : :"memory");
    return 0;
}

static inline __attribute__((no_instrument_function)) int __raw_write_trylock(rwlock_t *lock)
{
    __asm__ __volatile__("": : :"memory");
    if (queue_write_trylock(&(lock)->raw_lock)) {
        do { } while (0);
        return 1;
    }
    __asm__ __volatile__("": : :"memory");
    return 0;
}
# 146 "include/linux/rwlock_api_smp.h"
static inline __attribute__((no_instrument_function)) void __raw_read_lock(rwlock_t *lock)
{
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do {(void)0; queue_read_lock(&(lock)->raw_lock); } while (0);
}

static inline __attribute__((no_instrument_function)) unsigned long __raw_read_lock_irqsave(rwlock_t *lock)
{
    unsigned long flags;

    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); flags = arch_local_irq_save(); } while (0); } while (0);
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do {(void)0; queue_read_lock(&((lock))->raw_lock); } while (0)
            ;
    return flags;
}

static inline __attribute__((no_instrument_function)) void __raw_read_lock_irq(rwlock_t *lock)
{
    do { arch_local_irq_disable(); } while (0);
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do {(void)0; queue_read_lock(&(lock)->raw_lock); } while (0);
}

static inline __attribute__((no_instrument_function)) void __raw_read_lock_bh(rwlock_t *lock)
{
    __local_bh_disable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
    do { } while (0);
    do {(void)0; queue_read_lock(&(lock)->raw_lock); } while (0);
}

static inline __attribute__((no_instrument_function)) unsigned long __raw_write_lock_irqsave(rwlock_t *lock)
{
    unsigned long flags;

    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); flags = arch_local_irq_save(); } while (0); } while (0);
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do {(void)0; queue_write_lock(&((lock))->raw_lock); } while (0)
            ;
    return flags;
}

static inline __attribute__((no_instrument_function)) void __raw_write_lock_irq(rwlock_t *lock)
{
    do { arch_local_irq_disable(); } while (0);
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do {(void)0; queue_write_lock(&(lock)->raw_lock); } while (0);
}

static inline __attribute__((no_instrument_function)) void __raw_write_lock_bh(rwlock_t *lock)
{
    __local_bh_disable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
    do { } while (0);
    do {(void)0; queue_write_lock(&(lock)->raw_lock); } while (0);
}

static inline __attribute__((no_instrument_function)) void __raw_write_lock(rwlock_t *lock)
{
    __asm__ __volatile__("": : :"memory");
    do { } while (0);
    do {(void)0; queue_write_lock(&(lock)->raw_lock); } while (0);
}



static inline __attribute__((no_instrument_function)) void __raw_write_unlock(rwlock_t *lock)
{
    do { } while (0);
    do {queue_write_unlock(&(lock)->raw_lock); (void)0; } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_read_unlock(rwlock_t *lock)
{
    do { } while (0);
    do {queue_read_unlock(&(lock)->raw_lock); (void)0; } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void
__raw_read_unlock_irqrestore(rwlock_t *lock, unsigned long flags)
{
    do { } while (0);
    do {queue_read_unlock(&(lock)->raw_lock); (void)0; } while (0);
    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); arch_local_irq_restore(flags); } while (0); } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_read_unlock_irq(rwlock_t *lock)
{
    do { } while (0);
    do {queue_read_unlock(&(lock)->raw_lock); (void)0; } while (0);
    do { arch_local_irq_enable(); } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_read_unlock_bh(rwlock_t *lock)
{
    do { } while (0);
    do {queue_read_unlock(&(lock)->raw_lock); (void)0; } while (0);
    __local_bh_enable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
}

static inline __attribute__((no_instrument_function)) void __raw_write_unlock_irqrestore(rwlock_t *lock,
                                                                                         unsigned long flags)
{
    do { } while (0);
    do {queue_write_unlock(&(lock)->raw_lock); (void)0; } while (0);
    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); arch_local_irq_restore(flags); } while (0); } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_write_unlock_irq(rwlock_t *lock)
{
    do { } while (0);
    do {queue_write_unlock(&(lock)->raw_lock); (void)0; } while (0);
    do { arch_local_irq_enable(); } while (0);
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void __raw_write_unlock_bh(rwlock_t *lock)
{
    do { } while (0);
    do {queue_write_unlock(&(lock)->raw_lock); (void)0; } while (0);
    __local_bh_enable_ip((unsigned long)__builtin_return_address(0), ((2 * (1UL << (0 + 8))) + 0));
}
# 193 "include/linux/spinlock_api_smp.h" 2
# 291 "include/linux/spinlock.h" 2
# 299 "include/linux/spinlock.h"
static inline __attribute__((no_instrument_function)) raw_spinlock_t *spinlock_check(spinlock_t *lock)
{
    return &lock->rlock;
}







static inline __attribute__((no_instrument_function)) void spin_lock(spinlock_t *lock)
{
    _raw_spin_lock(&lock->rlock);
}

static inline __attribute__((no_instrument_function)) void spin_lock_bh(spinlock_t *lock)
{
    _raw_spin_lock_bh(&lock->rlock);
}

static inline __attribute__((no_instrument_function)) int spin_trylock(spinlock_t *lock)
{
    return (_raw_spin_trylock(&lock->rlock));
}
# 340 "include/linux/spinlock.h"
static inline __attribute__((no_instrument_function)) void spin_lock_irq(spinlock_t *lock)
{
    _raw_spin_lock_irq(&lock->rlock);
}
# 355 "include/linux/spinlock.h"
static inline __attribute__((no_instrument_function)) void spin_unlock(spinlock_t *lock)
{
    __raw_spin_unlock(&lock->rlock);
}

static inline __attribute__((no_instrument_function)) void spin_unlock_bh(spinlock_t *lock)
{
    _raw_spin_unlock_bh(&lock->rlock);
}

static inline __attribute__((no_instrument_function)) void spin_unlock_irq(spinlock_t *lock)
{
    __raw_spin_unlock_irq(&lock->rlock);
}

static inline __attribute__((no_instrument_function)) void spin_unlock_irqrestore(spinlock_t *lock, unsigned long flags)
{
    do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); _raw_spin_unlock_irqrestore(&lock->rlock, flags); } while (0);
}

static inline __attribute__((no_instrument_function)) int spin_trylock_bh(spinlock_t *lock)
{
    return (_raw_spin_trylock_bh(&lock->rlock));
}

static inline __attribute__((no_instrument_function)) int spin_trylock_irq(spinlock_t *lock)
{
    return ({ do { arch_local_irq_disable(); } while (0); (_raw_spin_trylock(&lock->rlock)) ? 1 : ({ do { arch_local_irq_enable(); } while (0); 0; }); });
}






static inline __attribute__((no_instrument_function)) void spin_unlock_wait(spinlock_t *lock)
{
    arch_spin_unlock_wait(&(&lock->rlock)->raw_lock);
}

static inline __attribute__((no_instrument_function)) int spin_is_locked(spinlock_t *lock)
{
    return arch_spin_is_locked(&(&lock->rlock)->raw_lock);
}

static inline __attribute__((no_instrument_function)) int spin_is_contended(spinlock_t *lock)
{
    return arch_spin_is_contended(&(&lock->rlock)->raw_lock);
}

static inline __attribute__((no_instrument_function)) int spin_can_lock(spinlock_t *lock)
{
    return (!arch_spin_is_locked(&(&lock->rlock)->raw_lock));
}
# 425 "include/linux/spinlock.h"
extern int _atomic_dec_and_lock(atomic_t *atomic, spinlock_t *lock);
# 36 "include/linux/seqlock.h" 2
# 46 "include/linux/seqlock.h"
typedef struct seqcount {
    unsigned sequence;



} seqcount_t;

static inline __attribute__((no_instrument_function)) void __seqcount_init(seqcount_t *s, const char *name,
                                                                           struct lock_class_key *key)
{



    do { (void)(name); (void)(key); } while (0);
    s->sequence = 0;
}
# 106 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) unsigned __read_seqcount_begin(const seqcount_t *s)
{
    unsigned ret;

    repeat:
    ret = ({ union { typeof(s->sequence) __val; char __c[1]; } __u; __read_once_size(&(s->sequence), __u.__c, sizeof(s->sequence)); __u.__val; });
    if (__builtin_expect(!!(ret & 1), 0)) {
        cpu_relax();
        goto repeat;
    }
    return ret;
}
# 128 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) unsigned raw_read_seqcount(const seqcount_t *s)
{
    unsigned ret = ({ union { typeof(s->sequence) __val; char __c[1]; } __u; __read_once_size(&(s->sequence), __u.__c, sizeof(s->sequence)); __u.__val; });
    __asm__ __volatile__("": : :"memory");
    return ret;
}
# 144 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) unsigned raw_read_seqcount_begin(const seqcount_t *s)
{
    unsigned ret = __read_seqcount_begin(s);
    __asm__ __volatile__("": : :"memory");
    return ret;
}
# 160 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) unsigned read_seqcount_begin(const seqcount_t *s)
{
    ;
    return raw_read_seqcount_begin(s);
}
# 180 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) unsigned raw_seqcount_begin(const seqcount_t *s)
{
    unsigned ret = ({ union { typeof(s->sequence) __val; char __c[1]; } __u; __read_once_size(&(s->sequence), __u.__c, sizeof(s->sequence)); __u.__val; });
    __asm__ __volatile__("": : :"memory");
    return ret & ~1;
}
# 201 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) int __read_seqcount_retry(const seqcount_t *s, unsigned start)
{
    return __builtin_expect(!!(s->sequence != start), 0);
}
# 216 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) int read_seqcount_retry(const seqcount_t *s, unsigned start)
{
    __asm__ __volatile__("": : :"memory");
    return __read_seqcount_retry(s, start);
}



static inline __attribute__((no_instrument_function)) void raw_write_seqcount_begin(seqcount_t *s)
{
    s->sequence++;
    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void raw_write_seqcount_end(seqcount_t *s)
{
    __asm__ __volatile__("": : :"memory");
    s->sequence++;
}





static inline __attribute__((no_instrument_function)) void raw_write_seqcount_latch(seqcount_t *s)
{
    __asm__ __volatile__("": : :"memory");
    s->sequence++;
    __asm__ __volatile__("": : :"memory");
}





static inline __attribute__((no_instrument_function)) void write_seqcount_begin_nested(seqcount_t *s, int subclass)
{
    raw_write_seqcount_begin(s);
    do { } while (0);
}

static inline __attribute__((no_instrument_function)) void write_seqcount_begin(seqcount_t *s)
{
    write_seqcount_begin_nested(s, 0);
}

static inline __attribute__((no_instrument_function)) void write_seqcount_end(seqcount_t *s)
{
    do { } while (0);
    raw_write_seqcount_end(s);
}
# 275 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) void write_seqcount_barrier(seqcount_t *s)
{
    __asm__ __volatile__("": : :"memory");
    s->sequence+=2;
}

typedef struct {
    struct seqcount seqcount;
    spinlock_t lock;
} seqlock_t;
# 308 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) unsigned read_seqbegin(const seqlock_t *sl)
{
    return read_seqcount_begin(&sl->seqcount);
}

static inline __attribute__((no_instrument_function)) unsigned read_seqretry(const seqlock_t *sl, unsigned start)
{
    return read_seqcount_retry(&sl->seqcount, start);
}






static inline __attribute__((no_instrument_function)) void write_seqlock(seqlock_t *sl)
{
    spin_lock(&sl->lock);
    write_seqcount_begin(&sl->seqcount);
}

static inline __attribute__((no_instrument_function)) void write_sequnlock(seqlock_t *sl)
{
    write_seqcount_end(&sl->seqcount);
    spin_unlock(&sl->lock);
}

static inline __attribute__((no_instrument_function)) void write_seqlock_bh(seqlock_t *sl)
{
    spin_lock_bh(&sl->lock);
    write_seqcount_begin(&sl->seqcount);
}

static inline __attribute__((no_instrument_function)) void write_sequnlock_bh(seqlock_t *sl)
{
    write_seqcount_end(&sl->seqcount);
    spin_unlock_bh(&sl->lock);
}

static inline __attribute__((no_instrument_function)) void write_seqlock_irq(seqlock_t *sl)
{
    spin_lock_irq(&sl->lock);
    write_seqcount_begin(&sl->seqcount);
}

static inline __attribute__((no_instrument_function)) void write_sequnlock_irq(seqlock_t *sl)
{
    write_seqcount_end(&sl->seqcount);
    spin_unlock_irq(&sl->lock);
}

static inline __attribute__((no_instrument_function)) unsigned long __write_seqlock_irqsave(seqlock_t *sl)
{
    unsigned long flags;

    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); flags = _raw_spin_lock_irqsave(spinlock_check(&sl->lock)); } while (0); } while (0);
    write_seqcount_begin(&sl->seqcount);
    return flags;
}




static inline __attribute__((no_instrument_function)) void
write_sequnlock_irqrestore(seqlock_t *sl, unsigned long flags)
{
    write_seqcount_end(&sl->seqcount);
    spin_unlock_irqrestore(&sl->lock, flags);
}






static inline __attribute__((no_instrument_function)) void read_seqlock_excl(seqlock_t *sl)
{
    spin_lock(&sl->lock);
}

static inline __attribute__((no_instrument_function)) void read_sequnlock_excl(seqlock_t *sl)
{
    spin_unlock(&sl->lock);
}
# 403 "include/linux/seqlock.h"
static inline __attribute__((no_instrument_function)) void read_seqbegin_or_lock(seqlock_t *lock, int *seq)
{
    if (!(*seq & 1))
        *seq = read_seqbegin(lock);
    else
        read_seqlock_excl(lock);
}

static inline __attribute__((no_instrument_function)) int need_seqretry(seqlock_t *lock, int seq)
{
    return !(seq & 1) && read_seqretry(lock, seq);
}

static inline __attribute__((no_instrument_function)) void done_seqretry(seqlock_t *lock, int seq)
{
    if (seq & 1)
        read_sequnlock_excl(lock);
}

static inline __attribute__((no_instrument_function)) void read_seqlock_excl_bh(seqlock_t *sl)
{
    spin_lock_bh(&sl->lock);
}

static inline __attribute__((no_instrument_function)) void read_sequnlock_excl_bh(seqlock_t *sl)
{
    spin_unlock_bh(&sl->lock);
}

static inline __attribute__((no_instrument_function)) void read_seqlock_excl_irq(seqlock_t *sl)
{
    spin_lock_irq(&sl->lock);
}

static inline __attribute__((no_instrument_function)) void read_sequnlock_excl_irq(seqlock_t *sl)
{
    spin_unlock_irq(&sl->lock);
}

static inline __attribute__((no_instrument_function)) unsigned long __read_seqlock_excl_irqsave(seqlock_t *sl)
{
    unsigned long flags;

    do { do { ({ unsigned long __dummy; typeof(flags) __dummy2; (void)(&__dummy == &__dummy2); 1; }); flags = _raw_spin_lock_irqsave(spinlock_check(&sl->lock)); } while (0); } while (0);
    return flags;
}




static inline __attribute__((no_instrument_function)) void
read_sequnlock_excl_irqrestore(seqlock_t *sl, unsigned long flags)
{
    spin_unlock_irqrestore(&sl->lock, flags);
}

static inline __attribute__((no_instrument_function)) unsigned long
read_seqbegin_or_lock_irqsave(seqlock_t *lock, int *seq)
{
    unsigned long flags = 0;

    if (!(*seq & 1))
        *seq = read_seqbegin(lock);
    else
        do { flags = __read_seqlock_excl_irqsave(lock); } while (0);

    return flags;
}

static inline __attribute__((no_instrument_function)) void
done_seqretry_irqrestore(seqlock_t *lock, int seq, unsigned long flags)
{
    if (seq & 1)
        read_sequnlock_excl_irqrestore(lock, flags);
}
# 6 "include/linux/time.h" 2

# 1 "include/linux/time64.h" 1



# 1 "include/uapi/linux/time.h" 1
# 9 "include/uapi/linux/time.h"
struct timespec {
    __kernel_time_t tv_sec;
    long tv_nsec;
};


struct timeval {
    __kernel_time_t tv_sec;
    __kernel_suseconds_t tv_usec;
};

struct timezone {
    int tz_minuteswest;
    int tz_dsttime;
};
# 34 "include/uapi/linux/time.h"
struct itimerspec {
    struct timespec it_interval;
    struct timespec it_value;
};

struct itimerval {
    struct timeval it_interval;
    struct timeval it_value;
};
# 5 "include/linux/time64.h" 2

typedef __s64 time64_t;
# 36 "include/linux/time64.h"
static inline __attribute__((no_instrument_function)) struct timespec timespec64_to_timespec(const struct timespec ts64)
{
    return ts64;
}

static inline __attribute__((no_instrument_function)) struct timespec timespec_to_timespec64(const struct timespec ts)
{
    return ts;
}
# 8 "include/linux/time.h" 2

extern struct timezone sys_tz;



static inline __attribute__((no_instrument_function)) int timespec_equal(const struct timespec *a,
                                                                         const struct timespec *b)
{
    return (a->tv_sec == b->tv_sec) && (a->tv_nsec == b->tv_nsec);
}






static inline __attribute__((no_instrument_function)) int timespec_compare(const struct timespec *lhs, const struct timespec *rhs)
{
    if (lhs->tv_sec < rhs->tv_sec)
        return -1;
    if (lhs->tv_sec > rhs->tv_sec)
        return 1;
    return lhs->tv_nsec - rhs->tv_nsec;
}

static inline __attribute__((no_instrument_function)) int timeval_compare(const struct timeval *lhs, const struct timeval *rhs)
{
    if (lhs->tv_sec < rhs->tv_sec)
        return -1;
    if (lhs->tv_sec > rhs->tv_sec)
        return 1;
    return lhs->tv_usec - rhs->tv_usec;
}

extern time64_t mktime64(const unsigned int year, const unsigned int mon,
                         const unsigned int day, const unsigned int hour,
                         const unsigned int min, const unsigned int sec);




static inline __attribute__((no_instrument_function)) unsigned long mktime(const unsigned int year,
                                                                           const unsigned int mon, const unsigned int day,
                                                                           const unsigned int hour, const unsigned int min,
                                                                           const unsigned int sec)
{
    return mktime64(year, mon, day, hour, min, sec);
}

extern void set_normalized_timespec(struct timespec *ts, time_t sec, s64 nsec);






extern struct timespec timespec_add_safe(const struct timespec lhs,
                                         const struct timespec rhs);


static inline __attribute__((no_instrument_function)) struct timespec timespec_add(struct timespec lhs,
                                                                                   struct timespec rhs)
{
    struct timespec ts_delta;
    set_normalized_timespec(&ts_delta, lhs.tv_sec + rhs.tv_sec,
                            lhs.tv_nsec + rhs.tv_nsec);
    return ts_delta;
}




static inline __attribute__((no_instrument_function)) struct timespec timespec_sub(struct timespec lhs,
                                                                                   struct timespec rhs)
{
    struct timespec ts_delta;
    set_normalized_timespec(&ts_delta, lhs.tv_sec - rhs.tv_sec,
                            lhs.tv_nsec - rhs.tv_nsec);
    return ts_delta;
}




static inline __attribute__((no_instrument_function)) bool timespec_valid(const struct timespec *ts)
{

    if (ts->tv_sec < 0)
        return false;

    if ((unsigned long)ts->tv_nsec >= 1000000000L)
        return false;
    return true;
}

static inline __attribute__((no_instrument_function)) bool timespec_valid_strict(const struct timespec *ts)
{
    if (!timespec_valid(ts))
        return false;

    if ((unsigned long long)ts->tv_sec >= (((s64)~((u64)1 << 63)) / 1000000000L))
        return false;
    return true;
}

static inline __attribute__((no_instrument_function)) bool timeval_valid(const struct timeval *tv)
{

    if (tv->tv_sec < 0)
        return false;


    if (tv->tv_usec < 0 || tv->tv_usec >= 1000000L)
        return false;

    return true;
}

extern struct timespec timespec_trunc(struct timespec t, unsigned gran);
# 144 "include/linux/time.h"
struct itimerval;
extern int do_setitimer(int which, struct itimerval *value,
                        struct itimerval *ovalue);
extern int do_getitimer(int which, struct itimerval *value);

extern unsigned int alarm_setitimer(unsigned int seconds);

extern long do_utimes(int dfd, const char *filename, struct timespec *times, int flags);

struct tms;
extern void do_sys_times(struct tms *);





struct tm {




    int tm_sec;

    int tm_min;

    int tm_hour;

    int tm_mday;

    int tm_mon;

    long tm_year;

    int tm_wday;

    int tm_yday;
};

void time_to_tm(time_t totalsecs, int offset, struct tm *result);
# 191 "include/linux/time.h"
static inline __attribute__((no_instrument_function)) s64 timespec_to_ns(const struct timespec *ts)
{
    return ((s64) ts->tv_sec * 1000000000L) + ts->tv_nsec;
}
# 203 "include/linux/time.h"
static inline __attribute__((no_instrument_function)) s64 timeval_to_ns(const struct timeval *tv)
{
    return ((s64) tv->tv_sec * 1000000000L) +
           tv->tv_usec * 1000L;
}







extern struct timespec ns_to_timespec(const s64 nsec);







extern struct timeval ns_to_timeval(const s64 nsec);
# 233 "include/linux/time.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void timespec_add_ns(struct timespec *a, u64 ns)
{
    a->tv_sec += __iter_div_u64_rem(a->tv_nsec + ns, 1000000000L, &ns);
    a->tv_nsec = ns;
}
# 57 "include/uapi/linux/timex.h" 2







struct timex {
    unsigned int modes;
    __kernel_long_t offset;
    __kernel_long_t freq;
    __kernel_long_t maxerror;
    __kernel_long_t esterror;
    int status;
    __kernel_long_t constant;
    __kernel_long_t precision;
    __kernel_long_t tolerance;


    struct timeval time;
    __kernel_long_t tick;

    __kernel_long_t ppsfreq;
    __kernel_long_t jitter;
    int shift;
    __kernel_long_t stabil;
    __kernel_long_t jitcnt;
    __kernel_long_t calcnt;
    __kernel_long_t errcnt;
    __kernel_long_t stbcnt;

    int tai;

    int :32; int :32; int :32; int :32;
    int :32; int :32; int :32; int :32;
    int :32; int :32; int :32;
};
# 57 "include/linux/timex.h" 2






# 1 "./include/uapi/linux/param.h" 1



# 1 "./arch/x86/include/uapi/asm/param.h" 1
# 5 "./include/uapi/linux/param.h" 2
# 64 "include/linux/timex.h" 2

# 1 "./arch/x86/include/asm/timex.h" 1




# 1 "./arch/x86/include/asm/tsc.h" 1
# 15 "./arch/x86/include/asm/tsc.h"
typedef unsigned long long cycles_t;

extern unsigned int cpu_khz;
extern unsigned int tsc_khz;

extern void disable_TSC(void);

static inline __attribute__((no_instrument_function)) cycles_t get_cycles(void)
{
    unsigned long long ret = 0;





    ((ret) = __native_read_tsc());

    return ret;
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) cycles_t vget_cycles(void)
{
# 45 "./arch/x86/include/asm/tsc.h"
    return (cycles_t)__native_read_tsc();
}

extern void tsc_init(void);
extern void mark_tsc_unstable(char *reason);
extern int unsynchronized_tsc(void);
extern int check_tsc_unstable(void);
extern int check_tsc_disabled(void);
extern unsigned long native_calibrate_tsc(void);

extern int tsc_clocksource_reliable;





extern void check_tsc_sync_source(int cpu);
extern void check_tsc_sync_target(void);

extern int notsc_setup(char *);
extern void tsc_save_sched_clock_state(void);
extern void tsc_restore_sched_clock_state(void);


unsigned long try_msr_calibrate_tsc(void);
# 6 "./arch/x86/include/asm/timex.h" 2
# 66 "include/linux/timex.h" 2
# 139 "include/linux/timex.h"
extern unsigned long tick_usec;
extern unsigned long tick_nsec;
# 154 "include/linux/timex.h"
extern int do_adjtimex(struct timex *);
extern void hardpps(const struct timespec *, const struct timespec *);

int read_current_timer(unsigned long *timer_val);
void ntp_notify_cmos_timer(void);
# 20 "include/linux/sched.h" 2
# 1 "include/linux/jiffies.h" 1
# 9 "include/linux/jiffies.h"
# 1 "./arch/x86/include/uapi/asm/param.h" 1
# 10 "include/linux/jiffies.h" 2
# 57 "include/linux/jiffies.h"
extern int register_refined_jiffies(long clock_tick_rate);
# 76 "include/linux/jiffies.h"
extern u64 __attribute__((section(".data"))) jiffies_64;
extern unsigned long volatile __attribute__((section(".data"))) jiffies;




static inline __attribute__((no_instrument_function)) u64 get_jiffies_64(void)
{
    return (u64)jiffies;
}
# 182 "include/linux/jiffies.h"
extern unsigned long preset_lpj;
# 283 "include/linux/jiffies.h"
extern unsigned int jiffies_to_msecs(const unsigned long j);
extern unsigned int jiffies_to_usecs(const unsigned long j);

static inline __attribute__((no_instrument_function)) u64 jiffies_to_nsecs(const unsigned long j)
{
    return (u64)jiffies_to_usecs(j) * 1000L;
}

extern unsigned long msecs_to_jiffies(const unsigned int m);
extern unsigned long usecs_to_jiffies(const unsigned int u);
extern unsigned long timespec_to_jiffies(const struct timespec *value);
extern void jiffies_to_timespec(const unsigned long jiffies,
                                struct timespec *value);
extern unsigned long timeval_to_jiffies(const struct timeval *value);
extern void jiffies_to_timeval(const unsigned long jiffies,
                               struct timeval *value);

extern clock_t jiffies_to_clock_t(unsigned long x);
static inline __attribute__((no_instrument_function)) clock_t jiffies_delta_to_clock_t(long delta)
{
    return jiffies_to_clock_t(({ typeof(0L) _max1 = (0L); typeof(delta) _max2 = (delta); (void) (&_max1 == &_max2); _max1 > _max2 ? _max1 : _max2; }));
}

extern unsigned long clock_t_to_jiffies(unsigned long x);
extern u64 jiffies_64_to_clock_t(u64 x);
extern u64 nsec_to_clock_t(u64 x);
extern u64 nsecs_to_jiffies64(u64 n);
extern unsigned long nsecs_to_jiffies(u64 n);
# 21 "include/linux/sched.h" 2
# 1 "include/linux/plist.h" 1
# 81 "include/linux/plist.h"
struct plist_head {
    struct list_head node_list;
};

struct plist_node {
    int prio;
    struct list_head prio_list;
    struct list_head node_list;
};
# 123 "include/linux/plist.h"
static inline __attribute__((no_instrument_function)) void
plist_head_init(struct plist_head *head)
{
    INIT_LIST_HEAD(&head->node_list);
}






static inline __attribute__((no_instrument_function)) void plist_node_init(struct plist_node *node, int prio)
{
    node->prio = prio;
    INIT_LIST_HEAD(&node->prio_list);
    INIT_LIST_HEAD(&node->node_list);
}

extern void plist_add(struct plist_node *node, struct plist_head *head);
extern void plist_del(struct plist_node *node, struct plist_head *head);

extern void plist_requeue(struct plist_node *node, struct plist_head *head);
# 212 "include/linux/plist.h"
static inline __attribute__((no_instrument_function)) int plist_head_empty(const struct plist_head *head)
{
    return list_empty(&head->node_list);
}





static inline __attribute__((no_instrument_function)) int plist_node_empty(const struct plist_node *node)
{
    return list_empty(&node->node_list);
}
# 282 "include/linux/plist.h"
static inline __attribute__((no_instrument_function)) struct plist_node *plist_first(const struct plist_head *head)
{
    return ({ const typeof( ((struct plist_node *)0)->node_list ) *__mptr = (head->node_list.next); (struct plist_node *)( (char *)__mptr - __builtin_offsetof(struct plist_node,node_list) );})
            ;
}







static inline __attribute__((no_instrument_function)) struct plist_node *plist_last(const struct plist_head *head)
{
    return ({ const typeof( ((struct plist_node *)0)->node_list ) *__mptr = (head->node_list.prev); (struct plist_node *)( (char *)__mptr - __builtin_offsetof(struct plist_node,node_list) );})
            ;
}
# 22 "include/linux/sched.h" 2
# 1 "include/linux/rbtree.h" 1
# 33 "include/linux/rbtree.h"
# 1 "include/linux/stddef.h" 1
# 34 "include/linux/rbtree.h" 2

struct rb_node {
    unsigned long __rb_parent_color;
    struct rb_node *rb_right;
    struct rb_node *rb_left;
} __attribute__((aligned(sizeof(long))));


struct rb_root {
    struct rb_node *rb_node;
};
# 61 "include/linux/rbtree.h"
extern void rb_insert_color(struct rb_node *, struct rb_root *);
extern void rb_erase(struct rb_node *, struct rb_root *);



extern struct rb_node *rb_next(const struct rb_node *);
extern struct rb_node *rb_prev(const struct rb_node *);
extern struct rb_node *rb_first(const struct rb_root *);
extern struct rb_node *rb_last(const struct rb_root *);


extern struct rb_node *rb_first_postorder(const struct rb_root *);
extern struct rb_node *rb_next_postorder(const struct rb_node *);


extern void rb_replace_node(struct rb_node *victim, struct rb_node *new,
struct rb_root *root);

static inline __attribute__((no_instrument_function)) void rb_link_node(struct rb_node * node, struct rb_node * parent,
                                                                        struct rb_node ** rb_link)
{
    node->__rb_parent_color = (unsigned long)parent;
    node->rb_left = node->rb_right = ((void *)0);

    *rb_link = node;
}
# 23 "include/linux/sched.h" 2



# 1 "include/linux/nodemask.h" 1
# 93 "include/linux/nodemask.h"
# 1 "include/linux/numa.h" 1
# 94 "include/linux/nodemask.h" 2

typedef struct { unsigned long bits[((((1 << 6)) + (8 * sizeof(long)) - 1) / (8 * sizeof(long)))]; } nodemask_t;
extern nodemask_t _unused_nodemask_arg_;
# 116 "include/linux/nodemask.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) void __node_set(int node, volatile nodemask_t *dstp)
{
    set_bit(node, dstp->bits);
}


static inline __attribute__((no_instrument_function)) void __node_clear(int node, volatile nodemask_t *dstp)
{
    clear_bit(node, dstp->bits);
}


static inline __attribute__((no_instrument_function)) void __nodes_setall(nodemask_t *dstp, unsigned int nbits)
{
    bitmap_fill(dstp->bits, nbits);
}


static inline __attribute__((no_instrument_function)) void __nodes_clear(nodemask_t *dstp, unsigned int nbits)
{
    bitmap_zero(dstp->bits, nbits);
}






static inline __attribute__((no_instrument_function)) int __node_test_and_set(int node, nodemask_t *addr)
{
    return test_and_set_bit(node, addr->bits);
}



static inline __attribute__((no_instrument_function)) void __nodes_and(nodemask_t *dstp, const nodemask_t *src1p,
                                                                       const nodemask_t *src2p, unsigned int nbits)
{
    bitmap_and(dstp->bits, src1p->bits, src2p->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_or(nodemask_t *dstp, const nodemask_t *src1p,
                                                                      const nodemask_t *src2p, unsigned int nbits)
{
    bitmap_or(dstp->bits, src1p->bits, src2p->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_xor(nodemask_t *dstp, const nodemask_t *src1p,
                                                                       const nodemask_t *src2p, unsigned int nbits)
{
    bitmap_xor(dstp->bits, src1p->bits, src2p->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_andnot(nodemask_t *dstp, const nodemask_t *src1p,
                                                                          const nodemask_t *src2p, unsigned int nbits)
{
    bitmap_andnot(dstp->bits, src1p->bits, src2p->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_complement(nodemask_t *dstp,
                                                                              const nodemask_t *srcp, unsigned int nbits)
{
    bitmap_complement(dstp->bits, srcp->bits, nbits);
}



static inline __attribute__((no_instrument_function)) int __nodes_equal(const nodemask_t *src1p,
                                                                        const nodemask_t *src2p, unsigned int nbits)
{
    return bitmap_equal(src1p->bits, src2p->bits, nbits);
}



static inline __attribute__((no_instrument_function)) int __nodes_intersects(const nodemask_t *src1p,
                                                                             const nodemask_t *src2p, unsigned int nbits)
{
    return bitmap_intersects(src1p->bits, src2p->bits, nbits);
}



static inline __attribute__((no_instrument_function)) int __nodes_subset(const nodemask_t *src1p,
                                                                         const nodemask_t *src2p, unsigned int nbits)
{
    return bitmap_subset(src1p->bits, src2p->bits, nbits);
}


static inline __attribute__((no_instrument_function)) int __nodes_empty(const nodemask_t *srcp, unsigned int nbits)
{
    return bitmap_empty(srcp->bits, nbits);
}


static inline __attribute__((no_instrument_function)) int __nodes_full(const nodemask_t *srcp, unsigned int nbits)
{
    return bitmap_full(srcp->bits, nbits);
}


static inline __attribute__((no_instrument_function)) int __nodes_weight(const nodemask_t *srcp, unsigned int nbits)
{
    return bitmap_weight(srcp->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_shift_right(nodemask_t *dstp,
                                                                               const nodemask_t *srcp, int n, int nbits)
{
    bitmap_shift_right(dstp->bits, srcp->bits, n, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_shift_left(nodemask_t *dstp,
                                                                              const nodemask_t *srcp, int n, int nbits)
{
    bitmap_shift_left(dstp->bits, srcp->bits, n, nbits);
}





static inline __attribute__((no_instrument_function)) int __first_node(const nodemask_t *srcp)
{
    return ({ int __min1 = ((1 << 6)); int __min2 = (find_first_bit(srcp->bits, (1 << 6))); __min1 < __min2 ? __min1: __min2; });
}


static inline __attribute__((no_instrument_function)) int __next_node(int n, const nodemask_t *srcp)
{
    return ({ int __min1 = ((1 << 6)); int __min2 = (find_next_bit(srcp->bits, (1 << 6), n+1)); __min1 < __min2 ? __min1: __min2; });
}

static inline __attribute__((no_instrument_function)) void init_nodemask_of_node(nodemask_t *mask, int node)
{
    __nodes_clear(&(*mask), (1 << 6));
    __node_set((node), &(*mask));
}
# 280 "include/linux/nodemask.h"
static inline __attribute__((no_instrument_function)) int __first_unset_node(const nodemask_t *maskp)
{
    return ({ int __min1 = ((1 << 6)); int __min2 = (find_first_zero_bit(maskp->bits, (1 << 6))); __min1 < __min2 ? __min1: __min2; })
            ;
}
# 314 "include/linux/nodemask.h"
static inline __attribute__((no_instrument_function)) int __nodemask_parse_user(const char *buf, int len,
                                                                                nodemask_t *dstp, int nbits)
{
    return bitmap_parse_user(buf, len, dstp->bits, nbits);
}


static inline __attribute__((no_instrument_function)) int __nodelist_parse(const char *buf, nodemask_t *dstp, int nbits)
{
    return bitmap_parselist(buf, dstp->bits, nbits);
}



static inline __attribute__((no_instrument_function)) int __node_remap(int oldbit,
                                                                       const nodemask_t *oldp, const nodemask_t *newp, int nbits)
{
    return bitmap_bitremap(oldbit, oldp->bits, newp->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_remap(nodemask_t *dstp, const nodemask_t *srcp,
                                                                         const nodemask_t *oldp, const nodemask_t *newp, int nbits)
{
    bitmap_remap(dstp->bits, srcp->bits, oldp->bits, newp->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_onto(nodemask_t *dstp, const nodemask_t *origp,
                                                                        const nodemask_t *relmapp, int nbits)
{
    bitmap_onto(dstp->bits, origp->bits, relmapp->bits, nbits);
}



static inline __attribute__((no_instrument_function)) void __nodes_fold(nodemask_t *dstp, const nodemask_t *origp,
                                                                        int sz, int nbits)
{
    bitmap_fold(dstp->bits, origp->bits, sz, nbits);
}
# 372 "include/linux/nodemask.h"
enum node_states {
    N_POSSIBLE,
    N_ONLINE,
    N_NORMAL_MEMORY,



    N_HIGH_MEMORY = N_NORMAL_MEMORY,




    N_MEMORY = N_HIGH_MEMORY,

    N_CPU,
    NR_NODE_STATES
};






extern nodemask_t node_states[NR_NODE_STATES];


static inline __attribute__((no_instrument_function)) int node_state(int node, enum node_states state)
{
    return (__builtin_constant_p(((node))) ? constant_test_bit(((node)), ((node_states[state]).bits)) : variable_test_bit(((node)), ((node_states[state]).bits)));
}

static inline __attribute__((no_instrument_function)) void node_set_state(int node, enum node_states state)
{
    __node_set(node, &node_states[state]);
}

static inline __attribute__((no_instrument_function)) void node_clear_state(int node, enum node_states state)
{
    __node_clear(node, &node_states[state]);
}

static inline __attribute__((no_instrument_function)) int num_node_state(enum node_states state)
{
    return __nodes_weight(&(node_states[state]), (1 << 6));
}






static inline __attribute__((no_instrument_function)) int next_online_node(int nid)
{
    return __next_node((nid), &(node_states[N_ONLINE]));
}
static inline __attribute__((no_instrument_function)) int next_memory_node(int nid)
{
    return __next_node((nid), &(node_states[N_MEMORY]));
}

extern int nr_node_ids;
extern int nr_online_nodes;

static inline __attribute__((no_instrument_function)) void node_set_online(int nid)
{
    node_set_state(nid, N_ONLINE);
    nr_online_nodes = num_node_state(N_ONLINE);
}

static inline __attribute__((no_instrument_function)) void node_set_offline(int nid)
{
    node_clear_state(nid, N_ONLINE);
    nr_online_nodes = num_node_state(N_ONLINE);
}
# 482 "include/linux/nodemask.h"
extern int node_random(const nodemask_t *maskp);
# 516 "include/linux/nodemask.h"
struct nodemask_scratch {
    nodemask_t mask1;
    nodemask_t mask2;
};
# 27 "include/linux/sched.h" 2
# 1 "include/linux/mm_types.h" 1



# 1 "include/linux/auxvec.h" 1



# 1 "include/uapi/linux/auxvec.h" 1



# 1 "./arch/x86/include/uapi/asm/auxvec.h" 1
# 5 "include/uapi/linux/auxvec.h" 2
# 5 "include/linux/auxvec.h" 2
# 5 "include/linux/mm_types.h" 2





# 1 "include/linux/rwsem.h" 1
# 21 "include/linux/rwsem.h"
struct rw_semaphore;





struct rw_semaphore {
    long count;
    struct list_head wait_list;
    raw_spinlock_t wait_lock;

    struct optimistic_spin_queue osq;




    struct task_struct *owner;




};

extern struct rw_semaphore *rwsem_down_read_failed(struct rw_semaphore *sem);
extern struct rw_semaphore *rwsem_down_write_failed(struct rw_semaphore *sem);
extern struct rw_semaphore *rwsem_wake(struct rw_semaphore *);
extern struct rw_semaphore *rwsem_downgrade_wake(struct rw_semaphore *sem);


# 1 "./arch/x86/include/asm/rwsem.h" 1
# 63 "./arch/x86/include/asm/rwsem.h"
static inline __attribute__((no_instrument_function)) void __down_read(struct rw_semaphore *sem)
{
    asm volatile("# beginning down_read\n\t"
                 ".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " " " "incq" " " "(%1)\n\t"

                 "  jns        1f\n"
                 "  call call_rwsem_down_read_failed\n"
                 "1:\n\t"
                 "# ending down_read\n\t"
            : "+m" (sem->count)
            : "a" (sem)
            : "memory", "cc");
}




static inline __attribute__((no_instrument_function)) int __down_read_trylock(struct rw_semaphore *sem)
{
    long result, tmp;
    asm volatile("# beginning __down_read_trylock\n\t"
                 "  mov          %0,%1\n\t"
                 "1:\n\t"
                 "  mov          %1,%2\n\t"
                 "  add          %3,%2\n\t"
                 "  jle	     2f\n\t"
                 ".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "  cmpxchg  %2,%0\n\t"
                 "  jnz	     1b\n\t"
                 "2:\n\t"
                 "# ending __down_read_trylock\n\t"
            : "+m" (sem->count), "=&a" (result), "=&r" (tmp)
            : "i" (0x00000001L)
            : "memory", "cc");
    return result >= 0 ? 1 : 0;
}




static inline __attribute__((no_instrument_function)) void __down_write_nested(struct rw_semaphore *sem, int subclass)
{
    long tmp;
    asm volatile("# beginning down_write\n\t"
                 ".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "  xadd      %1,(%2)\n\t"

                 "  test " " " "%k1" " " "," " " "%k1" " " "\n\t"

                 "  jz        1f\n"
                 "  call call_rwsem_down_write_failed\n"
                 "1:\n"
                 "# ending down_write"
            : "+m" (sem->count), "=d" (tmp)
            : "a" (sem), "1" (((-0xffffffffL -1) + 0x00000001L))
            : "memory", "cc");
}

static inline __attribute__((no_instrument_function)) void __down_write(struct rw_semaphore *sem)
{
    __down_write_nested(sem, 0);
}




static inline __attribute__((no_instrument_function)) int __down_write_trylock(struct rw_semaphore *sem)
{
    long result, tmp;
    asm volatile("# beginning __down_write_trylock\n\t"
                 "  mov          %0,%1\n\t"
                 "1:\n\t"
                 "  test " " " "%k1" " " "," " " "%k1" " " "\n\t"

                 "  jnz          2f\n\t"
                 "  mov          %1,%2\n\t"
                 "  add          %3,%2\n\t"
                 ".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "  cmpxchg  %2,%0\n\t"
                 "  jnz	     1b\n\t"
                 "2:\n\t"
                 "  sete         %b1\n\t"
                 "  movzbl       %b1, %k1\n\t"
                 "# ending __down_write_trylock\n\t"
            : "+m" (sem->count), "=&a" (result), "=&r" (tmp)
            : "er" (((-0xffffffffL -1) + 0x00000001L))
            : "memory", "cc");
    return result;
}




static inline __attribute__((no_instrument_function)) void __up_read(struct rw_semaphore *sem)
{
    long tmp;
    asm volatile("# beginning __up_read\n\t"
                 ".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "  xadd      %1,(%2)\n\t"

                 "  jns        1f\n\t"
                 "  call call_rwsem_wake\n"
                 "1:\n"
                 "# ending __up_read\n"
            : "+m" (sem->count), "=d" (tmp)
            : "a" (sem), "1" (-0x00000001L)
            : "memory", "cc");
}




static inline __attribute__((no_instrument_function)) void __up_write(struct rw_semaphore *sem)
{
    long tmp;
    asm volatile("# beginning __up_write\n\t"
                 ".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "  xadd      %1,(%2)\n\t"

                 "  jns        1f\n\t"
                 "  call call_rwsem_wake\n"
                 "1:\n\t"
                 "# ending __up_write\n"
            : "+m" (sem->count), "=d" (tmp)
            : "a" (sem), "1" (-((-0xffffffffL -1) + 0x00000001L))
            : "memory", "cc");
}




static inline __attribute__((no_instrument_function)) void __downgrade_write(struct rw_semaphore *sem)
{
    asm volatile("# beginning __downgrade_write\n\t"
                 ".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " " " "addq" " " "%2,(%1)\n\t"




                 "  jns       1f\n\t"
                 "  call call_rwsem_downgrade_wake\n"
                 "1:\n\t"
                 "# ending __downgrade_write\n"
            : "+m" (sem->count)
            : "a" (sem), "er" (-(-0xffffffffL -1))
            : "memory", "cc");
}




static inline __attribute__((no_instrument_function)) void rwsem_atomic_add(long delta, struct rw_semaphore *sem)
{
    asm volatile(".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " " " "addq" " " "%1,%0"
            : "+m" (sem->count)
            : "er" (delta));
}




static inline __attribute__((no_instrument_function)) long rwsem_atomic_update(long delta, struct rw_semaphore *sem)
{
    return delta + ({ __typeof__ (*(((&sem->count)))) __ret = (((delta))); switch (sizeof(*(((&sem->count))))) { case 1: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "b %b0, %1\n" : "+q" (__ret), "+m" (*(((&sem->count)))) : : "memory", "cc"); break; case 2: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "w %w0, %1\n" : "+r" (__ret), "+m" (*(((&sem->count)))) : : "memory", "cc"); break; case 4: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "l %0, %1\n" : "+r" (__ret), "+m" (*(((&sem->count)))) : : "memory", "cc"); break; case 8: asm volatile (".pushsection .smp_locks,\"a\"\n" ".balign 4\n" ".long 671f - .\n" ".popsection\n" "671:" "\n\tlock; " "xadd" "q %q0, %1\n" : "+r" (__ret), "+m" (*(((&sem->count)))) : : "memory", "cc"); break; default: __xadd_wrong_size(); } __ret; });
}
# 51 "include/linux/rwsem.h" 2


static inline __attribute__((no_instrument_function)) int rwsem_is_locked(struct rw_semaphore *sem)
{
    return sem->count != 0;
}
# 84 "include/linux/rwsem.h"
extern void __init_rwsem(struct rw_semaphore *sem, const char *name,
                         struct lock_class_key *key);
# 100 "include/linux/rwsem.h"
static inline __attribute__((no_instrument_function)) int rwsem_is_contended(struct rw_semaphore *sem)
{
    return !list_empty(&sem->wait_list);
}




extern void down_read(struct rw_semaphore *sem);




extern int down_read_trylock(struct rw_semaphore *sem);




extern void down_write(struct rw_semaphore *sem);




extern int down_write_trylock(struct rw_semaphore *sem);




extern void up_read(struct rw_semaphore *sem);




extern void up_write(struct rw_semaphore *sem);




extern void downgrade_write(struct rw_semaphore *sem);
# 11 "include/linux/mm_types.h" 2
# 1 "include/linux/completion.h" 1
# 11 "include/linux/completion.h"
# 1 "include/linux/wait.h" 1






# 1 "include/linux/stddef.h" 1
# 8 "include/linux/wait.h" 2


# 1 "include/uapi/linux/wait.h" 1
# 11 "include/linux/wait.h" 2

typedef struct __wait_queue wait_queue_t;
typedef int (*wait_queue_func_t)(wait_queue_t *wait, unsigned mode, int flags, void *key);
int default_wake_function(wait_queue_t *wait, unsigned mode, int flags, void *key);





struct __wait_queue {
    unsigned int flags;
    void *private;
    wait_queue_func_t func;
    struct list_head task_list;
};

struct wait_bit_key {
    void *flags;
    int bit_nr;

    unsigned long timeout;
};

struct wait_bit_queue {
    struct wait_bit_key key;
    wait_queue_t wait;
};

struct __wait_queue_head {
    spinlock_t lock;
    struct list_head task_list;
};
typedef struct __wait_queue_head wait_queue_head_t;

struct task_struct;
# 72 "include/linux/wait.h"
extern void __init_waitqueue_head(wait_queue_head_t *q, const char *name, struct lock_class_key *);
# 90 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) void init_waitqueue_entry(wait_queue_t *q, struct task_struct *p)
{
    q->flags = 0;
    q->private = p;
    q->func = default_wake_function;
}

static inline __attribute__((no_instrument_function)) void
init_waitqueue_func_entry(wait_queue_t *q, wait_queue_func_t func)
{
    q->flags = 0;
    q->private = ((void *)0);
    q->func = func;
}

static inline __attribute__((no_instrument_function)) int waitqueue_active(wait_queue_head_t *q)
{
    return !list_empty(&q->task_list);
}

extern void add_wait_queue(wait_queue_head_t *q, wait_queue_t *wait);
extern void add_wait_queue_exclusive(wait_queue_head_t *q, wait_queue_t *wait);
extern void remove_wait_queue(wait_queue_head_t *q, wait_queue_t *wait);

static inline __attribute__((no_instrument_function)) void __add_wait_queue(wait_queue_head_t *head, wait_queue_t *new)
{
list_add(&new->task_list, &head->task_list);
}




static inline __attribute__((no_instrument_function)) void
__add_wait_queue_exclusive(wait_queue_head_t *q, wait_queue_t *wait)
{
    wait->flags |= 0x01;
    __add_wait_queue(q, wait);
}

static inline __attribute__((no_instrument_function)) void __add_wait_queue_tail(wait_queue_head_t *head,
                                                                                 wait_queue_t *new)
{
list_add_tail(&new->task_list, &head->task_list);
}

static inline __attribute__((no_instrument_function)) void
__add_wait_queue_tail_exclusive(wait_queue_head_t *q, wait_queue_t *wait)
{
    wait->flags |= 0x01;
    __add_wait_queue_tail(q, wait);
}

static inline __attribute__((no_instrument_function)) void
__remove_wait_queue(wait_queue_head_t *head, wait_queue_t *old)
{
    list_del(&old->task_list);
}

typedef int wait_bit_action_f(struct wait_bit_key *);
void __wake_up(wait_queue_head_t *q, unsigned int mode, int nr, void *key);
void __wake_up_locked_key(wait_queue_head_t *q, unsigned int mode, void *key);
void __wake_up_sync_key(wait_queue_head_t *q, unsigned int mode, int nr, void *key);
void __wake_up_locked(wait_queue_head_t *q, unsigned int mode, int nr);
void __wake_up_sync(wait_queue_head_t *q, unsigned int mode, int nr);
void __wake_up_bit(wait_queue_head_t *, void *, int);
int __wait_on_bit(wait_queue_head_t *, struct wait_bit_queue *, wait_bit_action_f *, unsigned);
int __wait_on_bit_lock(wait_queue_head_t *, struct wait_bit_queue *, wait_bit_action_f *, unsigned);
void wake_up_bit(void *, int);
void wake_up_atomic_t(atomic_t *);
int out_of_line_wait_on_bit(void *, int, wait_bit_action_f *, unsigned);
int out_of_line_wait_on_bit_timeout(void *, int, wait_bit_action_f *, unsigned, unsigned long);
int out_of_line_wait_on_bit_lock(void *, int, wait_bit_action_f *, unsigned);
int out_of_line_wait_on_atomic_t(atomic_t *, int (*)(atomic_t *), unsigned);
wait_queue_head_t *bit_waitqueue(void *, int);
# 911 "include/linux/wait.h"
void prepare_to_wait(wait_queue_head_t *q, wait_queue_t *wait, int state);
void prepare_to_wait_exclusive(wait_queue_head_t *q, wait_queue_t *wait, int state);
long prepare_to_wait_event(wait_queue_head_t *q, wait_queue_t *wait, int state);
void finish_wait(wait_queue_head_t *q, wait_queue_t *wait);
void abort_exclusive_wait(wait_queue_head_t *q, wait_queue_t *wait, unsigned int mode, void *key);
long wait_woken(wait_queue_t *wait, unsigned mode, long timeout);
int woken_wake_function(wait_queue_t *wait, unsigned mode, int sync, void *key);
int autoremove_wake_function(wait_queue_t *wait, unsigned mode, int sync, void *key);
int wake_bit_function(wait_queue_t *wait, unsigned mode, int sync, void *key);
# 950 "include/linux/wait.h"
extern int bit_wait(struct wait_bit_key *);
extern int bit_wait_io(struct wait_bit_key *);
extern int bit_wait_timeout(struct wait_bit_key *);
extern int bit_wait_io_timeout(struct wait_bit_key *);
# 971 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) int
wait_on_bit(void *word, int bit, unsigned mode)
{
    do { _cond_resched(); } while (0);
    if (!(__builtin_constant_p((bit)) ? constant_test_bit((bit), (word)) : variable_test_bit((bit), (word))))
        return 0;
    return out_of_line_wait_on_bit(word, bit,
                                   bit_wait,
                                   mode);
}
# 996 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) int
wait_on_bit_io(void *word, int bit, unsigned mode)
{
    do { _cond_resched(); } while (0);
    if (!(__builtin_constant_p((bit)) ? constant_test_bit((bit), (word)) : variable_test_bit((bit), (word))))
        return 0;
    return out_of_line_wait_on_bit(word, bit,
                                   bit_wait_io,
                                   mode);
}
# 1022 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) int
wait_on_bit_timeout(void *word, int bit, unsigned mode, unsigned long timeout)
{
    do { _cond_resched(); } while (0);
    if (!(__builtin_constant_p((bit)) ? constant_test_bit((bit), (word)) : variable_test_bit((bit), (word))))
        return 0;
    return out_of_line_wait_on_bit_timeout(word, bit,
                                           bit_wait_timeout,
                                           mode, timeout);
}
# 1049 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) int
wait_on_bit_action(void *word, int bit, wait_bit_action_f *action, unsigned mode)
{
    do { _cond_resched(); } while (0);
    if (!(__builtin_constant_p((bit)) ? constant_test_bit((bit), (word)) : variable_test_bit((bit), (word))))
        return 0;
    return out_of_line_wait_on_bit(word, bit, action, mode);
}
# 1077 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) int
wait_on_bit_lock(void *word, int bit, unsigned mode)
{
    do { _cond_resched(); } while (0);
    if (!test_and_set_bit(bit, word))
        return 0;
    return out_of_line_wait_on_bit_lock(word, bit, bit_wait, mode);
}
# 1101 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) int
wait_on_bit_lock_io(void *word, int bit, unsigned mode)
{
    do { _cond_resched(); } while (0);
    if (!test_and_set_bit(bit, word))
        return 0;
    return out_of_line_wait_on_bit_lock(word, bit, bit_wait_io, mode);
}
# 1127 "include/linux/wait.h"
static inline __attribute__((no_instrument_function)) int
wait_on_bit_lock_action(void *word, int bit, wait_bit_action_f *action, unsigned mode)
{
    do { _cond_resched(); } while (0);
    if (!test_and_set_bit(bit, word))
        return 0;
    return out_of_line_wait_on_bit_lock(word, bit, action, mode);
}
# 1146 "include/linux/wait.h"
static inline __attribute__((no_instrument_function))
int wait_on_atomic_t(atomic_t *val, int (*action)(atomic_t *), unsigned mode)
{
    do { _cond_resched(); } while (0);
    if (atomic_read(val) == 0)
        return 0;
    return out_of_line_wait_on_atomic_t(val, action, mode);
}
# 12 "include/linux/completion.h" 2
# 25 "include/linux/completion.h"
struct completion {
    unsigned int done;
    wait_queue_head_t wait;
};
# 73 "include/linux/completion.h"
static inline __attribute__((no_instrument_function)) void init_completion(struct completion *x)
{
    x->done = 0;
    do { static struct lock_class_key __key; __init_waitqueue_head((&x->wait), "&x->wait", &__key); } while (0);
}
# 86 "include/linux/completion.h"
static inline __attribute__((no_instrument_function)) void reinit_completion(struct completion *x)
{
    x->done = 0;
}

extern void wait_for_completion(struct completion *);
extern void wait_for_completion_io(struct completion *);
extern int wait_for_completion_interruptible(struct completion *x);
extern int wait_for_completion_killable(struct completion *x);
extern unsigned long wait_for_completion_timeout(struct completion *x,
                                                 unsigned long timeout);
extern unsigned long wait_for_completion_io_timeout(struct completion *x,
                                                    unsigned long timeout);
extern long wait_for_completion_interruptible_timeout(
        struct completion *x, unsigned long timeout);
extern long wait_for_completion_killable_timeout(
        struct completion *x, unsigned long timeout);
extern bool try_wait_for_completion(struct completion *x);
extern bool completion_done(struct completion *x);

extern void complete(struct completion *);
extern void complete_all(struct completion *);
# 12 "include/linux/mm_types.h" 2

# 1 "include/linux/uprobes.h" 1
# 31 "include/linux/uprobes.h"
struct vm_area_struct;
struct mm_struct;
struct inode;
struct notifier_block;
struct page;






enum uprobe_filter_ctx {
    UPROBE_FILTER_REGISTER,
    UPROBE_FILTER_UNREGISTER,
    UPROBE_FILTER_MMAP,
};

struct uprobe_consumer {
    int (*handler)(struct uprobe_consumer *self, struct pt_regs *regs);
    int (*ret_handler)(struct uprobe_consumer *self,
                       unsigned long func,
                       struct pt_regs *regs);
    bool (*filter)(struct uprobe_consumer *self,
                   enum uprobe_filter_ctx ctx,
                   struct mm_struct *mm);

    struct uprobe_consumer *next;
};
# 135 "include/linux/uprobes.h"
struct uprobes_state {
};



static inline __attribute__((no_instrument_function)) int
uprobe_register(struct inode *inode, loff_t offset, struct uprobe_consumer *uc)
{
    return -38;
}
static inline __attribute__((no_instrument_function)) int
uprobe_apply(struct inode *inode, loff_t offset, struct uprobe_consumer *uc, bool add)
{
    return -38;
}
static inline __attribute__((no_instrument_function)) void
uprobe_unregister(struct inode *inode, loff_t offset, struct uprobe_consumer *uc)
{
}
static inline __attribute__((no_instrument_function)) int uprobe_mmap(struct vm_area_struct *vma)
{
    return 0;
}
static inline __attribute__((no_instrument_function)) void
uprobe_munmap(struct vm_area_struct *vma, unsigned long start, unsigned long end)
{
}
static inline __attribute__((no_instrument_function)) void uprobe_start_dup_mmap(void)
{
}
static inline __attribute__((no_instrument_function)) void uprobe_end_dup_mmap(void)
{
}
static inline __attribute__((no_instrument_function)) void
uprobe_dup_mmap(struct mm_struct *oldmm, struct mm_struct *newmm)
{
}
static inline __attribute__((no_instrument_function)) void uprobe_notify_resume(struct pt_regs *regs)
{
}
static inline __attribute__((no_instrument_function)) bool uprobe_deny_signal(void)
{
    return false;
}
static inline __attribute__((no_instrument_function)) void uprobe_free_utask(struct task_struct *t)
{
}
static inline __attribute__((no_instrument_function)) void uprobe_copy_process(struct task_struct *t, unsigned long flags)
{
}
static inline __attribute__((no_instrument_function)) void uprobe_clear_state(struct mm_struct *mm)
{
}
# 14 "include/linux/mm_types.h" 2
# 1 "include/linux/page-flags-layout.h" 1




# 1 "include/generated/bounds.h" 1
# 6 "include/linux/page-flags-layout.h" 2
# 15 "include/linux/mm_types.h" 2

# 1 "./arch/x86/include/asm/mmu.h" 1
# 11 "./arch/x86/include/asm/mmu.h"
typedef struct {
    void *ldt;
    int size;



    unsigned short ia32_compat;


    struct mutex lock;
    void *vdso;

    atomic_t perf_rdpmc_allowed;
} mm_context_t;


void leave_mm(int cpu);
# 17 "include/linux/mm_types.h" 2






struct address_space;
struct mem_cgroup;






typedef void compound_page_dtor(struct page *);
# 46 "include/linux/mm_types.h"
struct page {

    unsigned long flags;

    union {
        struct address_space *mapping;






        void *s_mem;
    };


    struct {
        union {
            unsigned long index;
            void *freelist;
            bool pfmemalloc;
# 75 "include/linux/mm_types.h"
        };

        union {



            unsigned long counters;
# 91 "include/linux/mm_types.h"
            struct {

                union {
# 110 "include/linux/mm_types.h"
                    atomic_t _mapcount;

                    struct {
                        unsigned inuse:16;
                        unsigned objects:15;
                        unsigned frozen:1;
                    };
                    int units;
                };
                atomic_t _count;
            };
            unsigned int active;
        };
    };


    union {
        struct list_head lru;




        struct {
            struct page *next;

            int pages;
            int pobjects;




        };

        struct slab *slab_page;
        struct callback_head callback_head;



        struct {
            compound_page_dtor *compound_dtor;
            unsigned long compound_order;
        };




    };


    union {
        unsigned long private;
# 171 "include/linux/mm_types.h"
        spinlock_t ptl;


        struct kmem_cache *slab_cache;
        struct page *first_page;
    };
# 208 "include/linux/mm_types.h"
}





    __attribute__((aligned(2 * sizeof(unsigned long))))

;

struct page_frag {
    struct page *page;

    __u32 offset;
    __u32 size;




};

typedef unsigned long vm_flags_t;






struct vm_region {
    struct rb_node vm_rb;
    vm_flags_t vm_flags;
    unsigned long vm_start;
    unsigned long vm_end;
    unsigned long vm_top;
    unsigned long vm_pgoff;
    struct file *vm_file;

    int vm_usage;
    bool vm_icache_flushed : 1;

};







struct vm_area_struct {


    unsigned long vm_start;
    unsigned long vm_end;



    struct vm_area_struct *vm_next, *vm_prev;

    struct rb_node vm_rb;







    unsigned long rb_subtree_gap;



    struct mm_struct *vm_mm;
    pgprot_t vm_page_prot;
    unsigned long vm_flags;





    struct {
        struct rb_node rb;
        unsigned long rb_subtree_last;
    } shared;







    struct list_head anon_vma_chain;

    struct anon_vma *anon_vma;


    const struct vm_operations_struct *vm_ops;


    unsigned long vm_pgoff;

    struct file * vm_file;
    void * vm_private_data;





    struct mempolicy *vm_policy;

};

struct core_thread {
    struct task_struct *task;
    struct core_thread *next;
};

struct core_state {
    atomic_t nr_threads;
    struct core_thread dumper;
    struct completion startup;
};

enum {
    MM_FILEPAGES,
    MM_ANONPAGES,
    MM_SWAPENTS,
    NR_MM_COUNTERS
};




struct task_rss_stat {
    int events;
    int count[NR_MM_COUNTERS];
};


struct mm_rss_stat {
    atomic_long_t count[NR_MM_COUNTERS];
};

struct kioctx_table;
struct mm_struct {
    struct vm_area_struct *mmap;
    struct rb_root mm_rb;
    u32 vmacache_seqnum;

    unsigned long (*get_unmapped_area) (struct file *filp,
                                        unsigned long addr, unsigned long len,
                                        unsigned long pgoff, unsigned long flags);

    unsigned long mmap_base;
    unsigned long mmap_legacy_base;
    unsigned long task_size;
    unsigned long highest_vm_end;
    pgd_t * pgd;
    atomic_t mm_users;
    atomic_t mm_count;
    atomic_long_t nr_ptes;

    atomic_long_t nr_pmds;

    int map_count;

    spinlock_t page_table_lock;
    struct rw_semaphore mmap_sem;

    struct list_head mmlist;





    unsigned long hiwater_rss;
    unsigned long hiwater_vm;

    unsigned long total_vm;
    unsigned long locked_vm;
    unsigned long pinned_vm;
    unsigned long shared_vm;
    unsigned long exec_vm;
    unsigned long stack_vm;
    unsigned long def_flags;
    unsigned long start_code, end_code, start_data, end_data;
    unsigned long start_brk, brk, start_stack;
    unsigned long arg_start, arg_end, env_start, env_end;

    unsigned long saved_auxv[(2*(2 + 20 + 1))];





    struct mm_rss_stat rss_stat;

    struct linux_binfmt *binfmt;

    cpumask_var_t cpu_vm_mask_var;


    mm_context_t context;

    unsigned long flags;

    struct core_state *core_state;

    spinlock_t ioctx_lock;
    struct kioctx_table *ioctx_table;
# 432 "include/linux/mm_types.h"
    struct file *exe_file;
# 462 "include/linux/mm_types.h"
    bool tlb_flush_pending;

    struct uprobes_state uprobes_state;




};

static inline __attribute__((no_instrument_function)) void mm_init_cpumask(struct mm_struct *mm)
{



    cpumask_clear(mm->cpu_vm_mask_var);
}


static inline __attribute__((no_instrument_function)) cpumask_t *mm_cpumask(struct mm_struct *mm)
{
    return mm->cpu_vm_mask_var;
}
# 492 "include/linux/mm_types.h"
static inline __attribute__((no_instrument_function)) bool mm_tlb_flush_pending(struct mm_struct *mm)
{
    __asm__ __volatile__("": : :"memory");
    return mm->tlb_flush_pending;
}
static inline __attribute__((no_instrument_function)) void set_tlb_flush_pending(struct mm_struct *mm)
{
    mm->tlb_flush_pending = true;





    __asm__ __volatile__("": : :"memory");
}

static inline __attribute__((no_instrument_function)) void clear_tlb_flush_pending(struct mm_struct *mm)
{
    __asm__ __volatile__("": : :"memory");
    mm->tlb_flush_pending = false;
}
# 526 "include/linux/mm_types.h"
struct vm_special_mapping
{
    const char *name;
    struct page **pages;
};

enum tlb_flush_reason {
    TLB_FLUSH_ON_TASK_SWITCH,
    TLB_REMOTE_SHOOTDOWN,
    TLB_LOCAL_SHOOTDOWN,
    TLB_LOCAL_MM_SHOOTDOWN,
    NR_TLB_FLUSH_REASONS,
};





typedef struct {
    unsigned long val;
} swp_entry_t;
# 28 "include/linux/sched.h" 2




# 1 "include/linux/cputime.h" 1



# 1 "arch/x86/include/generated/asm/cputime.h" 1
# 1 "include/asm-generic/cputime.h" 1







# 1 "include/asm-generic/cputime_jiffies.h" 1



typedef unsigned long cputime_t;
# 13 "include/asm-generic/cputime_jiffies.h"
typedef u64 cputime64_t;
# 9 "include/asm-generic/cputime.h" 2
# 1 "arch/x86/include/generated/asm/cputime.h" 2
# 5 "include/linux/cputime.h" 2
# 33 "include/linux/sched.h" 2

# 1 "include/linux/smp.h" 1
# 14 "include/linux/smp.h"
# 1 "include/linux/llist.h" 1
# 61 "include/linux/llist.h"
struct llist_head {
    struct llist_node *first;
};

struct llist_node {
    struct llist_node *next;
};
# 76 "include/linux/llist.h"
static inline __attribute__((no_instrument_function)) void init_llist_head(struct llist_head *list)
{
    list->first = ((void *)0);
}
# 158 "include/linux/llist.h"
static inline __attribute__((no_instrument_function)) bool llist_empty(const struct llist_head *head)
{
    return (*({ __attribute__((unused)) typeof(head->first) __var = ( typeof(head->first)) 0; (volatile typeof(head->first) *)&(head->first); })) == ((void *)0);
}

static inline __attribute__((no_instrument_function)) struct llist_node *llist_next(struct llist_node *node)
{
    return node->next;
}

extern bool llist_add_batch(struct llist_node *new_first,
                            struct llist_node *new_last,
                            struct llist_head *head);







static inline __attribute__((no_instrument_function)) bool llist_add(struct llist_node *new, struct llist_head *head)
{
return llist_add_batch(new, new, head);
}
# 191 "include/linux/llist.h"
static inline __attribute__((no_instrument_function)) struct llist_node *llist_del_all(struct llist_head *head)
{
    return ({ __typeof__ (*((&head->first))) __ret = ((((void *)0))); switch (sizeof(*((&head->first)))) { case 1: asm volatile ("" "xchg" "b %b0, %1\n" : "+q" (__ret), "+m" (*((&head->first))) : : "memory", "cc"); break; case 2: asm volatile ("" "xchg" "w %w0, %1\n" : "+r" (__ret), "+m" (*((&head->first))) : : "memory", "cc"); break; case 4: asm volatile ("" "xchg" "l %0, %1\n" : "+r" (__ret), "+m" (*((&head->first))) : : "memory", "cc"); break; case 8: asm volatile ("" "xchg" "q %q0, %1\n" : "+r" (__ret), "+m" (*((&head->first))) : : "memory", "cc"); break; default: __xchg_wrong_size(); } __ret; });
}

extern struct llist_node *llist_del_first(struct llist_head *head);

struct llist_node *llist_reverse_order(struct llist_node *head);
# 15 "include/linux/smp.h" 2

typedef void (*smp_call_func_t)(void *info);
struct call_single_data {
    struct llist_node llist;
    smp_call_func_t func;
    void *info;
    unsigned int flags;
};


extern unsigned int total_cpus;

int smp_call_function_single(int cpuid, smp_call_func_t func, void *info,
                             int wait);




int on_each_cpu(smp_call_func_t func, void *info, int wait);





void on_each_cpu_mask(const struct cpumask *mask, smp_call_func_t func,
                      void *info, bool wait);






void on_each_cpu_cond(bool (*cond_func)(int cpu, void *info),
                      smp_call_func_t func, void *info, bool wait,
                      gfp_t gfp_flags);

int smp_call_function_single_async(int cpu, struct call_single_data *csd);







# 1 "./arch/x86/include/asm/smp.h" 1
# 11 "./arch/x86/include/asm/smp.h"
# 1 "./arch/x86/include/asm/mpspec.h" 1




# 1 "./arch/x86/include/asm/mpspec_def.h" 1
# 21 "./arch/x86/include/asm/mpspec_def.h"
struct mpf_intel {
    char signature[4];
    unsigned int physptr;
    unsigned char length;
    unsigned char specification;
    unsigned char checksum;
    unsigned char feature1;
    unsigned char feature2;
    unsigned char feature3;
    unsigned char feature4;
    unsigned char feature5;
};



struct mpc_table {
    char signature[4];
    unsigned short length;
    char spec;
    char checksum;
    char oem[8];
    char productid[12];
    unsigned int oemptr;
    unsigned short oemsize;
    unsigned short oemcount;
    unsigned int lapic;
    unsigned int reserved;
};
# 67 "./arch/x86/include/asm/mpspec_def.h"
struct mpc_cpu {
    unsigned char type;
    unsigned char apicid;
    unsigned char apicver;
    unsigned char cpuflag;
    unsigned int cpufeature;
    unsigned int featureflag;
    unsigned int reserved[2];
};

struct mpc_bus {
    unsigned char type;
    unsigned char busid;
    unsigned char bustype[6];
};
# 105 "./arch/x86/include/asm/mpspec_def.h"
struct mpc_ioapic {
    unsigned char type;
    unsigned char apicid;
    unsigned char apicver;
    unsigned char flags;
    unsigned int apicaddr;
};

struct mpc_intsrc {
    unsigned char type;
    unsigned char irqtype;
    unsigned short irqflag;
    unsigned char srcbus;
    unsigned char srcbusirq;
    unsigned char dstapic;
    unsigned char dstirq;
};

enum mp_irq_source_types {
    mp_INT = 0,
    mp_NMI = 1,
    mp_SMI = 2,
    mp_ExtINT = 3
};







struct mpc_lintsrc {
    unsigned char type;
    unsigned char irqtype;
    unsigned short irqflag;
    unsigned char srcbusid;
    unsigned char srcbusirq;
    unsigned char destapic;
    unsigned char destapiclint;
};



struct mpc_oemtable {
    char signature[4];
    unsigned short length;
    char rev;
    char checksum;
    char mpc[8];
};
# 168 "./arch/x86/include/asm/mpspec_def.h"
enum mp_bustype {
    MP_BUS_ISA = 1,
    MP_BUS_EISA,
    MP_BUS_PCI,
};
# 6 "./arch/x86/include/asm/mpspec.h" 2
# 1 "./arch/x86/include/asm/x86_init.h" 1




# 1 "./arch/x86/include/uapi/asm/bootparam.h" 1
# 33 "./arch/x86/include/uapi/asm/bootparam.h"
# 1 "include/linux/screen_info.h" 1



# 1 "include/uapi/linux/screen_info.h" 1
# 10 "include/uapi/linux/screen_info.h"
struct screen_info {
    __u8 orig_x;
    __u8 orig_y;
    __u16 ext_mem_k;
    __u16 orig_video_page;
    __u8 orig_video_mode;
    __u8 orig_video_cols;
    __u8 flags;
    __u8 unused2;
    __u16 orig_video_ega_bx;
    __u16 unused3;
    __u8 orig_video_lines;
    __u8 orig_video_isVGA;
    __u16 orig_video_points;


    __u16 lfb_width;
    __u16 lfb_height;
    __u16 lfb_depth;
    __u32 lfb_base;
    __u32 lfb_size;
    __u16 cl_magic, cl_offset;
    __u16 lfb_linelength;
    __u8 red_size;
    __u8 red_pos;
    __u8 green_size;
    __u8 green_pos;
    __u8 blue_size;
    __u8 blue_pos;
    __u8 rsvd_size;
    __u8 rsvd_pos;
    __u16 vesapm_seg;
    __u16 vesapm_off;
    __u16 pages;
    __u16 vesa_attributes;
    __u32 capabilities;
    __u8 _reserved[6];
} __attribute__((packed));
# 5 "include/linux/screen_info.h" 2

extern struct screen_info screen_info;
# 34 "./arch/x86/include/uapi/asm/bootparam.h" 2
# 1 "include/linux/apm_bios.h" 1
# 18 "include/linux/apm_bios.h"
# 1 "include/uapi/linux/apm_bios.h" 1
# 21 "include/uapi/linux/apm_bios.h"
typedef unsigned short apm_event_t;
typedef unsigned short apm_eventinfo_t;

struct apm_bios_info {
    __u16 version;
    __u16 cseg;
    __u32 offset;
    __u16 cseg_16;
    __u16 dseg;
    __u16 flags;
    __u16 cseg_len;
    __u16 cseg_16_len;
    __u16 dseg_len;
};
# 19 "include/linux/apm_bios.h" 2
# 35 "include/linux/apm_bios.h"
struct apm_info {
    struct apm_bios_info bios;
    unsigned short connection_version;
    int get_power_status_broken;
    int get_power_status_swabinminutes;
    int allow_ints;
    int forbid_idle;
    int realmode_power_off;
    int disabled;
};
# 94 "include/linux/apm_bios.h"
extern struct apm_info apm_info;
# 35 "./arch/x86/include/uapi/asm/bootparam.h" 2
# 1 "include/linux/edd.h" 1
# 33 "include/linux/edd.h"
# 1 "include/uapi/linux/edd.h" 1
# 71 "include/uapi/linux/edd.h"
struct edd_device_params {
    __u16 length;
    __u16 info_flags;
    __u32 num_default_cylinders;
    __u32 num_default_heads;
    __u32 sectors_per_track;
    __u64 number_of_sectors;
    __u16 bytes_per_sector;
    __u32 dpte_ptr;
    __u16 key;
    __u8 device_path_info_length;
    __u8 reserved2;
    __u16 reserved3;
    __u8 host_bus_type[4];
    __u8 interface_type[8];
    union {
        struct {
            __u16 base_address;
            __u16 reserved1;
            __u32 reserved2;
        } __attribute__ ((packed)) isa;
        struct {
            __u8 bus;
            __u8 slot;
            __u8 function;
            __u8 channel;
            __u32 reserved;
        } __attribute__ ((packed)) pci;

        struct {
            __u64 reserved;
        } __attribute__ ((packed)) ibnd;
        struct {
            __u64 reserved;
        } __attribute__ ((packed)) xprs;
        struct {
            __u64 reserved;
        } __attribute__ ((packed)) htpt;
        struct {
            __u64 reserved;
        } __attribute__ ((packed)) unknown;
    } interface_path;
    union {
        struct {
            __u8 device;
            __u8 reserved1;
            __u16 reserved2;
            __u32 reserved3;
            __u64 reserved4;
        } __attribute__ ((packed)) ata;
        struct {
            __u8 device;
            __u8 lun;
            __u8 reserved1;
            __u8 reserved2;
            __u32 reserved3;
            __u64 reserved4;
        } __attribute__ ((packed)) atapi;
        struct {
            __u16 id;
            __u64 lun;
            __u16 reserved1;
            __u32 reserved2;
        } __attribute__ ((packed)) scsi;
        struct {
            __u64 serial_number;
            __u64 reserved;
        } __attribute__ ((packed)) usb;
        struct {
            __u64 eui;
            __u64 reserved;
        } __attribute__ ((packed)) i1394;
        struct {
            __u64 wwid;
            __u64 lun;
        } __attribute__ ((packed)) fibre;
        struct {
            __u64 identity_tag;
            __u64 reserved;
        } __attribute__ ((packed)) i2o;
        struct {
            __u32 array_number;
            __u32 reserved1;
            __u64 reserved2;
        } __attribute__ ((packed)) raid;
        struct {
            __u8 device;
            __u8 reserved1;
            __u16 reserved2;
            __u32 reserved3;
            __u64 reserved4;
        } __attribute__ ((packed)) sata;
        struct {
            __u64 reserved1;
            __u64 reserved2;
        } __attribute__ ((packed)) unknown;
    } device_path;
    __u8 reserved4;
    __u8 checksum;
} __attribute__ ((packed));

struct edd_info {
    __u8 device;
    __u8 version;
    __u16 interface_support;
    __u16 legacy_max_cylinder;
    __u8 legacy_max_head;
    __u8 legacy_sectors_per_track;
    struct edd_device_params params;
} __attribute__ ((packed));

struct edd {
    unsigned int mbr_signature[16];
    struct edd_info edd_info[6];
    unsigned char mbr_signature_nr;
    unsigned char edd_info_nr;
};
# 34 "include/linux/edd.h" 2


extern struct edd edd;
# 36 "./arch/x86/include/uapi/asm/bootparam.h" 2
# 1 "./arch/x86/include/asm/e820.h" 1
# 10 "./arch/x86/include/asm/e820.h"
# 1 "./arch/x86/include/uapi/asm/e820.h" 1
# 57 "./arch/x86/include/uapi/asm/e820.h"
struct e820entry {
    __u64 addr;
    __u64 size;
    __u32 type;
} __attribute__((packed));

struct e820map {
    __u32 nr_map;
    struct e820entry map[(128 + 3 * (1 << 6))];
};
# 11 "./arch/x86/include/asm/e820.h" 2


extern struct e820map e820;
extern struct e820map e820_saved;

extern unsigned long pci_mem_start;
extern int e820_any_mapped(u64 start, u64 end, unsigned type);
extern int e820_all_mapped(u64 start, u64 end, unsigned type);
extern void e820_add_region(u64 start, u64 size, int type);
extern void e820_print_map(char *who);
extern int
sanitize_e820_map(struct e820entry *biosmap, int max_nr_map, u32 *pnr_map);
extern u64 e820_update_range(u64 start, u64 size, unsigned old_type,
                             unsigned new_type);
extern u64 e820_remove_range(u64 start, u64 size, unsigned old_type,
                             int checktype);
extern void update_e820(void);
extern void e820_setup_gap(void);
extern int e820_search_gap(unsigned long *gapstart, unsigned long *gapsize,
                           unsigned long start_addr, unsigned long long end_addr);
struct setup_data;
extern void parse_e820_ext(u64 phys_addr, u32 data_len);



extern void e820_mark_nosave_regions(unsigned long limit_pfn);






extern unsigned long e820_end_of_ram_pfn(void);
extern unsigned long e820_end_of_low_ram_pfn(void);
extern u64 early_reserve_e820(u64 sizet, u64 align);

void memblock_x86_fill(void);
void memblock_find_dma_reserve(void);

extern void finish_e820_parsing(void);
extern void e820_reserve_resources(void);
extern void e820_reserve_resources_late(void);
extern void setup_memory_map(void);
extern char *default_machine_specific_memory_setup(void);





static inline __attribute__((no_instrument_function)) bool is_ISA_range(u64 s, u64 e)
{
    return s >= 0xa0000 && e <= 0x100000;
}


# 1 "include/linux/ioport.h" 1
# 18 "include/linux/ioport.h"
struct resource {
    resource_size_t start;
    resource_size_t end;
    const char *name;
    unsigned long flags;
    struct resource *parent, *sibling, *child;
};
# 138 "include/linux/ioport.h"
extern struct resource ioport_resource;
extern struct resource iomem_resource;

extern struct resource *request_resource_conflict(struct resource *root, struct resource *new);
extern int request_resource(struct resource *root, struct resource *new);
extern int release_resource(struct resource *new);
void release_child_resources(struct resource *new);
extern void reserve_region_with_split(struct resource *root,
                                      resource_size_t start, resource_size_t end,
                                      const char *name);
extern struct resource *insert_resource_conflict(struct resource *parent, struct resource *new);
extern int insert_resource(struct resource *parent, struct resource *new);
extern void insert_resource_expand_to_fit(struct resource *root, struct resource *new);
extern void arch_remove_reservations(struct resource *avail);
extern int allocate_resource(struct resource *root, struct resource *new,
resource_size_t size, resource_size_t min,
resource_size_t max, resource_size_t align,
resource_size_t (*alignf)(void *,
                          const struct resource *,
                          resource_size_t,
                          resource_size_t),
void *alignf_data);
struct resource *lookup_resource(struct resource *root, resource_size_t start);
int adjust_resource(struct resource *res, resource_size_t start,
                    resource_size_t size);
resource_size_t resource_alignment(struct resource *res);
static inline __attribute__((no_instrument_function)) resource_size_t resource_size(const struct resource *res)
{
    return res->end - res->start + 1;
}
static inline __attribute__((no_instrument_function)) unsigned long resource_type(const struct resource *res)
{
    return res->flags & 0x00001f00;
}

static inline __attribute__((no_instrument_function)) bool resource_contains(struct resource *r1, struct resource *r2)
{
    if (resource_type(r1) != resource_type(r2))
        return false;
    if (r1->flags & 0x20000000 || r2->flags & 0x20000000)
        return false;
    return r1->start <= r2->start && r1->end >= r2->end;
}
# 192 "include/linux/ioport.h"
extern struct resource * __request_region(struct resource *,
                                          resource_size_t start,
                                          resource_size_t n,
                                          const char *name, int flags);





extern void __release_region(struct resource *, resource_size_t,
                             resource_size_t);






struct device;

extern int devm_request_resource(struct device *dev, struct resource *root,
                                 struct resource *new);
extern void devm_release_resource(struct device *dev, struct resource *new);






extern struct resource * __devm_request_region(struct device *dev,
                                               struct resource *parent, resource_size_t start,
                                               resource_size_t n, const char *name);






extern void __devm_release_region(struct device *dev, struct resource *parent,
                                  resource_size_t start, resource_size_t n);
extern int iomem_map_sanity_check(resource_size_t addr, unsigned long size);
extern int iomem_is_exclusive(u64 addr);

extern int
walk_system_ram_range(unsigned long start_pfn, unsigned long nr_pages,
                      void *arg, int (*func)(unsigned long, unsigned long, void *));
extern int
walk_system_ram_res(u64 start, u64 end, void *arg,
                    int (*func)(u64, u64, void *));
extern int
walk_iomem_res(char *name, unsigned long flags, u64 start, u64 end, void *arg,
               int (*func)(u64, u64, void *));


static inline __attribute__((no_instrument_function)) bool resource_overlaps(struct resource *r1, struct resource *r2)
{
    return (r1->start <= r2->end && r1->end >= r2->start);
}
# 67 "./arch/x86/include/asm/e820.h" 2
# 37 "./arch/x86/include/uapi/asm/bootparam.h" 2
# 1 "./arch/x86/include/asm/ist.h" 1
# 18 "./arch/x86/include/asm/ist.h"
# 1 "./arch/x86/include/uapi/asm/ist.h" 1
# 22 "./arch/x86/include/uapi/asm/ist.h"
struct ist_info {
    __u32 signature;
    __u32 command;
    __u32 event;
    __u32 perf_level;
};
# 19 "./arch/x86/include/asm/ist.h" 2


extern struct ist_info ist_info;
# 38 "./arch/x86/include/uapi/asm/bootparam.h" 2
# 1 "include/video/edid.h" 1



# 1 "include/uapi/video/edid.h" 1



struct edid_info {
    unsigned char dummy[128];
};
# 5 "include/video/edid.h" 2


extern struct edid_info edid_info;
# 39 "./arch/x86/include/uapi/asm/bootparam.h" 2


struct setup_data {
    __u64 next;
    __u32 type;
    __u32 len;
    __u8 data[0];
};

struct setup_header {
    __u8 setup_sects;
    __u16 root_flags;
    __u32 syssize;
    __u16 ram_size;
    __u16 vid_mode;
    __u16 root_dev;
    __u16 boot_flag;
    __u16 jump;
    __u32 header;
    __u16 version;
    __u32 realmode_swtch;
    __u16 start_sys;
    __u16 kernel_version;
    __u8 type_of_loader;
    __u8 loadflags;
    __u16 setup_move_size;
    __u32 code32_start;
    __u32 ramdisk_image;
    __u32 ramdisk_size;
    __u32 bootsect_kludge;
    __u16 heap_end_ptr;
    __u8 ext_loader_ver;
    __u8 ext_loader_type;
    __u32 cmd_line_ptr;
    __u32 initrd_addr_max;
    __u32 kernel_alignment;
    __u8 relocatable_kernel;
    __u8 min_alignment;
    __u16 xloadflags;
    __u32 cmdline_size;
    __u32 hardware_subarch;
    __u64 hardware_subarch_data;
    __u32 payload_offset;
    __u32 payload_length;
    __u64 setup_data;
    __u64 pref_address;
    __u32 init_size;
    __u32 handover_offset;
} __attribute__((packed));

struct sys_desc_table {
    __u16 length;
    __u8 table[14];
};


struct olpc_ofw_header {
    __u32 ofw_magic;
    __u32 ofw_version;
    __u32 cif_handler;
    __u32 irq_desc_table;
} __attribute__((packed));

struct efi_info {
    __u32 efi_loader_signature;
    __u32 efi_systab;
    __u32 efi_memdesc_size;
    __u32 efi_memdesc_version;
    __u32 efi_memmap;
    __u32 efi_memmap_size;
    __u32 efi_systab_hi;
    __u32 efi_memmap_hi;
};


struct boot_params {
    struct screen_info screen_info;
    struct apm_bios_info apm_bios_info;
    __u8 _pad2[4];
    __u64 tboot_addr;
    struct ist_info ist_info;
    __u8 _pad3[16];
    __u8 hd0_info[16];
    __u8 hd1_info[16];
    struct sys_desc_table sys_desc_table;
    struct olpc_ofw_header olpc_ofw_header;
    __u32 ext_ramdisk_image;
    __u32 ext_ramdisk_size;
    __u32 ext_cmd_line_ptr;
    __u8 _pad4[116];
    struct edid_info edid_info;
    struct efi_info efi_info;
    __u32 alt_mem_k;
    __u32 scratch;
    __u8 e820_entries;
    __u8 eddbuf_entries;
    __u8 edd_mbr_sig_buf_entries;
    __u8 kbd_status;
    __u8 _pad5[3];
# 149 "./arch/x86/include/uapi/asm/bootparam.h"
    __u8 sentinel;
    __u8 _pad6[1];
    struct setup_header hdr;
    __u8 _pad7[0x290-0x1f1-sizeof(struct setup_header)];
    __u32 edd_mbr_sig_buffer[16];
    struct e820entry e820_map[128];
    __u8 _pad8[48];
    struct edd_info eddbuf[6];
    __u8 _pad9[276];
} __attribute__((packed));

enum {
    X86_SUBARCH_PC = 0,
    X86_SUBARCH_LGUEST,
    X86_SUBARCH_XEN,
    X86_SUBARCH_INTEL_MID,
    X86_SUBARCH_CE4100,
    X86_NR_SUBARCHS,
};
# 6 "./arch/x86/include/asm/x86_init.h" 2

struct mpc_bus;
struct mpc_cpu;
struct mpc_table;
struct cpuinfo_x86;
# 23 "./arch/x86/include/asm/x86_init.h"
struct x86_init_mpparse {
    void (*mpc_record)(unsigned int mode);
    void (*setup_ioapic_ids)(void);
    int (*mpc_apic_id)(struct mpc_cpu *m);
    void (*smp_read_mpc_oem)(struct mpc_table *mpc);
    void (*mpc_oem_pci_bus)(struct mpc_bus *m);
    void (*mpc_oem_bus_info)(struct mpc_bus *m, char *name);
    void (*find_smp_config)(void);
    void (*get_smp_config)(unsigned int early);
};
# 42 "./arch/x86/include/asm/x86_init.h"
struct x86_init_resources {
    void (*probe_roms)(void);
    void (*reserve_resources)(void);
    char *(*memory_setup)(void);
};
# 55 "./arch/x86/include/asm/x86_init.h"
struct x86_init_irqs {
    void (*pre_vector_init)(void);
    void (*intr_init)(void);
    void (*trap_init)(void);
};






struct x86_init_oem {
    void (*arch_setup)(void);
    void (*banner)(void);
};
# 78 "./arch/x86/include/asm/x86_init.h"
struct x86_init_paging {
    void (*pagetable_init)(void);
};
# 90 "./arch/x86/include/asm/x86_init.h"
struct x86_init_timers {
    void (*setup_percpu_clockev)(void);
    void (*tsc_pre_init)(void);
    void (*timer_init)(void);
    void (*wallclock_init)(void);
};





struct x86_init_iommu {
    int (*iommu_init)(void);
};
# 112 "./arch/x86/include/asm/x86_init.h"
struct x86_init_pci {
    int (*arch_init)(void);
    int (*init)(void);
    void (*init_irq)(void);
    void (*fixup_irqs)(void);
};





struct x86_init_ops {
    struct x86_init_resources resources;
    struct x86_init_mpparse mpparse;
    struct x86_init_irqs irqs;
    struct x86_init_oem oem;
    struct x86_init_paging paging;
    struct x86_init_timers timers;
    struct x86_init_iommu iommu;
    struct x86_init_pci pci;
};






struct x86_cpuinit_ops {
    void (*setup_percpu_clockev)(void);
    void (*early_percpu_clock_init)(void);
    void (*fixup_cpu_id)(struct cpuinfo_x86 *c, int node);
};

struct timespec;
# 159 "./arch/x86/include/asm/x86_init.h"
struct x86_platform_ops {
    unsigned long (*calibrate_tsc)(void);
    void (*get_wallclock)(struct timespec *ts);
    int (*set_wallclock)(const struct timespec *ts);
    void (*iommu_shutdown)(void);
    bool (*is_untracked_pat_range)(u64 start, u64 end);
    void (*nmi_init)(void);
    unsigned char (*get_nmi_reason)(void);
    int (*i8042_detect)(void);
    void (*save_sched_clock_state)(void);
    void (*restore_sched_clock_state)(void);
    void (*apic_post_init)(void);
};

struct pci_dev;
struct msi_msg;

struct x86_msi_ops {
    int (*setup_msi_irqs)(struct pci_dev *dev, int nvec, int type);
    void (*compose_msi_msg)(struct pci_dev *dev, unsigned int irq,
                            unsigned int dest, struct msi_msg *msg,
                            u8 hpet_id);
    void (*teardown_msi_irq)(unsigned int irq);
    void (*teardown_msi_irqs)(struct pci_dev *dev);
    void (*restore_msi_irqs)(struct pci_dev *dev);
    int (*setup_hpet_msi)(unsigned int irq, unsigned int id);
};

struct IO_APIC_route_entry;
struct io_apic_irq_attr;
struct irq_data;
struct cpumask;

struct x86_io_apic_ops {
    void (*init) (void);
    unsigned int (*read) (unsigned int apic, unsigned int reg);
    void (*write) (unsigned int apic, unsigned int reg, unsigned int value);
    void (*modify) (unsigned int apic, unsigned int reg, unsigned int value);
    void (*disable)(void);
    void (*print_entries)(unsigned int apic, unsigned int nr_entries);
    int (*set_affinity)(struct irq_data *data,
                        const struct cpumask *mask,
                        bool force);
    int (*setup_entry)(int irq, struct IO_APIC_route_entry *entry,
                       unsigned int destination, int vector,
                       struct io_apic_irq_attr *attr);
    void (*eoi_ioapic_pin)(int apic, int pin, int vector);
};

extern struct x86_init_ops x86_init;
extern struct x86_cpuinit_ops x86_cpuinit;
extern struct x86_platform_ops x86_platform;
extern struct x86_msi_ops x86_msi;
extern struct x86_io_apic_ops x86_io_apic_ops;
extern void x86_init_noop(void);
extern void x86_init_uint_noop(unsigned int unused);
# 7 "./arch/x86/include/asm/mpspec.h" 2
# 1 "./arch/x86/include/asm/apicdef.h" 1
# 178 "./arch/x86/include/asm/apicdef.h"
struct local_apic {

    struct { unsigned int __reserved[4]; } __reserved_01;

    struct { unsigned int __reserved[4]; } __reserved_02;

    struct {
        unsigned int __reserved_1 : 24,
                phys_apic_id : 4,
                __reserved_2 : 4;
        unsigned int __reserved[3];
    } id;

    const
    struct {
        unsigned int version : 8,
                __reserved_1 : 8,
                max_lvt : 8,
                __reserved_2 : 8;
        unsigned int __reserved[3];
    } version;

    struct { unsigned int __reserved[4]; } __reserved_03;

    struct { unsigned int __reserved[4]; } __reserved_04;

    struct { unsigned int __reserved[4]; } __reserved_05;

    struct { unsigned int __reserved[4]; } __reserved_06;

    struct {
        unsigned int priority : 8,
                __reserved_1 : 24;
        unsigned int __reserved_2[3];
    } tpr;

    const
    struct {
        unsigned int priority : 8,
                __reserved_1 : 24;
        unsigned int __reserved_2[3];
    } apr;

    const
    struct {
        unsigned int priority : 8,
                __reserved_1 : 24;
        unsigned int __reserved_2[3];
    } ppr;

    struct {
        unsigned int eoi;
        unsigned int __reserved[3];
    } eoi;

    struct { unsigned int __reserved[4]; } __reserved_07;

    struct {
        unsigned int __reserved_1 : 24,
                logical_dest : 8;
        unsigned int __reserved_2[3];
    } ldr;

    struct {
        unsigned int __reserved_1 : 28,
                model : 4;
        unsigned int __reserved_2[3];
    } dfr;

    struct {
        unsigned int spurious_vector : 8,
                apic_enabled : 1,
                focus_cpu : 1,
                __reserved_2 : 22;
        unsigned int __reserved_3[3];
    } svr;

    struct {
        unsigned int bitfield;
        unsigned int __reserved[3];
    } isr [8];

    struct {
        unsigned int bitfield;
        unsigned int __reserved[3];
    } tmr [8];

    struct {
        unsigned int bitfield;
        unsigned int __reserved[3];
    } irr [8];

    union {
        struct {
            unsigned int send_cs_error : 1,
                    receive_cs_error : 1,
                    send_accept_error : 1,
                    receive_accept_error : 1,
                    __reserved_1 : 1,
                    send_illegal_vector : 1,
                    receive_illegal_vector : 1,
                    illegal_register_address : 1,
                    __reserved_2 : 24;
            unsigned int __reserved_3[3];
        } error_bits;
        struct {
            unsigned int errors;
            unsigned int __reserved_3[3];
        } all_errors;
    } esr;

    struct { unsigned int __reserved[4]; } __reserved_08;

    struct { unsigned int __reserved[4]; } __reserved_09;

    struct { unsigned int __reserved[4]; } __reserved_10;

    struct { unsigned int __reserved[4]; } __reserved_11;

    struct { unsigned int __reserved[4]; } __reserved_12;

    struct { unsigned int __reserved[4]; } __reserved_13;

    struct { unsigned int __reserved[4]; } __reserved_14;

    struct {
        unsigned int vector : 8,
                delivery_mode : 3,
                destination_mode : 1,
                delivery_status : 1,
                __reserved_1 : 1,
                level : 1,
                trigger : 1,
                __reserved_2 : 2,
                shorthand : 2,
                __reserved_3 : 12;
        unsigned int __reserved_4[3];
    } icr1;

    struct {
        union {
            unsigned int __reserved_1 : 24,
                    phys_dest : 4,
                    __reserved_2 : 4;
            unsigned int __reserved_3 : 24,
                    logical_dest : 8;
        } dest;
        unsigned int __reserved_4[3];
    } icr2;

    struct {
        unsigned int vector : 8,
                __reserved_1 : 4,
                delivery_status : 1,
                __reserved_2 : 3,
                mask : 1,
                timer_mode : 1,
                __reserved_3 : 14;
        unsigned int __reserved_4[3];
    } lvt_timer;

    struct {
        unsigned int vector : 8,
                delivery_mode : 3,
                __reserved_1 : 1,
                delivery_status : 1,
                __reserved_2 : 3,
                mask : 1,
                __reserved_3 : 15;
        unsigned int __reserved_4[3];
    } lvt_thermal;

    struct {
        unsigned int vector : 8,
                delivery_mode : 3,
                __reserved_1 : 1,
                delivery_status : 1,
                __reserved_2 : 3,
                mask : 1,
                __reserved_3 : 15;
        unsigned int __reserved_4[3];
    } lvt_pc;

    struct {
        unsigned int vector : 8,
                delivery_mode : 3,
                __reserved_1 : 1,
                delivery_status : 1,
                polarity : 1,
                remote_irr : 1,
                trigger : 1,
                mask : 1,
                __reserved_2 : 15;
        unsigned int __reserved_3[3];
    } lvt_lint0;

    struct {
        unsigned int vector : 8,
                delivery_mode : 3,
                __reserved_1 : 1,
                delivery_status : 1,
                polarity : 1,
                remote_irr : 1,
                trigger : 1,
                mask : 1,
                __reserved_2 : 15;
        unsigned int __reserved_3[3];
    } lvt_lint1;

    struct {
        unsigned int vector : 8,
                __reserved_1 : 4,
                delivery_status : 1,
                __reserved_2 : 3,
                mask : 1,
                __reserved_3 : 15;
        unsigned int __reserved_4[3];
    } lvt_error;

    struct {
        unsigned int initial_count;
        unsigned int __reserved_2[3];
    } timer_icr;

    const
    struct {
        unsigned int curr_count;
        unsigned int __reserved_2[3];
    } timer_ccr;

    struct { unsigned int __reserved[4]; } __reserved_16;

    struct { unsigned int __reserved[4]; } __reserved_17;

    struct { unsigned int __reserved[4]; } __reserved_18;

    struct { unsigned int __reserved[4]; } __reserved_19;

    struct {
        unsigned int divisor : 4,
                __reserved_1 : 28;
        unsigned int __reserved_2[3];
    } timer_dcr;

    struct { unsigned int __reserved[4]; } __reserved_20;

} __attribute__ ((packed));
# 434 "./arch/x86/include/asm/apicdef.h"
enum ioapic_irq_destination_types {
    dest_Fixed = 0,
    dest_LowestPrio = 1,
    dest_SMI = 2,
    dest__reserved_1 = 3,
    dest_NMI = 4,
    dest_INIT = 5,
    dest__reserved_2 = 6,
    dest_ExtINT = 7
};
# 8 "./arch/x86/include/asm/mpspec.h" 2

extern int apic_version[];
extern int pic_mode;
# 40 "./arch/x86/include/asm/mpspec.h"
extern unsigned long mp_bus_not_pci[(((256) + (8 * sizeof(long)) - 1) / (8 * sizeof(long)))];

extern unsigned int boot_cpu_physical_apicid;
extern unsigned long mp_lapic_addr;


extern int smp_found_config;




static inline __attribute__((no_instrument_function)) void get_smp_config(void)
{
    x86_init.mpparse.get_smp_config(0);
}

static inline __attribute__((no_instrument_function)) void early_get_smp_config(void)
{
    x86_init.mpparse.get_smp_config(1);
}

static inline __attribute__((no_instrument_function)) void find_smp_config(void)
{
    x86_init.mpparse.find_smp_config();
}


extern void early_reserve_e820_mpc_new(void);
extern int enable_update_mptable;
extern int default_mpc_apic_id(struct mpc_cpu *m);
extern void default_smp_read_mpc_oem(struct mpc_table *mpc);

extern void default_mpc_oem_bus_info(struct mpc_bus *m, char *str);



extern void default_find_smp_config(void);
extern void default_get_smp_config(unsigned int early);
# 88 "./arch/x86/include/asm/mpspec.h"
int generic_processor_info(int apicid, int version);



struct physid_mask {
    unsigned long mask[(((32768) + (8 * sizeof(long)) - 1) / (8 * sizeof(long)))];
};

typedef struct physid_mask physid_mask_t;
# 131 "./arch/x86/include/asm/mpspec.h"
static inline __attribute__((no_instrument_function)) unsigned long physids_coerce(physid_mask_t *map)
{
    return map->mask[0];
}

static inline __attribute__((no_instrument_function)) void physids_promote(unsigned long physids, physid_mask_t *map)
{
    bitmap_zero((*map).mask, 32768);
    map->mask[0] = physids;
}

static inline __attribute__((no_instrument_function)) void physid_set_mask_of_physid(int physid, physid_mask_t *map)
{
    bitmap_zero((*map).mask, 32768);
    set_bit(physid, (*map).mask);
}




extern physid_mask_t phys_cpu_present_map;
# 12 "./arch/x86/include/asm/smp.h" 2
# 1 "./arch/x86/include/asm/apic.h" 1




# 1 "include/linux/pm.h" 1
# 25 "include/linux/pm.h"
# 1 "include/linux/workqueue.h" 1







# 1 "include/linux/timer.h" 1




# 1 "include/linux/ktime.h" 1
# 37 "include/linux/ktime.h"
union ktime {
    s64 tv64;
};

typedef union ktime ktime_t;
# 50 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) ktime_t ktime_set(const s64 secs, const unsigned long nsecs)
{
    if (__builtin_expect(!!(secs >= (((s64)~((u64)1 << 63)) / 1000000000L)), 0))
        return (ktime_t){ .tv64 = ((s64)~((u64)1 << 63)) };

    return (ktime_t) { .tv64 = secs * 1000000000L + (s64)nsecs };
}
# 81 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) ktime_t timespec_to_ktime(struct timespec ts)
{
    return ktime_set(ts.tv_sec, ts.tv_nsec);
}


static inline __attribute__((no_instrument_function)) ktime_t timespec64_to_ktime(struct timespec ts)
{
    return ktime_set(ts.tv_sec, ts.tv_nsec);
}


static inline __attribute__((no_instrument_function)) ktime_t timeval_to_ktime(struct timeval tv)
{
    return ktime_set(tv.tv_sec, tv.tv_usec * 1000L);
}
# 120 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) int ktime_equal(const ktime_t cmp1, const ktime_t cmp2)
{
    return cmp1.tv64 == cmp2.tv64;
}
# 135 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) int ktime_compare(const ktime_t cmp1, const ktime_t cmp2)
{
    if (cmp1.tv64 < cmp2.tv64)
        return -1;
    if (cmp1.tv64 > cmp2.tv64)
        return 1;
    return 0;
}
# 151 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) bool ktime_after(const ktime_t cmp1, const ktime_t cmp2)
{
    return ktime_compare(cmp1, cmp2) > 0;
}
# 163 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) bool ktime_before(const ktime_t cmp1, const ktime_t cmp2)
{
    return ktime_compare(cmp1, cmp2) < 0;
}
# 184 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) s64 ktime_to_us(const ktime_t kt)
{
    return (u64)((kt).tv64 / (1000L));
}

static inline __attribute__((no_instrument_function)) s64 ktime_to_ms(const ktime_t kt)
{
    return (u64)((kt).tv64 / (1000000L));
}

static inline __attribute__((no_instrument_function)) s64 ktime_us_delta(const ktime_t later, const ktime_t earlier)
{
    return ktime_to_us(({ (ktime_t){ .tv64 = (later).tv64 - (earlier).tv64 }; }));
}

static inline __attribute__((no_instrument_function)) s64 ktime_ms_delta(const ktime_t later, const ktime_t earlier)
{
    return ktime_to_ms(({ (ktime_t){ .tv64 = (later).tv64 - (earlier).tv64 }; }));
}

static inline __attribute__((no_instrument_function)) ktime_t ktime_add_us(const ktime_t kt, const u64 usec)
{
    return ({ (ktime_t){ .tv64 = (kt).tv64 + (usec * 1000L) }; });
}

static inline __attribute__((no_instrument_function)) ktime_t ktime_add_ms(const ktime_t kt, const u64 msec)
{
    return ({ (ktime_t){ .tv64 = (kt).tv64 + (msec * 1000000L) }; });
}

static inline __attribute__((no_instrument_function)) ktime_t ktime_sub_us(const ktime_t kt, const u64 usec)
{
    return ({ (ktime_t){ .tv64 = (kt).tv64 - (usec * 1000L) }; });
}

extern ktime_t ktime_add_safe(const ktime_t lhs, const ktime_t rhs);
# 229 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) __attribute__((warn_unused_result)) bool ktime_to_timespec_cond(const ktime_t kt,
                                                                                                                      struct timespec *ts)
{
    if (kt.tv64) {
        *ts = ns_to_timespec((kt).tv64);
        return true;
    } else {
        return false;
    }
}
# 248 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) __attribute__((warn_unused_result)) bool ktime_to_timespec64_cond(const ktime_t kt,
                                                                                                                        struct timespec *ts)
{
    if (kt.tv64) {
        *ts = ns_to_timespec((kt).tv64);
        return true;
    } else {
        return false;
    }
}
# 268 "include/linux/ktime.h"
static inline __attribute__((no_instrument_function)) ktime_t ns_to_ktime(u64 ns)
{
    static const ktime_t ktime_zero = { .tv64 = 0 };

    return ({ (ktime_t){ .tv64 = (ktime_zero).tv64 + (ns) }; });
}

static inline __attribute__((no_instrument_function)) ktime_t ms_to_ktime(u64 ms)
{
    static const ktime_t ktime_zero = { .tv64 = 0 };

    return ktime_add_ms(ktime_zero, ms);
}

# 1 "include/linux/timekeeping.h" 1





void timekeeping_init(void);
extern int timekeeping_suspended;




extern void do_gettimeofday(struct timeval *tv);
extern int do_settimeofday64(const struct timespec *ts);
extern int do_sys_settimeofday(const struct timespec *tv,
                               const struct timezone *tz);




unsigned long get_seconds(void);
struct timespec current_kernel_time(void);

struct timespec __current_kernel_time(void);




struct timespec get_monotonic_coarse64(void);
extern void getrawmonotonic64(struct timespec *ts);
extern void ktime_get_ts64(struct timespec *ts);
extern time64_t ktime_get_seconds(void);
extern time64_t ktime_get_real_seconds(void);

extern int __getnstimeofday64(struct timespec *tv);
extern void getnstimeofday64(struct timespec *tv);
extern void getboottime64(struct timespec *ts);





static inline __attribute__((no_instrument_function)) int do_settimeofday(const struct timespec *ts)
{
    return do_settimeofday64(ts);
}

static inline __attribute__((no_instrument_function)) int __getnstimeofday(struct timespec *ts)
{
    return __getnstimeofday64(ts);
}

static inline __attribute__((no_instrument_function)) void getnstimeofday(struct timespec *ts)
{
    getnstimeofday64(ts);
}

static inline __attribute__((no_instrument_function)) void ktime_get_ts(struct timespec *ts)
{
    ktime_get_ts64(ts);
}

static inline __attribute__((no_instrument_function)) void ktime_get_real_ts(struct timespec *ts)
{
    getnstimeofday64(ts);
}

static inline __attribute__((no_instrument_function)) void getrawmonotonic(struct timespec *ts)
{
    getrawmonotonic64(ts);
}

static inline __attribute__((no_instrument_function)) struct timespec get_monotonic_coarse(void)
{
    return get_monotonic_coarse64();
}

static inline __attribute__((no_instrument_function)) void getboottime(struct timespec *ts)
{
    return getboottime64(ts);
}
# 155 "include/linux/timekeeping.h"
enum tk_offsets {
    TK_OFFS_REAL,
    TK_OFFS_BOOT,
    TK_OFFS_TAI,
    TK_OFFS_MAX,
};

extern ktime_t ktime_get(void);
extern ktime_t ktime_get_with_offset(enum tk_offsets offs);
extern ktime_t ktime_mono_to_any(ktime_t tmono, enum tk_offsets offs);
extern ktime_t ktime_get_raw(void);




static inline __attribute__((no_instrument_function)) ktime_t ktime_get_real(void)
{
    return ktime_get_with_offset(TK_OFFS_REAL);
}







static inline __attribute__((no_instrument_function)) ktime_t ktime_get_boottime(void)
{
    return ktime_get_with_offset(TK_OFFS_BOOT);
}




static inline __attribute__((no_instrument_function)) ktime_t ktime_get_clocktai(void)
{
    return ktime_get_with_offset(TK_OFFS_TAI);
}




static inline __attribute__((no_instrument_function)) ktime_t ktime_mono_to_real(ktime_t mono)
{
    return ktime_mono_to_any(mono, TK_OFFS_REAL);
}

static inline __attribute__((no_instrument_function)) u64 ktime_get_ns(void)
{
    return ((ktime_get()).tv64);
}

static inline __attribute__((no_instrument_function)) u64 ktime_get_real_ns(void)
{
    return ((ktime_get_real()).tv64);
}

static inline __attribute__((no_instrument_function)) u64 ktime_get_boot_ns(void)
{
    return ((ktime_get_boottime()).tv64);
}

static inline __attribute__((no_instrument_function)) u64 ktime_get_tai_ns(void)
{
    return ((ktime_get_clocktai()).tv64);
}

static inline __attribute__((no_instrument_function)) u64 ktime_get_raw_ns(void)
{
    return ((ktime_get_raw()).tv64);
}

extern u64 ktime_get_mono_fast_ns(void);
extern u64 ktime_get_raw_fast_ns(void);




static inline __attribute__((no_instrument_function)) void get_monotonic_boottime(struct timespec *ts)
{
    *ts = ns_to_timespec((ktime_get_boottime()).tv64);
}

static inline __attribute__((no_instrument_function)) void get_monotonic_boottime64(struct timespec *ts)
{
    *ts = ns_to_timespec((ktime_get_boottime()).tv64);
}

static inline __attribute__((no_instrument_function)) void timekeeping_clocktai(struct timespec *ts)
{
    *ts = ns_to_timespec((ktime_get_clocktai()).tv64);
}




extern bool timekeeping_rtc_skipsuspend(void);
extern bool timekeeping_rtc_skipresume(void);

extern void timekeeping_inject_sleeptime64(struct timespec *delta);




extern void getnstime_raw_and_real(struct timespec *ts_raw,
                                   struct timespec *ts_real);




extern int persistent_clock_is_local;

extern void read_persistent_clock(struct timespec *ts);
extern void read_persistent_clock64(struct timespec *ts);
extern void read_boot_clock(struct timespec *ts);
extern void read_boot_clock64(struct timespec *ts);
extern int update_persistent_clock(struct timespec now);
extern int update_persistent_clock64(struct timespec now);
# 283 "include/linux/ktime.h" 2
# 6 "include/linux/timer.h" 2
# 1 "include/linux/stddef.h" 1
# 7 "include/linux/timer.h" 2
# 1 "include/linux/debugobjects.h" 1






enum debug_obj_state {
    ODEBUG_STATE_NONE,
    ODEBUG_STATE_INIT,
    ODEBUG_STATE_INACTIVE,
    ODEBUG_STATE_ACTIVE,
    ODEBUG_STATE_DESTROYED,
    ODEBUG_STATE_NOTAVAILABLE,
    ODEBUG_STATE_MAX,
};

struct debug_obj_descr;
# 27 "include/linux/debugobjects.h"
struct debug_obj {
    struct hlist_node node;
    enum debug_obj_state state;
    unsigned int astate;
    void *object;
    struct debug_obj_descr *descr;
};
# 52 "include/linux/debugobjects.h"
struct debug_obj_descr {
    const char *name;
    void *(*debug_hint) (void *addr);
    int (*fixup_init) (void *addr, enum debug_obj_state state);
    int (*fixup_activate) (void *addr, enum debug_obj_state state);
    int (*fixup_destroy) (void *addr, enum debug_obj_state state);
    int (*fixup_free) (void *addr, enum debug_obj_state state);
    int (*fixup_assert_init)(void *addr, enum debug_obj_state state);
};
# 84 "include/linux/debugobjects.h"
static inline __attribute__((no_instrument_function)) void
debug_object_init (void *addr, struct debug_obj_descr *descr) { }
static inline __attribute__((no_instrument_function)) void
debug_object_init_on_stack(void *addr, struct debug_obj_descr *descr) { }
static inline __attribute__((no_instrument_function)) int
debug_object_activate (void *addr, struct debug_obj_descr *descr) { return 0; }
static inline __attribute__((no_instrument_function)) void
debug_object_deactivate(void *addr, struct debug_obj_descr *descr) { }
static inline __attribute__((no_instrument_function)) void
debug_object_destroy (void *addr, struct debug_obj_descr *descr) { }
static inline __attribute__((no_instrument_function)) void
debug_object_free (void *addr, struct debug_obj_descr *descr) { }
static inline __attribute__((no_instrument_function)) void
debug_object_assert_init(void *addr, struct debug_obj_descr *descr) { }

static inline __attribute__((no_instrument_function)) void debug_objects_early_init(void) { }
static inline __attribute__((no_instrument_function)) void debug_objects_mem_init(void) { }





static inline __attribute__((no_instrument_function)) void
debug_check_no_obj_freed(const void *address, unsigned long size) { }
# 8 "include/linux/timer.h" 2


struct tvec_base;

struct timer_list {




    struct list_head entry;
    unsigned long expires;
    struct tvec_base *base;

    void (*function)(unsigned long);
    unsigned long data;

    int slack;


    int start_pid;
    void *start_site;
    char start_comm[16];




};

extern struct tvec_base boot_tvec_bases;
# 94 "include/linux/timer.h"
void init_timer_key(struct timer_list *timer, unsigned int flags,
                    const char *name, struct lock_class_key *key);







static inline __attribute__((no_instrument_function)) void destroy_timer_on_stack(struct timer_list *timer) { }
static inline __attribute__((no_instrument_function)) void init_timer_on_stack_key(struct timer_list *timer,
                                                                                   unsigned int flags, const char *name,
                                                                                   struct lock_class_key *key)
{
    init_timer_key(timer, flags, name, key);
}
# 169 "include/linux/timer.h"
static inline __attribute__((no_instrument_function)) int timer_pending(const struct timer_list * timer)
{
    return timer->entry.next != ((void *)0);
}

extern void add_timer_on(struct timer_list *timer, int cpu);
extern int del_timer(struct timer_list * timer);
extern int mod_timer(struct timer_list *timer, unsigned long expires);
extern int mod_timer_pending(struct timer_list *timer, unsigned long expires);
extern int mod_timer_pinned(struct timer_list *timer, unsigned long expires);

extern void set_timer_slack(struct timer_list *time, int slack_hz);
# 195 "include/linux/timer.h"
extern unsigned long get_next_timer_interrupt(unsigned long now);






extern int timer_stats_active;



extern void init_timer_stats(void);

extern void timer_stats_update_stats(void *timer, pid_t pid, void *startf,
                                     void *timerf, char *comm,
                                     unsigned int timer_flag);

extern void __timer_stats_timer_set_start_info(struct timer_list *timer,
                                               void *addr);

static inline __attribute__((no_instrument_function)) void timer_stats_timer_set_start_info(struct timer_list *timer)
{
    if (__builtin_expect(!!(!timer_stats_active), 1))
        return;
    __timer_stats_timer_set_start_info(timer, __builtin_return_address(0));
}

static inline __attribute__((no_instrument_function)) void timer_stats_timer_clear_start_info(struct timer_list *timer)
{
    timer->start_site = ((void *)0);
}
# 240 "include/linux/timer.h"
extern void add_timer(struct timer_list *timer);

extern int try_to_del_timer_sync(struct timer_list *timer);


extern int del_timer_sync(struct timer_list *timer);






extern void init_timers(void);
extern void run_local_timers(void);
struct hrtimer;
extern enum hrtimer_restart it_real_fn(struct hrtimer *);

unsigned long __round_jiffies(unsigned long j, int cpu);
unsigned long __round_jiffies_relative(unsigned long j, int cpu);
unsigned long round_jiffies(unsigned long j);
unsigned long round_jiffies_relative(unsigned long j);

unsigned long __round_jiffies_up(unsigned long j, int cpu);
unsigned long __round_jiffies_up_relative(unsigned long j, int cpu);
unsigned long round_jiffies_up(unsigned long j);
unsigned long round_jiffies_up_relative(unsigned long j);
# 9 "include/linux/workqueue.h" 2







struct workqueue_struct;

struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
void delayed_work_timer_fn(unsigned long __data);







enum {
    WORK_STRUCT_PENDING_BIT = 0,
    WORK_STRUCT_DELAYED_BIT = 1,
    WORK_STRUCT_PWQ_BIT = 2,
    WORK_STRUCT_LINKED_BIT = 3,




    WORK_STRUCT_COLOR_SHIFT = 4,


    WORK_STRUCT_COLOR_BITS = 4,

    WORK_STRUCT_PENDING = 1 << WORK_STRUCT_PENDING_BIT,
    WORK_STRUCT_DELAYED = 1 << WORK_STRUCT_DELAYED_BIT,
    WORK_STRUCT_PWQ = 1 << WORK_STRUCT_PWQ_BIT,
    WORK_STRUCT_LINKED = 1 << WORK_STRUCT_LINKED_BIT,



    WORK_STRUCT_STATIC = 0,






    WORK_NR_COLORS = (1 << WORK_STRUCT_COLOR_BITS) - 1,
    WORK_NO_COLOR = WORK_NR_COLORS,


    WORK_CPU_UNBOUND = 64,






    WORK_STRUCT_FLAG_BITS = WORK_STRUCT_COLOR_SHIFT +
                            WORK_STRUCT_COLOR_BITS,


    WORK_OFFQ_FLAG_BASE = WORK_STRUCT_COLOR_SHIFT,

    __WORK_OFFQ_CANCELING = WORK_OFFQ_FLAG_BASE,
    WORK_OFFQ_CANCELING = (1 << __WORK_OFFQ_CANCELING),






    WORK_OFFQ_FLAG_BITS = 1,
    WORK_OFFQ_POOL_SHIFT = WORK_OFFQ_FLAG_BASE + WORK_OFFQ_FLAG_BITS,
    WORK_OFFQ_LEFT = 64 - WORK_OFFQ_POOL_SHIFT,
    WORK_OFFQ_POOL_BITS = WORK_OFFQ_LEFT <= 31 ? WORK_OFFQ_LEFT : 31,
    WORK_OFFQ_POOL_NONE = (1LU << WORK_OFFQ_POOL_BITS) - 1,


    WORK_STRUCT_FLAG_MASK = (1UL << WORK_STRUCT_FLAG_BITS) - 1,
    WORK_STRUCT_WQ_DATA_MASK = ~WORK_STRUCT_FLAG_MASK,
    WORK_STRUCT_NO_POOL = (unsigned long)WORK_OFFQ_POOL_NONE << WORK_OFFQ_POOL_SHIFT,


    WORK_BUSY_PENDING = 1 << 0,
    WORK_BUSY_RUNNING = 1 << 1,


    WORKER_DESC_LEN = 24,
};

struct work_struct {
    atomic_long_t data;
    struct list_head entry;
    work_func_t func;



};





struct delayed_work {
    struct work_struct work;
    struct timer_list timer;


    struct workqueue_struct *wq;
    int cpu;
};
# 130 "include/linux/workqueue.h"
struct workqueue_attrs {
    int nice;
    cpumask_var_t cpumask;
    bool no_numa;
};

static inline __attribute__((no_instrument_function)) struct delayed_work *to_delayed_work(struct work_struct *work)
{
    return ({ const typeof( ((struct delayed_work *)0)->work ) *__mptr = (work); (struct delayed_work *)( (char *)__mptr - __builtin_offsetof(struct delayed_work,work) );});
}

struct execute_work {
    struct work_struct work;
};
# 189 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) void __init_work(struct work_struct *work, int onstack) { }
static inline __attribute__((no_instrument_function)) void destroy_work_on_stack(struct work_struct *work) { }
static inline __attribute__((no_instrument_function)) void destroy_delayed_work_on_stack(struct delayed_work *work) { }
static inline __attribute__((no_instrument_function)) unsigned int work_static(struct work_struct *work) { return 0; }
# 277 "include/linux/workqueue.h"
enum {
    WQ_UNBOUND = 1 << 1,
    WQ_FREEZABLE = 1 << 2,
    WQ_MEM_RECLAIM = 1 << 3,
    WQ_HIGHPRI = 1 << 4,
    WQ_CPU_INTENSIVE = 1 << 5,
    WQ_SYSFS = 1 << 6,
# 310 "include/linux/workqueue.h"
    WQ_POWER_EFFICIENT = 1 << 7,

    __WQ_DRAINING = 1 << 16,
    __WQ_ORDERED = 1 << 17,

    WQ_MAX_ACTIVE = 512,
    WQ_MAX_UNBOUND_PER_CPU = 4,
    WQ_DFL_ACTIVE = WQ_MAX_ACTIVE / 2,
};
# 352 "include/linux/workqueue.h"
extern struct workqueue_struct *system_wq;
extern struct workqueue_struct *system_highpri_wq;
extern struct workqueue_struct *system_long_wq;
extern struct workqueue_struct *system_unbound_wq;
extern struct workqueue_struct *system_freezable_wq;
extern struct workqueue_struct *system_power_efficient_wq;
extern struct workqueue_struct *system_freezable_power_efficient_wq;

extern struct workqueue_struct *
__alloc_workqueue_key(const char *fmt, unsigned int flags, int max_active,
                      struct lock_class_key *key, const char *lock_name, ...) __attribute__((format(printf, 1, 6)));
# 421 "include/linux/workqueue.h"
extern void destroy_workqueue(struct workqueue_struct *wq);

struct workqueue_attrs *alloc_workqueue_attrs(gfp_t gfp_mask);
void free_workqueue_attrs(struct workqueue_attrs *attrs);
int apply_workqueue_attrs(struct workqueue_struct *wq,
                          const struct workqueue_attrs *attrs);

extern bool queue_work_on(int cpu, struct workqueue_struct *wq,
                          struct work_struct *work);
extern bool queue_delayed_work_on(int cpu, struct workqueue_struct *wq,
                                  struct delayed_work *work, unsigned long delay);
extern bool mod_delayed_work_on(int cpu, struct workqueue_struct *wq,
                                struct delayed_work *dwork, unsigned long delay);

extern void flush_workqueue(struct workqueue_struct *wq);
extern void drain_workqueue(struct workqueue_struct *wq);
extern void flush_scheduled_work(void);

extern int schedule_on_each_cpu(work_func_t func);

int execute_in_process_context(work_func_t fn, struct execute_work *);

extern bool flush_work(struct work_struct *work);
extern bool cancel_work_sync(struct work_struct *work);

extern bool flush_delayed_work(struct delayed_work *dwork);
extern bool cancel_delayed_work(struct delayed_work *dwork);
extern bool cancel_delayed_work_sync(struct delayed_work *dwork);

extern void workqueue_set_max_active(struct workqueue_struct *wq,
                                     int max_active);
extern bool current_is_workqueue_rescuer(void);
extern bool workqueue_congested(int cpu, struct workqueue_struct *wq);
extern unsigned int work_busy(struct work_struct *work);
extern __attribute__((format(printf, 1, 2))) void set_worker_desc(const char *fmt, ...);
extern void print_worker_info(const char *log_lvl, struct task_struct *task);
extern void show_workqueue_state(void);
# 469 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) bool queue_work(struct workqueue_struct *wq,
                                                                      struct work_struct *work)
{
    return queue_work_on(WORK_CPU_UNBOUND, wq, work);
}
# 483 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) bool queue_delayed_work(struct workqueue_struct *wq,
                                                                              struct delayed_work *dwork,
                                                                              unsigned long delay)
{
    return queue_delayed_work_on(WORK_CPU_UNBOUND, wq, dwork, delay);
}
# 498 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) bool mod_delayed_work(struct workqueue_struct *wq,
                                                                            struct delayed_work *dwork,
                                                                            unsigned long delay)
{
    return mod_delayed_work_on(WORK_CPU_UNBOUND, wq, dwork, delay);
}
# 512 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) bool schedule_work_on(int cpu, struct work_struct *work)
{
    return queue_work_on(cpu, system_wq, work);
}
# 528 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) bool schedule_work(struct work_struct *work)
{
    return queue_work(system_wq, work);
}
# 542 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) bool schedule_delayed_work_on(int cpu, struct delayed_work *dwork,
                                                                                    unsigned long delay)
{
    return queue_delayed_work_on(cpu, system_wq, dwork, delay);
}
# 556 "include/linux/workqueue.h"
static inline __attribute__((no_instrument_function)) bool schedule_delayed_work(struct delayed_work *dwork,
                                                                                 unsigned long delay)
{
    return queue_delayed_work(system_wq, dwork, delay);
}




static inline __attribute__((no_instrument_function)) bool keventd_up(void)
{
    return system_wq != ((void *)0);
}







long work_on_cpu(int cpu, long (*fn)(void *), void *arg);



extern void freeze_workqueues_begin(void);
extern bool freeze_workqueues_busy(void);
extern void thaw_workqueues(void);



int workqueue_sysfs_register(struct workqueue_struct *wq);
# 26 "include/linux/pm.h" 2
# 34 "include/linux/pm.h"
extern void (*pm_power_off)(void);
extern void (*pm_power_off_prepare)(void);

struct device;

extern void pm_vt_switch_required(struct device *dev, bool required);
extern void pm_vt_switch_unregister(struct device *dev);
# 54 "include/linux/pm.h"
struct device;


extern const char power_group_name[];




typedef struct pm_message {
    int event;
} pm_message_t;
# 295 "include/linux/pm.h"
struct dev_pm_ops {
    int (*prepare)(struct device *dev);
    void (*complete)(struct device *dev);
    int (*suspend)(struct device *dev);
    int (*resume)(struct device *dev);
    int (*freeze)(struct device *dev);
    int (*thaw)(struct device *dev);
    int (*poweroff)(struct device *dev);
    int (*restore)(struct device *dev);
    int (*suspend_late)(struct device *dev);
    int (*resume_early)(struct device *dev);
    int (*freeze_late)(struct device *dev);
    int (*thaw_early)(struct device *dev);
    int (*poweroff_late)(struct device *dev);
    int (*restore_early)(struct device *dev);
    int (*suspend_noirq)(struct device *dev);
    int (*resume_noirq)(struct device *dev);
    int (*freeze_noirq)(struct device *dev);
    int (*thaw_noirq)(struct device *dev);
    int (*poweroff_noirq)(struct device *dev);
    int (*restore_noirq)(struct device *dev);
    int (*runtime_suspend)(struct device *dev);
    int (*runtime_resume)(struct device *dev);
    int (*runtime_idle)(struct device *dev);
};
# 501 "include/linux/pm.h"
enum rpm_status {
    RPM_ACTIVE = 0,
    RPM_RESUMING,
    RPM_SUSPENDED,
    RPM_SUSPENDING,
};
# 523 "include/linux/pm.h"
enum rpm_request {
    RPM_REQ_NONE = 0,
    RPM_REQ_IDLE,
    RPM_REQ_SUSPEND,
    RPM_REQ_AUTOSUSPEND,
    RPM_REQ_RESUME,
};

struct wakeup_source;
struct pm_domain_data;

struct pm_subsys_data {
    spinlock_t lock;
    unsigned int refcount;






};

struct dev_pm_info {
    pm_message_t power_state;
    unsigned int can_wakeup:1;
    unsigned int async_suspend:1;
    bool is_prepared:1;
    bool is_suspended:1;
    bool is_noirq_suspended:1;
    bool is_late_suspended:1;
    bool ignore_children:1;
    bool early_init:1;
    bool direct_complete:1;
    spinlock_t lock;

    struct list_head entry;
    struct completion completion;
    struct wakeup_source *wakeup;
    bool wakeup_path:1;
    bool syscore:1;




    struct timer_list suspend_timer;
    unsigned long timer_expires;
    struct work_struct work;
    wait_queue_head_t wait_queue;
    atomic_t usage_count;
    atomic_t child_count;
    unsigned int disable_depth:3;
    unsigned int idle_notification:1;
    unsigned int request_pending:1;
    unsigned int deferred_resume:1;
    unsigned int run_wake:1;
    unsigned int runtime_auto:1;
    unsigned int no_callbacks:1;
    unsigned int irq_safe:1;
    unsigned int use_autosuspend:1;
    unsigned int timer_autosuspends:1;
    unsigned int memalloc_noio:1;
    enum rpm_request request;
    enum rpm_status runtime_status;
    int runtime_error;
    int autosuspend_delay;
    unsigned long last_busy;
    unsigned long active_jiffies;
    unsigned long suspended_jiffies;
    unsigned long accounting_timestamp;

    struct pm_subsys_data *subsys_data;
    void (*set_latency_tolerance)(struct device *, s32);
    struct dev_pm_qos *qos;
};

extern void update_pm_runtime_accounting(struct device *dev);
extern int dev_pm_get_subsys_data(struct device *dev);
extern void dev_pm_put_subsys_data(struct device *dev);
# 612 "include/linux/pm.h"
struct dev_pm_domain {
    struct dev_pm_ops ops;
    void (*detach)(struct device *dev, bool power_off);
    int (*activate)(struct device *dev);
    void (*sync)(struct device *dev);
    void (*dismiss)(struct device *dev);
};
# 675 "include/linux/pm.h"
extern void device_pm_lock(void);
extern void dpm_resume_start(pm_message_t state);
extern void dpm_resume_end(pm_message_t state);
extern void dpm_resume_noirq(pm_message_t state);
extern void dpm_resume_early(pm_message_t state);
extern void dpm_resume(pm_message_t state);
extern void dpm_complete(pm_message_t state);

extern void device_pm_unlock(void);
extern int dpm_suspend_end(pm_message_t state);
extern int dpm_suspend_start(pm_message_t state);
extern int dpm_suspend_noirq(pm_message_t state);
extern int dpm_suspend_late(pm_message_t state);
extern int dpm_suspend(pm_message_t state);
extern int dpm_prepare(pm_message_t state);

extern void __suspend_report_result(const char *function, void *fn, int ret);






extern int device_pm_wait_for_dev(struct device *sub, struct device *dev);
extern void dpm_for_each_dev(void *data, void (*fn)(struct device *, void *));

extern int pm_generic_prepare(struct device *dev);
extern int pm_generic_suspend_late(struct device *dev);
extern int pm_generic_suspend_noirq(struct device *dev);
extern int pm_generic_suspend(struct device *dev);
extern int pm_generic_resume_early(struct device *dev);
extern int pm_generic_resume_noirq(struct device *dev);
extern int pm_generic_resume(struct device *dev);
extern int pm_generic_freeze_noirq(struct device *dev);
extern int pm_generic_freeze_late(struct device *dev);
extern int pm_generic_freeze(struct device *dev);
extern int pm_generic_thaw_noirq(struct device *dev);
extern int pm_generic_thaw_early(struct device *dev);
extern int pm_generic_thaw(struct device *dev);
extern int pm_generic_restore_noirq(struct device *dev);
extern int pm_generic_restore_early(struct device *dev);
extern int pm_generic_restore(struct device *dev);
extern int pm_generic_poweroff_noirq(struct device *dev);
extern int pm_generic_poweroff_late(struct device *dev);
extern int pm_generic_poweroff(struct device *dev);
extern void pm_generic_complete(struct device *dev);
# 766 "include/linux/pm.h"
enum dpm_order {
    DPM_ORDER_NONE,
    DPM_ORDER_DEV_AFTER_PARENT,
    DPM_ORDER_PARENT_BEFORE_DEV,
    DPM_ORDER_DEV_LAST,
};
# 6 "./arch/x86/include/asm/apic.h" 2






# 1 "./arch/x86/include/asm/fixmap.h" 1
# 19 "./arch/x86/include/asm/fixmap.h"
# 1 "./arch/x86/include/asm/acpi.h" 1
# 26 "./arch/x86/include/asm/acpi.h"
# 1 "include/acpi/pdc_intel.h" 1
# 27 "./arch/x86/include/asm/acpi.h" 2

# 1 "./arch/x86/include/asm/numa.h" 1





# 1 "./arch/x86/include/asm/topology.h" 1
# 51 "./arch/x86/include/asm/topology.h"
extern __attribute__((section(".data..percpu" ""))) __typeof__(int) x86_cpu_to_node_map; extern __typeof__(int) *x86_cpu_to_node_map_early_ptr; extern __typeof__(int) x86_cpu_to_node_map_early_map[];
# 65 "./arch/x86/include/asm/topology.h"
static inline __attribute__((no_instrument_function)) int early_cpu_to_node(int cpu)
{
    return *((x86_cpu_to_node_map_early_ptr) ? &(x86_cpu_to_node_map_early_ptr)[cpu] : &(*({ do { const void *__vpp_verify = (typeof((&(x86_cpu_to_node_map)) + 0))((void *)0); (void)__vpp_verify; } while (0); ({ unsigned long __ptr; __asm__ ("" : "=r"(__ptr) : "0"((typeof(*((&(x86_cpu_to_node_map)))) *)((&(x86_cpu_to_node_map))))); (typeof((typeof(*((&(x86_cpu_to_node_map)))) *)((&(x86_cpu_to_node_map))))) (__ptr + (((__per_cpu_offset[(cpu)])))); }); })));
}




extern cpumask_var_t node_to_cpumask_map[(1 << 6)];





static inline __attribute__((no_instrument_function)) const struct cpumask *cpumask_of_node(int node)
{
    return node_to_cpumask_map[node];
}


extern void setup_node_to_cpumask_map(void);
# 95 "./arch/x86/include/asm/topology.h"
extern int __node_distance(int, int);
# 118 "./arch/x86/include/asm/topology.h"
# 1 "include/asm-generic/topology.h" 1
# 119 "./arch/x86/include/asm/topology.h" 2

extern const struct cpumask *cpu_coregroup_mask(int cpu);
# 130 "./arch/x86/include/asm/topology.h"
static inline __attribute__((no_instrument_function)) void arch_fix_phys_package_id(int num, u32 slot)
{
}

struct pci_bus;
int x86_pci_root_bus_node(int bus);
void x86_pci_root_bus_resources(int bus, struct list_head *resources);
# 7 "./arch/x86/include/asm/numa.h" 2
# 20 "./arch/x86/include/asm/numa.h"
extern int numa_off;
# 30 "./arch/x86/include/asm/numa.h"
extern s16 __apicid_to_node[32768];
extern nodemask_t numa_nodes_parsed __attribute__ ((__section__(".init.data")));

extern int __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) numa_add_memblk(int nodeid, u64 start, u64 end);
extern void __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) numa_set_distance(int from, int to, int distance);

static inline __attribute__((no_instrument_function)) void set_apicid_to_node(int apicid, s16 node)
{
    __apicid_to_node[apicid] = node;
}

extern int numa_cpu_node(int cpu);
# 59 "./arch/x86/include/asm/numa.h"
extern void numa_set_node(int cpu, int node);
extern void numa_clear_node(int cpu);
extern void __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) init_cpu_to_node(void);
extern void numa_add_cpu(int cpu);
extern void numa_remove_cpu(int cpu);
# 29 "./arch/x86/include/asm/acpi.h" 2
# 1 "./arch/x86/include/asm/fixmap.h" 1
# 30 "./arch/x86/include/asm/acpi.h" 2



# 1 "./arch/x86/include/asm/realmode.h" 1




# 1 "./arch/x86/include/asm/io.h" 1
# 42 "./arch/x86/include/asm/io.h"
# 1 "arch/x86/include/generated/asm/early_ioremap.h" 1
# 1 "include/asm-generic/early_ioremap.h" 1
# 10 "include/asm-generic/early_ioremap.h"
extern void *early_ioremap(resource_size_t phys_addr,
                           unsigned long size);
extern void *early_memremap(resource_size_t phys_addr,
                            unsigned long size);
extern void early_iounmap(void *addr, unsigned long size);
extern void early_memunmap(void *addr, unsigned long size);





extern void early_ioremap_shutdown(void);



extern void early_ioremap_init(void);


extern void early_ioremap_setup(void);





extern void early_ioremap_reset(void);
# 1 "arch/x86/include/generated/asm/early_ioremap.h" 2
# 43 "./arch/x86/include/asm/io.h" 2
# 54 "./arch/x86/include/asm/io.h"
static inline __attribute__((no_instrument_function)) unsigned char readb(const volatile void *addr) { unsigned char ret; asm volatile("mov" "b" " %1,%0":"=q" (ret) :"m" (*(volatile unsigned char *)addr) :"memory"); return ret; }
static inline __attribute__((no_instrument_function)) unsigned short readw(const volatile void *addr) { unsigned short ret; asm volatile("mov" "w" " %1,%0":"=r" (ret) :"m" (*(volatile unsigned short *)addr) :"memory"); return ret; }
static inline __attribute__((no_instrument_function)) unsigned int readl(const volatile void *addr) { unsigned int ret; asm volatile("mov" "l" " %1,%0":"=r" (ret) :"m" (*(volatile unsigned int *)addr) :"memory"); return ret; }

static inline __attribute__((no_instrument_function)) unsigned char __readb(const volatile void *addr) { unsigned char ret; asm volatile("mov" "b" " %1,%0":"=q" (ret) :"m" (*(volatile unsigned char *)addr) ); return ret; }
static inline __attribute__((no_instrument_function)) unsigned short __readw(const volatile void *addr) { unsigned short ret; asm volatile("mov" "w" " %1,%0":"=r" (ret) :"m" (*(volatile unsigned short *)addr) ); return ret; }
static inline __attribute__((no_instrument_function)) unsigned int __readl(const volatile void *addr) { unsigned int ret; asm volatile("mov" "l" " %1,%0":"=r" (ret) :"m" (*(volatile unsigned int *)addr) ); return ret; }

static inline __attribute__((no_instrument_function)) void writeb(unsigned char val, volatile void *addr) { asm volatile("mov" "b" " %0,%1": :"q" (val), "m" (*(volatile unsigned char *)addr) :"memory"); }
static inline __attribute__((no_instrument_function)) void writew(unsigned short val, volatile void *addr) { asm volatile("mov" "w" " %0,%1": :"r" (val), "m" (*(volatile unsigned short *)addr) :"memory"); }
static inline __attribute__((no_instrument_function)) void writel(unsigned int val, volatile void *addr) { asm volatile("mov" "l" " %0,%1": :"r" (val), "m" (*(volatile unsigned int *)addr) :"memory"); }

static inline __attribute__((no_instrument_function)) void __writeb(unsigned char val, volatile void *addr) { asm volatile("mov" "b" " %0,%1": :"q" (val), "m" (*(volatile unsigned char *)addr) ); }
static inline __attribute__((no_instrument_function)) void __writew(unsigned short val, volatile void *addr) { asm volatile("mov" "w" " %0,%1": :"r" (val), "m" (*(volatile unsigned short *)addr) ); }
static inline __attribute__((no_instrument_function)) void __writel(unsigned int val, volatile void *addr) { asm volatile("mov" "l" " %0,%1": :"r" (val), "m" (*(volatile unsigned int *)addr) ); }
# 88 "./arch/x86/include/asm/io.h"
static inline __attribute__((no_instrument_function)) unsigned long readq(const volatile void *addr) { unsigned long ret; asm volatile("mov" "q" " %1,%0":"=r" (ret) :"m" (*(volatile unsigned long *)addr) :"memory"); return ret; }
static inline __attribute__((no_instrument_function)) void writeq(unsigned long val, volatile void *addr) { asm volatile("mov" "q" " %0,%1": :"r" (val), "m" (*(volatile unsigned long *)addr) :"memory"); }
# 116 "./arch/x86/include/asm/io.h"
static inline __attribute__((no_instrument_function)) phys_addr_t virt_to_phys(volatile void *address)
{
    return __phys_addr_nodebug((unsigned long)(address));
}
# 134 "./arch/x86/include/asm/io.h"
static inline __attribute__((no_instrument_function)) void *phys_to_virt(phys_addr_t address)
{
    return ((void *)((unsigned long)(address)+((unsigned long)(0xffff880000000000UL))));
}
# 149 "./arch/x86/include/asm/io.h"
static inline __attribute__((no_instrument_function)) unsigned int isa_virt_to_bus(volatile void *address)
{
    return (unsigned int)virt_to_phys(address);
}
# 179 "./arch/x86/include/asm/io.h"
extern void *ioremap_nocache(resource_size_t offset, unsigned long size);
extern void *ioremap_cache(resource_size_t offset, unsigned long size);
extern void *ioremap_prot(resource_size_t offset, unsigned long size,
                          unsigned long prot_val);




static inline __attribute__((no_instrument_function)) void *ioremap(resource_size_t offset, unsigned long size)
{
    return ioremap_nocache(offset, size);
}

extern void iounmap(volatile void *addr);

extern void set_iounmap_nonlazy(void);



# 1 "include/asm-generic/iomap.h" 1
# 28 "include/asm-generic/iomap.h"
extern unsigned int ioread8(void *);
extern unsigned int ioread16(void *);
extern unsigned int ioread16be(void *);
extern unsigned int ioread32(void *);
extern unsigned int ioread32be(void *);

extern void iowrite8(u8, void *);
extern void iowrite16(u16, void *);
extern void iowrite16be(u16, void *);
extern void iowrite32(u32, void *);
extern void iowrite32be(u32, void *);
# 51 "include/asm-generic/iomap.h"
extern void ioread8_rep(void *port, void *buf, unsigned long count);
extern void ioread16_rep(void *port, void *buf, unsigned long count);
extern void ioread32_rep(void *port, void *buf, unsigned long count);

extern void iowrite8_rep(void *port, const void *buf, unsigned long count);
extern void iowrite16_rep(void *port, const void *buf, unsigned long count);
extern void iowrite32_rep(void *port, const void *buf, unsigned long count);



extern void *ioport_map(unsigned long port, unsigned int nr);
extern void ioport_unmap(void *);
# 71 "include/asm-generic/iomap.h"
struct pci_dev;
extern void pci_iounmap(struct pci_dev *dev, void *);






# 1 "include/asm-generic/pci_iomap.h" 1
# 14 "include/asm-generic/pci_iomap.h"
struct pci_dev;


extern void *pci_iomap(struct pci_dev *dev, int bar, unsigned long max);
extern void *pci_iomap_range(struct pci_dev *dev, int bar,
                             unsigned long offset,
                             unsigned long maxlen);
# 80 "include/asm-generic/iomap.h" 2
# 199 "./arch/x86/include/asm/io.h" 2

# 1 "include/linux/vmalloc.h" 1
# 10 "include/linux/vmalloc.h"
struct vm_area_struct;
# 31 "include/linux/vmalloc.h"
struct vm_struct {
    struct vm_struct *next;
    void *addr;
    unsigned long size;
    unsigned long flags;
    struct page **pages;
    unsigned int nr_pages;
    phys_addr_t phys_addr;
    const void *caller;
};

struct vmap_area {
    unsigned long va_start;
    unsigned long va_end;
    unsigned long flags;
    struct rb_node rb_node;
    struct list_head list;
    struct list_head purge_list;
    struct vm_struct *vm;
    struct callback_head callback_head;
};




extern void vm_unmap_ram(const void *mem, unsigned int count);
extern void *vm_map_ram(struct page **pages, unsigned int count,
                        int node, pgprot_t prot);
extern void vm_unmap_aliases(void);


extern void __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) vmalloc_init(void);






extern void *vmalloc(unsigned long size);
extern void *vzalloc(unsigned long size);
extern void *vmalloc_user(unsigned long size);
extern void *vmalloc_node(unsigned long size, int node);
extern void *vzalloc_node(unsigned long size, int node);
extern void *vmalloc_exec(unsigned long size);
extern void *vmalloc_32(unsigned long size);
extern void *vmalloc_32_user(unsigned long size);
extern void *__vmalloc(unsigned long size, gfp_t gfp_mask, pgprot_t prot);
extern void *__vmalloc_node_range(unsigned long size, unsigned long align,
                                  unsigned long start, unsigned long end, gfp_t gfp_mask,
                                  pgprot_t prot, unsigned long vm_flags, int node,
                                  const void *caller);

extern void vfree(const void *addr);

extern void *vmap(struct page **pages, unsigned int count,
                  unsigned long flags, pgprot_t prot);
extern void vunmap(const void *addr);

extern int remap_vmalloc_range_partial(struct vm_area_struct *vma,
                                       unsigned long uaddr, void *kaddr,
                                       unsigned long size);

extern int remap_vmalloc_range(struct vm_area_struct *vma, void *addr,
                               unsigned long pgoff);
void vmalloc_sync_all(void);





static inline __attribute__((no_instrument_function)) size_t get_vm_area_size(const struct vm_struct *area)
{
    if (!(area->flags & 0x00000040))

        return area->size - ((1UL) << 12);
    else
        return area->size;

}

extern struct vm_struct *get_vm_area(unsigned long size, unsigned long flags);
extern struct vm_struct *get_vm_area_caller(unsigned long size,
                                            unsigned long flags, const void *caller);
extern struct vm_struct *__get_vm_area(unsigned long size, unsigned long flags,
                                       unsigned long start, unsigned long end);
extern struct vm_struct *__get_vm_area_caller(unsigned long size,
                                              unsigned long flags,
                                              unsigned long start, unsigned long end,
                                              const void *caller);
extern struct vm_struct *remove_vm_area(const void *addr);
extern struct vm_struct *find_vm_area(const void *addr);

extern int map_vm_area(struct vm_struct *area, pgprot_t prot,
                       struct page **pages);

extern int map_kernel_range_noflush(unsigned long start, unsigned long size,
                                    pgprot_t prot, struct page **pages);
extern void unmap_kernel_range_noflush(unsigned long addr, unsigned long size);
extern void unmap_kernel_range(unsigned long addr, unsigned long size);
# 148 "include/linux/vmalloc.h"
extern struct vm_struct *alloc_vm_area(size_t size, pte_t **ptes);
extern void free_vm_area(struct vm_struct *area);


extern long vread(char *buf, char *addr, unsigned long count);
extern long vwrite(char *buf, char *addr, unsigned long count);




extern struct list_head vmap_area_list;
extern __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) void vm_area_add_early(struct vm_struct *vm);
extern __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) void vm_area_register_early(struct vm_struct *vm, size_t align);



struct vm_struct **pcpu_get_vm_areas(const unsigned long *offsets,
                                     const size_t *sizes, int nr_vms,
                                     size_t align);

void pcpu_free_vm_areas(struct vm_struct **vms, int nr_vms);
# 185 "include/linux/vmalloc.h"
struct vmalloc_info {
    unsigned long used;
    unsigned long largest_chunk;
};



extern void get_vmalloc_info(struct vmalloc_info *vmi);
# 201 "./arch/x86/include/asm/io.h" 2






static inline __attribute__((no_instrument_function)) void
memset_io(volatile void *addr, unsigned char val, size_t count)
{
    memset((void *)addr, val, count);
}

static inline __attribute__((no_instrument_function)) void
memcpy_fromio(void *dst, const volatile void *src, size_t count)
{
    memcpy(dst, (const void *)src, count);
}

static inline __attribute__((no_instrument_function)) void
memcpy_toio(volatile void *dst, const void *src, size_t count)
{
    memcpy((void *)dst, src, count);
}
# 243 "./arch/x86/include/asm/io.h"
static inline __attribute__((no_instrument_function)) void flush_write_buffers(void)
{



}



extern void native_io_delay(void);

extern int io_delay_type;
extern void io_delay_init(void);





static inline __attribute__((no_instrument_function)) void slow_down_io(void)
{
    native_io_delay();





}
# 313 "./arch/x86/include/asm/io.h"
static inline __attribute__((no_instrument_function)) void outb(unsigned char value, int port) { asm volatile("out" "b" " %" "b" "0, %w1" : : "a"(value), "Nd"(port)); } static inline __attribute__((no_instrument_function)) unsigned char inb(int port) { unsigned char value; asm volatile("in" "b" " %w1, %" "b" "0" : "=a"(value) : "Nd"(port)); return value; } static inline __attribute__((no_instrument_function)) void outb_p(unsigned char value, int port) { outb(value, port); slow_down_io(); } static inline __attribute__((no_instrument_function)) unsigned char inb_p(int port) { unsigned char value = inb(port); slow_down_io(); return value; } static inline __attribute__((no_instrument_function)) void outsb(int port, const void *addr, unsigned long count) { asm volatile("rep; outs" "b" : "+S"(addr), "+c"(count) : "d"(port)); } static inline __attribute__((no_instrument_function)) void insb(int port, void *addr, unsigned long count) { asm volatile("rep; ins" "b" : "+D"(addr), "+c"(count) : "d"(port)); }
static inline __attribute__((no_instrument_function)) void outw(unsigned short value, int port) { asm volatile("out" "w" " %" "w" "0, %w1" : : "a"(value), "Nd"(port)); } static inline __attribute__((no_instrument_function)) unsigned short inw(int port) { unsigned short value; asm volatile("in" "w" " %w1, %" "w" "0" : "=a"(value) : "Nd"(port)); return value; } static inline __attribute__((no_instrument_function)) void outw_p(unsigned short value, int port) { outw(value, port); slow_down_io(); } static inline __attribute__((no_instrument_function)) unsigned short inw_p(int port) { unsigned short value = inw(port); slow_down_io(); return value; } static inline __attribute__((no_instrument_function)) void outsw(int port, const void *addr, unsigned long count) { asm volatile("rep; outs" "w" : "+S"(addr), "+c"(count) : "d"(port)); } static inline __attribute__((no_instrument_function)) void insw(int port, void *addr, unsigned long count) { asm volatile("rep; ins" "w" : "+D"(addr), "+c"(count) : "d"(port)); }
static inline __attribute__((no_instrument_function)) void outl(unsigned int value, int port) { asm volatile("out" "l" " %" "" "0, %w1" : : "a"(value), "Nd"(port)); } static inline __attribute__((no_instrument_function)) unsigned int inl(int port) { unsigned int value; asm volatile("in" "l" " %w1, %" "" "0" : "=a"(value) : "Nd"(port)); return value; } static inline __attribute__((no_instrument_function)) void outl_p(unsigned int value, int port) { outl(value, port); slow_down_io(); } static inline __attribute__((no_instrument_function)) unsigned int inl_p(int port) { unsigned int value = inl(port); slow_down_io(); return value; } static inline __attribute__((no_instrument_function)) void outsl(int port, const void *addr, unsigned long count) { asm volatile("rep; outs" "l" : "+S"(addr), "+c"(count) : "d"(port)); } static inline __attribute__((no_instrument_function)) void insl(int port, void *addr, unsigned long count) { asm volatile("rep; ins" "l" : "+D"(addr), "+c"(count) : "d"(port)); }

extern void *xlate_dev_mem_ptr(phys_addr_t phys);
extern void unxlate_dev_mem_ptr(phys_addr_t phys, void *addr);

extern int ioremap_change_attr(unsigned long vaddr, unsigned long size,
                               enum page_cache_mode pcm);
extern void *ioremap_wc(resource_size_t offset, unsigned long size);

extern bool is_early_ioremap_ptep(pte_t *ptep);
# 341 "./arch/x86/include/asm/io.h"
extern int __attribute__((warn_unused_result)) arch_phys_wc_add(unsigned long base,
                                                                unsigned long size);
extern void arch_phys_wc_del(int handle);
# 6 "./arch/x86/include/asm/realmode.h" 2


struct real_mode_header {
    u32 text_start;
    u32 ro_end;

    u32 trampoline_start;
    u32 trampoline_status;
    u32 trampoline_header;

    u32 trampoline_pgd;



    u32 wakeup_start;
    u32 wakeup_header;


    u32 machine_real_restart_asm;

    u32 machine_real_restart_seg;

};


struct trampoline_header {






    u64 start;
    u64 efer;
    u32 cr4;

};

extern struct real_mode_header *real_mode_header;
extern unsigned char real_mode_blob_end[];

extern unsigned long init_rsp;
extern unsigned long initial_code;
extern unsigned long initial_gs;

extern unsigned char real_mode_blob[];
extern unsigned char real_mode_relocs[];





extern unsigned char secondary_startup_64[];


void reserve_real_mode(void);
void setup_real_mode(void);
# 34 "./arch/x86/include/asm/acpi.h" 2


extern int acpi_lapic;
extern int acpi_ioapic;
extern int acpi_noirq;
extern int acpi_strict;
extern int acpi_disabled;
extern int acpi_pci_disabled;
extern int acpi_skip_timer_override;
extern int acpi_use_timer_override;
extern int acpi_fix_pin2_polarity;
extern int acpi_disable_cmcff;

extern u8 acpi_sci_flags;
extern int acpi_sci_override_gsi;
void acpi_pic_sci_set_trigger(unsigned int, u16);

extern int (*__acpi_register_gsi)(struct device *dev, u32 gsi,
                                  int trigger, int polarity);
extern void (*__acpi_unregister_gsi)(u32 gsi);

static inline __attribute__((no_instrument_function)) void disable_acpi(void)
{
    acpi_disabled = 1;
    acpi_pci_disabled = 1;
    acpi_noirq = 1;
}

extern int acpi_gsi_to_irq(u32 gsi, unsigned int *irq);

static inline __attribute__((no_instrument_function)) void acpi_noirq_set(void) { acpi_noirq = 1; }
static inline __attribute__((no_instrument_function)) void acpi_disable_pci(void)
{
    acpi_pci_disabled = 1;
    acpi_noirq_set();
}


extern int (*acpi_suspend_lowlevel)(void);







static inline __attribute__((no_instrument_function)) unsigned int acpi_processor_cstate_check(unsigned int max_cstate)
{






    if (boot_cpu_data.x86 == 0x0F &&
        boot_cpu_data.x86_vendor == 2 &&
        boot_cpu_data.x86_model <= 0x05 &&
        boot_cpu_data.x86_mask < 0x0A)
        return 1;
    else if (amd_e400_c1e_detected)
        return 1;
    else
        return max_cstate;
}

static inline __attribute__((no_instrument_function)) bool arch_has_acpi_pdc(void)
{
    struct cpuinfo_x86 *c = &(*({ do { const void *__vpp_verify = (typeof((&(cpu_info)) + 0))((void *)0); (void)__vpp_verify; } while (0); ({ unsigned long __ptr; __asm__ ("" : "=r"(__ptr) : "0"((typeof(*((&(cpu_info)))) *)((&(cpu_info))))); (typeof((typeof(*((&(cpu_info)))) *)((&(cpu_info))))) (__ptr + (((__per_cpu_offset[(0)])))); }); }));
    return (c->x86_vendor == 0 ||
            c->x86_vendor == 5);
}

static inline __attribute__((no_instrument_function)) void arch_acpi_set_pdc_bits(u32 *buf)
{
    struct cpuinfo_x86 *c = &(*({ do { const void *__vpp_verify = (typeof((&(cpu_info)) + 0))((void *)0); (void)__vpp_verify; } while (0); ({ unsigned long __ptr; __asm__ ("" : "=r"(__ptr) : "0"((typeof(*((&(cpu_info)))) *)((&(cpu_info))))); (typeof((typeof(*((&(cpu_info)))) *)((&(cpu_info))))) (__ptr + (((__per_cpu_offset[(0)])))); }); }));

    buf[2] |= ((0x0010) | (0x0008) | (0x0002) | (0x0100) | (0x0200));

    if ((__builtin_constant_p(( 4*32+ 7)) && ( (((( 4*32+ 7))>>5)==0 && (1UL<<((( 4*32+ 7))&31) & ((1<<(( 0*32+ 0) & 31))|(1<<(( 0*32+ 3)) & 31)|(1<<(( 0*32+ 5) & 31))|(1<<(( 0*32+ 6) & 31))| (1<<(( 0*32+ 8) & 31))|(1<<(( 0*32+13)) & 31)|(1<<(( 0*32+24) & 31))|(1<<(( 0*32+15) & 31))| (1<<(( 0*32+25) & 31))|(1<<(( 0*32+26) & 31))))) || (((( 4*32+ 7))>>5)==1 && (1UL<<((( 4*32+ 7))&31) & ((1<<(( 1*32+29) & 31))|0))) || (((( 4*32+ 7))>>5)==2 && (1UL<<((( 4*32+ 7))&31) & 0)) || (((( 4*32+ 7))>>5)==3 && (1UL<<((( 4*32+ 7))&31) & ((1<<(( 3*32+20) & 31))))) || (((( 4*32+ 7))>>5)==4 && (1UL<<((( 4*32+ 7))&31) & (0))) || (((( 4*32+ 7))>>5)==5 && (1UL<<((( 4*32+ 7))&31) & 0)) || (((( 4*32+ 7))>>5)==6 && (1UL<<((( 4*32+ 7))&31) & 0)) || (((( 4*32+ 7))>>5)==7 && (1UL<<((( 4*32+ 7))&31) & 0)) || (((( 4*32+ 7))>>5)==8 && (1UL<<((( 4*32+ 7))&31) & 0)) || (((( 4*32+ 7))>>5)==9 && (1UL<<((( 4*32+ 7))&31) & 0)) ) ? 1 : (__builtin_constant_p((( 4*32+ 7))) ? constant_test_bit((( 4*32+ 7)), ((unsigned long *)((c)->x86_capability))) : variable_test_bit((( 4*32+ 7)), ((unsigned long *)((c)->x86_capability))))))
        buf[2] |= ((0x0008) | (0x0002) | (0x0020) | (0x0800) | (0x0001));

    if ((__builtin_constant_p(( 0*32+22)) && ( (((( 0*32+22))>>5)==0 && (1UL<<((( 0*32+22))&31) & ((1<<(( 0*32+ 0) & 31))|(1<<(( 0*32+ 3)) & 31)|(1<<(( 0*32+ 5) & 31))|(1<<(( 0*32+ 6) & 31))| (1<<(( 0*32+ 8) & 31))|(1<<(( 0*32+13)) & 31)|(1<<(( 0*32+24) & 31))|(1<<(( 0*32+15) & 31))| (1<<(( 0*32+25) & 31))|(1<<(( 0*32+26) & 31))))) || (((( 0*32+22))>>5)==1 && (1UL<<((( 0*32+22))&31) & ((1<<(( 1*32+29) & 31))|0))) || (((( 0*32+22))>>5)==2 && (1UL<<((( 0*32+22))&31) & 0)) || (((( 0*32+22))>>5)==3 && (1UL<<((( 0*32+22))&31) & ((1<<(( 3*32+20) & 31))))) || (((( 0*32+22))>>5)==4 && (1UL<<((( 0*32+22))&31) & (0))) || (((( 0*32+22))>>5)==5 && (1UL<<((( 0*32+22))&31) & 0)) || (((( 0*32+22))>>5)==6 && (1UL<<((( 0*32+22))&31) & 0)) || (((( 0*32+22))>>5)==7 && (1UL<<((( 0*32+22))&31) & 0)) || (((( 0*32+22))>>5)==8 && (1UL<<((( 0*32+22))&31) & 0)) || (((( 0*32+22))>>5)==9 && (1UL<<((( 0*32+22))&31) & 0)) ) ? 1 : (__builtin_constant_p((( 0*32+22))) ? constant_test_bit((( 0*32+22)), ((unsigned long *)((c)->x86_capability))) : variable_test_bit((( 0*32+22)), ((unsigned long *)((c)->x86_capability))))))
        buf[2] |= (0x0004);




    if (!(__builtin_constant_p(( 4*32+ 3)) && ( (((( 4*32+ 3))>>5)==0 && (1UL<<((( 4*32+ 3))&31) & ((1<<(( 0*32+ 0) & 31))|(1<<(( 0*32+ 3)) & 31)|(1<<(( 0*32+ 5) & 31))|(1<<(( 0*32+ 6) & 31))| (1<<(( 0*32+ 8) & 31))|(1<<(( 0*32+13)) & 31)|(1<<(( 0*32+24) & 31))|(1<<(( 0*32+15) & 31))| (1<<(( 0*32+25) & 31))|(1<<(( 0*32+26) & 31))))) || (((( 4*32+ 3))>>5)==1 && (1UL<<((( 4*32+ 3))&31) & ((1<<(( 1*32+29) & 31))|0))) || (((( 4*32+ 3))>>5)==2 && (1UL<<((( 4*32+ 3))&31) & 0)) || (((( 4*32+ 3))>>5)==3 && (1UL<<((( 4*32+ 3))&31) & ((1<<(( 3*32+20) & 31))))) || (((( 4*32+ 3))>>5)==4 && (1UL<<((( 4*32+ 3))&31) & (0))) || (((( 4*32+ 3))>>5)==5 && (1UL<<((( 4*32+ 3))&31) & 0)) || (((( 4*32+ 3))>>5)==6 && (1UL<<((( 4*32+ 3))&31) & 0)) || (((( 4*32+ 3))>>5)==7 && (1UL<<((( 4*32+ 3))&31) & 0)) || (((( 4*32+ 3))>>5)==8 && (1UL<<((( 4*32+ 3))&31) & 0)) || (((( 4*32+ 3))>>5)==9 && (1UL<<((( 4*32+ 3))&31) & 0)) ) ? 1 : (__builtin_constant_p((( 4*32+ 3))) ? constant_test_bit((( 4*32+ 3)), ((unsigned long *)((c)->x86_capability))) : variable_test_bit((( 4*32+ 3)), ((unsigned long *)((c)->x86_capability))))))
        buf[2] &= ~((0x0200));
}

static inline __attribute__((no_instrument_function)) bool acpi_has_cpu_in_madt(void)
{
    return !!acpi_lapic;
}
# 144 "./arch/x86/include/asm/acpi.h"
extern int acpi_numa;
extern int x86_acpi_numa_init(void);
# 20 "./arch/x86/include/asm/fixmap.h" 2


# 1 "./arch/x86/include/asm/pvclock.h" 1



# 1 "include/linux/clocksource.h" 1
# 21 "include/linux/clocksource.h"
struct clocksource;
struct module;


# 1 "./arch/x86/include/asm/clocksource.h" 1
# 11 "./arch/x86/include/asm/clocksource.h"
struct arch_clocksource_data {
    int vclock_mode;
};
# 26 "include/linux/clocksource.h" 2
# 66 "include/linux/clocksource.h"
struct clocksource {




    cycle_t (*read)(struct clocksource *cs);
    cycle_t mask;
    u32 mult;
    u32 shift;
    u64 max_idle_ns;
    u32 maxadj;

    struct arch_clocksource_data archdata;

    u64 max_cycles;
    const char *name;
    struct list_head list;
    int rating;
    int (*enable)(struct clocksource *cs);
    void (*disable)(struct clocksource *cs);
    unsigned long flags;
    void (*suspend)(struct clocksource *cs);
    void (*resume)(struct clocksource *cs);




    struct list_head wd_list;
    cycle_t cs_last;
    cycle_t wd_last;

    struct module *owner;
} __attribute__((__aligned__((1 << (6)))));
# 123 "include/linux/clocksource.h"
static inline __attribute__((no_instrument_function)) u32 clocksource_khz2mult(u32 khz, u32 shift_constant)
{







    u64 tmp = ((u64)1000000) << shift_constant;

    tmp += khz/2;
    ({ uint32_t __base = (khz); uint32_t __rem; __rem = ((uint64_t)(tmp)) % __base; (tmp) = ((uint64_t)(tmp)) / __base; __rem; });

    return (u32)tmp;
}
# 149 "include/linux/clocksource.h"
static inline __attribute__((no_instrument_function)) u32 clocksource_hz2mult(u32 hz, u32 shift_constant)
{







    u64 tmp = ((u64)1000000000) << shift_constant;

    tmp += hz/2;
    ({ uint32_t __base = (hz); uint32_t __rem; __rem = ((uint64_t)(tmp)) % __base; (tmp) = ((uint64_t)(tmp)) / __base; __rem; });

    return (u32)tmp;
}
# 176 "include/linux/clocksource.h"
static inline __attribute__((no_instrument_function)) s64 clocksource_cyc2ns(cycle_t cycles, u32 mult, u32 shift)
{
    return ((u64) cycles * mult) >> shift;
}


extern int clocksource_unregister(struct clocksource*);
extern void clocksource_touch_watchdog(void);
extern struct clocksource* clocksource_get_next(void);
extern void clocksource_change_rating(struct clocksource *cs, int rating);
extern void clocksource_suspend(void);
extern void clocksource_resume(void);
extern struct clocksource * __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) clocksource_default_clock(void);
extern void clocksource_mark_unstable(struct clocksource *cs);

extern u64
clocks_calc_max_nsecs(u32 mult, u32 shift, u32 maxadj, u64 mask, u64 *max_cycles);
extern void
clocks_calc_mult_shift(u32 *mult, u32 *shift, u32 from, u32 to, u32 minsec);





extern int
__clocksource_register_scale(struct clocksource *cs, u32 scale, u32 freq);
extern void
__clocksource_update_freq_scale(struct clocksource *cs, u32 scale, u32 freq);





static inline __attribute__((no_instrument_function)) int __clocksource_register(struct clocksource *cs)
{
    return __clocksource_register_scale(cs, 1, 0);
}

static inline __attribute__((no_instrument_function)) int clocksource_register_hz(struct clocksource *cs, u32 hz)
{
    return __clocksource_register_scale(cs, 1, hz);
}

static inline __attribute__((no_instrument_function)) int clocksource_register_khz(struct clocksource *cs, u32 khz)
{
    return __clocksource_register_scale(cs, 1000, khz);
}

static inline __attribute__((no_instrument_function)) void __clocksource_update_freq_hz(struct clocksource *cs, u32 hz)
{
    __clocksource_update_freq_scale(cs, 1, hz);
}

static inline __attribute__((no_instrument_function)) void __clocksource_update_freq_khz(struct clocksource *cs, u32 khz)
{
    __clocksource_update_freq_scale(cs, 1000, khz);
}


extern int timekeeping_notify(struct clocksource *clock);

extern cycle_t clocksource_mmio_readl_up(struct clocksource *);
extern cycle_t clocksource_mmio_readl_down(struct clocksource *);
extern cycle_t clocksource_mmio_readw_up(struct clocksource *);
extern cycle_t clocksource_mmio_readw_down(struct clocksource *);

extern int clocksource_mmio_init(void *, const char *,
                                 unsigned long, int, unsigned, cycle_t (*)(struct clocksource *));

extern int clocksource_i8253_init(void);







static inline __attribute__((no_instrument_function)) void clocksource_of_init(void) {}



void acpi_generic_timer_init(void);
# 5 "./arch/x86/include/asm/pvclock.h" 2
# 1 "./arch/x86/include/asm/pvclock-abi.h" 1
# 25 "./arch/x86/include/asm/pvclock-abi.h"
struct pvclock_vcpu_time_info {
    u32 version;
    u32 pad0;
    u64 tsc_timestamp;
    u64 system_time;
    u32 tsc_to_system_mul;
    s8 tsc_shift;
    u8 flags;
    u8 pad[2];
} __attribute__((__packed__));

struct pvclock_wall_clock {
    u32 version;
    u32 sec;
    u32 nsec;
} __attribute__((__packed__));
# 6 "./arch/x86/include/asm/pvclock.h" 2


cycle_t pvclock_clocksource_read(struct pvclock_vcpu_time_info *src);
u8 pvclock_read_flags(struct pvclock_vcpu_time_info *src);
void pvclock_set_flags(u8 flags);
unsigned long pvclock_tsc_khz(struct pvclock_vcpu_time_info *src);
void pvclock_read_wallclock(struct pvclock_wall_clock *wall,
                            struct pvclock_vcpu_time_info *vcpu,
                            struct timespec *ts);
void pvclock_resume(void);

void pvclock_touch_watchdogs(void);





static inline __attribute__((no_instrument_function)) u64 pvclock_scale_delta(u64 delta, u32 mul_frac, int shift)
{
    u64 product;



    ulong tmp;


    if (shift < 0)
        delta >>= -shift;
    else
        delta <<= shift;
# 49 "./arch/x86/include/asm/pvclock.h"
    __asm__ (
            "mulq %[mul_frac] ; shrd $32, %[hi], %[lo]"
            : [lo]"=a"(product),
    [hi]"=d"(tmp)
    : "0"(delta),
    [mul_frac]"rm"((u64)mul_frac));




    return product;
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline))
u64 pvclock_get_nsec_offset(const struct pvclock_vcpu_time_info *src)
{
    u64 delta = __native_read_tsc() - src->tsc_timestamp;
    return pvclock_scale_delta(delta, src->tsc_to_system_mul,
                               src->tsc_shift);
}

static inline __attribute__((no_instrument_function)) __attribute__((always_inline))
unsigned __pvclock_read_cycles(const struct pvclock_vcpu_time_info *src,
                               cycle_t *cycles, u8 *flags)
{
    unsigned version;
    cycle_t ret, offset;
    u8 ret_flags;

    version = src->version;






    rdtsc_barrier();
    offset = pvclock_get_nsec_offset(src);
    ret = src->system_time + offset;
    ret_flags = src->flags;
    rdtsc_barrier();

    *cycles = ret;
    *flags = ret_flags;
    return version;
}

struct pvclock_vsyscall_time_info {
    struct pvclock_vcpu_time_info pvti;
} __attribute__((__aligned__((1 << (6)))));




int __attribute__ ((__section__(".init.text"))) __attribute__((__cold__)) __attribute__((no_instrument_function)) pvclock_init_vsyscall(struct pvclock_vsyscall_time_info *i,
                                                                                                                                        int size);
struct pvclock_vcpu_time_info *pvclock_get_vsyscall_time_info(int cpu);
# 23 "./arch/x86/include/asm/fixmap.h" 2




# 1 "./arch/x86/include/uapi/asm/vsyscall.h" 1



enum vsyscall_num {
    __NR_vgettimeofday,
    __NR_vtime,
    __NR_vgetcpu,
};
# 28 "./arch/x86/include/asm/fixmap.h" 2
# 68 "./arch/x86/include/asm/fixmap.h"
enum fixed_addresses {




    VSYSCALL_PAGE = (((((((-10UL << 20) + ((1UL) << 12))-1) | ((__typeof__((-10UL << 20) + ((1UL) << 12)))((1<<21)-1)))+1) - ((1UL) << 12)) - (-10UL << 20)) >> 12,






    FIX_DBGP_BASE,
    FIX_EARLYCON_MEM_BASE,

    FIX_OHCI1394_BASE,


    FIX_APIC_BASE,


    FIX_IO_APIC_BASE_0,
    FIX_IO_APIC_BASE_END = FIX_IO_APIC_BASE_0 + 128 - 1,

    FIX_RO_IDT,
# 103 "./arch/x86/include/asm/fixmap.h"
    FIX_TEXT_POKE1,
    FIX_TEXT_POKE0,



    __end_of_permanent_fixed_addresses,
# 120 "./arch/x86/include/asm/fixmap.h"
    FIX_BTMAP_END =
    (__end_of_permanent_fixed_addresses ^
     (__end_of_permanent_fixed_addresses + (64 * 8) - 1)) &
    -512
    ? __end_of_permanent_fixed_addresses + (64 * 8) -
      (__end_of_permanent_fixed_addresses & ((64 * 8) - 1))
    : __end_of_permanent_fixed_addresses,
    FIX_BTMAP_BEGIN = FIX_BTMAP_END + (64 * 8) - 1,






    __end_of_fixed_addresses
};


extern void reserve_top_address(unsigned long reserve);




extern int fixmaps_set;

extern pte_t *kmap_pte;
extern pgprot_t kmap_prot;
extern pte_t *pkmap_page_table;

void __native_set_fixmap(enum fixed_addresses idx, pte_t pte);
void native_set_fixmap(enum fixed_addresses idx,
                       phys_addr_t phys, pgprot_t flags);


static inline __attribute__((no_instrument_function)) void __set_fixmap(enum fixed_addresses idx,
                                                                        phys_addr_t phys, pgprot_t flags)
{
    native_set_fixmap(idx, phys, flags);
}


# 1 "include/asm-generic/fixmap.h" 1
# 29 "include/asm-generic/fixmap.h"
static inline __attribute__((no_instrument_function)) __attribute__((always_inline)) unsigned long fix_to_virt(const unsigned int idx)
{
    do { bool __cond = !(!(idx >= __end_of_fixed_addresses)); extern void __compiletime_assert_31(void) __attribute__((error("BUILD_BUG_ON failed: " "idx >= __end_of_fixed_addresses"))); if (__cond) __compiletime_assert_31(); do { } while (0); } while (0);
    return (((((((-10UL << 20) + ((1UL) << 12))-1) | ((__typeof__((-10UL << 20) + ((1UL) << 12)))((1<<21)-1)))+1) - ((1UL) << 12)) - ((idx) << 12));
}

static inline __attribute__((no_instrument_function)) unsigned long virt_to_fix(const unsigned long vaddr)
{
    do { if (__builtin_expect(!!(vaddr >= ((((((-10UL << 20) + ((1UL) << 12))-1) | ((__typeof__((-10UL << 20) + ((1UL) << 12)))((1<<21)-1)))+1) - ((1UL) << 12)) || vaddr < (((((((-10UL << 20) + ((1UL) << 12))-1) | ((__typeof__((-10UL << 20) + ((1UL) << 12)))((1<<21)-1)))+1) - ((1UL) << 12)) - (__end_of_permanent_fixed_addresses << 12))), 0)) do { asm volatile("1:\tud2\n" ".pushsection __bug_table,\"a\"\n" "2:\t.long 1b - 2b, %c0 - 2b\n" "\t.word %c1, 0\n" "\t.org 2b+%c2\n" ".popsection" : : "i" ("include/asm-generic/fixmap.h"), "i" (37), "i" (sizeof(struct bug_entry))); __builtin_unreachable(); } while (0); } while (0);
    return ((((((((-10UL << 20) + ((1UL) << 12))-1) | ((__typeof__((-10UL << 20) + ((1UL) << 12)))((1<<21)-1)))+1) - ((1UL) << 12)) - ((vaddr)&(~(((1UL) << 12)-1)))) >> 12);
}
# 162 "./arch/x86/include/asm/fixmap.h" 2




void __early_set_fixmap(enum fixed_addresses idx,
                        phys_addr_t phys, pgprot_t flags);
# 13 "./arch/x86/include/asm/apic.h" 2


# 1 "./arch/x86/include/asm/idle.h" 1






struct notifier_block;
void idle_notifier_register(struct notifier_block *n);
void idle_notifier_unregister(struct notifier_block *n);


void enter_idle(void);
void exit_idle(void);






void amd_e400_remove_cpu(int cpu);
# 16 "./arch/x86/include/asm/apic.h" 2
# 41 "./arch/x86/include/asm/apic.h"
static inline __attribute__((no_instrument_function)) void generic_apic_probe(void)
{
}




extern unsigned int apic_verbosity;
extern int local_apic_timer_c2_ok;

extern int disable_apic;
extern unsigned int lapic_timer_frequency;


extern void __inquire_remote_apic(int apicid);






static inline __attribute__((no_instrument_function)) void default_inquire_remote_apic(int apicid)
{
    if (apic_verbosity >= 2)
        __inquire_remote_apic(apicid);
}
# 76 "./arch/x86/include/asm/apic.h"
static inline __attribute__((no_instrument_function)) bool apic_from_smp_config(void)
{
    return smp_found_config && !disable_apic;
}
# 88 "./arch/x86/include/asm/apic.h"
extern int setup_profiling_timer(unsigned int);

static inline __attribute__((no_instrument_function)) void native_apic_mem_write(u32 reg, u32 v)
{
    volatile u32 *addr = (volatile u32 *)((fix_to_virt(FIX_APIC_BASE)) + reg);

    asm volatile ("661:\n\t" "movl %0, %P1" "\n662:\n" ".skip -(((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")) > 0) * " "((" "665""1""f-""664""1""f" ")-(" "662b-661b" ")),0x90\n" "663" ":\n" ".pushsection .altinstructions,\"a\"\n" " .long 661b - .\n" " .long " "664""1""f - .\n" " .word " "(13*32 + (5))" "\n" " .byte " "663""b-661b" "\n" " .byte " "665""1""f-""664""1""f" "\n" " .byte " "663""b-662b" "\n" ".popsection\n" ".pushsection .altinstr_replacement, \"ax\"\n" "664""1"":\n\t" "xchgl %0, %P1" "\n" "665""1" ":\n\t" ".popsection" : "=r" (v), "=m" (*addr) : "i" (0), "0" (v), "m" (*addr))

            ;
}

static inline __attribute__((no_instrument_function)) u32 native_apic_mem_read(u32 reg)
{
    return *((volatile u32 *)((fix_to_virt(FIX_APIC_BASE)) + reg));
}

extern void native_apic_wait_icr_idle(void);
extern u32 native_safe_apic_wait_icr_idle(void);
extern void native_apic_icr_write(u32 low, u32 id);
extern u64 native_apic_icr_read(void);

static inline __attribute__((no_instrument_function)) bool apic_is_x2apic_enabled(void)
{
    u64 msr;

    if (rdmsrl_safe(0x0000001b, &msr))
        return false;
    return msr & (1UL << 10);
}
# 190 "./arch/x86/include/asm/apic.h"
static inline __attribute__((no_instrument_function)) void check_x2apic(void) { }
static inline __attribute__((no_instrument_function)) void x2apic_setup(void) { }
static inline __attribute__((no_instrument_function)) int x2apic_enabled(void) { return 0; }





extern void enable_IR_x2apic(void);

extern int get_physical_broadcast(void);

extern int lapic_get_maxlvt(void);
extern void clear_local_APIC(void);
extern void disconnect_bsp_APIC(int virt_wire_setup);
extern void disable_local_APIC(void);
extern void lapic_shutdown(void);
extern void sync_Arb_IDs(void);
extern void init_bsp_APIC(void);
extern void setup_local_APIC(void);
extern void init_apic_mappings(void);
void register_lapic_address(unsigned long address);
extern void setup_boot_APIC_clock(void);
extern void setup_secondary_APIC_clock(void);
extern int APIC_init_uniprocessor(void);


static inline __attribute__((no_instrument_function)) int apic_force_enable(unsigned long addr)
{
    return -1;
}




extern int apic_bsp_setup(bool upmode);
extern void apic_ap_setup(void);





extern int apic_is_clustered_box(void);







extern int setup_APIC_eilvt(u8 lvt_off, u8 vector, u8 msg_type, u8 mask);
# 267 "./arch/x86/include/asm/apic.h"
struct apic {
    char *name;

    int (*probe)(void);
    int (*acpi_madt_oem_check)(char *oem_id, char *oem_table_id);
    int (*apic_id_valid)(int apicid);
    int (*apic_id_registered)(void);

    u32 irq_delivery_mode;
    u32 irq_dest_mode;

    const struct cpumask *(*target_cpus)(void);

    int disable_esr;

    int dest_logical;
    unsigned long (*check_apicid_used)(physid_mask_t *map, int apicid);

    void (*vector_allocation_domain)(int cpu, struct cpumask *retmask,
                                     const struct cpumask *mask);
    void (*init_apic_ldr)(void);

    void (*ioapic_phys_id_map)(physid_mask_t *phys_map, physid_mask_t *retmap);

    void (*setup_apic_routing)(void);
    int (*cpu_present_to_apicid)(int mps_cpu);
    void (*apicid_to_cpu_present)(int phys_apicid, physid_mask_t *retmap);
    int (*check_phys_apicid_present)(int phys_apicid);
    int (*phys_pkg_id)(int cpuid_apic, int index_msb);

    unsigned int (*get_apic_id)(unsigned long x
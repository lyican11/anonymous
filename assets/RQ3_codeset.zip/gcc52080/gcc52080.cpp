struct x {
    long a;
    unsigned int lock;
    unsigned int full : 1;
};

void
wrong(struct x *ptr)
{
    ptr->full = 1;
}
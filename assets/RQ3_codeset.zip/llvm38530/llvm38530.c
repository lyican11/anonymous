 typedef float ieee754_float32_t;





 typedef double ieee754_float64_t;
 typedef long double ieee854_float80_t;


typedef int ptrdiff_t;
typedef unsigned int size_t;
typedef unsigned short wchar_t;
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;

typedef __builtin_va_list va_list;
typedef __builtin_va_list __gnuc_va_list;





















#pragma pack(push,_CRT_PACKING)
 typedef __gnuc_va_list va_list;
#pragma pack(pop)
void __attribute__((__cdecl__)) __debugbreak(void);
extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void __attribute__((__cdecl__)) __debugbreak(void)
{
  __asm__ __volatile__("int {$}3":);
}




const char *__mingw_get_crt_info (void);




#pragma pack(push,_CRT_PACKING)
typedef unsigned int size_t;
typedef int ssize_t;




typedef size_t rsize_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef int ptrdiff_t;







typedef unsigned short wchar_t;







typedef unsigned short wint_t;
typedef unsigned short wctype_t;





typedef int errno_t;




typedef long __time32_t;




__extension__ typedef long long __time64_t;
typedef __time32_t time_t;
struct threadlocaleinfostruct;
struct threadmbcinfostruct;
typedef struct threadlocaleinfostruct *pthreadlocinfo;
typedef struct threadmbcinfostruct *pthreadmbcinfo;
struct __lc_time_data;

typedef struct localeinfo_struct {
  pthreadlocinfo locinfo;
  pthreadmbcinfo mbcinfo;
} _locale_tstruct,*_locale_t;



typedef struct tagLC_ID {
  unsigned short wLanguage;
  unsigned short wCountry;
  unsigned short wCodePage;
} LC_ID,*LPLC_ID;




typedef struct threadlocaleinfostruct {
  int refcount;
  unsigned int lc_codepage;
  unsigned int lc_collate_cp;
  unsigned long lc_handle[6];
  LC_ID lc_id[6];
  struct {
    char *locale;
    wchar_t *wlocale;
    int *refcount;
    int *wrefcount;
  } lc_category[6];
  int lc_clike;
  int mb_cur_max;
  int *lconv_intl_refcount;
  int *lconv_num_refcount;
  int *lconv_mon_refcount;
  struct lconv *lconv;
  int *ctype1_refcount;
  unsigned short *ctype1;
  const unsigned short *pctype;
  const unsigned char *pclmap;
  const unsigned char *pcumap;
  struct __lc_time_data *lc_time_curr;
} threadlocinfo;







#pragma pack(pop)


#pragma pack(push,_CRT_PACKING)
 struct _iobuf {
    char *_ptr;
    int _cnt;
    char *_base;
    int _flag;
    int _file;
    int _charbuf;
    int _bufsiz;
    char *_tmpfname;
  };
  typedef struct _iobuf FILE;




  typedef long _off_t;

  typedef long off32_t;





  __extension__ typedef long long _off64_t;

  __extension__ typedef long long off64_t;
typedef off64_t off_t;

__attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) __acrt_iob_func(unsigned index);
extern FILE (* __imp__iob)[];
  __extension__ typedef long long fpos_t;
extern
  __attribute__((__format__ (gnu_scanf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_sscanf(const char * __restrict__ _Src,const char * __restrict__ _Format,...);
extern
  __attribute__((__format__ (gnu_scanf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vsscanf (const char * __restrict__ _Str,const char * __restrict__ Format,va_list argp);
extern
  __attribute__((__format__ (gnu_scanf, 1, 2))) __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_scanf(const char * __restrict__ _Format,...);
extern
  __attribute__((__format__ (gnu_scanf, 1, 0))) __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_vscanf(const char * __restrict__ Format, va_list argp);
extern
  __attribute__((__format__ (gnu_scanf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_fscanf(FILE * __restrict__ _File,const char * __restrict__ _Format,...);
extern
  __attribute__((__format__ (gnu_scanf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vfscanf (FILE * __restrict__ fp, const char * __restrict__ Format,va_list argp);

extern
  __attribute__((__format__ (gnu_printf, 3, 0))) __attribute__ ((__nonnull__ (3)))
  int __attribute__((__cdecl__)) __mingw_vsnprintf(char * __restrict__ _DstBuf,size_t _MaxCount,const char * __restrict__ _Format,
                               va_list _ArgList);
extern
  __attribute__((__format__ (gnu_printf, 3, 4))) __attribute__ ((__nonnull__ (3)))
  int __attribute__((__cdecl__)) __mingw_snprintf(char * __restrict__ s, size_t n, const char * __restrict__ format, ...);
extern
  __attribute__((__format__ (gnu_printf, 1, 2))) __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_printf(const char * __restrict__ , ... ) __attribute__ ((__nothrow__));
extern
  __attribute__((__format__ (gnu_printf, 1, 0))) __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_vprintf (const char * __restrict__ , va_list) __attribute__ ((__nothrow__));
extern
  __attribute__((__format__ (gnu_printf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_fprintf (FILE * __restrict__ , const char * __restrict__ , ...) __attribute__ ((__nothrow__));
extern
  __attribute__((__format__ (gnu_printf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vfprintf (FILE * __restrict__ , const char * __restrict__ , va_list) __attribute__ ((__nothrow__));
extern
  __attribute__((__format__ (gnu_printf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_sprintf (char * __restrict__ , const char * __restrict__ , ...) __attribute__ ((__nothrow__));
extern
  __attribute__((__format__ (gnu_printf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vsprintf (char * __restrict__ , const char * __restrict__ , va_list) __attribute__ ((__nothrow__));
extern
  __attribute__((__format__ (gnu_printf, 2, 3))) __attribute__((nonnull (1,2)))
  int __attribute__((__cdecl__)) __mingw_asprintf(char ** __restrict__ , const char * __restrict__ , ...) __attribute__ ((__nothrow__));
extern
  __attribute__((__format__ (gnu_printf, 2, 0))) __attribute__((nonnull (1,2)))
  int __attribute__((__cdecl__)) __mingw_vasprintf(char ** __restrict__ , const char * __restrict__ , va_list) __attribute__ ((__nothrow__));


  int __attribute__((__cdecl__)) __stdio_common_vsprintf(unsigned long long options, char *str, size_t len, const char *format, _locale_t locale, va_list valist);
  int __attribute__((__cdecl__)) __stdio_common_vfprintf(unsigned long long options, FILE *file, const char *format, _locale_t locale, va_list valist);
  int __attribute__((__cdecl__)) __stdio_common_vsscanf(unsigned long long options, const char *input, size_t length, const char *format, _locale_t locale, va_list valist);
  int __attribute__((__cdecl__)) __stdio_common_vfscanf(unsigned long long options, FILE *file, const char *format, _locale_t locale, va_list valist);
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wshadow"

 __attribute__((__format__ (printf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) fprintf(FILE * __restrict__ _File,const char * __restrict__ _Format,...);
  __attribute__((__format__ (printf, 1, 2))) __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) printf(const char * __restrict__ _Format,...);
  __attribute__((__format__ (printf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) sprintf(char * __restrict__ _Dest,const char * __restrict__ _Format,...) ;

  __attribute__((__format__ (printf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) vfprintf(FILE * __restrict__ _File,const char * __restrict__ _Format,va_list _ArgList);
  __attribute__((__format__ (printf, 1, 0))) __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) vprintf(const char * __restrict__ _Format,va_list _ArgList);
  __attribute__((__format__ (printf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) vsprintf(char * __restrict__ _Dest,const char * __restrict__ _Format,va_list _Args) ;

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__((__format__ (scanf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) fscanf(FILE * __restrict__ _File,const char * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vfscanf(0, _File, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__((__format__ (scanf, 1, 2))) __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) scanf(const char * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vfscanf(0, (__acrt_iob_func(0)), _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__((__format__ (scanf, 2, 3))) __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) sscanf(const char * __restrict__ _Src,const char * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vsscanf(0, _Src, (size_t)-1, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }

  __attribute__ ((__format__ (printf, 2, 0)))
  int __attribute__((__cdecl__)) vasprintf(char ** __restrict__ _Ret,const char * __restrict__ _Format,va_list _Args);
  __attribute__ ((__format__ (printf, 2, 3)))
  int __attribute__((__cdecl__)) asprintf(char ** __restrict__ _Ret,const char * __restrict__ _Format,...);


  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__((__format__ (scanf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int vfscanf (FILE *__stream, const char *__format, __builtin_va_list __local_argv)
  {
    return __stdio_common_vfscanf(0, __stream, __format, ((void*)0), __local_argv);
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__((__format__ (scanf, 2, 0))) __attribute__ ((__nonnull__ (2)))
  int vsscanf (const char * __restrict__ __source, const char * __restrict__ __format, __builtin_va_list __local_argv)
  {
    return __stdio_common_vsscanf(0, __source, (size_t)-1, __format, ((void*)0), __local_argv);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__((__format__ (scanf, 1, 0))) __attribute__ ((__nonnull__ (1)))
  int vscanf(const char *__format, __builtin_va_list __local_argv)
  {
    return __stdio_common_vfscanf(0, (__acrt_iob_func(0)), __format, ((void*)0), __local_argv);
  }


#pragma GCC diagnostic pop
 __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _filbuf(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _flsbuf(int _Ch,FILE *_File);



  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _fsopen(const char *_Filename,const char *_Mode,int _ShFlag);

  void __attribute__((__cdecl__)) clearerr(FILE *_File);
  int __attribute__((__cdecl__)) fclose(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fcloseall(void);



  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _fdopen(int _FileHandle,const char *_Mode);

  int __attribute__((__cdecl__)) feof(FILE *_File);
  int __attribute__((__cdecl__)) ferror(FILE *_File);
  int __attribute__((__cdecl__)) fflush(FILE *_File);
  int __attribute__((__cdecl__)) fgetc(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fgetchar(void);
  int __attribute__((__cdecl__)) fgetpos(FILE * __restrict__ _File ,fpos_t * __restrict__ _Pos);
  int __attribute__((__cdecl__)) fgetpos64(FILE * __restrict__ _File ,fpos_t * __restrict__ _Pos);
  char *__attribute__((__cdecl__)) fgets(char * __restrict__ _Buf,int _MaxCount,FILE * __restrict__ _File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fileno(FILE *_File);



  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _tempnam(const char *_DirName,const char *_FilePrefix);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _flushall(void);
  FILE *__attribute__((__cdecl__)) fopen(const char * __restrict__ _Filename,const char * __restrict__ _Mode) ;
  FILE *fopen64(const char * __restrict__ filename,const char * __restrict__ mode);
  int __attribute__((__cdecl__)) fputc(int _Ch,FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fputchar(int _Ch);
  int __attribute__((__cdecl__)) fputs(const char * __restrict__ _Str,FILE * __restrict__ _File);
  size_t __attribute__((__cdecl__)) fread(void * __restrict__ _DstBuf,size_t _ElementSize,size_t _Count,FILE * __restrict__ _File);
  FILE *__attribute__((__cdecl__)) freopen(const char * __restrict__ _Filename,const char * __restrict__ _Mode,FILE * __restrict__ _File) ;
  int __attribute__((__cdecl__)) fsetpos(FILE *_File,const fpos_t *_Pos);
  int __attribute__((__cdecl__)) fsetpos64(FILE *_File,const fpos_t *_Pos);
  int __attribute__((__cdecl__)) fseek(FILE *_File,long _Offset,int _Origin);
  long __attribute__((__cdecl__)) ftell(FILE *_File);





  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fseeki64(FILE *_File,long long _Offset,int _Origin);
  __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _ftelli64(FILE *_File);
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int fseeko(FILE *_File, _off_t _Offset, int _Origin) {
    return fseek(_File, _Offset, _Origin);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int fseeko64(FILE *_File, _off64_t _Offset, int _Origin) {
    return _fseeki64(_File, _Offset, _Origin);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) _off_t ftello(FILE *_File) {
    return ftell(_File);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) _off64_t ftello64(FILE *_File) {
    return _ftelli64(_File);
  }
  size_t __attribute__((__cdecl__)) fwrite(const void * __restrict__ _Str,size_t _Size,size_t _Count,FILE * __restrict__ _File);
  int __attribute__((__cdecl__)) getc(FILE *_File);
  int __attribute__((__cdecl__)) getchar(void);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _getmaxstdio(void);
  char *__attribute__((__cdecl__)) gets(char *_Buffer) ;
  int __attribute__((__cdecl__)) _getw(FILE *_File);


  void __attribute__((__cdecl__)) perror(const char *_ErrMsg);

  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _pclose(FILE *_File);
  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _popen(const char *_Command,const char *_Mode);




  int __attribute__((__cdecl__)) putc(int _Ch,FILE *_File);
  int __attribute__((__cdecl__)) putchar(int _Ch);
  int __attribute__((__cdecl__)) puts(const char *_Str);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _putw(int _Word,FILE *_File);


  int __attribute__((__cdecl__)) remove(const char *_Filename);
  int __attribute__((__cdecl__)) rename(const char *_OldFilename,const char *_NewFilename);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _unlink(const char *_Filename);

  int __attribute__((__cdecl__)) unlink(const char *_Filename) ;


  void __attribute__((__cdecl__)) rewind(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _rmtmp(void);
  void __attribute__((__cdecl__)) setbuf(FILE * __restrict__ _File,char * __restrict__ _Buffer) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _setmaxstdio(int _Max);
  __attribute__ ((__dllimport__)) unsigned int __attribute__((__cdecl__)) _set_output_format(unsigned int _Format);
  __attribute__ ((__dllimport__)) unsigned int __attribute__((__cdecl__)) _get_output_format(void);
  int __attribute__((__cdecl__)) setvbuf(FILE * __restrict__ _File,char * __restrict__ _Buf,int _Mode,size_t _Size);

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _scprintf(const char * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vsprintf((0x0002), ((void*)0), 0, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _snscanf(const char * __restrict__ _Src,size_t _MaxCount,const char * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vsscanf(0, _Src, _MaxCount, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }




  FILE *__attribute__((__cdecl__)) tmpfile(void) ;
  char *__attribute__((__cdecl__)) tmpnam(char *_Buffer);
  int __attribute__((__cdecl__)) ungetc(int _Ch,FILE *_File);


  __attribute__((__format__ (printf, 3, 0))) __attribute__ ((__nonnull__ (3)))
  int __attribute__((__cdecl__)) _vsnprintf(char * __restrict__ _Dest,size_t _Count,const char * __restrict__ _Format,va_list _Args) ;
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__((__format__ (printf, 3, 4))) __attribute__ ((__nonnull__ (3)))
  int __attribute__((__cdecl__)) _snprintf(char * __restrict__ _Dest,size_t _Count,const char * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = _vsnprintf(_Dest, _Count, _Format, ap);
    __builtin_va_end(ap);
    return ret;
  }
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wshadow"

 __attribute__((__format__ (printf, 3, 0))) __attribute__ ((__nonnull__ (3)))
  int vsnprintf (char * __restrict__ __stream, size_t __n, const char * __restrict__ __format, va_list __local_argv);

  __attribute__((__format__ (printf, 3, 4))) __attribute__ ((__nonnull__ (3)))
  int snprintf (char * __restrict__ __stream, size_t __n, const char * __restrict__ __format, ...);

#pragma GCC diagnostic pop
 static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _vscprintf(const char * __restrict__ _Format,va_list _ArgList)
  {
    return __stdio_common_vsprintf((0x0002), ((void*)0), 0, _Format, ((void*)0), _ArgList);
  }




  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _set_printf_count_output(int _Value);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _get_printf_count_output(void);




                                                     __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_swscanf(const wchar_t * __restrict__ _Src,const wchar_t * __restrict__ _Format,...);
                                                     __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vswscanf (const wchar_t * __restrict__ _Str,const wchar_t * __restrict__ Format,va_list argp);
                                                     __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_wscanf(const wchar_t * __restrict__ _Format,...);
                                                     __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_vwscanf(const wchar_t * __restrict__ Format, va_list argp);
                                                     __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_fwscanf(FILE * __restrict__ _File,const wchar_t * __restrict__ _Format,...);
                                                     __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vfwscanf (FILE * __restrict__ fp, const wchar_t * __restrict__ Format,va_list argp);

                                                      __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_fwprintf(FILE * __restrict__ _File,const wchar_t * __restrict__ _Format,...);
                                                      __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_wprintf(const wchar_t * __restrict__ _Format,...);
                                                     __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vfwprintf(FILE * __restrict__ _File,const wchar_t * __restrict__ _Format,va_list _ArgList);
                                                     __attribute__ ((__nonnull__ (1)))
  int __attribute__((__cdecl__)) __mingw_vwprintf(const wchar_t * __restrict__ _Format,va_list _ArgList);
                                                      __attribute__ ((__nonnull__ (3)))
  int __attribute__((__cdecl__)) __mingw_snwprintf (wchar_t * __restrict__ s, size_t n, const wchar_t * __restrict__ format, ...);
                                                      __attribute__ ((__nonnull__ (3)))
  int __attribute__((__cdecl__)) __mingw_vsnwprintf (wchar_t * __restrict__ , size_t, const wchar_t * __restrict__ , va_list);
                                                      __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_swprintf(wchar_t * __restrict__ , const wchar_t * __restrict__ , ...);
                                                      __attribute__ ((__nonnull__ (2)))
  int __attribute__((__cdecl__)) __mingw_vswprintf(wchar_t * __restrict__ , const wchar_t * __restrict__ ,va_list);


  int __attribute__((__cdecl__)) __stdio_common_vswprintf(unsigned long long options, wchar_t *str, size_t len, const wchar_t *format, _locale_t locale, va_list valist);
  int __attribute__((__cdecl__)) __stdio_common_vfwprintf(unsigned long long options, FILE *file, const wchar_t *format, _locale_t locale, va_list valist);
  int __attribute__((__cdecl__)) __stdio_common_vswscanf(unsigned long long options, const wchar_t *input, size_t length, const wchar_t *format, _locale_t locale, va_list valist);
  int __attribute__((__cdecl__)) __stdio_common_vfwscanf(unsigned long long options, FILE *file, const wchar_t *format, _locale_t locale, va_list valist);
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) fwscanf(FILE * __restrict__ _File,const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vfwscanf(0, _File, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) swscanf(const wchar_t * __restrict__ _Src,const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vswscanf(0, _Src, (size_t)-1, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) wscanf(const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vfwscanf(0, (__acrt_iob_func(0)), _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__ ((__nonnull__ (2)))
  int vfwscanf (FILE *__stream, const wchar_t *__format, va_list __local_argv)
  {
    return __stdio_common_vfwscanf(0, __stream, __format, ((void*)0), __local_argv);
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__ ((__nonnull__ (2)))
  int vswscanf (const wchar_t * __restrict__ __source, const wchar_t * __restrict__ __format, va_list __local_argv)
  {
    return __stdio_common_vswscanf(0, __source, (size_t)-1, __format, ((void*)0), __local_argv);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  __attribute__ ((__nonnull__ (1)))
  int vwscanf(const wchar_t *__format, va_list __local_argv)
  {
    return __stdio_common_vfwscanf(0, (__acrt_iob_func(0)), __format, ((void*)0), __local_argv);
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) fwprintf(FILE * __restrict__ _File,const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vfwprintf(0, _File, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) wprintf(const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vfwprintf(0, (__acrt_iob_func(1)), _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) vfwprintf(FILE * __restrict__ _File,const wchar_t * __restrict__ _Format,va_list _ArgList)
  {
    return __stdio_common_vfwprintf(0, _File, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) vwprintf(const wchar_t * __restrict__ _Format,va_list _ArgList)
  {
    return __stdio_common_vfwprintf(0, (__acrt_iob_func(1)), _Format, ((void*)0), _ArgList);
  }
  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _wfsopen(const wchar_t *_Filename,const wchar_t *_Mode,int _ShFlag);


  wint_t __attribute__((__cdecl__)) fgetwc(FILE *_File);
  __attribute__ ((__dllimport__)) wint_t __attribute__((__cdecl__)) _fgetwchar(void);
  wint_t __attribute__((__cdecl__)) fputwc(wchar_t _Ch,FILE *_File);
  __attribute__ ((__dllimport__)) wint_t __attribute__((__cdecl__)) _fputwchar(wchar_t _Ch);
  wint_t __attribute__((__cdecl__)) getwc(FILE *_File);
  wint_t __attribute__((__cdecl__)) getwchar(void);
  wint_t __attribute__((__cdecl__)) putwc(wchar_t _Ch,FILE *_File);
  wint_t __attribute__((__cdecl__)) putwchar(wchar_t _Ch);
  wint_t __attribute__((__cdecl__)) ungetwc(wint_t _Ch,FILE *_File);
  wchar_t *__attribute__((__cdecl__)) fgetws(wchar_t * __restrict__ _Dst,int _SizeInWords,FILE * __restrict__ _File);
  int __attribute__((__cdecl__)) fputws(const wchar_t * __restrict__ _Str,FILE * __restrict__ _File);
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _getws(wchar_t *_String) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _putws(const wchar_t *_Str);


  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _scwprintf(const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vswprintf(0 | (0x0002), ((void*)0), 0, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _snwprintf(wchar_t * __restrict__ _Dest,size_t _Count,const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vswprintf(0 | (0x0001), _Dest, _Count, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  int __attribute__((__cdecl__)) _vsnwprintf(wchar_t * __restrict__ _Dest,size_t _Count,const wchar_t * __restrict__ _Format,va_list _Args) ;


  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int snwprintf (wchar_t * __restrict__ s, size_t n, const wchar_t * __restrict__ format, ...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, format);
    ret = __stdio_common_vswprintf(0 | (0x0002), s, n, format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) vsnwprintf (wchar_t * __restrict__ s, size_t n, const wchar_t * __restrict__ format, va_list arg)
  {
    return __stdio_common_vswprintf(0 | (0x0002), s, n, format, ((void*)0), arg);
  }


  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _swprintf(wchar_t * __restrict__ _Dest,const wchar_t * __restrict__ _Format,...)
  {
    __builtin_va_list ap;
    int ret;
    __builtin_va_start(ap, _Format);
    ret = __stdio_common_vswprintf(0, _Dest, (size_t)-1, _Format, ((void*)0), ap);
    __builtin_va_end(ap);
    return ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _vswprintf(wchar_t * __restrict__ _Dest,const wchar_t * __restrict__ _Format,va_list _Args)
  {
    return __stdio_common_vswprintf(0, _Dest, (size_t)-1, _Format, ((void*)0), _Args);
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
  int __attribute__((__cdecl__)) _vscwprintf(const wchar_t * __restrict__ _Format, va_list _ArgList)
  {
      int _Result = __stdio_common_vswprintf((0x0002), ((void*)0), 0, _Format, ((void*)0), _ArgList);
      return _Result < 0 ? -1 : _Result;
  }
static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
                                                      __attribute__ ((__nonnull__ (3)))
int vswprintf (wchar_t *__stream, size_t __count, const wchar_t *__format, __builtin_va_list __local_argv)
{
  return vsnwprintf( __stream, __count, __format, __local_argv );
}

static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__))
                                                      __attribute__ ((__nonnull__ (3)))
int swprintf (wchar_t *__stream, size_t __count, const wchar_t *__format, ...)
{
  int __retval;
  __builtin_va_list __local_argv;

  __builtin_va_start( __local_argv, __format );
  __retval = vswprintf( __stream, __count, __format, __local_argv );
  __builtin_va_end( __local_argv );
  return __retval;
}
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wtempnam(const wchar_t *_Directory,const wchar_t *_FilePrefix);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _snwscanf(const wchar_t * __restrict__ _Src,size_t _MaxCount,const wchar_t * __restrict__ _Format,...);
  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _wfdopen(int _FileHandle ,const wchar_t *_Mode);
  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _wfopen(const wchar_t * __restrict__ _Filename,const wchar_t *__restrict__ _Mode) ;
  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _wfreopen(const wchar_t * __restrict__ _Filename,const wchar_t * __restrict__ _Mode,FILE * __restrict__ _OldFile) ;



  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _wperror(const wchar_t *_ErrMsg);

  __attribute__ ((__dllimport__)) FILE *__attribute__((__cdecl__)) _wpopen(const wchar_t *_Command,const wchar_t *_Mode);




  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wremove(const wchar_t *_Filename);
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wtmpnam(wchar_t *_Buffer);
  __attribute__ ((__dllimport__)) wint_t __attribute__((__cdecl__)) _fgetwc_nolock(FILE *_File);
  __attribute__ ((__dllimport__)) wint_t __attribute__((__cdecl__)) _fputwc_nolock(wchar_t _Ch,FILE *_File);
  __attribute__ ((__dllimport__)) wint_t __attribute__((__cdecl__)) _ungetwc_nolock(wint_t _Ch,FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fgetc_nolock(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fputc_nolock(int _Char, FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _getc_nolock(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _putc_nolock(int _Char, FILE *_File);
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _lock_file(FILE *_File);
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _unlock_file(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fclose_nolock(FILE *_File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fflush_nolock(FILE *_File);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _fread_nolock(void * __restrict__ _DstBuf,size_t _ElementSize,size_t _Count,FILE * __restrict__ _File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fseek_nolock(FILE *_File,long _Offset,int _Origin);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _ftell_nolock(FILE *_File);
  __extension__ __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fseeki64_nolock(FILE *_File,long long _Offset,int _Origin);
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _ftelli64_nolock(FILE *_File);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _fwrite_nolock(const void * __restrict__ _DstBuf,size_t _Size,size_t _Count,FILE * __restrict__ _File);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _ungetc_nolock(int _Ch,FILE *_File);





  char *__attribute__((__cdecl__)) tempnam(const char *_Directory,const char *_FilePrefix) ;
  int __attribute__((__cdecl__)) fcloseall(void) ;
  FILE *__attribute__((__cdecl__)) fdopen(int _FileHandle,const char *_Format) ;
  int __attribute__((__cdecl__)) fgetchar(void) ;
  int __attribute__((__cdecl__)) fileno(FILE *_File) ;
  int __attribute__((__cdecl__)) flushall(void) ;
  int __attribute__((__cdecl__)) fputchar(int _Ch) ;
  int __attribute__((__cdecl__)) getw(FILE *_File) ;
  int __attribute__((__cdecl__)) putw(int _Ch,FILE *_File) ;
  int __attribute__((__cdecl__)) rmtmp(void) ;
int __attribute__((__cdecl__)) __mingw_str_wide_utf8 (const wchar_t * const wptr, char **mbptr, size_t * buflen);
int __attribute__((__cdecl__)) __mingw_str_utf8_wide (const char *const mbptr, wchar_t ** wptr, size_t * buflen);
void __attribute__((__cdecl__)) __mingw_str_free(void *ptr);





  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnl(int _Mode,const wchar_t *_Filename,const wchar_t *_ArgList,...);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnle(int _Mode,const wchar_t *_Filename,const wchar_t *_ArgList,...);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnlp(int _Mode,const wchar_t *_Filename,const wchar_t *_ArgList,...);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnlpe(int _Mode,const wchar_t *_Filename,const wchar_t *_ArgList,...);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnv(int _Mode,const wchar_t *_Filename,const wchar_t *const *_ArgList);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnve(int _Mode,const wchar_t *_Filename,const wchar_t *const *_ArgList,const wchar_t *const *_Env);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnvp(int _Mode,const wchar_t *_Filename,const wchar_t *const *_ArgList);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wspawnvpe(int _Mode,const wchar_t *_Filename,const wchar_t *const *_ArgList,const wchar_t *const *_Env);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _spawnv(int _Mode,const char *_Filename,const char *const *_ArgList);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _spawnve(int _Mode,const char *_Filename,const char *const *_ArgList,const char *const *_Env);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _spawnvp(int _Mode,const char *_Filename,const char *const *_ArgList);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _spawnvpe(int _Mode,const char *_Filename,const char *const *_ArgList,const char *const *_Env);






#pragma pack(pop)










  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) clearerr_s(FILE *_File);

  size_t __attribute__((__cdecl__)) fread_s(void *_DstBuf,size_t _DstSize,size_t _ElementSize,size_t _Count,FILE *_File);


  int __attribute__((__cdecl__)) __stdio_common_vsprintf_s(unsigned long long _Options, char *_Str, size_t _Len, const char *_Format, _locale_t _Locale, va_list _ArgList);
  int __attribute__((__cdecl__)) __stdio_common_vsprintf_p(unsigned long long _Options, char *_Str, size_t _Len, const char *_Format, _locale_t _Locale, va_list _ArgList);
  int __attribute__((__cdecl__)) __stdio_common_vsnprintf_s(unsigned long long _Options, char *_Str, size_t _Len, size_t _MaxCount, const char *_Format, _locale_t _Locale, va_list _ArgList);
  int __attribute__((__cdecl__)) __stdio_common_vfprintf_s(unsigned long long _Options, FILE *_File, const char *_Format, _locale_t _Locale, va_list _ArgList);
  int __attribute__((__cdecl__)) __stdio_common_vfprintf_p(unsigned long long _Options, FILE *_File, const char *_Format, _locale_t _Locale, va_list _ArgList);

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfscanf_s_l(FILE *_File, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vfscanf((0x0001), _File, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fscanf_s_l(FILE *_File, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfscanf_s_l(_File, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _scanf_s_l(const char *_Format, _locale_t _Locale ,...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfscanf_s_l((__acrt_iob_func(0)), _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfscanf_l(FILE *_File, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vfscanf(0, _File, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fscanf_l(FILE *_File, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfscanf_l(_File, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _scanf_l(const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfscanf_l((__acrt_iob_func(0)), _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsscanf_s_l(const char *_Src, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsscanf((0x0001), _Src, (size_t)-1, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vsscanf_s(const char *_Src, const char *_Format, va_list _ArgList)
  {
    return _vsscanf_s_l(_Src, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _sscanf_s_l(const char *_Src, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsscanf_s_l(_Src, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) sscanf_s(const char *_Src, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vsscanf_s_l(_Src, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsscanf_l(const char *_Src, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsscanf(0, _Src, (size_t)-1, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _sscanf_l(const char *_Src, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsscanf_l(_Src, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }


  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snscanf_s_l(const char *_Src, size_t _MaxCount, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = __stdio_common_vsscanf((0x0001), _Src, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snscanf_s(const char *_Src, size_t _MaxCount, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = __stdio_common_vsscanf((0x0001), _Src, _MaxCount, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }


  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snscanf_l(const char *_Src, size_t _MaxCount, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = __stdio_common_vsscanf(0, _Src, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }


  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfprintf_s_l(FILE *_File, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vfprintf_s(0, _File, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vfprintf_s(FILE *_File, const char *_Format, va_list _ArgList)
  {
    return _vfprintf_s_l(_File, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vprintf_s_l(const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return _vfprintf_s_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vprintf_s(const char *_Format, va_list _ArgList)
  {
    return _vfprintf_s_l((__acrt_iob_func(1)), _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fprintf_s_l(FILE *_File, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfprintf_s_l(_File, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _printf_s_l(const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfprintf_s_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) fprintf_s(FILE *_File, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vfprintf_s_l(_File, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) printf_s(const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vfprintf_s_l((__acrt_iob_func(1)), _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnprintf_c_l(char *_DstBuf, size_t _MaxCount, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsprintf(0, _DstBuf, _MaxCount, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnprintf_c(char *_DstBuf, size_t _MaxCount, const char *_Format, va_list _ArgList)
  {
    return _vsnprintf_c_l(_DstBuf, _MaxCount, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snprintf_c_l(char *_DstBuf, size_t _MaxCount, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsnprintf_c_l(_DstBuf, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snprintf_c(char *_DstBuf, size_t _MaxCount, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vsnprintf_c_l(_DstBuf, _MaxCount, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnprintf_s_l(char *_DstBuf, size_t _DstSize, size_t _MaxCount, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsnprintf_s(0, _DstBuf, _DstSize, _MaxCount, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vsnprintf_s(char *_DstBuf, size_t _DstSize, size_t _MaxCount, const char *_Format, va_list _ArgList)
  {
    return _vsnprintf_s_l(_DstBuf, _DstSize, _MaxCount, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnprintf_s(char *_DstBuf, size_t _DstSize, size_t _MaxCount, const char *_Format, va_list _ArgList)
  {
    return _vsnprintf_s_l(_DstBuf, _DstSize, _MaxCount, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snprintf_s_l(char *_DstBuf, size_t _DstSize, size_t _MaxCount, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsnprintf_s_l(_DstBuf, _DstSize, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snprintf_s(char *_DstBuf, size_t _DstSize, size_t _MaxCount, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vsnprintf_s_l(_DstBuf, _DstSize, _MaxCount, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsprintf_s_l(char *_DstBuf, size_t _DstSize, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsprintf_s(0, _DstBuf, _DstSize, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vsprintf_s(char *_DstBuf, size_t _Size, const char *_Format, va_list _ArgList)
  {
    return _vsprintf_s_l(_DstBuf, _Size, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _sprintf_s_l(char *_DstBuf, size_t _DstSize, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsprintf_s_l(_DstBuf, _DstSize, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) sprintf_s(char *_DstBuf, size_t _DstSize, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vsprintf_s_l(_DstBuf, _DstSize, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfprintf_p_l(FILE *_File, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vfprintf_p(0, _File, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfprintf_p(FILE *_File, const char *_Format, va_list _ArgList)
  {
    return _vfprintf_p_l(_File, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vprintf_p_l(const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return _vfprintf_p_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vprintf_p(const char *_Format, va_list _ArgList)
  {
    return _vfprintf_p_l((__acrt_iob_func(1)), _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fprintf_p_l(FILE *_File, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = __stdio_common_vfprintf_p(0, _File, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fprintf_p(FILE *_File, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vfprintf_p_l(_File, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _printf_p_l(const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfprintf_p_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _printf_p(const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vfprintf_p_l((__acrt_iob_func(1)), _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsprintf_p_l(char *_DstBuf, size_t _MaxCount, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsprintf_p(0, _DstBuf, _MaxCount, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsprintf_p(char *_Dst, size_t _MaxCount, const char *_Format, va_list _ArgList)
  {
    return _vsprintf_p_l(_Dst, _MaxCount, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _sprintf_p_l(char *_DstBuf, size_t _MaxCount, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsprintf_p_l(_DstBuf, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _sprintf_p(char *_Dst, size_t _MaxCount, const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vsprintf_p_l(_Dst, _MaxCount, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vscprintf_p_l(const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsprintf_p((0x0002), ((void*)0), 0, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vscprintf_p(const char *_Format, va_list _ArgList)
  {
    return _vscprintf_p_l(_Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _scprintf_p_l(const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vscprintf_p_l(_Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _scprintf_p(const char *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vscprintf_p_l(_Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfprintf_l(FILE *_File, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vfprintf(0, _File, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vprintf_l(const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return _vfprintf_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fprintf_l(FILE *_File, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfprintf_l(_File, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _printf_l(const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfprintf_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnprintf_l(char *_DstBuf, size_t _MaxCount, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsprintf((0x0001), _DstBuf, _MaxCount, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snprintf_l(char *_DstBuf, size_t _MaxCount, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsnprintf_l(_DstBuf, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsprintf_l(char *_DstBuf, const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return _vsnprintf_l(_DstBuf, (size_t)-1, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _sprintf_l(char *_DstBuf, const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsprintf_l(_DstBuf, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vscprintf_l(const char *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsprintf((0x0002), ((void*)0), 0, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _scprintf_l(const char *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vscprintf_l(_Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) fopen_s(FILE **_File,const char *_Filename,const char *_Mode);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) freopen_s(FILE** _File, const char *_Filename, const char *_Mode, FILE *_Stream);

  __attribute__ ((__dllimport__)) char* __attribute__((__cdecl__)) gets_s(char*,rsize_t);


  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) tmpnam_s(char*,rsize_t);





  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _getws_s(wchar_t *_Str,size_t _SizeInWords);



  int __attribute__((__cdecl__)) __stdio_common_vswprintf_s(unsigned long long _Options, wchar_t *_Str, size_t _Len, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList);
  int __attribute__((__cdecl__)) __stdio_common_vsnwprintf_s(unsigned long long _Options, wchar_t *_Str, size_t _Len, size_t _MaxCount, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList);
  int __attribute__((__cdecl__)) __stdio_common_vfwprintf_s(unsigned long long _Options, FILE *_File, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList);

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfwscanf_s_l(FILE *_File, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vfwscanf(0 | (0x0001), _File, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fwscanf_s_l(FILE *_File, const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfwscanf_s_l(_File, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _wscanf_s_l(const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfwscanf_s_l((__acrt_iob_func(0)), _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vswscanf_s_l(const wchar_t *_Src, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vswscanf(0 | (0x0001), _Src, (size_t)-1, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _swscanf_s_l(const wchar_t *_Src, const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vswscanf_s_l(_Src, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) swscanf_s(const wchar_t *_Src, const wchar_t *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vswscanf_s_l(_Src, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnwscanf_s_l(const wchar_t *_Src, size_t _MaxCount, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vswscanf(0 | (0x0001), _Src, _MaxCount, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snwscanf_s_l(const wchar_t *_Src, size_t _MaxCount, const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsnwscanf_s_l(_Src, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snwscanf_s(const wchar_t *_Src, size_t _MaxCount, const wchar_t *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vsnwscanf_s_l(_Src, _MaxCount, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vfwprintf_s_l(FILE *_File, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vfwprintf_s(0, _File, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vwprintf_s_l(const wchar_t *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return _vfwprintf_s_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vfwprintf_s(FILE *_File, const wchar_t *_Format, va_list _ArgList)
  {
    return _vfwprintf_s_l(_File, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vwprintf_s(const wchar_t *_Format, va_list _ArgList)
  {
    return _vfwprintf_s_l((__acrt_iob_func(1)), _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _fwprintf_s_l(FILE *_File, const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfwprintf_s_l(_File, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _wprintf_s_l(const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vfwprintf_s_l((__acrt_iob_func(1)), _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) fwprintf_s(FILE *_File, const wchar_t *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vfwprintf_s_l(_File, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) wprintf_s(const wchar_t *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vfwprintf_s_l((__acrt_iob_func(1)), _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vswprintf_s_l(wchar_t *_DstBuf, size_t _DstSize, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vswprintf_s(0, _DstBuf, _DstSize, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) vswprintf_s(wchar_t *_DstBuf, size_t _DstSize, const wchar_t *_Format, va_list _ArgList)
  {
    return _vswprintf_s_l(_DstBuf, _DstSize, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _swprintf_s_l(wchar_t *_DstBuf, size_t _DstSize, const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vswprintf_s_l(_DstBuf, _DstSize, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) swprintf_s(wchar_t *_DstBuf, size_t _DstSize, const wchar_t *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vswprintf_s_l(_DstBuf, _DstSize, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnwprintf_s_l(wchar_t *_DstBuf, size_t _DstSize, size_t _MaxCount, const wchar_t *_Format, _locale_t _Locale, va_list _ArgList)
  {
    return __stdio_common_vsnwprintf_s(0, _DstBuf, _DstSize, _MaxCount, _Format, _Locale, _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _vsnwprintf_s(wchar_t *_DstBuf, size_t _DstSize, size_t _MaxCount, const wchar_t *_Format, va_list _ArgList)
  {
    return _vsnwprintf_s_l(_DstBuf, _DstSize, _MaxCount, _Format, ((void*)0), _ArgList);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snwprintf_s_l(wchar_t *_DstBuf, size_t _DstSize, size_t _MaxCount, const wchar_t *_Format, _locale_t _Locale, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Locale);
    _Ret = _vsnwprintf_s_l(_DstBuf, _DstSize, _MaxCount, _Format, _Locale, _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) _snwprintf_s(wchar_t *_DstBuf, size_t _DstSize, size_t _MaxCount, const wchar_t *_Format, ...)
  {
    __builtin_va_list _ArgList;
    int _Ret;
    __builtin_va_start(_ArgList, _Format);
    _Ret = _vsnwprintf_s_l(_DstBuf, _DstSize, _MaxCount, _Format, ((void*)0), _ArgList);
    __builtin_va_end(_ArgList);
    return _Ret;
  }
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wfopen_s(FILE **_File,const wchar_t *_Filename,const wchar_t *_Mode);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wfreopen_s(FILE **_File,const wchar_t *_Filename,const wchar_t *_Mode,FILE *_OldFile);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wtmpnam_s(wchar_t *_DstBuf,size_t _SizeInWords);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _fread_nolock_s(void *_DstBuf,size_t _DstSize,size_t _ElementSize,size_t _Count,FILE *_File);






typedef void (*lame_report_function)(const char *format, va_list ap);
typedef enum vbr_mode_e {
  vbr_off=0,
  vbr_mt,
  vbr_rh,
  vbr_abr,
  vbr_mtrh,
  vbr_max_indicator,
  vbr_default=vbr_mtrh
} vbr_mode;



typedef enum MPEG_mode_e {
  STEREO = 0,
  JOINT_STEREO,
  DUAL_CHANNEL,
  MONO,
  NOT_SET,
  MAX_INDICATOR
} MPEG_mode;


typedef enum Padding_type_e {
  PAD_NO = 0,
  PAD_ALL,
  PAD_ADJUST,
  PAD_MAX_INDICATOR
} Padding_type;




typedef enum preset_mode_e {


    ABR_8 = 8,
    ABR_320 = 320,

    V9 = 410,
    VBR_10 = 410,
    V8 = 420,
    VBR_20 = 420,
    V7 = 430,
    VBR_30 = 430,
    V6 = 440,
    VBR_40 = 440,
    V5 = 450,
    VBR_50 = 450,
    V4 = 460,
    VBR_60 = 460,
    V3 = 470,
    VBR_70 = 470,
    V2 = 480,
    VBR_80 = 480,
    V1 = 490,
    VBR_90 = 490,
    V0 = 500,
    VBR_100 = 500,




    R3MIX = 1000,
    STANDARD = 1001,
    EXTREME = 1002,
    INSANE = 1003,
    STANDARD_FAST = 1004,
    EXTREME_FAST = 1005,
    MEDIUM = 1006,
    MEDIUM_FAST = 1007
} preset_mode;



typedef enum asm_optimizations_e {
    MMX = 1,
    AMD_3DNOW = 2,
    SSE = 3
} asm_optimizations;



typedef enum Psy_model_e {
    PSY_GPSYCHO = 1,
    PSY_NSPSYTUNE = 2
} Psy_model;



typedef enum buffer_constraint_e {
    MDB_DEFAULT=0,
    MDB_STRICT_ISO=1,
    MDB_MAXIMUM=2
} buffer_constraint;


struct lame_global_struct;
typedef struct lame_global_struct lame_global_flags;
typedef lame_global_flags *lame_t;
lame_global_flags * __attribute__((__cdecl__)) lame_init(void);
int __attribute__((__cdecl__)) lame_set_num_samples(lame_global_flags *, unsigned long);
unsigned long __attribute__((__cdecl__)) lame_get_num_samples(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_in_samplerate(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_in_samplerate(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_num_channels(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_num_channels(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_set_scale(lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_scale(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_set_scale_left(lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_scale_left(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_set_scale_right(lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_scale_right(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_out_samplerate(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_out_samplerate(const lame_global_flags *);






int __attribute__((__cdecl__)) lame_set_analysis(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_analysis(const lame_global_flags *);






int __attribute__((__cdecl__)) lame_set_bWriteVbrTag(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_bWriteVbrTag(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_decode_only(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_decode_only(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_quality(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_quality(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_set_mode(lame_global_flags *, MPEG_mode);
MPEG_mode __attribute__((__cdecl__)) lame_get_mode(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_force_ms(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_force_ms(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_free_format(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_free_format(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_findReplayGain(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_findReplayGain(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_set_decode_on_the_fly(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_decode_on_the_fly(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_nogap_total(lame_global_flags*, int);
int __attribute__((__cdecl__)) lame_get_nogap_total(const lame_global_flags*);

int __attribute__((__cdecl__)) lame_set_nogap_currentindex(lame_global_flags* , int);
int __attribute__((__cdecl__)) lame_get_nogap_currentindex(const lame_global_flags*);
int __attribute__((__cdecl__)) lame_set_errorf(lame_global_flags *, lame_report_function);
int __attribute__((__cdecl__)) lame_set_debugf(lame_global_flags *, lame_report_function);
int __attribute__((__cdecl__)) lame_set_msgf (lame_global_flags *, lame_report_function);




int __attribute__((__cdecl__)) lame_set_brate(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_brate(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_compression_ratio(lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_compression_ratio(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_preset( lame_global_flags* gfp, int );
int __attribute__((__cdecl__)) lame_set_asm_optimizations( lame_global_flags* gfp, int, int );







int __attribute__((__cdecl__)) lame_set_copyright(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_copyright(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_original(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_original(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_error_protection(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_error_protection(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_extension(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_extension(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_strict_ISO(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_strict_ISO(const lame_global_flags *);







int __attribute__((__cdecl__)) lame_set_disable_reservoir(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_disable_reservoir(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_quant_comp(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_quant_comp(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_quant_comp_short(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_quant_comp_short(const lame_global_flags *);

int __attribute__((__cdecl__)) lame_set_experimentalX(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_experimentalX(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_experimentalY(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_experimentalY(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_experimentalZ(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_experimentalZ(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_exp_nspsytune(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_exp_nspsytune(const lame_global_flags *);

void __attribute__((__cdecl__)) lame_set_msfix(lame_global_flags *, double);
float __attribute__((__cdecl__)) lame_get_msfix(const lame_global_flags *);






int __attribute__((__cdecl__)) lame_set_VBR(lame_global_flags *, vbr_mode);
vbr_mode __attribute__((__cdecl__)) lame_get_VBR(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_VBR_q(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_VBR_q(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_VBR_quality(lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_VBR_quality(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_VBR_mean_bitrate_kbps(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_VBR_mean_bitrate_kbps(const lame_global_flags *);

int __attribute__((__cdecl__)) lame_set_VBR_min_bitrate_kbps(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_VBR_min_bitrate_kbps(const lame_global_flags *);

int __attribute__((__cdecl__)) lame_set_VBR_max_bitrate_kbps(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_VBR_max_bitrate_kbps(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_set_VBR_hard_min(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_VBR_hard_min(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_lowpassfreq(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_lowpassfreq(const lame_global_flags *);

int __attribute__((__cdecl__)) lame_set_lowpasswidth(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_lowpasswidth(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_highpassfreq(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_highpassfreq(const lame_global_flags *);

int __attribute__((__cdecl__)) lame_set_highpasswidth(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_highpasswidth(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_ATHonly(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_ATHonly(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_ATHshort(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_ATHshort(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_noATH(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_noATH(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_ATHtype(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_ATHtype(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_ATHlower(lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_ATHlower(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_athaa_type( lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_athaa_type( const lame_global_flags *);
int __attribute__((__cdecl__)) lame_set_athaa_sensitivity( lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_athaa_sensitivity( const lame_global_flags* );
int __attribute__((__cdecl__)) lame_set_allow_diff_short(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_allow_diff_short(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_useTemporal(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_useTemporal(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_interChRatio(lame_global_flags *, float);
float __attribute__((__cdecl__)) lame_get_interChRatio(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_no_short_blocks(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_no_short_blocks(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_set_force_short_blocks(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_force_short_blocks(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_set_emphasis(lame_global_flags *, int);
int __attribute__((__cdecl__)) lame_get_emphasis(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_get_version(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_get_encoder_delay(const lame_global_flags *);







int __attribute__((__cdecl__)) lame_get_encoder_padding(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_get_framesize(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_get_mf_samples_to_encode( const lame_global_flags* gfp );
int __attribute__((__cdecl__)) lame_get_size_mp3buffer( const lame_global_flags* gfp );


int __attribute__((__cdecl__)) lame_get_frameNum(const lame_global_flags *);





int __attribute__((__cdecl__)) lame_get_totalframes(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_get_RadioGain(const lame_global_flags *);


int __attribute__((__cdecl__)) lame_get_AudiophileGain(const lame_global_flags *);


float __attribute__((__cdecl__)) lame_get_PeakSample(const lame_global_flags *);




int __attribute__((__cdecl__)) lame_get_noclipGainChange(const lame_global_flags *);





float __attribute__((__cdecl__)) lame_get_noclipScale(const lame_global_flags *);
int __attribute__((__cdecl__)) lame_init_params(lame_global_flags *);







const char* __attribute__((__cdecl__)) get_lame_version ( void );
const char* __attribute__((__cdecl__)) get_lame_short_version ( void );
const char* __attribute__((__cdecl__)) get_lame_very_short_version ( void );
const char* __attribute__((__cdecl__)) get_psy_version ( void );
const char* __attribute__((__cdecl__)) get_lame_url ( void );
const char* __attribute__((__cdecl__)) get_lame_os_bitness ( void );





typedef struct {

    int major;
    int minor;
    int alpha;
    int beta;


    int psy_major;
    int psy_minor;
    int psy_alpha;
    int psy_beta;


    const char *features;
} lame_version_t;
void __attribute__((__cdecl__)) get_lame_version_numerical(lame_version_t *);






void __attribute__((__cdecl__)) lame_print_config(const lame_global_flags* gfp);

void __attribute__((__cdecl__)) lame_print_internals( const lame_global_flags *gfp);
int __attribute__((__cdecl__)) lame_encode_buffer (
        lame_global_flags* gfp,
        const short int buffer_l [],
        const short int buffer_r [],
        const int nsamples,
        unsigned char* mp3buf,
        const int mp3buf_size );
int __attribute__((__cdecl__)) lame_encode_buffer_interleaved(
        lame_global_flags* gfp,
        short int pcm[],

        int num_samples,


        unsigned char* mp3buf,
        int mp3buf_size );







int __attribute__((__cdecl__)) lame_encode_buffer_float(
        lame_global_flags* gfp,
        const float pcm_l [],
        const float pcm_r [],
        const int nsamples,
        unsigned char* mp3buf,
        const int mp3buf_size );





int __attribute__((__cdecl__)) lame_encode_buffer_ieee_float(
        lame_t gfp,
        const float pcm_l [],
        const float pcm_r [],
        const int nsamples,
        unsigned char * mp3buf,
        const int mp3buf_size);
int __attribute__((__cdecl__)) lame_encode_buffer_interleaved_ieee_float(
        lame_t gfp,
        const float pcm[],

        const int nsamples,
        unsigned char * mp3buf,
        const int mp3buf_size);




int __attribute__((__cdecl__)) lame_encode_buffer_ieee_double(
        lame_t gfp,
        const double pcm_l [],
        const double pcm_r [],
        const int nsamples,
        unsigned char * mp3buf,
        const int mp3buf_size);
int __attribute__((__cdecl__)) lame_encode_buffer_interleaved_ieee_double(
        lame_t gfp,
        const double pcm[],

        const int nsamples,
        unsigned char * mp3buf,
        const int mp3buf_size);
int __attribute__((__cdecl__)) lame_encode_buffer_long(
        lame_global_flags* gfp,
        const long buffer_l [],
        const long buffer_r [],
        const int nsamples,
        unsigned char* mp3buf,
        const int mp3buf_size );







int __attribute__((__cdecl__)) lame_encode_buffer_long2(
        lame_global_flags* gfp,
        const long buffer_l [],
        const long buffer_r [],
        const int nsamples,
        unsigned char* mp3buf,
        const int mp3buf_size );
int __attribute__((__cdecl__)) lame_encode_buffer_int(
        lame_global_flags* gfp,
        const int buffer_l [],
        const int buffer_r [],
        const int nsamples,
        unsigned char* mp3buf,
        const int mp3buf_size );
int __attribute__((__cdecl__)) lame_encode_flush(
        lame_global_flags * gfp,
        unsigned char* mp3buf,
        int size);
int __attribute__((__cdecl__)) lame_encode_flush_nogap(
        lame_global_flags * gfp,
        unsigned char* mp3buf,
        int size);
int __attribute__((__cdecl__)) lame_init_bitstream(
        lame_global_flags * gfp);
void __attribute__((__cdecl__)) lame_bitrate_hist(
        const lame_global_flags * gfp,
        int bitrate_count[14] );
void __attribute__((__cdecl__)) lame_bitrate_kbps(
        const lame_global_flags * gfp,
        int bitrate_kbps [14] );
void __attribute__((__cdecl__)) lame_stereo_mode_hist(
        const lame_global_flags * gfp,
        int stereo_mode_count[4] );

void __attribute__((__cdecl__)) lame_bitrate_stereo_mode_hist (
        const lame_global_flags * gfp,
        int bitrate_stmode_count[14][4] );

void __attribute__((__cdecl__)) lame_block_type_hist (
        const lame_global_flags * gfp,
        int btype_count[6] );

void __attribute__((__cdecl__)) lame_bitrate_block_type_hist (
        const lame_global_flags * gfp,
        int bitrate_btype_count[14][6] );
void __attribute__((__cdecl__)) lame_mp3_tags_fid(lame_global_flags *, FILE* fid);
size_t __attribute__((__cdecl__)) lame_get_lametag_frame(
        const lame_global_flags *, unsigned char* buffer, size_t size);





int __attribute__((__cdecl__)) lame_close (lame_global_flags *);
struct hip_global_struct;
typedef struct hip_global_struct hip_global_flags;
typedef hip_global_flags *hip_t;


typedef struct {
  int header_parsed;

  int stereo;
  int samplerate;
  int bitrate;
  int mode;
  int mode_ext;
  int framesize;


  unsigned long nsamp;
  int totalframes;


  int framenum;
} mp3data_struct;


hip_t __attribute__((__cdecl__)) hip_decode_init(void);


int __attribute__((__cdecl__)) hip_decode_exit(hip_t gfp);


void __attribute__((__cdecl__)) hip_set_errorf(hip_t gfp, lame_report_function f);
void __attribute__((__cdecl__)) hip_set_debugf(hip_t gfp, lame_report_function f);
void __attribute__((__cdecl__)) hip_set_msgf (hip_t gfp, lame_report_function f);
int __attribute__((__cdecl__)) hip_decode( hip_t gfp
                    , unsigned char * mp3buf
                    , size_t len
                    , short pcm_l[]
                    , short pcm_r[]
                    );


int __attribute__((__cdecl__)) hip_decode_headers( hip_t gfp
                            , unsigned char* mp3buf
                            , size_t len
                            , short pcm_l[]
                            , short pcm_r[]
                            , mp3data_struct* mp3data
                            );


int __attribute__((__cdecl__)) hip_decode1( hip_t gfp
                     , unsigned char* mp3buf
                     , size_t len
                     , short pcm_l[]
                     , short pcm_r[]
                     );


int __attribute__((__cdecl__)) hip_decode1_headers( hip_t gfp
                             , unsigned char* mp3buf
                             , size_t len
                             , short pcm_l[]
                             , short pcm_r[]
                             , mp3data_struct* mp3data
                             );



int __attribute__((__cdecl__)) hip_decode1_headersB( hip_t gfp
                              , unsigned char* mp3buf
                              , size_t len
                              , short pcm_l[]
                              , short pcm_r[]
                              , mp3data_struct* mp3data
                              , int *enc_delay
                              , int *enc_padding
                              );
void __attribute__((__cdecl__)) id3tag_genre_list(
        void (*handler)(int, const char *, void *),
        void* cookie);

void __attribute__((__cdecl__)) id3tag_init (lame_t gfp);


void __attribute__((__cdecl__)) id3tag_add_v2 (lame_t gfp);


void __attribute__((__cdecl__)) id3tag_v1_only (lame_t gfp);


void __attribute__((__cdecl__)) id3tag_v2_only (lame_t gfp);


void __attribute__((__cdecl__)) id3tag_space_v1 (lame_t gfp);


void __attribute__((__cdecl__)) id3tag_pad_v2 (lame_t gfp);


void __attribute__((__cdecl__)) id3tag_set_pad (lame_t gfp, size_t n);

void __attribute__((__cdecl__)) id3tag_set_title(lame_t gfp, const char* title);
void __attribute__((__cdecl__)) id3tag_set_artist(lame_t gfp, const char* artist);
void __attribute__((__cdecl__)) id3tag_set_album(lame_t gfp, const char* album);
void __attribute__((__cdecl__)) id3tag_set_year(lame_t gfp, const char* year);
void __attribute__((__cdecl__)) id3tag_set_comment(lame_t gfp, const char* comment);



int __attribute__((__cdecl__)) id3tag_set_track(lame_t gfp, const char* track);






int __attribute__((__cdecl__)) id3tag_set_genre(lame_t gfp, const char* genre);


int __attribute__((__cdecl__)) id3tag_set_fieldvalue(lame_t gfp, const char* fieldvalue);


int __attribute__((__cdecl__)) id3tag_set_albumart(lame_t gfp, const char* image, size_t size);
size_t __attribute__((__cdecl__)) lame_get_id3v1_tag(lame_t gfp, unsigned char* buffer, size_t size);
size_t __attribute__((__cdecl__)) lame_get_id3v2_tag(lame_t gfp, unsigned char* buffer, size_t size);






void __attribute__((__cdecl__)) lame_set_write_id3tag_automatic(lame_global_flags * gfp, int);
int __attribute__((__cdecl__)) lame_get_write_id3tag_automatic(lame_global_flags const* gfp);


int __attribute__((__cdecl__)) id3tag_set_textinfo_latin1(lame_t gfp, char const *id, char const *text);


int __attribute__((__cdecl__)) id3tag_set_comment_latin1(lame_t gfp, char const *lang, char const *desc, char const *text);
int __attribute__((__cdecl__)) id3tag_set_fieldvalue_utf16(lame_t gfp, const unsigned short *fieldvalue);


int __attribute__((__cdecl__)) id3tag_set_textinfo_utf16(lame_t gfp, char const *id, unsigned short const *text);


int __attribute__((__cdecl__)) id3tag_set_comment_utf16(lame_t gfp, char const *lang, unsigned short const *desc, unsigned short const *text);
extern const int bitrate_table [3][16];
extern const int samplerate_table [3][ 4];


int __attribute__((__cdecl__)) lame_get_bitrate(int mpeg_version, int table_index);
int __attribute__((__cdecl__)) lame_get_samplerate(int mpeg_version, int table_index);
typedef enum {
    LAME_OKAY = 0,
    LAME_NOERROR = 0,
    LAME_GENERICERROR = -1,
    LAME_NOMEM = -10,
    LAME_BADBITRATE = -11,
    LAME_BADSAMPFREQ = -12,
    LAME_INTERNALERROR = -13,

    FRONTEND_READERROR = -80,
    FRONTEND_WRITEERROR = -81,
    FRONTEND_FILETOOLARGE = -82

} lame_errorcodes_t;






  void __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) exit(int _Code) __attribute__ ((__noreturn__));
  void __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) _exit(int _Code) __attribute__ ((__noreturn__));



  void __attribute__((__cdecl__)) _Exit(int) __attribute__ ((__noreturn__));

  extern inline __attribute__((__gnu_inline__)) __attribute__ ((__noreturn__)) void __attribute__((__cdecl__)) _Exit(int status)
  { _exit(status); }





  void __attribute__((__cdecl__)) __attribute__ ((__noreturn__)) abort(void);




extern void __attribute__((__cdecl__))
_wassert(const wchar_t *_Message,const wchar_t *_File,unsigned _Line);
extern void __attribute__((__cdecl__))
_assert (const char *_Message, const char *_File, unsigned _Line);


#pragma pack(push,_CRT_PACKING)
 typedef int (__attribute__((__cdecl__)) *_onexit_t)(void);
  typedef struct _div_t {
    int quot;
    int rem;
  } div_t;

  typedef struct _ldiv_t {
    long quot;
    long rem;
  } ldiv_t;





#pragma pack(4)
 typedef struct {
    unsigned char ld[10];
  } _LDOUBLE;
#pragma pack()



 typedef struct {
    double x;
  } _CRT_DOUBLE;

  typedef struct {
    float f;
  } _CRT_FLOAT;




  typedef struct {
    long double x;
  } _LONGDOUBLE;



#pragma pack(4)
 typedef struct {
    unsigned char ld12[12];
  } _LDBL12;
#pragma pack()
__attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) ___mb_cur_max_func(void);
  typedef void (__attribute__((__cdecl__)) *_purecall_handler)(void);

  __attribute__ ((__dllimport__)) _purecall_handler __attribute__((__cdecl__)) _set_purecall_handler(_purecall_handler _Handler);
  __attribute__ ((__dllimport__)) _purecall_handler __attribute__((__cdecl__)) _get_purecall_handler(void);

  typedef void (__attribute__((__cdecl__)) *_invalid_parameter_handler)(const wchar_t *,const wchar_t *,const wchar_t *,unsigned int,uintptr_t);
  __attribute__ ((__dllimport__)) _invalid_parameter_handler __attribute__((__cdecl__)) _set_invalid_parameter_handler(_invalid_parameter_handler _Handler);
  __attribute__ ((__dllimport__)) _invalid_parameter_handler __attribute__((__cdecl__)) _get_invalid_parameter_handler(void);



  __attribute__ ((__dllimport__)) extern int *__attribute__((__cdecl__)) _errno(void);

  errno_t __attribute__((__cdecl__)) _set_errno(int _Value);
  errno_t __attribute__((__cdecl__)) _get_errno(int *_Value);

  __attribute__ ((__dllimport__)) unsigned long *__attribute__((__cdecl__)) __doserrno(void);

  errno_t __attribute__((__cdecl__)) _set_doserrno(unsigned long _Value);
  errno_t __attribute__((__cdecl__)) _get_doserrno(unsigned long *_Value);





  __attribute__ ((__dllimport__)) char **__attribute__((__cdecl__)) __sys_errlist(void);
  __attribute__ ((__dllimport__)) int *__attribute__((__cdecl__)) __sys_nerr(void);
  __attribute__ ((__dllimport__)) char ***__attribute__((__cdecl__)) __p___argv(void);
  __attribute__ ((__dllimport__)) int *__attribute__((__cdecl__)) __p__fmode(void);

  __attribute__ ((__dllimport__)) int *__attribute__((__cdecl__)) __p___argc(void);
  __attribute__ ((__dllimport__)) wchar_t ***__attribute__((__cdecl__)) __p___wargv(void);
  __attribute__ ((__dllimport__)) char ***__attribute__((__cdecl__)) __p__environ(void);
  __attribute__ ((__dllimport__)) wchar_t ***__attribute__((__cdecl__)) __p__wenviron(void);
  __attribute__ ((__dllimport__)) char **__attribute__((__cdecl__)) __p__pgmptr(void);
  __attribute__ ((__dllimport__)) wchar_t **__attribute__((__cdecl__)) __p__wpgmptr(void);


  errno_t __attribute__((__cdecl__)) _get_pgmptr(char **_Value);
  errno_t __attribute__((__cdecl__)) _get_wpgmptr(wchar_t **_Value);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _set_fmode(int _Mode);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _get_fmode(int *_PMode);
  errno_t __attribute__((__cdecl__)) _get_osplatform(unsigned int *_Value);
  errno_t __attribute__((__cdecl__)) _get_osver(unsigned int *_Value);
  errno_t __attribute__((__cdecl__)) _get_winver(unsigned int *_Value);
  errno_t __attribute__((__cdecl__)) _get_winmajor(unsigned int *_Value);
  errno_t __attribute__((__cdecl__)) _get_winminor(unsigned int *_Value);
  __attribute__ ((__dllimport__)) unsigned int __attribute__((__cdecl__)) _set_abort_behavior(unsigned int _Flags,unsigned int _Mask);



  int __attribute__((__cdecl__)) abs(int _X);
  long __attribute__((__cdecl__)) labs(long _X);


  __extension__ long long __attribute__((__cdecl__)) _abs64(long long);

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) long long __attribute__((__cdecl__)) _abs64(long long x) {
    return __builtin_llabs(x);
  }


  int __attribute__((__cdecl__)) atexit(void (__attribute__((__cdecl__)) *)(void));


  double __attribute__((__cdecl__)) atof(const char *_String);
  double __attribute__((__cdecl__)) _atof_l(const char *_String,_locale_t _Locale);

  int __attribute__((__cdecl__)) atoi(const char *_Str);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _atoi_l(const char *_Str,_locale_t _Locale);
  long __attribute__((__cdecl__)) atol(const char *_Str);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _atol_l(const char *_Str,_locale_t _Locale);


  void *__attribute__((__cdecl__)) bsearch(const void *_Key,const void *_Base,size_t _NumOfElements,size_t _SizeOfElements,int (__attribute__((__cdecl__)) *_PtFuncCompare)(const void *,const void *));
  void __attribute__((__cdecl__)) qsort(void *_Base,size_t _NumOfElements,size_t _SizeOfElements,int (__attribute__((__cdecl__)) *_PtFuncCompare)(const void *,const void *));

  unsigned short __attribute__((__cdecl__)) _byteswap_ushort(unsigned short _Short);
  unsigned long __attribute__((__cdecl__)) _byteswap_ulong (unsigned long _Long);
  __extension__ unsigned long long __attribute__((__cdecl__)) _byteswap_uint64(unsigned long long _Int64);
  div_t __attribute__((__cdecl__)) div(int _Numerator,int _Denominator);
  char *__attribute__((__cdecl__)) getenv(const char *_VarName) ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _itoa(int _Value,char *_Dest,int _Radix);
  __extension__ __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _i64toa(long long _Val,char *_DstBuf,int _Radix) ;
  __extension__ __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _ui64toa(unsigned long long _Val,char *_DstBuf,int _Radix) ;
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _atoi64(const char *_String);
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _atoi64_l(const char *_String,_locale_t _Locale);
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _strtoi64(const char *_String,char **_EndPtr,int _Radix);
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _strtoi64_l(const char *_String,char **_EndPtr,int _Radix,_locale_t _Locale);
  __extension__ __attribute__ ((__dllimport__)) unsigned long long __attribute__((__cdecl__)) _strtoui64(const char *_String,char **_EndPtr,int _Radix);
  __extension__ __attribute__ ((__dllimport__)) unsigned long long __attribute__((__cdecl__)) _strtoui64_l(const char *_String,char **_EndPtr,int _Radix,_locale_t _Locale);
  ldiv_t __attribute__((__cdecl__)) ldiv(long _Numerator,long _Denominator);
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _ltoa(long _Value,char *_Dest,int _Radix) ;
  int __attribute__((__cdecl__)) mblen(const char *_Ch,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _mblen_l(const char *_Ch,size_t _MaxCount,_locale_t _Locale);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _mbstrlen(const char *_Str);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _mbstrlen_l(const char *_Str,_locale_t _Locale);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _mbstrnlen(const char *_Str,size_t _MaxCount);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _mbstrnlen_l(const char *_Str,size_t _MaxCount,_locale_t _Locale);
  int __attribute__((__cdecl__)) mbtowc(wchar_t * __restrict__ _DstCh,const char * __restrict__ _SrcCh,size_t _SrcSizeInBytes);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _mbtowc_l(wchar_t * __restrict__ _DstCh,const char * __restrict__ _SrcCh,size_t _SrcSizeInBytes,_locale_t _Locale);
  size_t __attribute__((__cdecl__)) mbstowcs(wchar_t * __restrict__ _Dest,const char * __restrict__ _Source,size_t _MaxCount);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _mbstowcs_l(wchar_t * __restrict__ _Dest,const char * __restrict__ _Source,size_t _MaxCount,_locale_t _Locale);
  int __attribute__((__cdecl__)) mkstemp(char *template_name);
  int __attribute__((__cdecl__)) rand(void);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _set_error_mode(int _Mode);
  void __attribute__((__cdecl__)) srand(unsigned int _Seed);
  double __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) strtod(const char * __restrict__ _Str,char ** __restrict__ _EndPtr);
  float __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) strtof(const char * __restrict__ nptr, char ** __restrict__ endptr);

  long double __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) strtold(const char * __restrict__ , char ** __restrict__ );


  extern double __attribute__((__cdecl__)) __attribute__ ((__nothrow__))
  __strtod (const char * __restrict__ , char ** __restrict__);







  float __attribute__((__cdecl__)) __mingw_strtof (const char * __restrict__, char ** __restrict__);
  double __attribute__((__cdecl__)) __mingw_strtod (const char * __restrict__, char ** __restrict__);
  long double __attribute__((__cdecl__)) __mingw_strtold(const char * __restrict__, char ** __restrict__);

  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _strtod_l(const char * __restrict__ _Str,char ** __restrict__ _EndPtr,_locale_t _Locale);
  long __attribute__((__cdecl__)) strtol(const char * __restrict__ _Str,char ** __restrict__ _EndPtr,int _Radix);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _strtol_l(const char * __restrict__ _Str,char ** __restrict__ _EndPtr,int _Radix,_locale_t _Locale);
  unsigned long __attribute__((__cdecl__)) strtoul(const char * __restrict__ _Str,char ** __restrict__ _EndPtr,int _Radix);
  __attribute__ ((__dllimport__)) unsigned long __attribute__((__cdecl__)) _strtoul_l(const char * __restrict__ _Str,char ** __restrict__ _EndPtr,int _Radix,_locale_t _Locale);


  int __attribute__((__cdecl__)) system(const char *_Command);

  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _ultoa(unsigned long _Value,char *_Dest,int _Radix) ;
  int __attribute__((__cdecl__)) wctomb(char *_MbCh,wchar_t _WCh) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wctomb_l(char *_MbCh,wchar_t _WCh,_locale_t _Locale) ;
  size_t __attribute__((__cdecl__)) wcstombs(char * __restrict__ _Dest,const wchar_t * __restrict__ _Source,size_t _MaxCount) ;
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _wcstombs_l(char * __restrict__ _Dest,const wchar_t * __restrict__ _Source,size_t _MaxCount,_locale_t _Locale) ;



  void *__attribute__((__cdecl__)) calloc(size_t _NumOfElements,size_t _SizeOfElements);
  void __attribute__((__cdecl__)) free(void *_Memory);
  void *__attribute__((__cdecl__)) malloc(size_t _Size);
  void *__attribute__((__cdecl__)) realloc(void *_Memory,size_t _NewSize);
  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _recalloc(void *_Memory,size_t _Count,size_t _Size);






  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _aligned_free(void *_Memory);
  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _aligned_malloc(size_t _Size,size_t _Alignment);



  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _aligned_offset_malloc(size_t _Size,size_t _Alignment,size_t _Offset);
  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _aligned_realloc(void *_Memory,size_t _Size,size_t _Alignment);
  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _aligned_recalloc(void *_Memory,size_t _Count,size_t _Size,size_t _Alignment);
  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _aligned_offset_realloc(void *_Memory,size_t _Size,size_t _Alignment,size_t _Offset);
  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _aligned_offset_recalloc(void *_Memory,size_t _Count,size_t _Size,size_t _Alignment,size_t _Offset);





  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _itow(int _Value,wchar_t *_Dest,int _Radix) ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _ltow(long _Value,wchar_t *_Dest,int _Radix) ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _ultow(unsigned long _Value,wchar_t *_Dest,int _Radix) ;

  double __attribute__((__cdecl__)) __mingw_wcstod(const wchar_t * __restrict__ _Str,wchar_t ** __restrict__ _EndPtr);
  float __attribute__((__cdecl__)) __mingw_wcstof(const wchar_t * __restrict__ nptr, wchar_t ** __restrict__ endptr);
  long double __attribute__((__cdecl__)) __mingw_wcstold(const wchar_t * __restrict__, wchar_t ** __restrict__);
  double __attribute__((__cdecl__)) wcstod(const wchar_t * __restrict__ _Str,wchar_t ** __restrict__ _EndPtr);
  float __attribute__((__cdecl__)) wcstof(const wchar_t * __restrict__ nptr, wchar_t ** __restrict__ endptr);


  long double __attribute__((__cdecl__)) wcstold(const wchar_t * __restrict__, wchar_t ** __restrict__);

  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _wcstod_l(const wchar_t * __restrict__ _Str,wchar_t ** __restrict__ _EndPtr,_locale_t _Locale);
  long __attribute__((__cdecl__)) wcstol(const wchar_t * __restrict__ _Str,wchar_t ** __restrict__ _EndPtr,int _Radix);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _wcstol_l(const wchar_t * __restrict__ _Str,wchar_t ** __restrict__ _EndPtr,int _Radix,_locale_t _Locale);
  unsigned long __attribute__((__cdecl__)) wcstoul(const wchar_t * __restrict__ _Str,wchar_t ** __restrict__ _EndPtr,int _Radix);
  __attribute__ ((__dllimport__)) unsigned long __attribute__((__cdecl__)) _wcstoul_l(const wchar_t * __restrict__ _Str,wchar_t ** __restrict__ _EndPtr,int _Radix,_locale_t _Locale);
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wgetenv(const wchar_t *_VarName) ;


  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wsystem(const wchar_t *_Command);

  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _wtof(const wchar_t *_Str);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _wtof_l(const wchar_t *_Str,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wtoi(const wchar_t *_Str);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wtoi_l(const wchar_t *_Str,_locale_t _Locale);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _wtol(const wchar_t *_Str);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _wtol_l(const wchar_t *_Str,_locale_t _Locale);

  __extension__ __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _i64tow(long long _Val,wchar_t *_DstBuf,int _Radix) ;
  __extension__ __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _ui64tow(unsigned long long _Val,wchar_t *_DstBuf,int _Radix) ;
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _wtoi64(const wchar_t *_Str);
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _wtoi64_l(const wchar_t *_Str,_locale_t _Locale);
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _wcstoi64(const wchar_t *_Str,wchar_t **_EndPtr,int _Radix);
  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _wcstoi64_l(const wchar_t *_Str,wchar_t **_EndPtr,int _Radix,_locale_t _Locale);
  __extension__ __attribute__ ((__dllimport__)) unsigned long long __attribute__((__cdecl__)) _wcstoui64(const wchar_t *_Str,wchar_t **_EndPtr,int _Radix);
  __extension__ __attribute__ ((__dllimport__)) unsigned long long __attribute__((__cdecl__)) _wcstoui64_l(const wchar_t *_Str ,wchar_t **_EndPtr,int _Radix,_locale_t _Locale);


  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _putenv(const char *_EnvString);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wputenv(const wchar_t *_EnvString);



  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _fullpath(char *_FullPath,const char *_Path,size_t _SizeInBytes);
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _ecvt(double _Val,int _NumOfDigits,int *_PtDec,int *_PtSign) ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _fcvt(double _Val,int _NumOfDec,int *_PtDec,int *_PtSign) ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _gcvt(double _Val,int _NumOfDigits,char *_DstBuf) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _atodbl(_CRT_DOUBLE *_Result,char *_Str);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _atoldbl(_LDOUBLE *_Result,char *_Str);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _atoflt(_CRT_FLOAT *_Result,char *_Str);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _atodbl_l(_CRT_DOUBLE *_Result,char *_Str,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _atoldbl_l(_LDOUBLE *_Result,char *_Str,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _atoflt_l(_CRT_FLOAT *_Result,char *_Str,_locale_t _Locale);
unsigned long __attribute__((__cdecl__)) _lrotl(unsigned long,int);
unsigned long __attribute__((__cdecl__)) _lrotr(unsigned long,int);





  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _makepath(char *_Path,const char *_Drive,const char *_Dir,const char *_Filename,const char *_Ext);
  _onexit_t __attribute__((__cdecl__)) _onexit(_onexit_t _Func);
  __extension__ unsigned long long __attribute__((__cdecl__)) _rotl64(unsigned long long _Val,int _Shift);
  __extension__ unsigned long long __attribute__((__cdecl__)) _rotr64(unsigned long long Value,int Shift);






  unsigned int __attribute__((__cdecl__)) _rotr(unsigned int _Val,int _Shift);
  unsigned int __attribute__((__cdecl__)) _rotl(unsigned int _Val,int _Shift);


  __extension__ unsigned long long __attribute__((__cdecl__)) _rotr64(unsigned long long _Val,int _Shift);
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _searchenv(const char *_Filename,const char *_EnvVar,char *_ResultPath) ;
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _splitpath(const char *_FullPath,char *_Drive,char *_Dir,char *_Filename,char *_Ext) ;
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _swab(char *_Buf1,char *_Buf2,int _SizeInBytes);



  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wfullpath(wchar_t *_FullPath,const wchar_t *_Path,size_t _SizeInWords);
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _wmakepath(wchar_t *_ResultPath,const wchar_t *_Drive,const wchar_t *_Dir,const wchar_t *_Filename,const wchar_t *_Ext);




  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _wsearchenv(const wchar_t *_Filename,const wchar_t *_EnvVar,wchar_t *_ResultPath) ;
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _wsplitpath(const wchar_t *_FullPath,wchar_t *_Drive,wchar_t *_Dir,wchar_t *_Filename,wchar_t *_Ext) ;


  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _beep(unsigned _Frequency,unsigned _Duration) __attribute__ ((__deprecated__));

  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _seterrormode(int _Mode) __attribute__ ((__deprecated__));
  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) _sleep(unsigned long _Duration) __attribute__ ((__deprecated__));
  char *__attribute__((__cdecl__)) ecvt(double _Val,int _NumOfDigits,int *_PtDec,int *_PtSign) ;
  char *__attribute__((__cdecl__)) fcvt(double _Val,int _NumOfDec,int *_PtDec,int *_PtSign) ;
  char *__attribute__((__cdecl__)) gcvt(double _Val,int _NumOfDigits,char *_DstBuf) ;
  char *__attribute__((__cdecl__)) itoa(int _Val,char *_DstBuf,int _Radix) ;
  char *__attribute__((__cdecl__)) ltoa(long _Val,char *_DstBuf,int _Radix) ;
  int __attribute__((__cdecl__)) putenv(const char *_EnvString) ;



  void __attribute__((__cdecl__)) swab(char *_Buf1,char *_Buf2,int _SizeInBytes) ;


  char *__attribute__((__cdecl__)) ultoa(unsigned long _Val,char *_Dstbuf,int _Radix) ;
  _onexit_t __attribute__((__cdecl__)) onexit(_onexit_t _Func);





  typedef struct { __extension__ long long quot, rem; } lldiv_t;

  __extension__ lldiv_t __attribute__((__cdecl__)) lldiv(long long, long long);

  __extension__ long long __attribute__((__cdecl__)) llabs(long long);

  __extension__ extern inline __attribute__((__gnu_inline__)) long long __attribute__((__cdecl__)) llabs(long long _j) { return (_j >= 0 ? _j : -_j); }


  __extension__ long long __attribute__((__cdecl__)) strtoll(const char * __restrict__, char ** __restrict, int);
  __extension__ unsigned long long __attribute__((__cdecl__)) strtoull(const char * __restrict__, char ** __restrict__, int);


  __extension__ long long __attribute__((__cdecl__)) atoll (const char *);


  __extension__ long long __attribute__((__cdecl__)) wtoll (const wchar_t *);
  __extension__ char *__attribute__((__cdecl__)) lltoa (long long, char *, int);
  __extension__ char *__attribute__((__cdecl__)) ulltoa (unsigned long long , char *, int);
  __extension__ wchar_t *__attribute__((__cdecl__)) lltow (long long, wchar_t *, int);
  __extension__ wchar_t *__attribute__((__cdecl__)) ulltow (unsigned long long, wchar_t *, int);



  __extension__ extern inline __attribute__((__gnu_inline__)) long long __attribute__((__cdecl__)) atoll (const char * _c) { return _atoi64 (_c); }
  __extension__ extern inline __attribute__((__gnu_inline__)) char *__attribute__((__cdecl__)) lltoa (long long _n, char * _c, int _i) { return _i64toa (_n, _c, _i); }
  __extension__ extern inline __attribute__((__gnu_inline__)) char *__attribute__((__cdecl__)) ulltoa (unsigned long long _n, char * _c, int _i) { return _ui64toa (_n, _c, _i); }
  __extension__ extern inline __attribute__((__gnu_inline__)) long long __attribute__((__cdecl__)) wtoll (const wchar_t * _w) { return _wtoi64 (_w); }
  __extension__ extern inline __attribute__((__gnu_inline__)) wchar_t *__attribute__((__cdecl__)) lltow (long long _n, wchar_t * _w, int _i) { return _i64tow (_n, _w, _i); }
  __extension__ extern inline __attribute__((__gnu_inline__)) wchar_t *__attribute__((__cdecl__)) ulltow (unsigned long long _n, wchar_t * _w, int _i) { return _ui64tow (_n, _w, _i); }
#pragma pack(pop)

















  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _dupenv_s(char **_PBuffer,size_t *_PBufferSizeInBytes,const char *_VarName);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _itoa_s(int _Value,char *_DstBuf,size_t _Size,int _Radix);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _i64toa_s(long long _Val,char *_DstBuf,size_t _Size,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _ui64toa_s(unsigned long long _Val,char *_DstBuf,size_t _Size,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _ltoa_s(long _Val,char *_DstBuf,size_t _Size,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) mbstowcs_s(size_t *_PtNumOfCharConverted,wchar_t *_DstBuf,size_t _SizeInWords,const char *_SrcBuf,size_t _MaxCount);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _mbstowcs_s_l(size_t *_PtNumOfCharConverted,wchar_t *_DstBuf,size_t _SizeInWords,const char *_SrcBuf,size_t _MaxCount,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _ultoa_s(unsigned long _Val,char *_DstBuf,size_t _Size,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wctomb_s_l(int *_SizeConverted,char *_MbCh,size_t _SizeInBytes,wchar_t _WCh,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) wcstombs_s(size_t *_PtNumOfCharConverted,char *_Dst,size_t _DstSizeInBytes,const wchar_t *_Src,size_t _MaxCountInBytes);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcstombs_s_l(size_t *_PtNumOfCharConverted,char *_Dst,size_t _DstSizeInBytes,const wchar_t *_Src,size_t _MaxCountInBytes,_locale_t _Locale);



  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _itow_s (int _Val,wchar_t *_DstBuf,size_t _SizeInWords,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _ltow_s (long _Val,wchar_t *_DstBuf,size_t _SizeInWords,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _ultow_s (unsigned long _Val,wchar_t *_DstBuf,size_t _SizeInWords,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wgetenv_s(size_t *_ReturnSize,wchar_t *_DstBuf,size_t _DstSizeInWords,const wchar_t *_VarName);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wdupenv_s(wchar_t **_Buffer,size_t *_BufferSizeInWords,const wchar_t *_VarName);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _i64tow_s(long long _Val,wchar_t *_DstBuf,size_t _SizeInWords,int _Radix);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _ui64tow_s(unsigned long long _Val,wchar_t *_DstBuf,size_t _SizeInWords,int _Radix);



  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _ecvt_s(char *_DstBuf,size_t _Size,double _Val,int _NumOfDights,int *_PtDec,int *_PtSign);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _fcvt_s(char *_DstBuf,size_t _Size,double _Val,int _NumOfDec,int *_PtDec,int *_PtSign);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _gcvt_s(char *_DstBuf,size_t _Size,double _Val,int _NumOfDigits);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _makepath_s(char *_PathResult,size_t _Size,const char *_Drive,const char *_Dir,const char *_Filename,const char *_Ext);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _putenv_s(const char *_Name,const char *_Value);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _searchenv_s(const char *_Filename,const char *_EnvVar,char *_ResultPath,size_t _SizeInBytes);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _splitpath_s(const char *_FullPath,char *_Drive,size_t _DriveSize,char *_Dir,size_t _DirSize,char *_Filename,size_t _FilenameSize,char *_Ext,size_t _ExtSize);




  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wmakepath_s(wchar_t *_PathResult,size_t _SizeInWords,const wchar_t *_Drive,const wchar_t *_Dir,const wchar_t *_Filename,const wchar_t *_Ext);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wputenv_s(const wchar_t *_Name,const wchar_t *_Value);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wsearchenv_s(const wchar_t *_Filename,const wchar_t *_EnvVar,wchar_t *_ResultPath,size_t _SizeInWords);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wsplitpath_s(const wchar_t *_FullPath,wchar_t *_Drive,size_t _DriveSizeInWords,wchar_t *_Dir,size_t _DirSizeInWords,wchar_t *_Filename,size_t _FilenameSizeInWords,wchar_t *_Ext,size_t _ExtSizeInWords);






  __attribute__ ((__dllimport__)) void __attribute__((__cdecl__)) qsort_s(void *_Base,size_t _NumOfElements,size_t _SizeOfElements,int (__attribute__((__cdecl__)) *_PtFuncCompare)(void *,const void *,const void *),void *_Context);
#pragma pack(push,_CRT_PACKING)
 typedef struct _heapinfo {
    int *_pentry;
    size_t _size;
    int _useflag;
  } _HEAPINFO;


  extern unsigned int _amblksiz;
void * __mingw_aligned_malloc (size_t _Size, size_t _Alignment);
void __mingw_aligned_free (void *_Memory);
void * __mingw_aligned_offset_realloc (void *_Memory, size_t _Size, size_t _Alignment, size_t _Offset);
void * __mingw_aligned_realloc (void *_Memory, size_t _Size, size_t _Offset);



  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _resetstkoflw (void);
  __attribute__ ((__dllimport__)) unsigned long __attribute__((__cdecl__)) _set_malloc_crt_max_wait(unsigned long _NewValue);

  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _expand(void *_Memory,size_t _NewSize);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _msize(void *_Memory);






  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _get_sbh_threshold(void);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _set_sbh_threshold(size_t _NewValue);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _set_amblksiz(size_t _Value);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _get_amblksiz(size_t *_Value);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _heapadd(void *_Memory,size_t _Size);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _heapchk(void);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _heapmin(void);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _heapset(unsigned int _Fill);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _heapwalk(_HEAPINFO *_EntryInfo);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _heapused(size_t *_Used,size_t *_Commit);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _get_heap_handle(void);
  static __inline void *_MarkAllocaS(void *_Ptr,unsigned int _Marker) {
    if(_Ptr) {
      *((unsigned int*)_Ptr) = _Marker;
      _Ptr = (char*)_Ptr + 8;
    }
    return _Ptr;
  }
  static __inline void __attribute__((__cdecl__)) _freea(void *_Memory) {
    unsigned int _Marker;
    if(_Memory) {
      _Memory = (char*)_Memory - 8;
      _Marker = *(unsigned int *)_Memory;
      if(_Marker==0xDDDD) {
 free(_Memory);
      }





    }
  }
#pragma pack(pop)
  __attribute__ ((__dllimport__)) void *__attribute__((__cdecl__)) _memccpy(void *_Dst,const void *_Src,int _Val,size_t _MaxCount);
                void *__attribute__((__cdecl__)) memchr(const void *_Buf ,int _Val,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _memicmp(const void *_Buf1,const void *_Buf2,size_t _Size);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _memicmp_l(const void *_Buf1,const void *_Buf2,size_t _Size,_locale_t _Locale);
  int __attribute__((__cdecl__)) memcmp(const void *_Buf1,const void *_Buf2,size_t _Size);
  void * __attribute__((__cdecl__)) memcpy(void * __restrict__ _Dst,const void * __restrict__ _Src,size_t _Size) ;
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) memcpy_s (void *_dest,size_t _numberOfElements,const void *_src,size_t _count);
  void * __attribute__((__cdecl__)) mempcpy (void *_Dst, const void *_Src, size_t _Size);
  void * __attribute__((__cdecl__)) memset(void *_Dst,int _Val,size_t _Size);

  void * __attribute__((__cdecl__)) memccpy(void *_Dst,const void *_Src,int _Val,size_t _Size) ;
  int __attribute__((__cdecl__)) memicmp(const void *_Buf1,const void *_Buf2,size_t _Size) ;


  char * __attribute__((__cdecl__)) _strset(char *_Str,int _Val) ;
  char * __attribute__((__cdecl__)) _strset_l(char *_Str,int _Val,_locale_t _Locale) ;
  char * __attribute__((__cdecl__)) strcpy(char * __restrict__ _Dest,const char * __restrict__ _Source);
  char * __attribute__((__cdecl__)) strcat(char * __restrict__ _Dest,const char * __restrict__ _Source);
  int __attribute__((__cdecl__)) strcmp(const char *_Str1,const char *_Str2);
  size_t __attribute__((__cdecl__)) strlen(const char *_Str);
  size_t __attribute__((__cdecl__)) strnlen(const char *_Str,size_t _MaxCount);
  void *__attribute__((__cdecl__)) memmove(void *_Dst,const void *_Src,size_t _Size) ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strdup(const char *_Src);
                char *__attribute__((__cdecl__)) strchr(const char *_Str,int _Val);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _stricmp(const char *_Str1,const char *_Str2);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strcmpi(const char *_Str1,const char *_Str2);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _stricmp_l(const char *_Str1,const char *_Str2,_locale_t _Locale);
  int __attribute__((__cdecl__)) strcoll(const char *_Str1,const char *_Str2);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strcoll_l(const char *_Str1,const char *_Str2,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _stricoll(const char *_Str1,const char *_Str2);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _stricoll_l(const char *_Str1,const char *_Str2,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strncoll (const char *_Str1,const char *_Str2,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strncoll_l(const char *_Str1,const char *_Str2,size_t _MaxCount,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strnicoll (const char *_Str1,const char *_Str2,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strnicoll_l(const char *_Str1,const char *_Str2,size_t _MaxCount,_locale_t _Locale);
  size_t __attribute__((__cdecl__)) strcspn(const char *_Str,const char *_Control);
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strerror(const char *_ErrMsg) ;
  char *__attribute__((__cdecl__)) strerror(int) ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strlwr(char *_String) ;
  char *strlwr_l(char *_String,_locale_t _Locale) ;
  char *__attribute__((__cdecl__)) strncat(char * __restrict__ _Dest,const char * __restrict__ _Source,size_t _Count) ;
  int __attribute__((__cdecl__)) strncmp(const char *_Str1,const char *_Str2,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strnicmp(const char *_Str1,const char *_Str2,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _strnicmp_l(const char *_Str1,const char *_Str2,size_t _MaxCount,_locale_t _Locale);
  char *strncpy(char * __restrict__ _Dest,const char * __restrict__ _Source,size_t _Count) ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strnset(char *_Str,int _Val,size_t _MaxCount) ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strnset_l(char *str,int c,size_t count,_locale_t _Locale) ;
                char *__attribute__((__cdecl__)) strpbrk(const char *_Str,const char *_Control);
                char *__attribute__((__cdecl__)) strrchr(const char *_Str,int _Ch);
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strrev(char *_Str);
  size_t __attribute__((__cdecl__)) strspn(const char *_Str,const char *_Control);
                char *__attribute__((__cdecl__)) strstr(const char *_Str,const char *_SubStr);
  char *__attribute__((__cdecl__)) strtok(char * __restrict__ _Str,const char * __restrict__ _Delim) ;


  char *strtok_r(char * __restrict__ _Str, const char * __restrict__ _Delim, char ** __restrict__ __last);

  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strupr(char *_String) ;
  __attribute__ ((__dllimport__)) char *_strupr_l(char *_String,_locale_t _Locale) ;
  size_t __attribute__((__cdecl__)) strxfrm(char * __restrict__ _Dst,const char * __restrict__ _Src,size_t _MaxCount);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _strxfrm_l(char * __restrict__ _Dst,const char * __restrict__ _Src,size_t _MaxCount,_locale_t _Locale);


  char *__attribute__((__cdecl__)) strdup(const char *_Src) ;
  int __attribute__((__cdecl__)) strcmpi(const char *_Str1,const char *_Str2) ;
  int __attribute__((__cdecl__)) stricmp(const char *_Str1,const char *_Str2) ;
  char *__attribute__((__cdecl__)) strlwr(char *_Str) ;
  int __attribute__((__cdecl__)) strnicmp(const char *_Str1,const char *_Str,size_t _MaxCount) ;
  int __attribute__((__cdecl__)) strncasecmp (const char *, const char *, size_t);
  int __attribute__((__cdecl__)) strcasecmp (const char *, const char *);

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) strncasecmp (const char *__sz1, const char *__sz2, size_t __sizeMaxCompare) { return _strnicmp (__sz1, __sz2, __sizeMaxCompare); }
  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) strcasecmp (const char *__sz1, const char *__sz2) { return _stricmp (__sz1, __sz2); }




  char *__attribute__((__cdecl__)) strnset(char *_Str,int _Val,size_t _MaxCount) ;
  char *__attribute__((__cdecl__)) strrev(char *_Str) ;
  char *__attribute__((__cdecl__)) strset(char *_Str,int _Val) ;
  char *__attribute__((__cdecl__)) strupr(char *_Str) ;





  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcsdup(const wchar_t *_Str);
  wchar_t *__attribute__((__cdecl__)) wcscat(wchar_t * __restrict__ _Dest,const wchar_t * __restrict__ _Source) ;
                wchar_t *__attribute__((__cdecl__)) wcschr(const wchar_t *_Str,wchar_t _Ch);
  int __attribute__((__cdecl__)) wcscmp(const wchar_t *_Str1,const wchar_t *_Str2);
  wchar_t *__attribute__((__cdecl__)) wcscpy(wchar_t * __restrict__ _Dest,const wchar_t * __restrict__ _Source) ;
  size_t __attribute__((__cdecl__)) wcscspn(const wchar_t *_Str,const wchar_t *_Control);
  size_t __attribute__((__cdecl__)) wcslen(const wchar_t *_Str);
  size_t __attribute__((__cdecl__)) wcsnlen(const wchar_t *_Src,size_t _MaxCount);
  wchar_t *wcsncat(wchar_t * __restrict__ _Dest,const wchar_t * __restrict__ _Source,size_t _Count) ;
  int __attribute__((__cdecl__)) wcsncmp(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount);
  wchar_t *wcsncpy(wchar_t * __restrict__ _Dest,const wchar_t * __restrict__ _Source,size_t _Count) ;
  wchar_t *__attribute__((__cdecl__)) _wcsncpy_l(wchar_t * __restrict__ _Dest,const wchar_t * __restrict__ _Source,size_t _Count,_locale_t _Locale) ;
                wchar_t *__attribute__((__cdecl__)) wcspbrk(const wchar_t *_Str,const wchar_t *_Control);
                wchar_t *__attribute__((__cdecl__)) wcsrchr(const wchar_t *_Str,wchar_t _Ch);
  size_t __attribute__((__cdecl__)) wcsspn(const wchar_t *_Str,const wchar_t *_Control);
                wchar_t *__attribute__((__cdecl__)) wcsstr(const wchar_t *_Str,const wchar_t *_SubStr);
  wchar_t *__attribute__((__cdecl__)) wcstok(wchar_t * __restrict__ _Str,const wchar_t * __restrict__ _Delim) ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcserror(int _ErrNum) ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) __wcserror(const wchar_t *_Str) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsicmp(const wchar_t *_Str1,const wchar_t *_Str2);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsicmp_l(const wchar_t *_Str1,const wchar_t *_Str2,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsnicmp(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsnicmp_l(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount,_locale_t _Locale);
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcsnset(wchar_t *_Str,wchar_t _Val,size_t _MaxCount) ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcsrev(wchar_t *_Str);
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcsset(wchar_t *_Str,wchar_t _Val) ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcslwr(wchar_t *_String) ;
  __attribute__ ((__dllimport__)) wchar_t *_wcslwr_l(wchar_t *_String,_locale_t _Locale) ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcsupr(wchar_t *_String) ;
  __attribute__ ((__dllimport__)) wchar_t *_wcsupr_l(wchar_t *_String,_locale_t _Locale) ;
  size_t __attribute__((__cdecl__)) wcsxfrm(wchar_t * __restrict__ _Dst,const wchar_t * __restrict__ _Src,size_t _MaxCount);
  __attribute__ ((__dllimport__)) size_t __attribute__((__cdecl__)) _wcsxfrm_l(wchar_t * __restrict__ _Dst,const wchar_t * __restrict__ _Src,size_t _MaxCount,_locale_t _Locale);
  int __attribute__((__cdecl__)) wcscoll(const wchar_t *_Str1,const wchar_t *_Str2);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcscoll_l(const wchar_t *_Str1,const wchar_t *_Str2,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsicoll(const wchar_t *_Str1,const wchar_t *_Str2);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsicoll_l(const wchar_t *_Str1,const wchar_t *_Str2,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsncoll(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsncoll_l(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsnicoll(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcsnicoll_l(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount,_locale_t _Locale);


  wchar_t *__attribute__((__cdecl__)) wcsdup(const wchar_t *_Str) ;

  int __attribute__((__cdecl__)) wcsicmp(const wchar_t *_Str1,const wchar_t *_Str2) ;
  int __attribute__((__cdecl__)) wcsnicmp(const wchar_t *_Str1,const wchar_t *_Str2,size_t _MaxCount) ;
  wchar_t *__attribute__((__cdecl__)) wcsnset(wchar_t *_Str,wchar_t _Val,size_t _MaxCount) ;
  wchar_t *__attribute__((__cdecl__)) wcsrev(wchar_t *_Str) ;
  wchar_t *__attribute__((__cdecl__)) wcsset(wchar_t *_Str,wchar_t _Val) ;
  wchar_t *__attribute__((__cdecl__)) wcslwr(wchar_t *_Str) ;
  wchar_t *__attribute__((__cdecl__)) wcsupr(wchar_t *_Str) ;
  int __attribute__((__cdecl__)) wcsicoll(const wchar_t *_Str1,const wchar_t *_Str2) ;
















  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strset_s(char *_Dst,size_t _DstSize,int _Value);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strerror_s(char *_Buf,size_t _SizeInBytes,const char *_ErrMsg);
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) strerror_s(char *_Buf,size_t _SizeInBytes,int _ErrNum);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strlwr_s(char *_Str,size_t _Size);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strlwr_s_l(char *_Str,size_t _Size,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strnset_s(char *_Str,size_t _Size,int _Val,size_t _MaxCount);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strupr_s(char *_Str,size_t _Size);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strupr_s_l(char *_Str,size_t _Size,_locale_t _Locale);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) strncat_s(char *_Dst,size_t _DstSizeInChars,const char *_Src,size_t _MaxCount);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strncat_s_l(char *_Dst,size_t _DstSizeInChars,const char *_Src,size_t _MaxCount,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) strcpy_s(char *_Dst, rsize_t _SizeInBytes, const char *_Src);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) strncpy_s(char *_Dst, size_t _DstSizeInChars, const char *_Src, size_t _MaxCount);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _strncpy_s_l(char *_Dst, size_t _DstSizeInChars, const char *_Src, size_t _MaxCount, _locale_t _Locale);
                                                                                                                                         ;
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) strtok_s(char *_Str,const char *_Delim,char **_Context);
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _strtok_s_l(char *_Str,const char *_Delim,char **_Context,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) strcat_s(char *_Dst, rsize_t _SizeInBytes, const char * _Src);


  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) memmove_s(void *_dest,size_t _numberOfElements,const void *_src,size_t _count);


  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) wcstok_s(wchar_t *_Str,const wchar_t *_Delim,wchar_t **_Context);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcserror_s(wchar_t *_Buf,size_t _SizeInWords,int _ErrNum);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) __wcserror_s(wchar_t *_Buffer,size_t _SizeInWords,const wchar_t *_ErrMsg);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsnset_s(wchar_t *_Dst,size_t _DstSizeInWords,wchar_t _Val,size_t _MaxCount);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsset_s(wchar_t *_Str,size_t _SizeInWords,wchar_t _Val);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcslwr_s(wchar_t *_Str,size_t _SizeInWords);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcslwr_s_l(wchar_t *_Str,size_t _SizeInWords,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsupr_s(wchar_t *_Str,size_t _Size);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsupr_s_l(wchar_t *_Str,size_t _Size,_locale_t _Locale);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) wcscpy_s(wchar_t *_Dst, rsize_t _SizeInWords, const wchar_t *_Src);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) wcscat_s(wchar_t * _Dst, rsize_t _SizeInWords, const wchar_t *_Src);


  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) wcsncat_s(wchar_t *_Dst,size_t _DstSizeInChars,const wchar_t *_Src,size_t _MaxCount);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsncat_s_l(wchar_t *_Dst,size_t _DstSizeInChars,const wchar_t *_Src,size_t _MaxCount,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) wcsncpy_s(wchar_t *_Dst, size_t _DstSizeInChars, const wchar_t *_Src, size_t _MaxCount);
                                                                                                                        ;
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsncpy_s_l(wchar_t *_Dst, size_t _DstSizeInChars, const wchar_t *_Src, size_t _MaxCount, _locale_t _Locale);
                                                                                                                                               ;
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wcstok_s_l(wchar_t *_Str,const wchar_t *_Delim,wchar_t **_Context,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsset_s_l(wchar_t *_Str,size_t _SizeInChars,unsigned int _Val,_locale_t _Locale);
  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wcsnset_s_l(wchar_t *_Str,size_t _SizeInChars,unsigned int _Val, size_t _Count,_locale_t _Locale);

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) size_t __attribute__((__cdecl__)) wcsnlen_s(const wchar_t * _src, size_t _count) {
    return _src ? wcsnlen(_src, _count) : 0;
  }




struct _exception;

#pragma pack(push,_CRT_PACKING)
 typedef union __mingw_dbl_type_t {
    double x;
    unsigned long long val;
    __extension__ struct {
      unsigned int low, high;
    } lh;
  } __mingw_dbl_type_t;

  typedef union __mingw_flt_type_t {
    float x;
    unsigned int val;
  } __mingw_flt_type_t;

  typedef union __mingw_ldbl_type_t
  {
    long double x;
    __extension__ struct {
      unsigned int low, high;
      int sign_exponent : 16;
      int res1 : 16;
      int res0 : 32;
    } lh;
  } __mingw_ldbl_type_t;

  typedef union __mingw_fp_types_t
  {
    long double *ld;
    double *d;
    float *f;
    __mingw_ldbl_type_t *ldt;
    __mingw_dbl_type_t *dt;
    __mingw_flt_type_t *ft;
  } __mingw_fp_types_t;




  extern double * __imp__HUGE;
  struct _exception {
    int type;
    const char *name;
    double arg1;
    double arg2;
    double retval;
  };

  void __mingw_raise_matherr (int typ, const char *name, double a1, double a2,
         double rslt);
  void __mingw_setusermatherr (int (__attribute__((__cdecl__)) *)(struct _exception *));
  __attribute__ ((__dllimport__)) void __setusermatherr(int (__attribute__((__cdecl__)) *)(struct _exception *));



  double __attribute__((__cdecl__)) sin(double _X);
  double __attribute__((__cdecl__)) cos(double _X);
  double __attribute__((__cdecl__)) tan(double _X);
  double __attribute__((__cdecl__)) sinh(double _X);
  double __attribute__((__cdecl__)) cosh(double _X);
  double __attribute__((__cdecl__)) tanh(double _X);
  double __attribute__((__cdecl__)) asin(double _X);
  double __attribute__((__cdecl__)) acos(double _X);
  double __attribute__((__cdecl__)) atan(double _X);
  double __attribute__((__cdecl__)) atan2(double _Y,double _X);
  double __attribute__((__cdecl__)) exp(double _X);
  double __attribute__((__cdecl__)) log(double _X);
  double __attribute__((__cdecl__)) log10(double _X);
  double __attribute__((__cdecl__)) pow(double _X,double _Y);
  double __attribute__((__cdecl__)) sqrt(double _X);
  double __attribute__((__cdecl__)) ceil(double _X);
  double __attribute__((__cdecl__)) floor(double _X);


  extern float __attribute__((__cdecl__)) fabsf (float x);
  extern long double __attribute__((__cdecl__)) fabsl (long double);
  extern double __attribute__((__cdecl__)) fabs (double _X);



  extern inline __attribute__((__gnu_inline__)) float __attribute__((__cdecl__)) fabsf (float x)
  {

    return __builtin_fabsf (x);





  }

  extern inline __attribute__((__gnu_inline__)) long double __attribute__((__cdecl__)) fabsl (long double x)
  {

    return __builtin_fabsl (x);





  }

  extern inline __attribute__((__gnu_inline__)) double __attribute__((__cdecl__)) fabs (double x)
  {

    return __builtin_fabs (x);





  }



  double __attribute__((__cdecl__)) ldexp(double _X,int _Y);
  double __attribute__((__cdecl__)) frexp(double _X,int *_Y);
  double __attribute__((__cdecl__)) modf(double _X,double *_Y);
  double __attribute__((__cdecl__)) fmod(double _X,double _Y);

  void __attribute__((__cdecl__)) sincos (double __x, double *p_sin, double *p_cos);
  void __attribute__((__cdecl__)) sincosl (long double __x, long double *p_sin, long double *p_cos);
  void __attribute__((__cdecl__)) sincosf (float __x, float *p_sin, float *p_cos);
  struct _complex {
    double x;
    double y;
  };


  double __attribute__((__cdecl__)) _cabs(struct _complex _ComplexA);
  double __attribute__((__cdecl__)) _hypot(double _X,double _Y);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _j0(double _X);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _j1(double _X);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _jn(int _X,double _Y);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _y0(double _X);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _y1(double _X);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _yn(int _X,double _Y);


  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _matherr (struct _exception *);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _chgsign (double _X);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _copysign (double _Number,double _Sign);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _logb (double);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _nextafter (double, double);
  __attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) _scalb (double, long);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _finite (double);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fpclass (double);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isnan (double);






__attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) j0 (double) ;
__attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) j1 (double) ;
__attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) jn (int, double) ;
__attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) y0 (double) ;
__attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) y1 (double) ;
__attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) yn (int, double) ;

__attribute__ ((__dllimport__)) double __attribute__((__cdecl__)) chgsign (double);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) finite (double);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) fpclass (double);
typedef float float_t;
typedef double double_t;
  extern int __attribute__((__cdecl__)) __fpclassifyl (long double);
  extern int __attribute__((__cdecl__)) __fpclassifyf (float);
  extern int __attribute__((__cdecl__)) __fpclassify (double);


  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __fpclassifyl (long double x) {
    return __fpclassify(x);





  }
  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __fpclassify (double x) {

    __mingw_fp_types_t hlp;
    unsigned int l, h;

    hlp.d = &x;
    h = hlp.ldt->lh.high;
    l = hlp.ldt->lh.low | (h & 0xfffff);
    h &= 0x7ff00000;
    if ((h | l) == 0)
      return 0x4000;
    if (!h)
      return (0x0400 | 0x4000);
    if (h == 0x7ff00000)
      return (l ? 0x0100 : (0x0100 | 0x0400));
    return 0x0400;





  }
  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __fpclassifyf (float x) {

    __mingw_fp_types_t hlp;

    hlp.f = &x;
    hlp.ft->val &= 0x7fffffff;
    if (hlp.ft->val == 0)
      return 0x4000;
    if (hlp.ft->val < 0x800000)
      return (0x0400 | 0x4000);
    if (hlp.ft->val >= 0x7f800000)
      return (hlp.ft->val > 0x7f800000 ? 0x0100 : (0x0100 | 0x0400));
    return 0x0400;





  }
  extern int __attribute__((__cdecl__)) __isnan (double);
  extern int __attribute__((__cdecl__)) __isnanf (float);
  extern int __attribute__((__cdecl__)) __isnanl (long double);


  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __isnan (double _x)
  {

    __mingw_fp_types_t hlp;
    int l, h;

    hlp.d = &_x;
    l = hlp.dt->lh.low;
    h = hlp.dt->lh.high & 0x7fffffff;
    h |= (unsigned int) (l | -l) >> 31;
    h = 0x7ff00000 - h;
    return (int) ((unsigned int) h) >> 31;







  }

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __isnanf (float _x)
  {

    __mingw_fp_types_t hlp;
    int i;

    hlp.f = &_x;
    i = hlp.ft->val & 0x7fffffff;
    i = 0x7f800000 - i;
    return (int) (((unsigned int) i) >> 31);







  }

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __isnanl (long double _x)
  {
    return __isnan(_x);







  }
  extern int __attribute__((__cdecl__)) __signbit (double);
  extern int __attribute__((__cdecl__)) __signbitf (float);
  extern int __attribute__((__cdecl__)) __signbitl (long double);

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __signbit (double x) {

    __mingw_fp_types_t hlp;

    hlp.d = &x;
    return ((hlp.dt->lh.high & 0x80000000) != 0);





  }

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __signbitf (float x) {

    __mingw_fp_types_t hlp;
    hlp.f = &x;
    return ((hlp.ft->val & 0x80000000) != 0);





  }

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) __signbitl (long double x) {





    return __signbit(x);





  }
  extern float __attribute__((__cdecl__)) sinf(float _X);
  extern long double __attribute__((__cdecl__)) sinl(long double);

  extern float __attribute__((__cdecl__)) cosf(float _X);
  extern long double __attribute__((__cdecl__)) cosl(long double);

  extern float __attribute__((__cdecl__)) tanf(float _X);
  extern long double __attribute__((__cdecl__)) tanl(long double);
  extern float __attribute__((__cdecl__)) asinf(float _X);
  extern long double __attribute__((__cdecl__)) asinl(long double);

  extern float __attribute__((__cdecl__)) acosf (float);
  extern long double __attribute__((__cdecl__)) acosl (long double);

  extern float __attribute__((__cdecl__)) atanf (float);
  extern long double __attribute__((__cdecl__)) atanl (long double);

  extern float __attribute__((__cdecl__)) atan2f (float, float);
  extern long double __attribute__((__cdecl__)) atan2l (long double, long double);


  extern float __attribute__((__cdecl__)) sinhf(float _X);

  extern inline __attribute__((__gnu_inline__)) float sinhf(float _X) { return ((float)sinh((double)_X)); }

  extern long double __attribute__((__cdecl__)) sinhl(long double);

  extern float __attribute__((__cdecl__)) coshf(float _X);

  extern inline __attribute__((__gnu_inline__)) float coshf(float _X) { return ((float)cosh((double)_X)); }

  extern long double __attribute__((__cdecl__)) coshl(long double);

  extern float __attribute__((__cdecl__)) tanhf(float _X);

  extern inline __attribute__((__gnu_inline__)) float tanhf(float _X) { return ((float)tanh((double)_X)); }

  extern long double __attribute__((__cdecl__)) tanhl(long double);



  extern double __attribute__((__cdecl__)) acosh (double);
  extern float __attribute__((__cdecl__)) acoshf (float);
  extern long double __attribute__((__cdecl__)) acoshl (long double);


  extern double __attribute__((__cdecl__)) asinh (double);
  extern float __attribute__((__cdecl__)) asinhf (float);
  extern long double __attribute__((__cdecl__)) asinhl (long double);


  extern double __attribute__((__cdecl__)) atanh (double);
  extern float __attribute__((__cdecl__)) atanhf (float);
  extern long double __attribute__((__cdecl__)) atanhl (long double);



  extern float __attribute__((__cdecl__)) expf(float _X);

  extern inline __attribute__((__gnu_inline__)) float expf(float _X) { return ((float)exp((double)_X)); }

  extern long double __attribute__((__cdecl__)) expl(long double);


  extern double __attribute__((__cdecl__)) exp2(double);
  extern float __attribute__((__cdecl__)) exp2f(float);
  extern long double __attribute__((__cdecl__)) exp2l(long double);



  extern double __attribute__((__cdecl__)) expm1(double);
  extern float __attribute__((__cdecl__)) expm1f(float);
  extern long double __attribute__((__cdecl__)) expm1l(long double);


  extern float frexpf(float _X,int *_Y);

  extern inline __attribute__((__gnu_inline__)) float frexpf(float _X,int *_Y) { return ((float)frexp((double)_X,_Y)); }

  extern long double __attribute__((__cdecl__)) frexpl(long double,int *);




  extern int __attribute__((__cdecl__)) ilogb (double);
  extern int __attribute__((__cdecl__)) ilogbf (float);
  extern int __attribute__((__cdecl__)) ilogbl (long double);


  extern float __attribute__((__cdecl__)) ldexpf(float _X,int _Y);

  extern inline __attribute__((__gnu_inline__)) float __attribute__((__cdecl__)) ldexpf (float x, int expn) { return (float) ldexp ((double)x, expn); }

  extern long double __attribute__((__cdecl__)) ldexpl (long double, int);


  extern float __attribute__((__cdecl__)) logf (float);
  extern long double __attribute__((__cdecl__)) logl(long double);


  extern float __attribute__((__cdecl__)) log10f (float);
  extern long double __attribute__((__cdecl__)) log10l(long double);


  extern double __attribute__((__cdecl__)) log1p(double);
  extern float __attribute__((__cdecl__)) log1pf(float);
  extern long double __attribute__((__cdecl__)) log1pl(long double);


  extern double __attribute__((__cdecl__)) log2 (double);
  extern float __attribute__((__cdecl__)) log2f (float);
  extern long double __attribute__((__cdecl__)) log2l (long double);


  extern double __attribute__((__cdecl__)) logb (double);
  extern float __attribute__((__cdecl__)) logbf (float);
  extern long double __attribute__((__cdecl__)) logbl (long double);
  extern float __attribute__((__cdecl__)) modff (float, float*);
  extern long double __attribute__((__cdecl__)) modfl (long double, long double*);


  extern double __attribute__((__cdecl__)) scalbn (double, int);
  extern float __attribute__((__cdecl__)) scalbnf (float, int);
  extern long double __attribute__((__cdecl__)) scalbnl (long double, int);

  extern double __attribute__((__cdecl__)) scalbln (double, long);
  extern float __attribute__((__cdecl__)) scalblnf (float, long);
  extern long double __attribute__((__cdecl__)) scalblnl (long double, long);



  extern double __attribute__((__cdecl__)) cbrt (double);
  extern float __attribute__((__cdecl__)) cbrtf (float);
  extern long double __attribute__((__cdecl__)) cbrtl (long double);


  extern double __attribute__((__cdecl__)) hypot (double, double) ;
  extern float __attribute__((__cdecl__)) hypotf (float x, float y);

  extern inline __attribute__((__gnu_inline__)) float __attribute__((__cdecl__)) hypotf (float x, float y) { return (float) hypot ((double)x, (double)y);}

  extern long double __attribute__((__cdecl__)) hypotl (long double, long double);


  extern float __attribute__((__cdecl__)) powf(float _X,float _Y);

  extern inline __attribute__((__gnu_inline__)) float powf(float _X,float _Y) { return ((float)pow((double)_X,(double)_Y)); }

  extern long double __attribute__((__cdecl__)) powl (long double, long double);


  extern float __attribute__((__cdecl__)) sqrtf (float);
  extern long double sqrtl(long double);


  extern double __attribute__((__cdecl__)) erf (double);
  extern float __attribute__((__cdecl__)) erff (float);
  extern long double __attribute__((__cdecl__)) erfl (long double);


  extern double __attribute__((__cdecl__)) erfc (double);
  extern float __attribute__((__cdecl__)) erfcf (float);
  extern long double __attribute__((__cdecl__)) erfcl (long double);


  extern double __attribute__((__cdecl__)) lgamma (double);
  extern float __attribute__((__cdecl__)) lgammaf (float);
  extern long double __attribute__((__cdecl__)) lgammal (long double);

  extern int signgam;


  extern double __attribute__((__cdecl__)) tgamma (double);
  extern float __attribute__((__cdecl__)) tgammaf (float);
  extern long double __attribute__((__cdecl__)) tgammal (long double);


  extern float __attribute__((__cdecl__)) ceilf (float);
  extern long double __attribute__((__cdecl__)) ceill (long double);


  extern float __attribute__((__cdecl__)) floorf (float);
  extern long double __attribute__((__cdecl__)) floorl (long double);


  extern double __attribute__((__cdecl__)) nearbyint ( double);
  extern float __attribute__((__cdecl__)) nearbyintf (float);
  extern long double __attribute__((__cdecl__)) nearbyintl (long double);



extern double __attribute__((__cdecl__)) rint (double);
extern float __attribute__((__cdecl__)) rintf (float);
extern long double __attribute__((__cdecl__)) rintl (long double);


extern long __attribute__((__cdecl__)) lrint (double);
extern long __attribute__((__cdecl__)) lrintf (float);
extern long __attribute__((__cdecl__)) lrintl (long double);

__extension__ long long __attribute__((__cdecl__)) llrint (double);
__extension__ long long __attribute__((__cdecl__)) llrintf (float);
__extension__ long long __attribute__((__cdecl__)) llrintl (long double);
  extern double __attribute__((__cdecl__)) round (double);
  extern float __attribute__((__cdecl__)) roundf (float);
  extern long double __attribute__((__cdecl__)) roundl (long double);


  extern long __attribute__((__cdecl__)) lround (double);
  extern long __attribute__((__cdecl__)) lroundf (float);
  extern long __attribute__((__cdecl__)) lroundl (long double);
  __extension__ long long __attribute__((__cdecl__)) llround (double);
  __extension__ long long __attribute__((__cdecl__)) llroundf (float);
  __extension__ long long __attribute__((__cdecl__)) llroundl (long double);



  extern double __attribute__((__cdecl__)) trunc (double);
  extern float __attribute__((__cdecl__)) truncf (float);
  extern long double __attribute__((__cdecl__)) truncl (long double);


  extern float __attribute__((__cdecl__)) fmodf (float, float);
  extern long double __attribute__((__cdecl__)) fmodl (long double, long double);


  extern double __attribute__((__cdecl__)) remainder (double, double);
  extern float __attribute__((__cdecl__)) remainderf (float, float);
  extern long double __attribute__((__cdecl__)) remainderl (long double, long double);


  extern double __attribute__((__cdecl__)) remquo(double, double, int *);
  extern float __attribute__((__cdecl__)) remquof(float, float, int *);
  extern long double __attribute__((__cdecl__)) remquol(long double, long double, int *);


  extern double __attribute__((__cdecl__)) copysign (double, double);
  extern float __attribute__((__cdecl__)) copysignf (float, float);
  extern long double __attribute__((__cdecl__)) copysignl (long double, long double);



  extern inline __attribute__((__gnu_inline__)) double __attribute__((__cdecl__)) copysign (double x, double y)
  {
    __mingw_dbl_type_t hx, hy;
    hx.x = x; hy.x = y;
    hx.lh.high = (hx.lh.high & 0x7fffffff) | (hy.lh.high & 0x80000000);
    return hx.x;
  }
  extern inline __attribute__((__gnu_inline__)) float __attribute__((__cdecl__)) copysignf (float x, float y)
  {
    __mingw_flt_type_t hx, hy;
    hx.x = x; hy.x = y;
    hx.val = (hx.val & 0x7fffffff) | (hy.val & 0x80000000);
    return hx.x;
  }




  extern double __attribute__((__cdecl__)) nan(const char *tagp);
  extern float __attribute__((__cdecl__)) nanf(const char *tagp);
  extern long double __attribute__((__cdecl__)) nanl(const char *tagp);
  extern double __attribute__((__cdecl__)) nextafter (double, double);
  extern float __attribute__((__cdecl__)) nextafterf (float, float);
  extern long double __attribute__((__cdecl__)) nextafterl (long double, long double);


  extern double __attribute__((__cdecl__)) nexttoward (double, long double);
  extern float __attribute__((__cdecl__)) nexttowardf (float, long double);
  extern long double __attribute__((__cdecl__)) nexttowardl (long double, long double);



  extern double __attribute__((__cdecl__)) fdim (double x, double y);
  extern float __attribute__((__cdecl__)) fdimf (float x, float y);
  extern long double __attribute__((__cdecl__)) fdiml (long double x, long double y);







  extern double __attribute__((__cdecl__)) fmax (double, double);
  extern float __attribute__((__cdecl__)) fmaxf (float, float);
  extern long double __attribute__((__cdecl__)) fmaxl (long double, long double);


  extern double __attribute__((__cdecl__)) fmin (double, double);
  extern float __attribute__((__cdecl__)) fminf (float, float);
  extern long double __attribute__((__cdecl__)) fminl (long double, long double);



  extern double __attribute__((__cdecl__)) fma (double, double, double);
  extern float __attribute__((__cdecl__)) fmaf (float, float, float);
  extern long double __attribute__((__cdecl__)) fmal (long double, long double, long double);
   __attribute__ ((__dllimport__)) float __attribute__((__cdecl__)) _copysignf (float _Number,float _Sign);
   __attribute__ ((__dllimport__)) float __attribute__((__cdecl__)) _chgsignf (float _X);
   __attribute__ ((__dllimport__)) float __attribute__((__cdecl__)) _logbf(float _X);
   __attribute__ ((__dllimport__)) float __attribute__((__cdecl__)) _nextafterf(float _X,float _Y);
   __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _finitef(float _X);
   __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isnanf(float _X);
   __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fpclassf(float _X);



   extern long double __attribute__((__cdecl__)) _chgsignl (long double);
#pragma pack(pop)



  __attribute__ ((__dllimport__)) unsigned short* __pctype_func(void);
  extern unsigned short ** __imp__wctype;
  extern unsigned short ** __imp__pwctype;
  extern const unsigned char __newclmap[];
  extern const unsigned char __newcumap[];
  extern pthreadlocinfo __ptlocinfo;
  extern pthreadmbcinfo __ptmbcinfo;
  extern int __globallocalestatus;
  extern int __locale_changed;
  extern struct threadlocaleinfostruct __initiallocinfo;
  extern _locale_tstruct __initiallocalestructinfo;
  pthreadlocinfo __attribute__((__cdecl__)) __updatetlocinfo(void);
  pthreadmbcinfo __attribute__((__cdecl__)) __updatetmbcinfo(void);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isctype(int _C,int _Type);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isctype_l(int _C,int _Type,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isalpha(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isalpha_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isupper(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isupper_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) islower(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _islower_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isdigit(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isdigit_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isxdigit(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isxdigit_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isspace(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isspace_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) ispunct(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _ispunct_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isalnum(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isalnum_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isprint(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isprint_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) isgraph(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isgraph_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) iscntrl(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iscntrl_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) toupper(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) tolower(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _tolower(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _tolower_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _toupper(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _toupper_l(int _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) __isascii(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) __toascii(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) __iscsymf(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) __iscsym(int _C);


int __attribute__((__cdecl__)) isblank(int _C);






  int __attribute__((__cdecl__)) iswalpha(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswalpha_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswupper(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswupper_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswlower(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswlower_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswdigit(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswdigit_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswxdigit(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswxdigit_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswspace(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswspace_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswpunct(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswpunct_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswalnum(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswalnum_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswprint(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswprint_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswgraph(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswgraph_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswcntrl(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswcntrl_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswascii(wint_t _C);
  int __attribute__((__cdecl__)) isleadbyte(int _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isleadbyte_l(int _C,_locale_t _Locale);
  wint_t __attribute__((__cdecl__)) towupper(wint_t _C);
  __attribute__ ((__dllimport__)) wint_t __attribute__((__cdecl__)) _towupper_l(wint_t _C,_locale_t _Locale);
  wint_t __attribute__((__cdecl__)) towlower(wint_t _C);
  __attribute__ ((__dllimport__)) wint_t __attribute__((__cdecl__)) _towlower_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) iswctype(wint_t _C,wctype_t _Type);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswctype_l(wint_t _C,wctype_t _Type,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) __iswcsymf(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswcsymf_l(wint_t _C,_locale_t _Locale);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) __iswcsym(wint_t _C);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _iswcsym_l(wint_t _C,_locale_t _Locale);
  int __attribute__((__cdecl__)) is_wctype(wint_t _C,wctype_t _Type);


int __attribute__((__cdecl__)) iswblank(wint_t _C);











#pragma pack(push,_CRT_PACKING)





__attribute__ ((__dllimport__)) char* __attribute__((__cdecl__)) _getcwd (char*, int);

  typedef unsigned long _fsize_t;





  struct _finddata32_t {
    unsigned attrib;
    __time32_t time_create;
    __time32_t time_access;
    __time32_t time_write;
    _fsize_t size;
    char name[260];
  };

  struct _finddata32i64_t {
    unsigned attrib;
    __time32_t time_create;
    __time32_t time_access;
    __time32_t time_write;
    __extension__ long long size;
    char name[260];
  };

  struct _finddata64i32_t {
    unsigned attrib;
    __time64_t time_create;
    __time64_t time_access;
    __time64_t time_write;
    _fsize_t size;
    char name[260];
  };

  struct __finddata64_t {
    unsigned attrib;
    __time64_t time_create;
    __time64_t time_access;
    __time64_t time_write;
    __extension__ long long size;
    char name[260];
  };
  struct _wfinddata32_t {
    unsigned attrib;
    __time32_t time_create;
    __time32_t time_access;
    __time32_t time_write;
    _fsize_t size;
    wchar_t name[260];
  };

  struct _wfinddata32i64_t {
    unsigned attrib;
    __time32_t time_create;
    __time32_t time_access;
    __time32_t time_write;
    __extension__ long long size;
    wchar_t name[260];
  };

  struct _wfinddata64i32_t {
    unsigned attrib;
    __time64_t time_create;
    __time64_t time_access;
    __time64_t time_write;
    _fsize_t size;
    wchar_t name[260];
  };

  struct _wfinddata64_t {
    unsigned attrib;
    __time64_t time_create;
    __time64_t time_access;
    __time64_t time_write;
    __extension__ long long size;
    wchar_t name[260];
  };
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _access(const char *_Filename,int _AccessMode);
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _access_s(const char *_Filename,int _AccessMode);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _chmod(const char *_Filename,int _Mode);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _chsize(int _FileHandle,long _Size) ;
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _chsize_s (int _FileHandle,long long _Size);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _close(int _FileHandle);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _commit(int _FileHandle);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _creat(const char *_Filename,int _PermissionMode) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _dup(int _FileHandle);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _dup2(int _FileHandleSrc,int _FileHandleDst);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _eof(int _FileHandle);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _filelength(int _FileHandle);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _findfirst32(const char *_Filename,struct _finddata32_t *_FindData);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _findnext32(intptr_t _FindHandle,struct _finddata32_t *_FindData);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _findclose(intptr_t _FindHandle);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _isatty(int _FileHandle);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _locking(int _FileHandle,int _LockMode,long _NumOfBytes);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _lseek(int _FileHandle,long _Offset,int _Origin);
  _off64_t lseek64(int fd,_off64_t offset, int whence);
  __attribute__ ((__dllimport__)) char *__attribute__((__cdecl__)) _mktemp(char *_TemplateName) ;
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _mktemp_s (char *_TemplateName,size_t _Size);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _pipe(int *_PtHandles,unsigned int _PipeSize,int _TextMode);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _read(int _FileHandle,void *_DstBuf,unsigned int _MaxCharCount);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _setmode(int _FileHandle,int _Mode);
  __attribute__ ((__dllimport__)) long __attribute__((__cdecl__)) _tell(int _FileHandle);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _umask(int _Mode) ;
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _umask_s (int _NewMode,int *_OldMode);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _write(int _FileHandle,const void *_Buf,unsigned int _MaxCharCount);

  __extension__ __attribute__ ((__dllimport__)) long long __attribute__((__cdecl__)) _filelengthi64(int _FileHandle);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _findfirst32i64(const char *_Filename,struct _finddata32i64_t *_FindData);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _findfirst64(const char *_Filename,struct __finddata64_t *_FindData);



  intptr_t __attribute__((__cdecl__)) _findfirst64i32(const char *_Filename,struct _finddata64i32_t *_FindData);

  extern inline __attribute__((__gnu_inline__)) intptr_t __attribute__((__cdecl__)) _findfirst64i32(const char *_Filename,struct _finddata64i32_t *_FindData)
  {
    struct __finddata64_t fd;
    intptr_t ret = _findfirst64(_Filename,&fd);
    if (ret == -1) {
      memset(_FindData,0,sizeof(struct _finddata64i32_t));
      return -1;
    }
    _FindData->attrib=fd.attrib;
    _FindData->time_create=fd.time_create;
    _FindData->time_access=fd.time_access;
    _FindData->time_write=fd.time_write;
    _FindData->size=(_fsize_t) fd.size;
    strncpy(_FindData->name,fd.name,260);
    return ret;
  }

  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _findnext32i64(intptr_t _FindHandle,struct _finddata32i64_t *_FindData);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _findnext64(intptr_t _FindHandle,struct __finddata64_t *_FindData);
  int __attribute__((__cdecl__)) _findnext64i32(intptr_t _FindHandle,struct _finddata64i32_t *_FindData);

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) _findnext64i32(intptr_t _FindHandle,struct _finddata64i32_t *_FindData)
  {
    struct __finddata64_t fd;
    int ret = _findnext64(_FindHandle,&fd);
    if (ret == -1) {
      memset(_FindData,0,sizeof(struct _finddata64i32_t));
      return -1;
    }
    _FindData->attrib=fd.attrib;
    _FindData->time_create=fd.time_create;
    _FindData->time_access=fd.time_access;
    _FindData->time_write=fd.time_write;
    _FindData->size=(_fsize_t) fd.size;
    strncpy(_FindData->name,fd.name,260);
    return ret;
  }

  __extension__ long long __attribute__((__cdecl__)) _lseeki64(int _FileHandle,long long _Offset,int _Origin);
  __extension__ long long __attribute__((__cdecl__)) _telli64(int _FileHandle);



  int __attribute__((__cdecl__)) chdir (const char *) ;
  char *__attribute__((__cdecl__)) getcwd (char *, int) ;
  int __attribute__((__cdecl__)) mkdir (const char *) ;
  char *__attribute__((__cdecl__)) mktemp(char *) ;
  int __attribute__((__cdecl__)) rmdir (const char*) ;
  int __attribute__((__cdecl__)) chmod (const char *, int) ;



  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _sopen_s(int *_FileHandle,const char *_Filename,int _OpenFlag,int _ShareFlag,int _PermissionMode);

  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _open(const char *_Filename,int _OpenFlag,...) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _sopen(const char *_Filename,int _OpenFlag,int _ShareFlag,...) ;



  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _waccess(const wchar_t *_Filename,int _AccessMode);
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _waccess_s (const wchar_t *_Filename,int _AccessMode);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wchmod(const wchar_t *_Filename,int _Mode);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wcreat(const wchar_t *_Filename,int _PermissionMode) ;
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wfindfirst32(const wchar_t *_Filename,struct _wfinddata32_t *_FindData);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wfindnext32(intptr_t _FindHandle,struct _wfinddata32_t *_FindData);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wunlink(const wchar_t *_Filename);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wrename(const wchar_t *_OldFilename,const wchar_t *_NewFilename);
  __attribute__ ((__dllimport__)) wchar_t *__attribute__((__cdecl__)) _wmktemp(wchar_t *_TemplateName) ;
  __attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _wmktemp_s (wchar_t *_TemplateName, size_t _SizeInWords);

  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wfindfirsti64(const wchar_t *_Filename,struct _wfinddata32i64_t *_FindData);
  intptr_t __attribute__((__cdecl__)) _wfindfirst64i32(const wchar_t *_Filename,struct _wfinddata64i32_t *_FindData);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _wfindfirst64(const wchar_t *_Filename,struct _wfinddata64_t *_FindData);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wfindnexti64(intptr_t _FindHandle,struct _wfinddata32i64_t *_FindData);
  int __attribute__((__cdecl__)) _wfindnext64i32(intptr_t _FindHandle,struct _wfinddata64i32_t *_FindData);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wfindnext64(intptr_t _FindHandle,struct _wfinddata64_t *_FindData);

  __attribute__ ((__dllimport__)) errno_t __attribute__((__cdecl__)) _wsopen_s(int *_FileHandle,const wchar_t *_Filename,int _OpenFlag,int _ShareFlag,int _PermissionFlag);

  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wopen(const wchar_t *_Filename,int _OpenFlag,...) ;
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wsopen(const wchar_t *_Filename,int _OpenFlag,int _ShareFlag,...) ;



  int __attribute__((__cdecl__)) __lock_fhandle(int _Filehandle);
  void __attribute__((__cdecl__)) _unlock_fhandle(int _Filehandle);
  __attribute__ ((__dllimport__)) intptr_t __attribute__((__cdecl__)) _get_osfhandle(int _FileHandle);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _open_osfhandle(intptr_t _OSFileHandle,int _Flags);


  int __attribute__((__cdecl__)) access(const char *_Filename,int _AccessMode) ;
  int __attribute__((__cdecl__)) chmod(const char *_Filename,int _AccessMode) ;
  int __attribute__((__cdecl__)) chsize(int _FileHandle,long _Size) ;
  int __attribute__((__cdecl__)) close(int _FileHandle) ;
  int __attribute__((__cdecl__)) creat(const char *_Filename,int _PermissionMode) ;
  int __attribute__((__cdecl__)) dup(int _FileHandle) ;
  int __attribute__((__cdecl__)) dup2(int _FileHandleSrc,int _FileHandleDst) ;
  int __attribute__((__cdecl__)) eof(int _FileHandle) ;
  long __attribute__((__cdecl__)) filelength(int _FileHandle) ;
  int __attribute__((__cdecl__)) isatty(int _FileHandle) ;
  int __attribute__((__cdecl__)) locking(int _FileHandle,int _LockMode,long _NumOfBytes) ;
  long __attribute__((__cdecl__)) lseek(int _FileHandle,long _Offset,int _Origin) ;
  char *__attribute__((__cdecl__)) mktemp(char *_TemplateName) ;
  int __attribute__((__cdecl__)) open(const char *_Filename,int _OpenFlag,...) ;
  int __attribute__((__cdecl__)) read(int _FileHandle,void *_DstBuf,unsigned int _MaxCharCount) ;
  int __attribute__((__cdecl__)) setmode(int _FileHandle,int _Mode) ;
  int __attribute__((__cdecl__)) sopen(const char *_Filename,int _OpenFlag,int _ShareFlag,...) ;
  long __attribute__((__cdecl__)) tell(int _FileHandle) ;
  int __attribute__((__cdecl__)) umask(int _Mode) ;
  int __attribute__((__cdecl__)) write(int _Filehandle,const void *_Buf,unsigned int _MaxCharCount) ;
#pragma pack(pop)






typedef unsigned short _ino_t;

typedef unsigned short ino_t;





typedef unsigned int _dev_t;

typedef unsigned int dev_t;






typedef int _pid_t;







typedef _pid_t pid_t;





typedef unsigned short _mode_t;


typedef _mode_t mode_t;






typedef unsigned int useconds_t;




struct timespec {
  time_t tv_sec;
  long tv_nsec;
};

struct itimerspec {
  struct timespec it_interval;
  struct timespec it_value;
};
typedef unsigned long _sigset_t;
#pragma pack(push,_CRT_PACKING)
  struct _stat32 {
    _dev_t st_dev;
   _ino_t st_ino;
    unsigned short st_mode;
    short st_nlink;
    short st_uid;
    short st_gid;
    _dev_t st_rdev;
    _off_t st_size;
    __time32_t st_atime;
    __time32_t st_mtime;
    __time32_t st_ctime;
  };


  struct stat {
    _dev_t st_dev;
    _ino_t st_ino;
    unsigned short st_mode;
    short st_nlink;
    short st_uid;
    short st_gid;
    _dev_t st_rdev;
    _off_t st_size;
    time_t st_atime;
    time_t st_mtime;
    time_t st_ctime;
  };


  struct _stat32i64 {
    _dev_t st_dev;
    _ino_t st_ino;
    unsigned short st_mode;
    short st_nlink;
    short st_uid;
    short st_gid;
    _dev_t st_rdev;
    __extension__ long long st_size;
    __time32_t st_atime;
    __time32_t st_mtime;
    __time32_t st_ctime;
  };

  struct _stat64i32 {
    _dev_t st_dev;
    _ino_t st_ino;
    unsigned short st_mode;
    short st_nlink;
    short st_uid;
    short st_gid;
    _dev_t st_rdev;
    _off_t st_size;
    __time64_t st_atime;
    __time64_t st_mtime;
    __time64_t st_ctime;
  };

  struct _stat64 {
    _dev_t st_dev;
    _ino_t st_ino;
    unsigned short st_mode;
    short st_nlink;
    short st_uid;
    short st_gid;
    _dev_t st_rdev;
    __extension__ long long st_size;
    __time64_t st_atime;
    __time64_t st_mtime;
    __time64_t st_ctime;
  };
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fstat32(int _FileDes,struct _stat32 *_Stat);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _stat32(const char *_Name,struct _stat32 *_Stat);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fstat64(int _FileDes,struct _stat64 *_Stat);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _fstat32i64(int _FileDes,struct _stat32i64 *_Stat);
  int __attribute__((__cdecl__)) _fstat64i32(int _FileDes,struct _stat64i32 *_Stat);

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) _fstat64i32(int _FileDes,struct _stat64i32 *_Stat)
  {
    struct _stat64 st;
    int ret=_fstat64(_FileDes,&st);
    if (ret == -1) {
      memset(_Stat,0,sizeof(struct _stat64i32));
      return -1;
    }
    _Stat->st_dev=st.st_dev;
    _Stat->st_ino=st.st_ino;
    _Stat->st_mode=st.st_mode;
    _Stat->st_nlink=st.st_nlink;
    _Stat->st_uid=st.st_uid;
    _Stat->st_gid=st.st_gid;
    _Stat->st_rdev=st.st_rdev;
    _Stat->st_size=(_off_t) st.st_size;
    _Stat->st_atime=st.st_atime;
    _Stat->st_mtime=st.st_mtime;
    _Stat->st_ctime=st.st_ctime;
    return ret;
  }

  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _stat64(const char *_Name,struct _stat64 *_Stat);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _stat32i64(const char *_Name,struct _stat32i64 *_Stat);
  int __attribute__((__cdecl__)) _stat64i32(const char *_Name,struct _stat64i32 *_Stat);

  extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__)) _stat64i32(const char *_Name,struct _stat64i32 *_Stat)
  {
    struct _stat64 st;
    int ret=_stat64(_Name,&st);
    if (ret == -1) {
      memset(_Stat,0,sizeof(struct _stat64i32));
      return -1;
    }
    _Stat->st_dev=st.st_dev;
    _Stat->st_ino=st.st_ino;
    _Stat->st_mode=st.st_mode;
    _Stat->st_nlink=st.st_nlink;
    _Stat->st_uid=st.st_uid;
    _Stat->st_gid=st.st_gid;
    _Stat->st_rdev=st.st_rdev;
    _Stat->st_size=(_off_t) st.st_size;
    _Stat->st_atime=st.st_atime;
    _Stat->st_mtime=st.st_mtime;
    _Stat->st_ctime=st.st_ctime;
    return ret;
  }




  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wstat32(const wchar_t *_Name,struct _stat32 *_Stat);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wstat32i64(const wchar_t *_Name,struct _stat32i64 *_Stat);
  int __attribute__((__cdecl__)) _wstat64i32(const wchar_t *_Name,struct _stat64i32 *_Stat);
  __attribute__ ((__dllimport__)) int __attribute__((__cdecl__)) _wstat64(const wchar_t *_Name,struct _stat64 *_Stat);
int __attribute__((__cdecl__)) fstat(int _Desc,struct stat *_Stat);

  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) stat(const char *_Filename,struct stat *_Stat)
  {
    return _stat32(_Filename, (struct _stat32 *)_Stat);
  }
  static __attribute__ ((__unused__)) __inline__ __attribute__((__cdecl__)) int __attribute__((__cdecl__)) wstat(const wchar_t *_Filename,struct stat *_Stat)
  {
    return _wstat32(_Filename, (struct _stat32 *)_Stat);
  }







extern inline __attribute__((__gnu_inline__)) int __attribute__((__cdecl__))
 fstat(int _Desc,struct stat *_Stat) {
  struct _stat32 st;
  int ret=_fstat32(_Desc,&st);
  if (ret == -1) {
    memset(_Stat,0,sizeof(struct stat));
    return -1;
  }


  memcpy(_Stat, &st, sizeof(struct _stat32));
  return ret;
}
#pragma pack(pop)





typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef int int32_t;
typedef unsigned uint32_t;
__extension__ typedef long long int64_t;
__extension__ typedef unsigned long long uint64_t;


typedef signed char int_least8_t;
typedef unsigned char uint_least8_t;
typedef short int_least16_t;
typedef unsigned short uint_least16_t;
typedef int int_least32_t;
typedef unsigned uint_least32_t;
__extension__ typedef long long int_least64_t;
__extension__ typedef unsigned long long uint_least64_t;





typedef signed char int_fast8_t;
typedef unsigned char uint_fast8_t;
typedef short int_fast16_t;
typedef unsigned short uint_fast16_t;
typedef int int_fast32_t;
typedef unsigned int uint_fast32_t;
__extension__ typedef long long int_fast64_t;
__extension__ typedef unsigned long long uint_fast64_t;


__extension__ typedef long long intmax_t;
__extension__ typedef unsigned long long uintmax_t;






typedef struct {
 intmax_t quot;
 intmax_t rem;
 } imaxdiv_t;



intmax_t __attribute__((__cdecl__)) imaxabs (intmax_t j);

extern inline __attribute__((__gnu_inline__)) intmax_t __attribute__((__cdecl__)) imaxabs (intmax_t j)
 {return (j >= 0 ? j : -j);}

imaxdiv_t __attribute__((__cdecl__)) imaxdiv (intmax_t numer, intmax_t denom);



intmax_t __attribute__((__cdecl__)) strtoimax (const char* __restrict__ nptr,
                            char** __restrict__ endptr, int base);
uintmax_t __attribute__((__cdecl__)) strtoumax (const char* __restrict__ nptr,
        char** __restrict__ endptr, int base);

intmax_t __attribute__((__cdecl__)) wcstoimax (const wchar_t* __restrict__ nptr,
                            wchar_t** __restrict__ endptr, int base);
uintmax_t __attribute__((__cdecl__)) wcstoumax (const wchar_t* __restrict__ nptr,
        wchar_t** __restrict__ endptr, int base);











#pragma pack(push,_CRT_PACKING)





 struct _EXCEPTION_POINTERS;
  unsigned long __attribute__((__cdecl__)) _exception_code(void);
  void *__attribute__((__cdecl__)) _exception_info(void);
  int __attribute__((__cdecl__)) _abnormal_termination(void);






  typedef void (__attribute__((__cdecl__)) * _PHNDLR)(int);

  struct _XCPT_ACTION {
    unsigned long XcptNum;
    int SigNum;
    _PHNDLR XcptAction;
  };

  extern struct _XCPT_ACTION _XcptActTab[];
  extern int _XcptActTabCount;
  extern int _XcptActTabSize;
  extern int _First_FPE_Indx;
  extern int _Num_FPE;

  int __attribute__((__cdecl__)) __CppXcptFilter(unsigned long _ExceptionNum,struct _EXCEPTION_POINTERS * _ExceptionPtr);
  int __attribute__((__cdecl__)) _XcptFilter(unsigned long _ExceptionNum,struct _EXCEPTION_POINTERS * _ExceptionPtr);





  typedef int (*PEXCEPTION_HANDLER)(struct _EXCEPTION_RECORD*, void*, struct _CONTEXT*, void*);
#pragma pack(pop)













  typedef unsigned long ULONG;
  typedef ULONG *PULONG;
  typedef unsigned short USHORT;
  typedef USHORT *PUSHORT;
  typedef unsigned char UCHAR;
  typedef UCHAR *PUCHAR;
  typedef char *PSZ;
typedef int WINBOOL;



  typedef int BOOL;


typedef WINBOOL *PBOOL;
typedef WINBOOL *LPBOOL;



  typedef unsigned char BYTE;
  typedef unsigned short WORD;
  typedef unsigned long DWORD;
  typedef float FLOAT;
  typedef FLOAT *PFLOAT;
  typedef BYTE *PBYTE;
  typedef BYTE *LPBYTE;
  typedef int *PINT;
  typedef int *LPINT;
  typedef WORD *PWORD;
  typedef WORD *LPWORD;
  typedef long *LPLONG;
  typedef DWORD *PDWORD;
  typedef DWORD *LPDWORD;
  typedef void *LPVOID;


  typedef const void *LPCVOID;

  typedef int INT;
  typedef unsigned int UINT;
  typedef unsigned int *PUINT;


































unsigned char _interlockedbittestandset(long volatile *a, long b);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
unsigned char _interlockedbittestandset(long volatile *Base, long Offset) { unsigned int old, tmp1, tmp2; unsigned int bit = 1 << Offset; __asm__ __volatile__ ("dmb	sy\n\t" "1: ldrex	%[old], %[Base]\n\t" "mov	%[tmp1], %[old]\n\t" "orr" "	%[tmp1], %[tmp1], %[bit]\n\t" "strex	%[tmp2], %[tmp1], %[Base]\n\t" "cmp	%[tmp2], #0\n\t" "bne	1b\n\t" "dmb	sy" : [old] "=&r" (old), [tmp1] "=&r" (tmp1), [tmp2] "=&r" (tmp2), [Base] "+m" (*Base) : [bit] "r" (bit) : "memory", "cc"); return (old >> Offset) & 1; }





unsigned char _interlockedbittestandreset(long volatile *a, long b);
extern __inline__ __attribute__((__always_inline__,__gnu_inline__))

unsigned char _interlockedbittestandreset(long volatile *Base, long Offset) { unsigned int old, tmp1, tmp2; unsigned int bit = 1 << Offset; __asm__ __volatile__ ("dmb	sy\n\t" "1: ldrex	%[old], %[Base]\n\t" "mov	%[tmp1], %[old]\n\t" "bic" "	%[tmp1], %[tmp1], %[bit]\n\t" "strex	%[tmp2], %[tmp1], %[Base]\n\t" "cmp	%[tmp2], #0\n\t" "bne	1b\n\t" "dmb	sy" : [old] "=&r" (old), [tmp1] "=&r" (tmp1), [tmp2] "=&r" (tmp2), [Base] "+m" (*Base) : [bit] "r" (bit) : "memory", "cc"); return (old >> Offset) & 1; }





unsigned char _interlockedbittestandcomplement(long volatile *a, long b);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
unsigned char _interlockedbittestandcomplement(long volatile *Base, long Offset) { unsigned int old, tmp1, tmp2; unsigned int bit = 1 << Offset; __asm__ __volatile__ ("dmb	sy\n\t" "1: ldrex	%[old], %[Base]\n\t" "mov	%[tmp1], %[old]\n\t" "eor" "	%[tmp1], %[tmp1], %[bit]\n\t" "strex	%[tmp2], %[tmp1], %[Base]\n\t" "cmp	%[tmp2], #0\n\t" "bne	1b\n\t" "dmb	sy" : [old] "=&r" (old), [tmp1] "=&r" (tmp1), [tmp2] "=&r" (tmp2), [Base] "+m" (*Base) : [bit] "r" (bit) : "memory", "cc"); return (old >> Offset) & 1; }





unsigned char InterlockedBitTestAndSet(volatile long *a, long b);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
unsigned char InterlockedBitTestAndSet(long volatile *Base, long Offset) { unsigned int old, tmp1, tmp2; unsigned int bit = 1 << Offset; __asm__ __volatile__ ("dmb	sy\n\t" "1: ldrex	%[old], %[Base]\n\t" "mov	%[tmp1], %[old]\n\t" "orr" "	%[tmp1], %[tmp1], %[bit]\n\t" "strex	%[tmp2], %[tmp1], %[Base]\n\t" "cmp	%[tmp2], #0\n\t" "bne	1b\n\t" "dmb	sy" : [old] "=&r" (old), [tmp1] "=&r" (tmp1), [tmp2] "=&r" (tmp2), [Base] "+m" (*Base) : [bit] "r" (bit) : "memory", "cc"); return (old >> Offset) & 1; }





unsigned char InterlockedBitTestAndReset(volatile long *a, long b);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
unsigned char InterlockedBitTestAndReset(long volatile *Base, long Offset) { unsigned int old, tmp1, tmp2; unsigned int bit = 1 << Offset; __asm__ __volatile__ ("dmb	sy\n\t" "1: ldrex	%[old], %[Base]\n\t" "mov	%[tmp1], %[old]\n\t" "bic" "	%[tmp1], %[tmp1], %[bit]\n\t" "strex	%[tmp2], %[tmp1], %[Base]\n\t" "cmp	%[tmp2], #0\n\t" "bne	1b\n\t" "dmb	sy" : [old] "=&r" (old), [tmp1] "=&r" (tmp1), [tmp2] "=&r" (tmp2), [Base] "+m" (*Base) : [bit] "r" (bit) : "memory", "cc"); return (old >> Offset) & 1; }





unsigned char InterlockedBitTestAndComplement(volatile long *a, long b);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
unsigned char InterlockedBitTestAndComplement(long volatile *Base, long Offset) { unsigned int old, tmp1, tmp2; unsigned int bit = 1 << Offset; __asm__ __volatile__ ("dmb	sy\n\t" "1: ldrex	%[old], %[Base]\n\t" "mov	%[tmp1], %[old]\n\t" "eor" "	%[tmp1], %[tmp1], %[bit]\n\t" "strex	%[tmp2], %[tmp1], %[Base]\n\t" "cmp	%[tmp2], #0\n\t" "bne	1b\n\t" "dmb	sy" : [old] "=&r" (old), [tmp1] "=&r" (tmp1), [tmp2] "=&r" (tmp2), [Base] "+m" (*Base) : [bit] "r" (bit) : "memory", "cc"); return (old >> Offset) & 1; }





__extension__ unsigned char _BitScanForward(unsigned long *Index, unsigned long Mask);

__extension__ extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
unsigned char _BitScanForward(unsigned long *Index, unsigned long Mask)
{
    if (Mask == 0)
        return 0;
    *Index = __builtin_ctz(Mask);
    return 1;
}





__extension__ unsigned char _BitScanReverse(unsigned long *Index, unsigned long Mask);

__extension__ extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
unsigned char _BitScanReverse(unsigned long *Index, unsigned long Mask)
{
    if (Mask == 0)
        return 0;
    *Index = 31 - __builtin_clz(Mask);
    return 1;
}
long _InterlockedAnd(long volatile *, long);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedAnd(volatile long *Destination, long Value) { return __sync_fetch_and_and(Destination, Value); }





long _InterlockedOr(long volatile *, long);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedOr(volatile long *Destination, long Value) { return __sync_fetch_and_or(Destination, Value); }





long _InterlockedXor(long volatile *, long);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedXor(volatile long *Destination, long Value) { return __sync_fetch_and_xor(Destination, Value); }





short _InterlockedIncrement16(short volatile *Addend);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
short _InterlockedIncrement16(short volatile *Addend) {
    return __sync_add_and_fetch(Addend, 1);
}





short _InterlockedDecrement16(short volatile *Addend);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
short _InterlockedDecrement16(short volatile *Addend) {
    return __sync_sub_and_fetch(Addend, 1);
}





short _InterlockedCompareExchange16(short volatile *Destination, short ExChange, short Comperand);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
short _InterlockedCompareExchange16(short volatile *Destination, short ExChange, short Comperand) {
    return __sync_val_compare_and_swap(Destination, Comperand, ExChange);
}





long _InterlockedExchangeAdd(long volatile *Addend, long Value);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedExchangeAdd(long volatile *Addend, long Value) {
    return __sync_fetch_and_add(Addend, Value);
}





long _InterlockedCompareExchange(long volatile *Destination, long ExChange, long Comperand);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedCompareExchange(long volatile *Destination, long ExChange, long Comperand) {
    return __sync_val_compare_and_swap(Destination, Comperand, ExChange);
}





long _InterlockedIncrement(long volatile *Addend);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedIncrement(long volatile *Addend) {
   return __sync_add_and_fetch(Addend, 1);
}





long _InterlockedDecrement(long volatile *Addend);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedDecrement(long volatile *Addend) {
   return __sync_sub_and_fetch(Addend, 1);
}





long _InterlockedAdd(long volatile *Addend, long Value);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedAdd(long volatile *Addend, long Value) {
    return __sync_add_and_fetch(Addend, Value);
}





__extension__ long long _InterlockedAdd64(long long volatile *Addend, long long Value);

__extension__ extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long long _InterlockedAdd64(long long volatile *Addend, long long Value) {
    return __sync_add_and_fetch(Addend, Value);
}





long _InterlockedExchange(long volatile *Target, long Value);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long _InterlockedExchange(long volatile *Target, long Value) {
    return __sync_lock_test_and_set(Target, Value);
}





__extension__ long long _InterlockedCompareExchange64(long long volatile *Destination, long long ExChange, long long Comperand);

__extension__ extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
long long _InterlockedCompareExchange64(long long volatile *Destination, long long ExChange, long long Comperand) {
    return __sync_val_compare_and_swap(Destination, Comperand, ExChange);
}





void *_InterlockedCompareExchangePointer(void * volatile *Destination, void *ExChange, void *Comperand);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
void *_InterlockedCompareExchangePointer(void *volatile *Destination, void *ExChange, void *Comperand) {
    return __sync_val_compare_and_swap(Destination, Comperand, ExChange);
}





void *_InterlockedExchangePointer(void *volatile *Target,void *Value);

extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
void *_InterlockedExchangePointer(void *volatile *Target,void *Value) {
    return __sync_lock_test_and_set(Target, Value);
}











typedef unsigned long POINTER_64_INT;
  typedef signed char INT8,*PINT8;
  typedef signed short INT16,*PINT16;
  typedef signed int INT32,*PINT32;
  __extension__ typedef signed long long INT64,*PINT64;
  typedef unsigned char UINT8,*PUINT8;
  typedef unsigned short UINT16,*PUINT16;
  typedef unsigned int UINT32,*PUINT32;
  __extension__ typedef unsigned long long UINT64,*PUINT64;
  typedef signed int LONG32,*PLONG32;
  typedef unsigned int ULONG32,*PULONG32;
  typedef unsigned int DWORD32,*PDWORD32;
  typedef int INT_PTR,*PINT_PTR;
  typedef unsigned int UINT_PTR,*PUINT_PTR;
  typedef long LONG_PTR,*PLONG_PTR;
  typedef unsigned long ULONG_PTR,*PULONG_PTR;
  typedef unsigned short UHALF_PTR,*PUHALF_PTR;
  typedef short HALF_PTR,*PHALF_PTR;
  typedef long SHANDLE_PTR;
  typedef unsigned long HANDLE_PTR;
  static __inline void * PtrToPtr64 (const void *p) { return ((void *) (ULONG_PTR) p); }
  static __inline void *Ptr64ToPtr (const void * p) { return ((void *) (ULONG_PTR) p); }
  static __inline void * HandleToHandle64 (const void *h) { return ((void *) (LONG_PTR) h); }
  static __inline void *Handle64ToHandle (const void * h) { return ((void *) (ULONG_PTR) h); }
  __extension__ typedef ULONG_PTR SIZE_T,*PSIZE_T;
  __extension__ typedef LONG_PTR SSIZE_T,*PSSIZE_T;
  __extension__ typedef ULONG_PTR DWORD_PTR,*PDWORD_PTR;
  __extension__ typedef long long LONG64,*PLONG64;
  __extension__ typedef unsigned long long ULONG64,*PULONG64;
  __extension__ typedef unsigned long long DWORD64,*PDWORD64;
  __extension__ typedef ULONG_PTR KAFFINITY;
  __extension__ typedef KAFFINITY *PKAFFINITY;
  typedef void *PVOID;
  typedef void *PVOID64;
  typedef char CHAR;
  typedef short SHORT;
  typedef long LONG;

  typedef int INT;





  typedef wchar_t WCHAR;

  typedef WCHAR *PWCHAR,*LPWCH,*PWCH;
  typedef const WCHAR *LPCWCH,*PCWCH;
  typedef WCHAR *NWPSTR,*LPWSTR,*PWSTR;
  typedef PWSTR *PZPWSTR;
  typedef const PWSTR *PCZPWSTR;
  typedef WCHAR *LPUWSTR,*PUWSTR;
  typedef const WCHAR *LPCWSTR,*PCWSTR;
  typedef PCWSTR *PZPCWSTR;
  typedef const WCHAR *LPCUWSTR,*PCUWSTR;
  typedef WCHAR *PZZWSTR;
  typedef const WCHAR *PCZZWSTR;
  typedef WCHAR *PUZZWSTR;
  typedef const WCHAR *PCUZZWSTR;
  typedef WCHAR *PNZWCH;
  typedef const WCHAR *PCNZWCH;
  typedef WCHAR *PUNZWCH;
  typedef const WCHAR *PCUNZWCH;


  typedef const WCHAR *LPCWCHAR,*PCWCHAR;
  typedef const WCHAR *LPCUWCHAR,*PCUWCHAR;
  typedef unsigned long UCSCHAR;





  typedef UCSCHAR *PUCSCHAR;
  typedef const UCSCHAR *PCUCSCHAR;
  typedef UCSCHAR *PUCSSTR;
  typedef UCSCHAR *PUUCSSTR;
  typedef const UCSCHAR *PCUCSSTR;
  typedef const UCSCHAR *PCUUCSSTR;
  typedef UCSCHAR *PUUCSCHAR;
  typedef const UCSCHAR *PCUUCSCHAR;


  typedef CHAR *PCHAR,*LPCH,*PCH;
  typedef const CHAR *LPCCH,*PCCH;
  typedef CHAR *NPSTR,*LPSTR,*PSTR;
  typedef PSTR *PZPSTR;
  typedef const PSTR *PCZPSTR;
  typedef const CHAR *LPCSTR,*PCSTR;
  typedef PCSTR *PZPCSTR;
  typedef CHAR *PZZSTR;
  typedef const CHAR *PCZZSTR;
  typedef CHAR *PNZCH;
  typedef const CHAR *PCNZCH;
  typedef char TCHAR, *PTCHAR;
  typedef unsigned char TBYTE, *PTBYTE;


  typedef LPSTR LPTCH,PTCH;
  typedef LPCCH LPCTCH,PCTCH;
  typedef LPSTR PTSTR,LPTSTR,PUTSTR,LPUTSTR;
  typedef LPCSTR PCTSTR,LPCTSTR,PCUTSTR,LPCUTSTR;
  typedef PZZSTR PZZTSTR, PUZZTSTR;
  typedef PCZZSTR PCZZTSTR, PCUZZTSTR;
  typedef PZPSTR PZPTSTR;
  typedef PNZCH PNZTCH, PUNZTCH;
  typedef PCNZCH PCNZTCH, PCUNZTCH;






  typedef SHORT *PSHORT;
  typedef LONG *PLONG;



typedef struct _GROUP_AFFINITY {
  KAFFINITY Mask;
  WORD Group;
  WORD Reserved[3];
} GROUP_AFFINITY, *PGROUP_AFFINITY;



  typedef void *HANDLE;






  typedef HANDLE *PHANDLE;
  typedef BYTE FCHAR;
  typedef WORD FSHORT;
  typedef DWORD FLONG;



  typedef LONG HRESULT;
  typedef char CCHAR;


typedef DWORD LCID;

  typedef PDWORD PLCID;


  typedef WORD LANGID;





typedef enum {
  UNSPECIFIED_COMPARTMENT_ID = 0,
  DEFAULT_COMPARTMENT_ID
} COMPARTMENT_ID,*PCOMPARTMENT_ID;
    typedef struct _FLOAT128 {
      __extension__ long long LowPart;
      __extension__ long long HighPart;
  } FLOAT128;

  typedef FLOAT128 *PFLOAT128;


  __extension__ typedef long long LONGLONG;
  __extension__ typedef unsigned long long ULONGLONG;



  typedef LONGLONG *PLONGLONG;
  typedef ULONGLONG *PULONGLONG;
  typedef LONGLONG USN;







  typedef union _LARGE_INTEGER {
    __extension__ struct {
      DWORD LowPart;
      LONG HighPart;
    } ;
    struct {
      DWORD LowPart;
      LONG HighPart;
    } u;

    LONGLONG QuadPart;
  } LARGE_INTEGER;

  typedef LARGE_INTEGER *PLARGE_INTEGER;




  typedef union _ULARGE_INTEGER {
    __extension__ struct {
      DWORD LowPart;
      DWORD HighPart;
    } ;
    struct {
      DWORD LowPart;
      DWORD HighPart;
    } u;

    ULONGLONG QuadPart;
  } ULARGE_INTEGER;

  typedef ULARGE_INTEGER *PULARGE_INTEGER;

  typedef struct _LUID {
    DWORD LowPart;
    LONG HighPart;
  } LUID,*PLUID;




  typedef ULONGLONG DWORDLONG;
  typedef DWORDLONG *PDWORDLONG;
    unsigned int __attribute__((__cdecl__)) _rotl(unsigned int Value,int Shift);
    unsigned int __attribute__((__cdecl__)) _rotr(unsigned int Value,int Shift);






    __extension__ unsigned long long __attribute__((__cdecl__)) _rotl64(unsigned long long Value,int Shift);
    __extension__ unsigned long long __attribute__((__cdecl__)) _rotr64(unsigned long long Value,int Shift);
  typedef BYTE BOOLEAN;

  typedef BOOLEAN *PBOOLEAN;




  typedef struct _LIST_ENTRY {
    struct _LIST_ENTRY *Flink;
    struct _LIST_ENTRY *Blink;
  } LIST_ENTRY,*PLIST_ENTRY,* PRLIST_ENTRY;

  typedef struct _SINGLE_LIST_ENTRY {
    struct _SINGLE_LIST_ENTRY *Next;
  } SINGLE_LIST_ENTRY,*PSINGLE_LIST_ENTRY;

  typedef struct LIST_ENTRY32 {
    DWORD Flink;
    DWORD Blink;
  } LIST_ENTRY32;
  typedef LIST_ENTRY32 *PLIST_ENTRY32;

  typedef struct LIST_ENTRY64 {
    ULONGLONG Flink;
    ULONGLONG Blink;
  } LIST_ENTRY64;
  typedef LIST_ENTRY64 *PLIST_ENTRY64;












typedef struct _GUID {
  unsigned long Data1;
  unsigned short Data2;
  unsigned short Data3;
  unsigned char Data4[8];
} GUID;
typedef GUID *LPGUID;




typedef const GUID *LPCGUID;





typedef GUID IID;
typedef IID *LPIID;






typedef GUID CLSID;


typedef CLSID *LPCLSID;



typedef GUID FMTID;
typedef FMTID *LPFMTID;



  typedef struct _OBJECTID {
    GUID Lineage;
    DWORD Uniquifier;
  } OBJECTID;
    typedef int EXCEPTION_ROUTINE (struct _EXCEPTION_RECORD *ExceptionRecord, PVOID EstablisherFrame, struct _CONTEXT *ContextRecord, PVOID DispatcherContext);


    typedef EXCEPTION_ROUTINE *PEXCEPTION_ROUTINE;
  typedef ULONG_PTR KSPIN_LOCK;
  typedef KSPIN_LOCK *PKSPIN_LOCK;

    typedef struct __attribute__ ((__aligned__ (16))) _M128A {
      ULONGLONG Low;
      LONGLONG High;
    } M128A,*PM128A;

    typedef struct __attribute__ ((__aligned__ (16))) _XSAVE_FORMAT {
      WORD ControlWord;
      WORD StatusWord;
      BYTE TagWord;
      BYTE Reserved1;
      WORD ErrorOpcode;
      DWORD ErrorOffset;
      WORD ErrorSelector;
      WORD Reserved2;
      DWORD DataOffset;
      WORD DataSelector;
      WORD Reserved3;
      DWORD MxCsr;
      DWORD MxCsr_Mask;
      M128A FloatRegisters[8];




      M128A XmmRegisters[8];
      BYTE Reserved4[220];
      DWORD Cr0NpxState;

    } XSAVE_FORMAT,*PXSAVE_FORMAT;

    typedef struct __attribute__ ((__aligned__ (8))) _XSAVE_AREA_HEADER {
      DWORD64 Mask;
      DWORD64 Reserved[7];
    } XSAVE_AREA_HEADER,*PXSAVE_AREA_HEADER;

    typedef struct __attribute__ ((__aligned__ (16))) _XSAVE_AREA {
      XSAVE_FORMAT LegacyState;
      XSAVE_AREA_HEADER Header;
    } XSAVE_AREA,*PXSAVE_AREA;

    typedef struct _XSTATE_CONTEXT {
      DWORD64 Mask;
      DWORD Length;
      DWORD Reserved1;
      PXSAVE_AREA Area;



      PVOID Buffer;



    } XSTATE_CONTEXT,*PXSTATE_CONTEXT;

    typedef struct _SCOPE_TABLE_AMD64 {
      DWORD Count;
      struct {
 DWORD BeginAddress;
 DWORD EndAddress;
 DWORD HandlerAddress;
 DWORD JumpTarget;
      } ScopeRecord[1];
    } SCOPE_TABLE_AMD64,*PSCOPE_TABLE_AMD64;
  typedef struct _NEON128 {
    ULONGLONG Low;
    LONGLONG High;
  } NEON128, *PNEON128;

  typedef struct _CONTEXT {
    DWORD ContextFlags;

    DWORD R0;
    DWORD R1;
    DWORD R2;
    DWORD R3;
    DWORD R4;
    DWORD R5;
    DWORD R6;
    DWORD R7;
    DWORD R8;
    DWORD R9;
    DWORD R10;
    DWORD R11;
    DWORD R12;

    DWORD Sp;
    DWORD Lr;
    DWORD Pc;
    DWORD Cpsr;

    DWORD Fpscr;
    DWORD Padding;
    union {
        NEON128 Q[16];
        ULONGLONG D[32];
        DWORD S[32];
    } ;

    DWORD Bvr[8];
    DWORD Bcr[8];
    DWORD Wvr[1];
    DWORD Wcr[1];

    DWORD Padding2[2];
  } CONTEXT, *PCONTEXT;

  typedef struct _IMAGE_ARM_RUNTIME_FUNCTION_ENTRY RUNTIME_FUNCTION, *PRUNTIME_FUNCTION;
  typedef PRUNTIME_FUNCTION (*PGET_RUNTIME_FUNCTION_CALLBACK)(DWORD64 ControlPc,PVOID Context);







  typedef struct _UNWIND_HISTORY_TABLE_ENTRY {
    DWORD ImageBase;
    PRUNTIME_FUNCTION FunctionEntry;
  } UNWIND_HISTORY_TABLE_ENTRY, *PUNWIND_HISTORY_TABLE_ENTRY;

  typedef struct _UNWIND_HISTORY_TABLE {
    DWORD Count;
    BYTE LocalHint;
    BYTE GlobalHint;
    BYTE Search;
    BYTE Once;
    DWORD LowAddress;
    DWORD HighAddress;
    UNWIND_HISTORY_TABLE_ENTRY Entry[12];
  } UNWIND_HISTORY_TABLE, *PUNWIND_HISTORY_TABLE;

  typedef struct _KNONVOLATILE_CONTEXT_POINTERS {
    PDWORD R4;
    PDWORD R5;
    PDWORD R6;
    PDWORD R7;
    PDWORD R8;
    PDWORD R9;
    PDWORD R10;
    PDWORD R11;
    PDWORD Lr;
    PULONGLONG D8;
    PULONGLONG D9;
    PULONGLONG D10;
    PULONGLONG D11;
    PULONGLONG D12;
    PULONGLONG D13;
    PULONGLONG D14;
    PULONGLONG D15;
  } KNONVOLATILE_CONTEXT_POINTERS, *PKNONVOLATILE_CONTEXT_POINTERS;
    typedef struct _LDT_ENTRY {
      WORD LimitLow;
      WORD BaseLow;
      union {
 struct {
   BYTE BaseMid;
   BYTE Flags1;
   BYTE Flags2;
   BYTE BaseHi;
 } Bytes;
 struct {
   DWORD BaseMid : 8;
   DWORD Type : 5;
   DWORD Dpl : 2;
   DWORD Pres : 1;
   DWORD LimitHi : 4;
   DWORD Sys : 1;
   DWORD Reserved_0 : 1;
   DWORD Default_Big : 1;
   DWORD Granularity : 1;
   DWORD BaseHi : 8;
 } Bits;
      } HighWord;
    } LDT_ENTRY,*PLDT_ENTRY;
    typedef struct _EXCEPTION_RECORD {
      DWORD ExceptionCode;
      DWORD ExceptionFlags;
      struct _EXCEPTION_RECORD *ExceptionRecord;
      PVOID ExceptionAddress;
      DWORD NumberParameters;
      ULONG_PTR ExceptionInformation[15];
    } EXCEPTION_RECORD;

    typedef EXCEPTION_RECORD *PEXCEPTION_RECORD;

    typedef struct _EXCEPTION_RECORD32 {
      DWORD ExceptionCode;
      DWORD ExceptionFlags;
      DWORD ExceptionRecord;
      DWORD ExceptionAddress;
      DWORD NumberParameters;
      DWORD ExceptionInformation[15];
    } EXCEPTION_RECORD32,*PEXCEPTION_RECORD32;

    typedef struct _EXCEPTION_RECORD64 {
      DWORD ExceptionCode;
      DWORD ExceptionFlags;
      DWORD64 ExceptionRecord;
      DWORD64 ExceptionAddress;
      DWORD NumberParameters;
      DWORD __unusedAlignment;
      DWORD64 ExceptionInformation[15];
    } EXCEPTION_RECORD64,*PEXCEPTION_RECORD64;

    typedef struct _EXCEPTION_POINTERS {
      PEXCEPTION_RECORD ExceptionRecord;
      PCONTEXT ContextRecord;
    } EXCEPTION_POINTERS,*PEXCEPTION_POINTERS;
    typedef PVOID PACCESS_TOKEN;
    typedef PVOID PSECURITY_DESCRIPTOR;
    typedef PVOID PSID;
    typedef PVOID PCLAIMS_BLOB;
    typedef DWORD ACCESS_MASK;
    typedef ACCESS_MASK *PACCESS_MASK;
    typedef struct _GENERIC_MAPPING {
      ACCESS_MASK GenericRead;
      ACCESS_MASK GenericWrite;
      ACCESS_MASK GenericExecute;
      ACCESS_MASK GenericAll;
    } GENERIC_MAPPING;
    typedef GENERIC_MAPPING *PGENERIC_MAPPING;








#pragma pack(push,4)
 typedef struct _LUID_AND_ATTRIBUTES {
      LUID Luid;
      DWORD Attributes;
    } LUID_AND_ATTRIBUTES,*PLUID_AND_ATTRIBUTES;
    typedef LUID_AND_ATTRIBUTES LUID_AND_ATTRIBUTES_ARRAY[1];
    typedef LUID_AND_ATTRIBUTES_ARRAY *PLUID_AND_ATTRIBUTES_ARRAY;







#pragma pack(pop)



    typedef struct _SID_IDENTIFIER_AUTHORITY {
      BYTE Value[6];
    } SID_IDENTIFIER_AUTHORITY,*PSID_IDENTIFIER_AUTHORITY;




    typedef struct _SID {
      BYTE Revision;
      BYTE SubAuthorityCount;
      SID_IDENTIFIER_AUTHORITY IdentifierAuthority;
      DWORD SubAuthority[1];
    } SID,*PISID;
    typedef enum _SID_NAME_USE {
      SidTypeUser = 1,SidTypeGroup,SidTypeDomain,SidTypeAlias,SidTypeWellKnownGroup,SidTypeDeletedAccount,SidTypeInvalid,SidTypeUnknown,SidTypeComputer,SidTypeLabel
    } SID_NAME_USE,*PSID_NAME_USE;

    typedef struct _SID_AND_ATTRIBUTES {



      PSID Sid;

      DWORD Attributes;
    } SID_AND_ATTRIBUTES,*PSID_AND_ATTRIBUTES;

    typedef SID_AND_ATTRIBUTES SID_AND_ATTRIBUTES_ARRAY[1];
    typedef SID_AND_ATTRIBUTES_ARRAY *PSID_AND_ATTRIBUTES_ARRAY;

    typedef ULONG_PTR SID_HASH_ENTRY, *PSID_HASH_ENTRY;

    typedef struct _SID_AND_ATTRIBUTES_HASH {
      DWORD SidCount;
      PSID_AND_ATTRIBUTES SidAttr;
      SID_HASH_ENTRY Hash[32];
    } SID_AND_ATTRIBUTES_HASH, *PSID_AND_ATTRIBUTES_HASH;
    typedef enum {
      WinNullSid = 0,WinWorldSid = 1,WinLocalSid = 2,WinCreatorOwnerSid = 3,
      WinCreatorGroupSid = 4,WinCreatorOwnerServerSid = 5,
      WinCreatorGroupServerSid = 6,WinNtAuthoritySid = 7,WinDialupSid = 8,
      WinNetworkSid = 9,WinBatchSid = 10,WinInteractiveSid = 11,
      WinServiceSid = 12,WinAnonymousSid = 13,WinProxySid = 14,
      WinEnterpriseControllersSid = 15,WinSelfSid = 16,
      WinAuthenticatedUserSid = 17,WinRestrictedCodeSid = 18,
      WinTerminalServerSid = 19,WinRemoteLogonIdSid = 20,WinLogonIdsSid = 21,
      WinLocalSystemSid = 22,WinLocalServiceSid = 23,WinNetworkServiceSid = 24,
      WinBuiltinDomainSid = 25,WinBuiltinAdministratorsSid = 26,
      WinBuiltinUsersSid = 27,WinBuiltinGuestsSid = 28,
      WinBuiltinPowerUsersSid = 29,WinBuiltinAccountOperatorsSid = 30,
      WinBuiltinSystemOperatorsSid = 31,WinBuiltinPrintOperatorsSid = 32,
      WinBuiltinBackupOperatorsSid = 33,WinBuiltinReplicatorSid = 34,
      WinBuiltinPreWindows2000CompatibleAccessSid = 35,
      WinBuiltinRemoteDesktopUsersSid = 36,
      WinBuiltinNetworkConfigurationOperatorsSid = 37,
      WinAccountAdministratorSid = 38,WinAccountGuestSid = 39,
      WinAccountKrbtgtSid = 40,WinAccountDomainAdminsSid = 41,
      WinAccountDomainUsersSid = 42,WinAccountDomainGuestsSid = 43,
      WinAccountComputersSid = 44,WinAccountControllersSid = 45,
      WinAccountCertAdminsSid = 46,WinAccountSchemaAdminsSid = 47,
      WinAccountEnterpriseAdminsSid = 48,WinAccountPolicyAdminsSid = 49,
      WinAccountRasAndIasServersSid = 50,WinNTLMAuthenticationSid = 51,
      WinDigestAuthenticationSid = 52,WinSChannelAuthenticationSid = 53,
      WinThisOrganizationSid = 54,WinOtherOrganizationSid = 55,
      WinBuiltinIncomingForestTrustBuildersSid = 56,
      WinBuiltinPerfMonitoringUsersSid = 57,WinBuiltinPerfLoggingUsersSid = 58,
      WinBuiltinAuthorizationAccessSid = 59,
      WinBuiltinTerminalServerLicenseServersSid = 60,
      WinBuiltinDCOMUsersSid = 61,WinBuiltinIUsersSid = 62,
      WinIUserSid = 63, WinBuiltinCryptoOperatorsSid = 64,
      WinUntrustedLabelSid = 65, WinLowLabelSid = 66, WinMediumLabelSid = 67,
      WinHighLabelSid = 68, WinSystemLabelSid = 69, WinWriteRestrictedCodeSid = 70,
      WinCreatorOwnerRightsSid = 71, WinCacheablePrincipalsGroupSid = 72,
      WinNonCacheablePrincipalsGroupSid = 73, WinEnterpriseReadonlyControllersSid = 74,
      WinAccountReadonlyControllersSid = 75, WinBuiltinEventLogReadersGroup = 76,
      WinNewEnterpriseReadonlyControllersSid = 77, WinBuiltinCertSvcDComAccessGroup = 78,
      WinMediumPlusLabelSid = 79, WinLocalLogonSid = 80, WinConsoleLogonSid = 81,
      WinThisOrganizationCertificateSid = 82, WinApplicationPackageAuthoritySid = 83,
      WinBuiltinAnyPackageSid = 84, WinCapabilityInternetClientSid = 85,
      WinCapabilityInternetClientServerSid = 86,
      WinCapabilityPrivateNetworkClientServerSid = 87,
      WinCapabilityPicturesLibrarySid = 88, WinCapabilityVideosLibrarySid = 89,
      WinCapabilityMusicLibrarySid = 90, WinCapabilityDocumentsLibrarySid = 91,
      WinCapabilitySharedUserCertificatesSid = 92, WinCapabilityEnterpriseAuthenticationSid = 93,
      WinCapabilityRemovableStorageSid = 94, WinBuiltinRDSRemoteAccessServersSid = 95,
      WinBuiltinRDSEndpointServersSid = 96, WinBuiltinRDSManagementServersSid = 97,
      WinUserModeDriversSid = 98, WinBuiltinHyperVAdminsSid = 99,
      WinAccountCloneableControllersSid = 100,
      WinBuiltinAccessControlAssistanceOperatorsSid = 101,
      WinBuiltinRemoteManagementUsersSid = 102, WinAuthenticationAuthorityAssertedSid = 103,
      WinAuthenticationServiceAssertedSid = 104,
      WinLocalAccountSid = 105,
      WinLocalAccountAndAdministratorSid = 106,
      WinAccountProtectedUsersSid = 107,
      WinCapabilityAppointmentsSid = 108,
      WinCapabilityContactsSid = 109,
      WinAccountDefaultSystemManagedSid = 110,
      WinBuiltinDefaultSystemManagedGroupSid = 111,
      WinBuiltinStorageReplicaAdminsSid = 112,
      WinAccountKeyAdminsSid = 113,
      WinAccountEnterpriseKeyAdminsSid = 114,
      WinAuthenticationKeyTrustSid = 115,
      WinAuthenticationKeyPropertyMFASid = 116,
      WinAuthenticationKeyPropertyAttestationSid = 117
} WELL_KNOWN_SID_TYPE;
    typedef struct _ACL {
      BYTE AclRevision;
      BYTE Sbz1;
      WORD AclSize;
      WORD AceCount;
      WORD Sbz2;
    } ACL;
    typedef ACL *PACL;

    typedef struct _ACE_HEADER {
      BYTE AceType;
      BYTE AceFlags;
      WORD AceSize;
    } ACE_HEADER;
    typedef ACE_HEADER *PACE_HEADER;
    typedef struct _ACCESS_ALLOWED_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } ACCESS_ALLOWED_ACE;

    typedef ACCESS_ALLOWED_ACE *PACCESS_ALLOWED_ACE;

    typedef struct _ACCESS_DENIED_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } ACCESS_DENIED_ACE;
    typedef ACCESS_DENIED_ACE *PACCESS_DENIED_ACE;

    typedef struct _SYSTEM_AUDIT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } SYSTEM_AUDIT_ACE;
    typedef SYSTEM_AUDIT_ACE *PSYSTEM_AUDIT_ACE;

    typedef struct _SYSTEM_ALARM_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } SYSTEM_ALARM_ACE;
    typedef SYSTEM_ALARM_ACE *PSYSTEM_ALARM_ACE;

    typedef struct _SYSTEM_RESOURCE_ATTRIBUTE_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } SYSTEM_RESOURCE_ATTRIBUTE_ACE,*PSYSTEM_RESOURCE_ATTRIBUTE_ACE;

    typedef struct _SYSTEM_SCOPED_POLICY_ID_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } SYSTEM_SCOPED_POLICY_ID_ACE,*PSYSTEM_SCOPED_POLICY_ID_ACE;

    typedef struct _SYSTEM_MANDATORY_LABEL_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } SYSTEM_MANDATORY_LABEL_ACE, *PSYSTEM_MANDATORY_LABEL_ACE;







    typedef struct _ACCESS_ALLOWED_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;
    } ACCESS_ALLOWED_OBJECT_ACE,*PACCESS_ALLOWED_OBJECT_ACE;

    typedef struct _ACCESS_DENIED_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;
    } ACCESS_DENIED_OBJECT_ACE,*PACCESS_DENIED_OBJECT_ACE;

    typedef struct _SYSTEM_AUDIT_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;
    } SYSTEM_AUDIT_OBJECT_ACE,*PSYSTEM_AUDIT_OBJECT_ACE;

    typedef struct _SYSTEM_ALARM_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;
    } SYSTEM_ALARM_OBJECT_ACE,*PSYSTEM_ALARM_OBJECT_ACE;

    typedef struct _ACCESS_ALLOWED_CALLBACK_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } ACCESS_ALLOWED_CALLBACK_ACE,*PACCESS_ALLOWED_CALLBACK_ACE;

    typedef struct _ACCESS_DENIED_CALLBACK_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } ACCESS_DENIED_CALLBACK_ACE,*PACCESS_DENIED_CALLBACK_ACE;

    typedef struct _SYSTEM_AUDIT_CALLBACK_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } SYSTEM_AUDIT_CALLBACK_ACE,*PSYSTEM_AUDIT_CALLBACK_ACE;

    typedef struct _SYSTEM_ALARM_CALLBACK_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD SidStart;
    } SYSTEM_ALARM_CALLBACK_ACE,*PSYSTEM_ALARM_CALLBACK_ACE;

    typedef struct _ACCESS_ALLOWED_CALLBACK_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;

    } ACCESS_ALLOWED_CALLBACK_OBJECT_ACE,*PACCESS_ALLOWED_CALLBACK_OBJECT_ACE;

    typedef struct _ACCESS_DENIED_CALLBACK_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;
    } ACCESS_DENIED_CALLBACK_OBJECT_ACE,*PACCESS_DENIED_CALLBACK_OBJECT_ACE;

    typedef struct _SYSTEM_AUDIT_CALLBACK_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;
    } SYSTEM_AUDIT_CALLBACK_OBJECT_ACE,*PSYSTEM_AUDIT_CALLBACK_OBJECT_ACE;

    typedef struct _SYSTEM_ALARM_CALLBACK_OBJECT_ACE {
      ACE_HEADER Header;
      ACCESS_MASK Mask;
      DWORD Flags;
      GUID ObjectType;
      GUID InheritedObjectType;
      DWORD SidStart;

    } SYSTEM_ALARM_CALLBACK_OBJECT_ACE,*PSYSTEM_ALARM_CALLBACK_OBJECT_ACE;




    typedef enum _ACL_INFORMATION_CLASS {
      AclRevisionInformation = 1,AclSizeInformation
    } ACL_INFORMATION_CLASS;

    typedef struct _ACL_REVISION_INFORMATION {
      DWORD AclRevision;
    } ACL_REVISION_INFORMATION;
    typedef ACL_REVISION_INFORMATION *PACL_REVISION_INFORMATION;

    typedef struct _ACL_SIZE_INFORMATION {
      DWORD AceCount;
      DWORD AclBytesInUse;
      DWORD AclBytesFree;
    } ACL_SIZE_INFORMATION;
    typedef ACL_SIZE_INFORMATION *PACL_SIZE_INFORMATION;






    typedef WORD SECURITY_DESCRIPTOR_CONTROL,*PSECURITY_DESCRIPTOR_CONTROL;
    typedef struct _SECURITY_DESCRIPTOR_RELATIVE {
      BYTE Revision;
      BYTE Sbz1;
      SECURITY_DESCRIPTOR_CONTROL Control;
      DWORD Owner;
      DWORD Group;
      DWORD Sacl;
      DWORD Dacl;
    } SECURITY_DESCRIPTOR_RELATIVE,*PISECURITY_DESCRIPTOR_RELATIVE;

    typedef struct _SECURITY_DESCRIPTOR {
      BYTE Revision;
      BYTE Sbz1;
      SECURITY_DESCRIPTOR_CONTROL Control;
      PSID Owner;
      PSID Group;
      PACL Sacl;
      PACL Dacl;
    } SECURITY_DESCRIPTOR,*PISECURITY_DESCRIPTOR;

    typedef struct _OBJECT_TYPE_LIST {
      WORD Level;
      WORD Sbz;
      GUID *ObjectType;
    } OBJECT_TYPE_LIST,*POBJECT_TYPE_LIST;







    typedef enum _AUDIT_EVENT_TYPE {
      AuditEventObjectAccess,AuditEventDirectoryServiceAccess
    } AUDIT_EVENT_TYPE,*PAUDIT_EVENT_TYPE;
    typedef struct _PRIVILEGE_SET {
      DWORD PrivilegeCount;
      DWORD Control;
      LUID_AND_ATTRIBUTES Privilege[1];
    } PRIVILEGE_SET,*PPRIVILEGE_SET;







    typedef enum _ACCESS_REASON_TYPE {
      AccessReasonNone = 0x00000000,
      AccessReasonAllowedAce = 0x00010000,
      AccessReasonDeniedAce = 0x00020000,
      AccessReasonAllowedParentAce = 0x00030000,
      AccessReasonDeniedParentAce = 0x00040000,
      AccessReasonNotGrantedByCape = 0x00050000,
      AccessReasonNotGrantedByParentCape = 0x00060000,
      AccessReasonNotGrantedToAppContainer = 0x00070000,
      AccessReasonMissingPrivilege = 0x00100000,
      AccessReasonFromPrivilege = 0x00200000,
      AccessReasonIntegrityLevel = 0x00300000,
      AccessReasonOwnership = 0x00400000,
      AccessReasonNullDacl = 0x00500000,
      AccessReasonEmptyDacl = 0x00600000,
      AccessReasonNoSD = 0x00700000,
      AccessReasonNoGrant = 0x00800000
    } ACCESS_REASON_TYPE;
    typedef DWORD ACCESS_REASON;

    typedef struct _ACCESS_REASONS {
      ACCESS_REASON Data[32];
    } ACCESS_REASONS,*PACCESS_REASONS;





    typedef struct _SE_SECURITY_DESCRIPTOR {
      DWORD Size;
      DWORD Flags;
      PSECURITY_DESCRIPTOR SecurityDescriptor;
    } SE_SECURITY_DESCRIPTOR,*PSE_SECURITY_DESCRIPTOR;

    typedef struct _SE_ACCESS_REQUEST {
      DWORD Size;
      PSE_SECURITY_DESCRIPTOR SeSecurityDescriptor;
      ACCESS_MASK DesiredAccess;
      ACCESS_MASK PreviouslyGrantedAccess;
      PSID PrincipalSelfSid;
      PGENERIC_MAPPING GenericMapping;
      DWORD ObjectTypeListCount;
      POBJECT_TYPE_LIST ObjectTypeList;
    } SE_ACCESS_REQUEST,*PSE_ACCESS_REQUEST;

    typedef struct _SE_ACCESS_REPLY {
      DWORD Size;
      DWORD ResultListCount;
      PACCESS_MASK GrantedAccess;
      PDWORD AccessStatus;
      PACCESS_REASONS AccessReason;
      PPRIVILEGE_SET *Privileges;
    } SE_ACCESS_REPLY,*PSE_ACCESS_REPLY;
    typedef enum _SECURITY_IMPERSONATION_LEVEL {
      SecurityAnonymous,SecurityIdentification,SecurityImpersonation,SecurityDelegation
    } SECURITY_IMPERSONATION_LEVEL,*PSECURITY_IMPERSONATION_LEVEL;
    typedef enum _TOKEN_TYPE {
      TokenPrimary = 1,TokenImpersonation
    } TOKEN_TYPE;
    typedef TOKEN_TYPE *PTOKEN_TYPE;

    typedef enum _TOKEN_ELEVATION_TYPE {
      TokenElevationTypeDefault = 1,
      TokenElevationTypeFull,
      TokenElevationTypeLimited
    } TOKEN_ELEVATION_TYPE, *PTOKEN_ELEVATION_TYPE;

    typedef enum _TOKEN_INFORMATION_CLASS {
      TokenUser = 1,
      TokenGroups,
      TokenPrivileges,
      TokenOwner,
      TokenPrimaryGroup,
      TokenDefaultDacl,
      TokenSource,
      TokenType,
      TokenImpersonationLevel,
      TokenStatistics,
      TokenRestrictedSids,
      TokenSessionId,
      TokenGroupsAndPrivileges,
      TokenSessionReference,
      TokenSandBoxInert,
      TokenAuditPolicy,
      TokenOrigin,
      TokenElevationType,
      TokenLinkedToken,
      TokenElevation,
      TokenHasRestrictions,
      TokenAccessInformation,
      TokenVirtualizationAllowed,
      TokenVirtualizationEnabled,
      TokenIntegrityLevel,
      TokenUIAccess,
      TokenMandatoryPolicy,
      TokenLogonSid,
      TokenIsAppContainer,
      TokenCapabilities,
      TokenAppContainerSid,
      TokenAppContainerNumber,
      TokenUserClaimAttributes,
      TokenDeviceClaimAttributes,
      TokenRestrictedUserClaimAttributes,
      TokenRestrictedDeviceClaimAttributes,
      TokenDeviceGroups,
      TokenRestrictedDeviceGroups,
      TokenSecurityAttributes,
      TokenIsRestricted,
      MaxTokenInfoClass
    } TOKEN_INFORMATION_CLASS,*PTOKEN_INFORMATION_CLASS;

    typedef struct _TOKEN_USER {
      SID_AND_ATTRIBUTES User;
    } TOKEN_USER,*PTOKEN_USER;

    typedef struct _TOKEN_GROUPS {
      DWORD GroupCount;



      SID_AND_ATTRIBUTES Groups[1];

    } TOKEN_GROUPS,*PTOKEN_GROUPS;

    typedef struct _TOKEN_PRIVILEGES {
      DWORD PrivilegeCount;
      LUID_AND_ATTRIBUTES Privileges[1];
    } TOKEN_PRIVILEGES,*PTOKEN_PRIVILEGES;

    typedef struct _TOKEN_OWNER {
      PSID Owner;
    } TOKEN_OWNER,*PTOKEN_OWNER;

    typedef struct _TOKEN_PRIMARY_GROUP {
      PSID PrimaryGroup;
    } TOKEN_PRIMARY_GROUP,*PTOKEN_PRIMARY_GROUP;

    typedef struct _TOKEN_DEFAULT_DACL {
      PACL DefaultDacl;
    } TOKEN_DEFAULT_DACL,*PTOKEN_DEFAULT_DACL;

    typedef struct _TOKEN_USER_CLAIMS {
      PCLAIMS_BLOB UserClaims;
    } TOKEN_USER_CLAIMS,*PTOKEN_USER_CLAIMS;

    typedef struct _TOKEN_DEVICE_CLAIMS {
      PCLAIMS_BLOB DeviceClaims;
    } TOKEN_DEVICE_CLAIMS,*PTOKEN_DEVICE_CLAIMS;

    typedef struct _TOKEN_GROUPS_AND_PRIVILEGES {
      DWORD SidCount;
      DWORD SidLength;
      PSID_AND_ATTRIBUTES Sids;
      DWORD RestrictedSidCount;
      DWORD RestrictedSidLength;
      PSID_AND_ATTRIBUTES RestrictedSids;
      DWORD PrivilegeCount;
      DWORD PrivilegeLength;
      PLUID_AND_ATTRIBUTES Privileges;
      LUID AuthenticationId;
    } TOKEN_GROUPS_AND_PRIVILEGES,*PTOKEN_GROUPS_AND_PRIVILEGES;

    typedef struct _TOKEN_LINKED_TOKEN {
      HANDLE LinkedToken;
    } TOKEN_LINKED_TOKEN,*PTOKEN_LINKED_TOKEN;

    typedef struct _TOKEN_ELEVATION {
      DWORD TokenIsElevated;
    } TOKEN_ELEVATION,*PTOKEN_ELEVATION;

    typedef struct _TOKEN_MANDATORY_LABEL {
      SID_AND_ATTRIBUTES Label;
    } TOKEN_MANDATORY_LABEL,*PTOKEN_MANDATORY_LABEL;







    typedef struct _TOKEN_MANDATORY_POLICY {
      DWORD Policy;
    } TOKEN_MANDATORY_POLICY,*PTOKEN_MANDATORY_POLICY;

    typedef struct _TOKEN_ACCESS_INFORMATION {
      PSID_AND_ATTRIBUTES_HASH SidHash;
      PSID_AND_ATTRIBUTES_HASH RestrictedSidHash;
      PTOKEN_PRIVILEGES Privileges;
      LUID AuthenticationId;
      TOKEN_TYPE TokenType;
      SECURITY_IMPERSONATION_LEVEL ImpersonationLevel;
      TOKEN_MANDATORY_POLICY MandatoryPolicy;
      DWORD Flags;
      DWORD AppContainerNumber;
      PSID PackageSid;
      PSID_AND_ATTRIBUTES_HASH CapabilitiesHash;
    } TOKEN_ACCESS_INFORMATION,*PTOKEN_ACCESS_INFORMATION;



    typedef struct _TOKEN_AUDIT_POLICY {
      UCHAR PerUserPolicy[(((56)) >> 1) + 1];
    } TOKEN_AUDIT_POLICY, *PTOKEN_AUDIT_POLICY;



    typedef struct _TOKEN_SOURCE {
      CHAR SourceName[8];
      LUID SourceIdentifier;
    } TOKEN_SOURCE,*PTOKEN_SOURCE;

    typedef struct _TOKEN_STATISTICS {
      LUID TokenId;
      LUID AuthenticationId;
      LARGE_INTEGER ExpirationTime;
      TOKEN_TYPE TokenType;
      SECURITY_IMPERSONATION_LEVEL ImpersonationLevel;
      DWORD DynamicCharged;
      DWORD DynamicAvailable;
      DWORD GroupCount;
      DWORD PrivilegeCount;
      LUID ModifiedId;
    } TOKEN_STATISTICS,*PTOKEN_STATISTICS;

    typedef struct _TOKEN_CONTROL {
      LUID TokenId;
      LUID AuthenticationId;
      LUID ModifiedId;
      TOKEN_SOURCE TokenSource;
    } TOKEN_CONTROL,*PTOKEN_CONTROL;

    typedef struct _TOKEN_ORIGIN {
      LUID OriginatingLogonSession;
    } TOKEN_ORIGIN,*PTOKEN_ORIGIN;

    typedef enum _MANDATORY_LEVEL {
      MandatoryLevelUntrusted = 0,
      MandatoryLevelLow,
      MandatoryLevelMedium,
      MandatoryLevelHigh,
      MandatoryLevelSystem,
      MandatoryLevelSecureProcess,
      MandatoryLevelCount
    } MANDATORY_LEVEL,*PMANDATORY_LEVEL;

    typedef struct _TOKEN_APPCONTAINER_INFORMATION {
      PSID TokenAppContainer;
    } TOKEN_APPCONTAINER_INFORMATION,*PTOKEN_APPCONTAINER_INFORMATION;
    typedef struct _CLAIM_SECURITY_ATTRIBUTE_FQBN_VALUE {
      DWORD64 Version;
      PWSTR Name;
    } CLAIM_SECURITY_ATTRIBUTE_FQBN_VALUE,*PCLAIM_SECURITY_ATTRIBUTE_FQBN_VALUE;

    typedef struct _CLAIM_SECURITY_ATTRIBUTE_OCTET_STRING_VALUE {
      PVOID pValue;
      DWORD ValueLength;
    } CLAIM_SECURITY_ATTRIBUTE_OCTET_STRING_VALUE, *PCLAIM_SECURITY_ATTRIBUTE_OCTET_STRING_VALUE;
    typedef struct _CLAIM_SECURITY_ATTRIBUTE_V1 {
      PWSTR Name;
      WORD ValueType;
      WORD Reserved;
      DWORD Flags;
      DWORD ValueCount;
      union {
 PLONG64 pInt64;
 PDWORD64 pUint64;
 PWSTR *ppString;
 PCLAIM_SECURITY_ATTRIBUTE_FQBN_VALUE pFqbn;
 PCLAIM_SECURITY_ATTRIBUTE_OCTET_STRING_VALUE pOctetString;
      } Values;
    } CLAIM_SECURITY_ATTRIBUTE_V1,*PCLAIM_SECURITY_ATTRIBUTE_V1;

    typedef struct _CLAIM_SECURITY_ATTRIBUTE_RELATIVE_V1 {
      DWORD Name;
      WORD ValueType;
      WORD Reserved;
      DWORD Flags;
      DWORD ValueCount;
      union {
 DWORD pInt64[1];
 DWORD pUint64[1];
 DWORD ppString[1];
 DWORD pFqbn[1];
 DWORD pOctetString[1];
      } Values;
    } CLAIM_SECURITY_ATTRIBUTE_RELATIVE_V1,*PCLAIM_SECURITY_ATTRIBUTE_RELATIVE_V1;





    typedef struct _CLAIM_SECURITY_ATTRIBUTES_INFORMATION {
      WORD Version;
      WORD Reserved;
      DWORD AttributeCount;
      union {
 PCLAIM_SECURITY_ATTRIBUTE_V1 pAttributeV1;
      } Attribute;
    } CLAIM_SECURITY_ATTRIBUTES_INFORMATION,*PCLAIM_SECURITY_ATTRIBUTES_INFORMATION;




    typedef BOOLEAN SECURITY_CONTEXT_TRACKING_MODE,*PSECURITY_CONTEXT_TRACKING_MODE;

    typedef struct _SECURITY_QUALITY_OF_SERVICE {
      DWORD Length;
      SECURITY_IMPERSONATION_LEVEL ImpersonationLevel;
      SECURITY_CONTEXT_TRACKING_MODE ContextTrackingMode;
      BOOLEAN EffectiveOnly;
    } SECURITY_QUALITY_OF_SERVICE,*PSECURITY_QUALITY_OF_SERVICE;

    typedef struct _SE_IMPERSONATION_STATE {
      PACCESS_TOKEN Token;
      BOOLEAN CopyOnOpen;
      BOOLEAN EffectiveOnly;
      SECURITY_IMPERSONATION_LEVEL Level;
    } SE_IMPERSONATION_STATE,*PSE_IMPERSONATION_STATE;






    typedef DWORD SECURITY_INFORMATION,*PSECURITY_INFORMATION;
    typedef enum _SE_LEARNING_MODE_DATA_TYPE {
      SeLearningModeInvalidType = 0,
      SeLearningModeSettings,
      SeLearningModeMax
    } SE_LEARNING_MODE_DATA_TYPE;



    typedef struct _SECURITY_CAPABILITIES {
      PSID AppContainerSid;
      PSID_AND_ATTRIBUTES Capabilities;
      DWORD CapabilityCount;
      DWORD Reserved;
    } SECURITY_CAPABILITIES,*PSECURITY_CAPABILITIES,*LPSECURITY_CAPABILITIES;
    typedef struct _JOB_SET_ARRAY {
      HANDLE JobHandle;
      DWORD MemberLevel;
      DWORD Flags;
    } JOB_SET_ARRAY,*PJOB_SET_ARRAY;





    typedef struct _EXCEPTION_REGISTRATION_RECORD {
      __extension__ union {
        struct _EXCEPTION_REGISTRATION_RECORD *Next;
        struct _EXCEPTION_REGISTRATION_RECORD *prev;
      };
      __extension__ union {
        PEXCEPTION_ROUTINE Handler;
        PEXCEPTION_ROUTINE handler;
      };
    } EXCEPTION_REGISTRATION_RECORD;

    typedef EXCEPTION_REGISTRATION_RECORD *PEXCEPTION_REGISTRATION_RECORD;

    typedef EXCEPTION_REGISTRATION_RECORD EXCEPTION_REGISTRATION;
    typedef PEXCEPTION_REGISTRATION_RECORD PEXCEPTION_REGISTRATION;




    __extension__ typedef struct _NT_TIB {
      struct _EXCEPTION_REGISTRATION_RECORD *ExceptionList;
      PVOID StackBase;
      PVOID StackLimit;
      PVOID SubSystemTib;
      __extension__ union {
 PVOID FiberData;
 DWORD Version;
      };
      PVOID ArbitraryUserPointer;
      struct _NT_TIB *Self;
    } NT_TIB;
    typedef NT_TIB *PNT_TIB;


    __extension__ typedef struct _NT_TIB32 {
      DWORD ExceptionList;
      DWORD StackBase;
      DWORD StackLimit;
      DWORD SubSystemTib;
      __extension__ union {
 DWORD FiberData;
 DWORD Version;
      };
      DWORD ArbitraryUserPointer;
      DWORD Self;
    } NT_TIB32,*PNT_TIB32;

    __extension__ typedef struct _NT_TIB64 {
      DWORD64 ExceptionList;
      DWORD64 StackBase;
      DWORD64 StackLimit;
      DWORD64 SubSystemTib;
      __extension__ union {
 DWORD64 FiberData;
 DWORD Version;
      };
      DWORD64 ArbitraryUserPointer;
      DWORD64 Self;
    } NT_TIB64,*PNT_TIB64;
    typedef struct _UMS_CREATE_THREAD_ATTRIBUTES {
      DWORD UmsVersion;
      PVOID UmsContext;
      PVOID UmsCompletionList;
    } UMS_CREATE_THREAD_ATTRIBUTES,*PUMS_CREATE_THREAD_ATTRIBUTES;

    typedef struct _QUOTA_LIMITS {
      SIZE_T PagedPoolLimit;
      SIZE_T NonPagedPoolLimit;
      SIZE_T MinimumWorkingSetSize;
      SIZE_T MaximumWorkingSetSize;
      SIZE_T PagefileLimit;
      LARGE_INTEGER TimeLimit;
    } QUOTA_LIMITS,*PQUOTA_LIMITS;







    typedef union _RATE_QUOTA_LIMIT {
      DWORD RateData;
      __extension__ struct {
        DWORD RatePercent : 7;
        DWORD Reserved0 : 25;
      } ;
    } RATE_QUOTA_LIMIT, *PRATE_QUOTA_LIMIT;

    typedef struct _QUOTA_LIMITS_EX {
      SIZE_T PagedPoolLimit;
      SIZE_T NonPagedPoolLimit;
      SIZE_T MinimumWorkingSetSize;
      SIZE_T MaximumWorkingSetSize;
      SIZE_T PagefileLimit;
      LARGE_INTEGER TimeLimit;
      SIZE_T WorkingSetLimit;
      SIZE_T Reserved2;
      SIZE_T Reserved3;
      SIZE_T Reserved4;
      DWORD Flags;
      RATE_QUOTA_LIMIT CpuRateLimit;
    } QUOTA_LIMITS_EX,*PQUOTA_LIMITS_EX;

    typedef struct _IO_COUNTERS {
      ULONGLONG ReadOperationCount;
      ULONGLONG WriteOperationCount;
      ULONGLONG OtherOperationCount;
      ULONGLONG ReadTransferCount;
      ULONGLONG WriteTransferCount;
      ULONGLONG OtherTransferCount;
    } IO_COUNTERS;
    typedef IO_COUNTERS *PIO_COUNTERS;




    typedef enum _HARDWARE_COUNTER_TYPE {
      PMCCounter,
      MaxHardwareCounterType
    } HARDWARE_COUNTER_TYPE, *PHARDWARE_COUNTER_TYPE;

    typedef enum _PROCESS_MITIGATION_POLICY {
      ProcessDEPPolicy,
      ProcessASLRPolicy,
      ProcessDynamicCodePolicy,
      ProcessStrictHandleCheckPolicy,
      ProcessSystemCallDisablePolicy,
      ProcessMitigationOptionsMask,
      ProcessExtensionPointDisablePolicy,
      ProcessControlFlowGuardPolicy,
      ProcessSignaturePolicy,
      ProcessFontDisablePolicy,
      ProcessImageLoadPolicy,
      MaxProcessMitigationPolicy
    } PROCESS_MITIGATION_POLICY,*PPROCESS_MITIGATION_POLICY;

    typedef struct _PROCESS_MITIGATION_ASLR_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD EnableBottomUpRandomization : 1;
          DWORD EnableForceRelocateImages : 1;
          DWORD EnableHighEntropy : 1;
          DWORD DisallowStrippedImages : 1;
          DWORD ReservedFlags : 28;
        };
      };
    } PROCESS_MITIGATION_ASLR_POLICY,*PPROCESS_MITIGATION_ASLR_POLICY;

    typedef struct _PROCESS_MITIGATION_DEP_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD Enable : 1;
          DWORD DisableAtlThunkEmulation : 1;
          DWORD ReservedFlags : 30;
        };
      };
      BOOLEAN Permanent;
    } PROCESS_MITIGATION_DEP_POLICY,*PPROCESS_MITIGATION_DEP_POLICY;

    typedef struct _PROCESS_MITIGATION_STRICT_HANDLE_CHECK_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD RaiseExceptionOnInvalidHandleReference : 1;
          DWORD HandleExceptionsPermanentlyEnabled : 1;
          DWORD ReservedFlags : 30;
        };
      };
    } PROCESS_MITIGATION_STRICT_HANDLE_CHECK_POLICY,*PPROCESS_MITIGATION_STRICT_HANDLE_CHECK_POLICY;

    typedef struct _PROCESS_MITIGATION_SYSTEM_CALL_DISABLE_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD DisallowWin32kSystemCalls : 1;
          DWORD ReservedFlags : 31;
        };
      };
    } PROCESS_MITIGATION_SYSTEM_CALL_DISABLE_POLICY,*PPROCESS_MITIGATION_SYSTEM_CALL_DISABLE_POLICY;

    typedef struct _PROCESS_MITIGATION_EXTENSION_POINT_DISABLE_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD DisableExtensionPoints : 1;
          DWORD ReservedFlags : 31;
        };
      };
    } PROCESS_MITIGATION_EXTENSION_POINT_DISABLE_POLICY,*PPROCESS_MITIGATION_EXTENSION_POINT_DISABLE_POLICY;

    typedef struct _PROCESS_MITIGATION_CONTROL_FLOW_GUARD_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD EnableControlFlowGuard :1;
          DWORD EnableExportSuppression :1;
          DWORD StrictMode :1;
          DWORD ReservedFlags :29;
        };
      };
    } PROCESS_MITIGATION_CONTROL_FLOW_GUARD_POLICY, *PPROCESS_MITIGATION_CONTROL_FLOW_GUARD_POLICY;

    typedef struct _PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD MicrosoftSignedOnly :1;
          DWORD StoreSignedOnly :1;
          DWORD MitigationOptIn :1;
          DWORD ReservedFlags :29;
        };
      };
    } PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY, *PPROCESS_MITIGATION_BINARY_SIGNATURE_POLICY;

    typedef struct _PROCESS_MITIGATION_DYNAMIC_CODE_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD ProhibitDynamicCode :1;
          DWORD AllowThreadOptOut :1;
          DWORD AllowRemoteDowngrade :1;
          DWORD ReservedFlags :30;
        };
      };
    } PROCESS_MITIGATION_DYNAMIC_CODE_POLICY, *PPROCESS_MITIGATION_DYNAMIC_CODE_POLICY;

    typedef struct _PROCESS_MITIGATION_FONT_DISABLE_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD DisableNonSystemFonts :1;
          DWORD AuditNonSystemFontLoading :1;
          DWORD ReservedFlags :30;
        };
      };
    } PROCESS_MITIGATION_FONT_DISABLE_POLICY, *PPROCESS_MITIGATION_FONT_DISABLE_POLICY;

    typedef struct _PROCESS_MITIGATION_IMAGE_LOAD_POLICY {
      __extension__ union {
        DWORD Flags;
        __extension__ struct {
          DWORD NoRemoteImages :1;
          DWORD NoLowMandatoryLabelImages :1;
          DWORD PreferSystem32Images :1;
          DWORD ReservedFlags :29;
        };
      };
    } PROCESS_MITIGATION_IMAGE_LOAD_POLICY, *PPROCESS_MITIGATION_IMAGE_LOAD_POLICY;

    typedef struct _JOBOBJECT_BASIC_ACCOUNTING_INFORMATION {
      LARGE_INTEGER TotalUserTime;
      LARGE_INTEGER TotalKernelTime;
      LARGE_INTEGER ThisPeriodTotalUserTime;
      LARGE_INTEGER ThisPeriodTotalKernelTime;
      DWORD TotalPageFaultCount;
      DWORD TotalProcesses;
      DWORD ActiveProcesses;
      DWORD TotalTerminatedProcesses;
    } JOBOBJECT_BASIC_ACCOUNTING_INFORMATION,*PJOBOBJECT_BASIC_ACCOUNTING_INFORMATION;

    typedef struct _JOBOBJECT_BASIC_LIMIT_INFORMATION {
      LARGE_INTEGER PerProcessUserTimeLimit;
      LARGE_INTEGER PerJobUserTimeLimit;
      DWORD LimitFlags;
      SIZE_T MinimumWorkingSetSize;
      SIZE_T MaximumWorkingSetSize;
      DWORD ActiveProcessLimit;
      ULONG_PTR Affinity;
      DWORD PriorityClass;
      DWORD SchedulingClass;
    } JOBOBJECT_BASIC_LIMIT_INFORMATION,*PJOBOBJECT_BASIC_LIMIT_INFORMATION;

    typedef struct _JOBOBJECT_EXTENDED_LIMIT_INFORMATION {
      JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
      IO_COUNTERS IoInfo;
      SIZE_T ProcessMemoryLimit;
      SIZE_T JobMemoryLimit;
      SIZE_T PeakProcessMemoryUsed;
      SIZE_T PeakJobMemoryUsed;
    } JOBOBJECT_EXTENDED_LIMIT_INFORMATION,*PJOBOBJECT_EXTENDED_LIMIT_INFORMATION;

    typedef struct _JOBOBJECT_BASIC_PROCESS_ID_LIST {
      DWORD NumberOfAssignedProcesses;
      DWORD NumberOfProcessIdsInList;
      ULONG_PTR ProcessIdList[1];
    } JOBOBJECT_BASIC_PROCESS_ID_LIST,*PJOBOBJECT_BASIC_PROCESS_ID_LIST;

    typedef struct _JOBOBJECT_BASIC_UI_RESTRICTIONS {
      DWORD UIRestrictionsClass;
    } JOBOBJECT_BASIC_UI_RESTRICTIONS,*PJOBOBJECT_BASIC_UI_RESTRICTIONS;

    typedef struct _JOBOBJECT_SECURITY_LIMIT_INFORMATION {
      DWORD SecurityLimitFlags;
      HANDLE JobToken;
      PTOKEN_GROUPS SidsToDisable;
      PTOKEN_PRIVILEGES PrivilegesToDelete;
      PTOKEN_GROUPS RestrictedSids;
    } JOBOBJECT_SECURITY_LIMIT_INFORMATION,*PJOBOBJECT_SECURITY_LIMIT_INFORMATION;

    typedef struct _JOBOBJECT_END_OF_JOB_TIME_INFORMATION {
      DWORD EndOfJobTimeAction;
    } JOBOBJECT_END_OF_JOB_TIME_INFORMATION,*PJOBOBJECT_END_OF_JOB_TIME_INFORMATION;

    typedef struct _JOBOBJECT_ASSOCIATE_COMPLETION_PORT {
      PVOID CompletionKey;
      HANDLE CompletionPort;
    } JOBOBJECT_ASSOCIATE_COMPLETION_PORT,*PJOBOBJECT_ASSOCIATE_COMPLETION_PORT;

    typedef struct _JOBOBJECT_BASIC_AND_IO_ACCOUNTING_INFORMATION {
      JOBOBJECT_BASIC_ACCOUNTING_INFORMATION BasicInfo;
      IO_COUNTERS IoInfo;
    } JOBOBJECT_BASIC_AND_IO_ACCOUNTING_INFORMATION,*PJOBOBJECT_BASIC_AND_IO_ACCOUNTING_INFORMATION;

    typedef struct _JOBOBJECT_JOBSET_INFORMATION {
      DWORD MemberLevel;
    } JOBOBJECT_JOBSET_INFORMATION,*PJOBOBJECT_JOBSET_INFORMATION;

    typedef enum _JOBOBJECT_RATE_CONTROL_TOLERANCE {
      ToleranceLow = 1,
      ToleranceMedium,
      ToleranceHigh
    } JOBOBJECT_RATE_CONTROL_TOLERANCE;

    typedef enum _JOBOBJECT_RATE_CONTROL_TOLERANCE_INTERVAL {
      ToleranceIntervalShort = 1,
      ToleranceIntervalMedium,
      ToleranceIntervalLong
    } JOBOBJECT_RATE_CONTROL_TOLERANCE_INTERVAL;

    typedef struct _JOBOBJECT_NOTIFICATION_LIMIT_INFORMATION {
      DWORD64 IoReadBytesLimit;
      DWORD64 IoWriteBytesLimit;
      LARGE_INTEGER PerJobUserTimeLimit;
      DWORD64 JobMemoryLimit;
      JOBOBJECT_RATE_CONTROL_TOLERANCE RateControlTolerance;
      JOBOBJECT_RATE_CONTROL_TOLERANCE_INTERVAL RateControlToleranceInterval;
      DWORD LimitFlags;
    } JOBOBJECT_NOTIFICATION_LIMIT_INFORMATION,*PJOBOBJECT_NOTIFICATION_LIMIT_INFORMATION;

    typedef struct _JOBOBJECT_LIMIT_VIOLATION_INFORMATION {
      DWORD LimitFlags;
      DWORD ViolationLimitFlags;
      DWORD64 IoReadBytes;
      DWORD64 IoReadBytesLimit;
      DWORD64 IoWriteBytes;
      DWORD64 IoWriteBytesLimit;
      LARGE_INTEGER PerJobUserTime;
      LARGE_INTEGER PerJobUserTimeLimit;
      DWORD64 JobMemory;
      DWORD64 JobMemoryLimit;
      JOBOBJECT_RATE_CONTROL_TOLERANCE RateControlTolerance;
      JOBOBJECT_RATE_CONTROL_TOLERANCE_INTERVAL RateControlToleranceLimit;
    } JOBOBJECT_LIMIT_VIOLATION_INFORMATION,*PJOBOBJECT_LIMIT_VIOLATION_INFORMATION;

    typedef struct _JOBOBJECT_CPU_RATE_CONTROL_INFORMATION {
      DWORD ControlFlags;
      __extension__ union {
 DWORD CpuRate;
 DWORD Weight;
      };
    } JOBOBJECT_CPU_RATE_CONTROL_INFORMATION,*PJOBOBJECT_CPU_RATE_CONTROL_INFORMATION;
    typedef enum _JOBOBJECTINFOCLASS {
      JobObjectBasicAccountingInformation = 1, JobObjectBasicLimitInformation,
      JobObjectBasicProcessIdList, JobObjectBasicUIRestrictions,
      JobObjectSecurityLimitInformation, JobObjectEndOfJobTimeInformation,
      JobObjectAssociateCompletionPortInformation, JobObjectBasicAndIoAccountingInformation,
      JobObjectExtendedLimitInformation, JobObjectJobSetInformation,
      JobObjectGroupInformation,
      JobObjectNotificationLimitInformation,
      JobObjectLimitViolationInformation,
      JobObjectGroupInformationEx,
      JobObjectCpuRateControlInformation,
      JobObjectCompletionFilter,
      JobObjectCompletionCounter,
      JobObjectReserved1Information = 18,
      JobObjectReserved2Information,
      JobObjectReserved3Information,
      JobObjectReserved4Information,
      JobObjectReserved5Information,
      JobObjectReserved6Information,
      JobObjectReserved7Information,
      JobObjectReserved8Information,
      MaxJobObjectInfoClass
    } JOBOBJECTINFOCLASS;

    typedef enum _FIRMWARE_TYPE {
      FirmwareTypeUnknown,
      FirmwareTypeBios,
      FirmwareTypeUefi,
      FirmwareTypeMax
    } FIRMWARE_TYPE,*PFIRMWARE_TYPE;
    typedef enum _LOGICAL_PROCESSOR_RELATIONSHIP {
      RelationProcessorCore,RelationNumaNode,RelationCache,
      RelationProcessorPackage,RelationGroup,RelationAll=0xffff
    } LOGICAL_PROCESSOR_RELATIONSHIP;



    typedef enum _PROCESSOR_CACHE_TYPE {
      CacheUnified,CacheInstruction,CacheData,CacheTrace
    } PROCESSOR_CACHE_TYPE;



    typedef struct _CACHE_DESCRIPTOR {
      BYTE Level;
      BYTE Associativity;
      WORD LineSize;
      DWORD Size;
      PROCESSOR_CACHE_TYPE Type;
    } CACHE_DESCRIPTOR,*PCACHE_DESCRIPTOR;

    typedef struct _SYSTEM_LOGICAL_PROCESSOR_INFORMATION {
      ULONG_PTR ProcessorMask;
      LOGICAL_PROCESSOR_RELATIONSHIP Relationship;
      __extension__ union {
 struct {
   BYTE Flags;
 } ProcessorCore;
 struct {
   DWORD NodeNumber;
 } NumaNode;
 CACHE_DESCRIPTOR Cache;
 ULONGLONG Reserved[2];
      } ;
    } SYSTEM_LOGICAL_PROCESSOR_INFORMATION,*PSYSTEM_LOGICAL_PROCESSOR_INFORMATION;

    typedef struct _PROCESSOR_RELATIONSHIP {
      BYTE Flags;
      BYTE Reserved[21];
      WORD GroupCount;
      GROUP_AFFINITY GroupMask[1];
    } PROCESSOR_RELATIONSHIP,*PPROCESSOR_RELATIONSHIP;

    typedef struct _NUMA_NODE_RELATIONSHIP {
      DWORD NodeNumber;
      BYTE Reserved[20];
      GROUP_AFFINITY GroupMask;
    } NUMA_NODE_RELATIONSHIP,*PNUMA_NODE_RELATIONSHIP;

    typedef struct _CACHE_RELATIONSHIP {
      BYTE Level;
      BYTE Associativity;
      WORD LineSize;
      DWORD CacheSize;
      PROCESSOR_CACHE_TYPE Type;
      BYTE Reserved[20];
      GROUP_AFFINITY GroupMask;
    } CACHE_RELATIONSHIP,*PCACHE_RELATIONSHIP;

    typedef struct _PROCESSOR_GROUP_INFO {
      BYTE MaximumProcessorCount;
      BYTE ActiveProcessorCount;
      BYTE Reserved[38];
      KAFFINITY ActiveProcessorMask;
    } PROCESSOR_GROUP_INFO,*PPROCESSOR_GROUP_INFO;

    typedef struct _GROUP_RELATIONSHIP {
      WORD MaximumGroupCount;
      WORD ActiveGroupCount;
      BYTE Reserved[20];
      PROCESSOR_GROUP_INFO GroupInfo[1];
    } GROUP_RELATIONSHIP,*PGROUP_RELATIONSHIP;

    struct _SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX {
      LOGICAL_PROCESSOR_RELATIONSHIP Relationship;
      DWORD Size;
      __extension__ union {
 PROCESSOR_RELATIONSHIP Processor;
 NUMA_NODE_RELATIONSHIP NumaNode;
 CACHE_RELATIONSHIP Cache;
 GROUP_RELATIONSHIP Group;
      } ;
    };

    typedef struct _SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX,*PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX;

    typedef struct _SYSTEM_PROCESSOR_CYCLE_TIME_INFORMATION {
      DWORD64 CycleTime;
    } SYSTEM_PROCESSOR_CYCLE_TIME_INFORMATION,*PSYSTEM_PROCESSOR_CYCLE_TIME_INFORMATION;
    typedef struct _XSTATE_FEATURE {
      DWORD Offset;
      DWORD Size;
    } XSTATE_FEATURE,*PXSTATE_FEATURE;

    typedef struct _XSTATE_CONFIGURATION {
      DWORD64 EnabledFeatures;
      DWORD64 EnabledVolatileFeatures;
      DWORD Size;
      DWORD OptimizedSave : 1;
      XSTATE_FEATURE Features[(64)];
    } XSTATE_CONFIGURATION,*PXSTATE_CONFIGURATION;

    typedef struct _MEMORY_BASIC_INFORMATION {
      PVOID BaseAddress;
      PVOID AllocationBase;
      DWORD AllocationProtect;
      SIZE_T RegionSize;
      DWORD State;
      DWORD Protect;
      DWORD Type;
    } MEMORY_BASIC_INFORMATION,*PMEMORY_BASIC_INFORMATION;

    typedef struct _MEMORY_BASIC_INFORMATION32 {
      DWORD BaseAddress;
      DWORD AllocationBase;
      DWORD AllocationProtect;
      DWORD RegionSize;
      DWORD State;
      DWORD Protect;
      DWORD Type;
    } MEMORY_BASIC_INFORMATION32,*PMEMORY_BASIC_INFORMATION32;

    typedef struct __attribute__ ((__aligned__ (16))) _MEMORY_BASIC_INFORMATION64 {
      ULONGLONG BaseAddress;
      ULONGLONG AllocationBase;
      DWORD AllocationProtect;
      DWORD __alignment1;
      ULONGLONG RegionSize;
      DWORD State;
      DWORD Protect;
      DWORD Type;
      DWORD __alignment2;
    } MEMORY_BASIC_INFORMATION64,*PMEMORY_BASIC_INFORMATION64;
    typedef struct FILE_ID_128 {
      ULONGLONG LowPart;
      ULONGLONG HighPart;
    } FILE_ID_128, *PFILE_ID_128;

    typedef struct _FILE_NOTIFY_INFORMATION {
      DWORD NextEntryOffset;
      DWORD Action;
      DWORD FileNameLength;
      WCHAR FileName[1];
    } FILE_NOTIFY_INFORMATION,*PFILE_NOTIFY_INFORMATION;

    typedef union _FILE_SEGMENT_ELEMENT {
      PVOID64 Buffer;
      ULONGLONG Alignment;
    } FILE_SEGMENT_ELEMENT,*PFILE_SEGMENT_ELEMENT;

    typedef struct _REPARSE_GUID_DATA_BUFFER {
      DWORD ReparseTag;
      WORD ReparseDataLength;
      WORD Reserved;
      GUID ReparseGuid;
      struct {
 BYTE DataBuffer[1];
      } GenericReparseBuffer;
    } REPARSE_GUID_DATA_BUFFER,*PREPARSE_GUID_DATA_BUFFER;
    extern const GUID GUID_MAX_POWER_SAVINGS;
    extern const GUID GUID_MIN_POWER_SAVINGS;
    extern const GUID GUID_TYPICAL_POWER_SAVINGS;
    extern const GUID NO_SUBGROUP_GUID;
    extern const GUID ALL_POWERSCHEMES_GUID;
    extern const GUID GUID_POWERSCHEME_PERSONALITY;
    extern const GUID GUID_ACTIVE_POWERSCHEME;
    extern const GUID GUID_IDLE_RESILIENCY_SUBGROUP;
    extern const GUID GUID_IDLE_RESILIENCY_PERIOD;
    extern const GUID GUID_DISK_COALESCING_POWERDOWN_TIMEOUT;
    extern const GUID GUID_EXECUTION_REQUIRED_REQUEST_TIMEOUT;
    extern const GUID GUID_VIDEO_SUBGROUP;
    extern const GUID GUID_VIDEO_POWERDOWN_TIMEOUT;
    extern const GUID GUID_VIDEO_ANNOYANCE_TIMEOUT;
    extern const GUID GUID_VIDEO_ADAPTIVE_PERCENT_INCREASE;
    extern const GUID GUID_VIDEO_DIM_TIMEOUT;
    extern const GUID GUID_VIDEO_ADAPTIVE_POWERDOWN;
    extern const GUID GUID_MONITOR_POWER_ON;
    extern const GUID GUID_DEVICE_POWER_POLICY_VIDEO_BRIGHTNESS;
    extern const GUID GUID_DEVICE_POWER_POLICY_VIDEO_DIM_BRIGHTNESS;
    extern const GUID GUID_VIDEO_CURRENT_MONITOR_BRIGHTNESS;
    extern const GUID GUID_VIDEO_ADAPTIVE_DISPLAY_BRIGHTNESS;
    extern const GUID GUID_CONSOLE_DISPLAY_STATE;
    extern const GUID GUID_ALLOW_DISPLAY_REQUIRED;
    extern const GUID GUID_VIDEO_CONSOLE_LOCK_TIMEOUT;
    extern const GUID GUID_ADAPTIVE_POWER_BEHAVIOR_SUBGROUP;
    extern const GUID GUID_NON_ADAPTIVE_INPUT_TIMEOUT;
    extern const GUID GUID_DISK_SUBGROUP;
    extern const GUID GUID_DISK_POWERDOWN_TIMEOUT;
    extern const GUID GUID_DISK_IDLE_TIMEOUT;
    extern const GUID GUID_DISK_BURST_IGNORE_THRESHOLD;
    extern const GUID GUID_DISK_ADAPTIVE_POWERDOWN;
    extern const GUID GUID_SLEEP_SUBGROUP;
    extern const GUID GUID_SLEEP_IDLE_THRESHOLD;
    extern const GUID GUID_STANDBY_TIMEOUT;
    extern const GUID GUID_UNATTEND_SLEEP_TIMEOUT;
    extern const GUID GUID_HIBERNATE_TIMEOUT;
    extern const GUID GUID_HIBERNATE_FASTS4_POLICY;
    extern const GUID GUID_CRITICAL_POWER_TRANSITION;
    extern const GUID GUID_SYSTEM_AWAYMODE;
    extern const GUID GUID_ALLOW_AWAYMODE;
    extern const GUID GUID_ALLOW_STANDBY_STATES;
    extern const GUID GUID_ALLOW_RTC_WAKE;
    extern const GUID GUID_ALLOW_SYSTEM_REQUIRED;
    extern const GUID GUID_SYSTEM_BUTTON_SUBGROUP;
    extern const GUID GUID_POWERBUTTON_ACTION;
    extern const GUID GUID_SLEEPBUTTON_ACTION;
    extern const GUID GUID_USERINTERFACEBUTTON_ACTION;
    extern const GUID GUID_LIDCLOSE_ACTION;
    extern const GUID GUID_LIDOPEN_POWERSTATE;
    extern const GUID GUID_BATTERY_SUBGROUP;
    extern const GUID GUID_BATTERY_DISCHARGE_ACTION_0;
    extern const GUID GUID_BATTERY_DISCHARGE_LEVEL_0;
    extern const GUID GUID_BATTERY_DISCHARGE_FLAGS_0;
    extern const GUID GUID_BATTERY_DISCHARGE_ACTION_1;
    extern const GUID GUID_BATTERY_DISCHARGE_LEVEL_1;
    extern const GUID GUID_BATTERY_DISCHARGE_FLAGS_1;
    extern const GUID GUID_BATTERY_DISCHARGE_ACTION_2;
    extern const GUID GUID_BATTERY_DISCHARGE_LEVEL_2;
    extern const GUID GUID_BATTERY_DISCHARGE_FLAGS_2;
    extern const GUID GUID_BATTERY_DISCHARGE_ACTION_3;
    extern const GUID GUID_BATTERY_DISCHARGE_LEVEL_3;
    extern const GUID GUID_BATTERY_DISCHARGE_FLAGS_3;
    extern const GUID GUID_PROCESSOR_SETTINGS_SUBGROUP;
    extern const GUID GUID_PROCESSOR_THROTTLE_POLICY;
    extern const GUID GUID_PROCESSOR_THROTTLE_MAXIMUM;
    extern const GUID GUID_PROCESSOR_THROTTLE_MINIMUM;
    extern const GUID GUID_PROCESSOR_ALLOW_THROTTLING;
    extern const GUID GUID_PROCESSOR_IDLESTATE_POLICY;
    extern const GUID GUID_PROCESSOR_PERFSTATE_POLICY;
    extern const GUID GUID_PROCESSOR_PERF_INCREASE_THRESHOLD;
    extern const GUID GUID_PROCESSOR_PERF_DECREASE_THRESHOLD;
    extern const GUID GUID_PROCESSOR_PERF_INCREASE_POLICY;
    extern const GUID GUID_PROCESSOR_PERF_DECREASE_POLICY;
    extern const GUID GUID_PROCESSOR_PERF_INCREASE_TIME;
    extern const GUID GUID_PROCESSOR_PERF_DECREASE_TIME;
    extern const GUID GUID_PROCESSOR_PERF_TIME_CHECK;
    extern const GUID GUID_PROCESSOR_PERF_BOOST_POLICY;
    extern const GUID GUID_PROCESSOR_PERF_BOOST_MODE;
    extern const GUID GUID_PROCESSOR_IDLE_ALLOW_SCALING;
    extern const GUID GUID_PROCESSOR_IDLE_DISABLE;
    extern const GUID GUID_PROCESSOR_IDLE_STATE_MAXIMUM;
    extern const GUID GUID_PROCESSOR_IDLE_TIME_CHECK;
    extern const GUID GUID_PROCESSOR_IDLE_DEMOTE_THRESHOLD;
    extern const GUID GUID_PROCESSOR_IDLE_PROMOTE_THRESHOLD;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_INCREASE_THRESHOLD;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_DECREASE_THRESHOLD;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_INCREASE_POLICY;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_DECREASE_POLICY;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_MAX_CORES;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_MIN_CORES;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_INCREASE_TIME;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_DECREASE_TIME;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_AFFINITY_HISTORY_DECREASE_FACTOR;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_AFFINITY_HISTORY_THRESHOLD;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_AFFINITY_WEIGHTING;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_OVER_UTILIZATION_HISTORY_DECREASE_FACTOR;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_OVER_UTILIZATION_HISTORY_THRESHOLD;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_OVER_UTILIZATION_WEIGHTING;
    extern const GUID GUID_PROCESSOR_CORE_PARKING_OVER_UTILIZATION_THRESHOLD;
    extern const GUID GUID_PROCESSOR_PARKING_CORE_OVERRIDE;
    extern const GUID GUID_PROCESSOR_PARKING_PERF_STATE;
    extern const GUID GUID_PROCESSOR_PARKING_CONCURRENCY_THRESHOLD;
    extern const GUID GUID_PROCESSOR_PARKING_HEADROOM_THRESHOLD;
    extern const GUID GUID_PROCESSOR_PERF_HISTORY;
    extern const GUID GUID_PROCESSOR_PERF_LATENCY_HINT;
    extern const GUID GUID_PROCESSOR_DISTRIBUTE_UTILITY;
    extern const GUID GUID_SYSTEM_COOLING_POLICY;
    extern const GUID GUID_LOCK_CONSOLE_ON_WAKE;
    extern const GUID GUID_DEVICE_IDLE_POLICY;
    extern const GUID GUID_ACDC_POWER_SOURCE;
    extern const GUID GUID_LIDSWITCH_STATE_CHANGE;
    extern const GUID GUID_BATTERY_PERCENTAGE_REMAINING;
    extern const GUID GUID_GLOBAL_USER_PRESENCE;
    extern const GUID GUID_SESSION_DISPLAY_STATUS;
    extern const GUID GUID_SESSION_USER_PRESENCE;
    extern const GUID GUID_IDLE_BACKGROUND_TASK;
    extern const GUID GUID_BACKGROUND_TASK_NOTIFICATION;
    extern const GUID GUID_APPLAUNCH_BUTTON;
    extern const GUID GUID_PCIEXPRESS_SETTINGS_SUBGROUP;
    extern const GUID GUID_PCIEXPRESS_ASPM_POLICY;
    extern const GUID GUID_ENABLE_SWITCH_FORCED_SHUTDOWN;

  typedef enum _SYSTEM_POWER_STATE {
    PowerSystemUnspecified = 0,PowerSystemWorking = 1,PowerSystemSleeping1 = 2,PowerSystemSleeping2 = 3,PowerSystemSleeping3 = 4,PowerSystemHibernate = 5,PowerSystemShutdown = 6,PowerSystemMaximum = 7
  } SYSTEM_POWER_STATE,*PSYSTEM_POWER_STATE;



  typedef enum {
    PowerActionNone = 0, PowerActionReserved, PowerActionSleep, PowerActionHibernate,
    PowerActionShutdown, PowerActionShutdownReset, PowerActionShutdownOff,
    PowerActionWarmEject
  } POWER_ACTION,*PPOWER_ACTION;

  typedef enum _DEVICE_POWER_STATE {
    PowerDeviceUnspecified = 0, PowerDeviceD0, PowerDeviceD1, PowerDeviceD2, PowerDeviceD3,
    PowerDeviceMaximum
  } DEVICE_POWER_STATE,*PDEVICE_POWER_STATE;

  typedef enum _MONITOR_DISPLAY_STATE {
    PowerMonitorOff = 0, PowerMonitorOn, PowerMonitorDim
  } MONITOR_DISPLAY_STATE, *PMONITOR_DISPLAY_STATE;

  typedef enum _USER_ACTIVITY_PRESENCE {
    PowerUserPresent = 0,
    PowerUserNotPresent,
    PowerUserInactive,
    PowerUserMaximum,
    PowerUserInvalid = PowerUserMaximum
  } USER_ACTIVITY_PRESENCE,*PUSER_ACTIVITY_PRESENCE;







  typedef DWORD EXECUTION_STATE, *PEXECUTION_STATE;

  typedef enum {
    LT_DONT_CARE,LT_LOWEST_LATENCY
  } LATENCY_TIME;
  typedef enum _POWER_REQUEST_TYPE {
    PowerRequestDisplayRequired,
    PowerRequestSystemRequired,
    PowerRequestAwayModeRequired,
    PowerRequestExecutionRequired
  } POWER_REQUEST_TYPE,*PPOWER_REQUEST_TYPE;
    typedef struct CM_Power_Data_s {
      DWORD PD_Size;
      DEVICE_POWER_STATE PD_MostRecentPowerState;
      DWORD PD_Capabilities;
      DWORD PD_D1Latency;
      DWORD PD_D2Latency;
      DWORD PD_D3Latency;
      DEVICE_POWER_STATE PD_PowerStateMapping[7];
      SYSTEM_POWER_STATE PD_DeepestSystemWake;
    } CM_POWER_DATA,*PCM_POWER_DATA;

    typedef enum {
      SystemPowerPolicyAc,
      SystemPowerPolicyDc,
      VerifySystemPolicyAc,
      VerifySystemPolicyDc,
      SystemPowerCapabilities,
      SystemBatteryState,
      SystemPowerStateHandler,
      ProcessorStateHandler,
      SystemPowerPolicyCurrent,
      AdministratorPowerPolicy,
      SystemReserveHiberFile,
      ProcessorInformation,
      SystemPowerInformation,
      ProcessorStateHandler2,
      LastWakeTime,
      LastSleepTime,
      SystemExecutionState,
      SystemPowerStateNotifyHandler,
      ProcessorPowerPolicyAc,
      ProcessorPowerPolicyDc,
      VerifyProcessorPowerPolicyAc,
      VerifyProcessorPowerPolicyDc,
      ProcessorPowerPolicyCurrent,
      SystemPowerStateLogging,
      SystemPowerLoggingEntry,
      SetPowerSettingValue,
      NotifyUserPowerSetting,
      PowerInformationLevelUnused0,
      SystemMonitorHiberBootPowerOff,
      SystemVideoState,
      TraceApplicationPowerMessage,
      TraceApplicationPowerMessageEnd,
      ProcessorPerfStates,
      ProcessorIdleStates,
      ProcessorCap,
      SystemWakeSource,
      SystemHiberFileInformation,
      TraceServicePowerMessage,
      ProcessorLoad,
      PowerShutdownNotification,
      MonitorCapabilities,
      SessionPowerInit,
      SessionDisplayState,
      PowerRequestCreate,
      PowerRequestAction,
      GetPowerRequestList,
      ProcessorInformationEx,
      NotifyUserModeLegacyPowerEvent,
      GroupPark,
      ProcessorIdleDomains,
      WakeTimerList,
      SystemHiberFileSize,
      ProcessorIdleStatesHv,
      ProcessorPerfStatesHv,
      ProcessorPerfCapHv,
      ProcessorSetIdle,
      LogicalProcessorIdling,
      UserPresence,
      PowerSettingNotificationName,
      GetPowerSettingValue,
      IdleResiliency,
      SessionRITState,
      SessionConnectNotification,
      SessionPowerCleanup,
      SessionLockState,
      SystemHiberbootState,
      PlatformInformation,
      PdcInvocation,
      MonitorInvocation,
      FirmwareTableInformationRegistered,
      SetShutdownSelectedTime,
      SuspendResumeInvocation,
      PlmPowerRequestCreate,
      ScreenOff,
      CsDeviceNotification,
      PlatformRole,
      LastResumePerformance,
      DisplayBurst,
      ExitLatencySamplingPercentage,
      ApplyLowPowerScenarioSettings,
      PowerInformationLevelMaximum
    } POWER_INFORMATION_LEVEL;

    typedef enum {
      UserNotPresent = 0,
      UserPresent = 1,
      UserUnknown = 0xff
    } POWER_USER_PRESENCE_TYPE,*PPOWER_USER_PRESENCE_TYPE;

    typedef struct _POWER_USER_PRESENCE {
      POWER_USER_PRESENCE_TYPE UserPresence;
    } POWER_USER_PRESENCE,*PPOWER_USER_PRESENCE;

    typedef struct _POWER_SESSION_CONNECT {
      BOOLEAN Connected;
      BOOLEAN Console;
    } POWER_SESSION_CONNECT,*PPOWER_SESSION_CONNECT;

    typedef struct _POWER_SESSION_TIMEOUTS {
      DWORD InputTimeout;
      DWORD DisplayTimeout;
    } POWER_SESSION_TIMEOUTS,*PPOWER_SESSION_TIMEOUTS;

    typedef struct _POWER_SESSION_RIT_STATE {
      BOOLEAN Active;
      DWORD LastInputTime;
    } POWER_SESSION_RIT_STATE,*PPOWER_SESSION_RIT_STATE;

    typedef struct _POWER_SESSION_WINLOGON {
      DWORD SessionId;
      BOOLEAN Console;
      BOOLEAN Locked;
    } POWER_SESSION_WINLOGON,*PPOWER_SESSION_WINLOGON;

    typedef struct _POWER_IDLE_RESILIENCY {
      DWORD CoalescingTimeout;
      DWORD IdleResiliencyPeriod;
    } POWER_IDLE_RESILIENCY,*PPOWER_IDLE_RESILIENCY;

    typedef enum {
      MonitorRequestReasonUnknown,
      MonitorRequestReasonPowerButton,
      MonitorRequestReasonRemoteConnection,
      MonitorRequestReasonScMonitorpower,
      MonitorRequestReasonUserInput,
      MonitorRequestReasonAcDcDisplayBurst,
      MonitorRequestReasonUserDisplayBurst,
      MonitorRequestReasonPoSetSystemState,
      MonitorRequestReasonSetThreadExecutionState,
      MonitorRequestReasonFullWake,
      MonitorRequestReasonSessionUnlock,
      MonitorRequestReasonScreenOffRequest,
      MonitorRequestReasonIdleTimeout,
      MonitorRequestReasonPolicyChange,
      MonitorRequestReasonMax
    } POWER_MONITOR_REQUEST_REASON;

    typedef struct _POWER_MONITOR_INVOCATION {
      BOOLEAN On;
      BOOLEAN Console;
      POWER_MONITOR_REQUEST_REASON RequestReason;
    } POWER_MONITOR_INVOCATION,*PPOWER_MONITOR_INVOCATION;

    typedef struct _RESUME_PERFORMANCE {
      DWORD PostTimeMs;
      ULONGLONG TotalResumeTimeMs;
      ULONGLONG ResumeCompleteTimestamp;
    } RESUME_PERFORMANCE,*PRESUME_PERFORMANCE;

    typedef enum {
      PoAc,
      PoDc,
      PoHot,
      PoConditionMaximum
    } SYSTEM_POWER_CONDITION;

    typedef struct {
      DWORD Version;
      GUID Guid;
      SYSTEM_POWER_CONDITION PowerCondition;
      DWORD DataLength;
      BYTE Data[1];
    } SET_POWER_SETTING_VALUE,*PSET_POWER_SETTING_VALUE;



    typedef struct {
      GUID Guid;
    } NOTIFY_USER_POWER_SETTING,*PNOTIFY_USER_POWER_SETTING;

    typedef struct _APPLICATIONLAUNCH_SETTING_VALUE {
      LARGE_INTEGER ActivationTime;
      DWORD Flags;
      DWORD ButtonInstanceID;
    } APPLICATIONLAUNCH_SETTING_VALUE,*PAPPLICATIONLAUNCH_SETTING_VALUE;

    typedef enum _POWER_PLATFORM_ROLE {
      PlatformRoleUnspecified = 0,
      PlatformRoleDesktop,
      PlatformRoleMobile,
      PlatformRoleWorkstation,
      PlatformRoleEnterpriseServer,
      PlatformRoleSOHOServer,
      PlatformRoleAppliancePC,
      PlatformRolePerformanceServer,
      PlatformRoleSlate,
      PlatformRoleMaximum
    } POWER_PLATFORM_ROLE,*PPOWER_PLATFORM_ROLE;

    typedef struct _POWER_PLATFORM_INFORMATION {
      BOOLEAN AoAc;
    } POWER_PLATFORM_INFORMATION,*PPOWER_PLATFORM_INFORMATION;
    typedef struct {
      DWORD Granularity;
      DWORD Capacity;
    } BATTERY_REPORTING_SCALE,*PBATTERY_REPORTING_SCALE;

    typedef struct {
      DWORD Frequency;
      DWORD Flags;
      DWORD PercentFrequency;
    } PPM_WMI_LEGACY_PERFSTATE,*PPPM_WMI_LEGACY_PERFSTATE;

    typedef struct {
      DWORD Latency;
      DWORD Power;
      DWORD TimeCheck;
      BYTE PromotePercent;
      BYTE DemotePercent;
      BYTE StateType;
      BYTE Reserved;
      DWORD StateFlags;
      DWORD Context;
      DWORD IdleHandler;
      DWORD Reserved1;
    } PPM_WMI_IDLE_STATE,*PPPM_WMI_IDLE_STATE;

    typedef struct {
      DWORD Type;
      DWORD Count;
      DWORD TargetState;
      DWORD OldState;
      DWORD64 TargetProcessors;
      PPM_WMI_IDLE_STATE State[1];
    } PPM_WMI_IDLE_STATES,*PPPM_WMI_IDLE_STATES;

    typedef struct {
      DWORD Type;
      DWORD Count;
      DWORD TargetState;
      DWORD OldState;
      PVOID TargetProcessors;
      PPM_WMI_IDLE_STATE State[1];
    } PPM_WMI_IDLE_STATES_EX,*PPPM_WMI_IDLE_STATES_EX;

    typedef struct {
      DWORD Frequency;
      DWORD Power;
      BYTE PercentFrequency;
      BYTE IncreaseLevel;
      BYTE DecreaseLevel;
      BYTE Type;
      DWORD IncreaseTime;
      DWORD DecreaseTime;
      DWORD64 Control;
      DWORD64 Status;
      DWORD HitCount;
      DWORD Reserved1;
      DWORD64 Reserved2;
      DWORD64 Reserved3;
    } PPM_WMI_PERF_STATE,*PPPM_WMI_PERF_STATE;

    typedef struct {
      DWORD Count;
      DWORD MaxFrequency;
      DWORD CurrentState;
      DWORD MaxPerfState;
      DWORD MinPerfState;
      DWORD LowestPerfState;
      DWORD ThermalConstraint;
      BYTE BusyAdjThreshold;
      BYTE PolicyType;
      BYTE Type;
      BYTE Reserved;
      DWORD TimerInterval;
      DWORD64 TargetProcessors;
      DWORD PStateHandler;
      DWORD PStateContext;
      DWORD TStateHandler;
      DWORD TStateContext;
      DWORD FeedbackHandler;
      DWORD Reserved1;
      DWORD64 Reserved2;
      PPM_WMI_PERF_STATE State[1];
    } PPM_WMI_PERF_STATES,*PPPM_WMI_PERF_STATES;

    typedef struct {
      DWORD Count;
      DWORD MaxFrequency;
      DWORD CurrentState;
      DWORD MaxPerfState;
      DWORD MinPerfState;
      DWORD LowestPerfState;
      DWORD ThermalConstraint;
      BYTE BusyAdjThreshold;
      BYTE PolicyType;
      BYTE Type;
      BYTE Reserved;
      DWORD TimerInterval;
      PVOID TargetProcessors;
      DWORD PStateHandler;
      DWORD PStateContext;
      DWORD TStateHandler;
      DWORD TStateContext;
      DWORD FeedbackHandler;
      DWORD Reserved1;
      DWORD64 Reserved2;
      PPM_WMI_PERF_STATE State[1];
    } PPM_WMI_PERF_STATES_EX,*PPPM_WMI_PERF_STATES_EX;




    typedef struct {
      DWORD IdleTransitions;
      DWORD FailedTransitions;
      DWORD InvalidBucketIndex;
      DWORD64 TotalTime;
      DWORD IdleTimeBuckets[6];
    } PPM_IDLE_STATE_ACCOUNTING,*PPPM_IDLE_STATE_ACCOUNTING;

    typedef struct {
      DWORD StateCount;
      DWORD TotalTransitions;
      DWORD ResetCount;
      DWORD64 StartTime;
      PPM_IDLE_STATE_ACCOUNTING State[1];
    } PPM_IDLE_ACCOUNTING,*PPPM_IDLE_ACCOUNTING;

    typedef struct {
      DWORD64 TotalTimeUs;
      DWORD MinTimeUs;
      DWORD MaxTimeUs;
      DWORD Count;
    } PPM_IDLE_STATE_BUCKET_EX,*PPPM_IDLE_STATE_BUCKET_EX;

    typedef struct {
      DWORD64 TotalTime;
      DWORD IdleTransitions;
      DWORD FailedTransitions;
      DWORD InvalidBucketIndex;
      DWORD MinTimeUs;
      DWORD MaxTimeUs;
      DWORD CancelledTransitions;
      PPM_IDLE_STATE_BUCKET_EX IdleTimeBuckets[16];
    } PPM_IDLE_STATE_ACCOUNTING_EX,*PPPM_IDLE_STATE_ACCOUNTING_EX;

    typedef struct {
      DWORD StateCount;
      DWORD TotalTransitions;
      DWORD ResetCount;
      DWORD AbortCount;
      DWORD64 StartTime;
      PPM_IDLE_STATE_ACCOUNTING_EX State[1];
    } PPM_IDLE_ACCOUNTING_EX,*PPPM_IDLE_ACCOUNTING_EX;
    typedef struct {
      DWORD State;
      DWORD Status;
      DWORD Latency;
      DWORD Speed;
      DWORD Processor;
    } PPM_PERFSTATE_EVENT,*PPPM_PERFSTATE_EVENT;

    typedef struct {
      DWORD State;
      DWORD Latency;
      DWORD Speed;
      DWORD64 Processors;
    } PPM_PERFSTATE_DOMAIN_EVENT,*PPPM_PERFSTATE_DOMAIN_EVENT;

    typedef struct {
      DWORD NewState;
      DWORD OldState;
      DWORD64 Processors;
    } PPM_IDLESTATE_EVENT,*PPPM_IDLESTATE_EVENT;

    typedef struct {
      DWORD ThermalConstraint;
      DWORD64 Processors;
    } PPM_THERMALCHANGE_EVENT,*PPPM_THERMALCHANGE_EVENT;
    typedef struct {
      BYTE Mode;
      DWORD64 Processors;
    } PPM_THERMAL_POLICY_EVENT,*PPPM_THERMAL_POLICY_EVENT;

    extern const GUID PPM_PERFSTATE_CHANGE_GUID;
    extern const GUID PPM_PERFSTATE_DOMAIN_CHANGE_GUID;
    extern const GUID PPM_IDLESTATE_CHANGE_GUID;
    extern const GUID PPM_PERFSTATES_DATA_GUID;
    extern const GUID PPM_IDLESTATES_DATA_GUID;
    extern const GUID PPM_IDLE_ACCOUNTING_GUID;
    extern const GUID PPM_IDLE_ACCOUNTING_EX_GUID;
    extern const GUID PPM_THERMALCONSTRAINT_GUID;
    extern const GUID PPM_PERFMON_PERFSTATE_GUID;
    extern const GUID PPM_THERMAL_POLICY_CHANGE_GUID;

    typedef struct {
      POWER_ACTION Action;
      DWORD Flags;
      DWORD EventCode;
    } POWER_ACTION_POLICY,*PPOWER_ACTION_POLICY;
    typedef struct {
      DWORD TimeCheck;
      BYTE DemotePercent;
      BYTE PromotePercent;
      BYTE Spare[2];
    } PROCESSOR_IDLESTATE_INFO,*PPROCESSOR_IDLESTATE_INFO;

    typedef struct {
      BOOLEAN Enable;
      BYTE Spare[3];
      DWORD BatteryLevel;
      POWER_ACTION_POLICY PowerPolicy;
      SYSTEM_POWER_STATE MinSystemState;
    } SYSTEM_POWER_LEVEL,*PSYSTEM_POWER_LEVEL;

    typedef struct _SYSTEM_POWER_POLICY {
      DWORD Revision;
      POWER_ACTION_POLICY PowerButton;
      POWER_ACTION_POLICY SleepButton;
      POWER_ACTION_POLICY LidClose;
      SYSTEM_POWER_STATE LidOpenWake;
      DWORD Reserved;
      POWER_ACTION_POLICY Idle;
      DWORD IdleTimeout;
      BYTE IdleSensitivity;
      BYTE DynamicThrottle;
      BYTE Spare2[2];
      SYSTEM_POWER_STATE MinSleep;
      SYSTEM_POWER_STATE MaxSleep;
      SYSTEM_POWER_STATE ReducedLatencySleep;
      DWORD WinLogonFlags;
      DWORD Spare3;
      DWORD DozeS4Timeout;
      DWORD BroadcastCapacityResolution;
      SYSTEM_POWER_LEVEL DischargePolicy[4];
      DWORD VideoTimeout;
      BOOLEAN VideoDimDisplay;
      DWORD VideoReserved[3];
      DWORD SpindownTimeout;
      BOOLEAN OptimizeForPower;
      BYTE FanThrottleTolerance;
      BYTE ForcedThrottle;
      BYTE MinThrottle;
      POWER_ACTION_POLICY OverThrottled;
    } SYSTEM_POWER_POLICY,*PSYSTEM_POWER_POLICY;







    typedef struct {
      WORD Revision;
      union {
 WORD AsWORD;
 __extension__ struct {
   WORD AllowScaling : 1;
   WORD Disabled : 1;
   WORD Reserved : 14;
 } ;
      } Flags;
      DWORD PolicyCount;
      PROCESSOR_IDLESTATE_INFO Policy[0x3];
    } PROCESSOR_IDLESTATE_POLICY,*PPROCESSOR_IDLESTATE_POLICY;

    typedef struct _PROCESSOR_POWER_POLICY_INFO {
      DWORD TimeCheck;
      DWORD DemoteLimit;
      DWORD PromoteLimit;
      BYTE DemotePercent;
      BYTE PromotePercent;
      BYTE Spare[2];
      DWORD AllowDemotion:1;
      DWORD AllowPromotion:1;
      DWORD Reserved:30;
    } PROCESSOR_POWER_POLICY_INFO,*PPROCESSOR_POWER_POLICY_INFO;

    typedef struct _PROCESSOR_POWER_POLICY {
      DWORD Revision;
      BYTE DynamicThrottle;
      BYTE Spare[3];
      DWORD DisableCStates:1;
      DWORD Reserved:31;
      DWORD PolicyCount;
      PROCESSOR_POWER_POLICY_INFO Policy[3];
    } PROCESSOR_POWER_POLICY,*PPROCESSOR_POWER_POLICY;

    typedef struct {
      DWORD Revision;
      BYTE MaxThrottle;
      BYTE MinThrottle;
      BYTE BusyAdjThreshold;
      __extension__ union {
 BYTE Spare;
 union {
   BYTE AsBYTE;
   __extension__ struct {
     BYTE NoDomainAccounting : 1;
     BYTE IncreasePolicy: 2;
     BYTE DecreasePolicy: 2;
     BYTE Reserved : 3;
   } ;
 } Flags;
      } ;
      DWORD TimeCheck;
      DWORD IncreaseTime;
      DWORD DecreaseTime;
      DWORD IncreasePercent;
      DWORD DecreasePercent;
    } PROCESSOR_PERFSTATE_POLICY,*PPROCESSOR_PERFSTATE_POLICY;

    typedef struct _ADMINISTRATOR_POWER_POLICY {
      SYSTEM_POWER_STATE MinSleep;
      SYSTEM_POWER_STATE MaxSleep;
      DWORD MinVideoTimeout;
      DWORD MaxVideoTimeout;
      DWORD MinSpindownTimeout;
      DWORD MaxSpindownTimeout;
    } ADMINISTRATOR_POWER_POLICY,*PADMINISTRATOR_POWER_POLICY;

    typedef struct {
      BOOLEAN PowerButtonPresent;
      BOOLEAN SleepButtonPresent;
      BOOLEAN LidPresent;
      BOOLEAN SystemS1;
      BOOLEAN SystemS2;
      BOOLEAN SystemS3;
      BOOLEAN SystemS4;
      BOOLEAN SystemS5;
      BOOLEAN HiberFilePresent;
      BOOLEAN FullWake;
      BOOLEAN VideoDimPresent;
      BOOLEAN ApmPresent;
      BOOLEAN UpsPresent;
      BOOLEAN ThermalControl;
      BOOLEAN ProcessorThrottle;
      BYTE ProcessorMinThrottle;
      BYTE ProcessorMaxThrottle;
      BOOLEAN FastSystemS4;
      BYTE spare2[3];
      BOOLEAN DiskSpinDown;
      BYTE spare3[8];
      BOOLEAN SystemBatteriesPresent;
      BOOLEAN BatteriesAreShortTerm;
      BATTERY_REPORTING_SCALE BatteryScale[3];
      SYSTEM_POWER_STATE AcOnLineWake;
      SYSTEM_POWER_STATE SoftLidWake;
      SYSTEM_POWER_STATE RtcWake;
      SYSTEM_POWER_STATE MinDeviceWakeState;
      SYSTEM_POWER_STATE DefaultLowLatencyWake;
    } SYSTEM_POWER_CAPABILITIES,*PSYSTEM_POWER_CAPABILITIES;

    typedef struct {
      BOOLEAN AcOnLine;
      BOOLEAN BatteryPresent;
      BOOLEAN Charging;
      BOOLEAN Discharging;
      BOOLEAN Spare1[4];
      DWORD MaxCapacity;
      DWORD RemainingCapacity;
      DWORD Rate;
      DWORD EstimatedTime;
      DWORD DefaultAlert1;
      DWORD DefaultAlert2;
    } SYSTEM_BATTERY_STATE,*PSYSTEM_BATTERY_STATE;








#pragma pack(push,4)













#pragma pack(push,2)

    typedef struct _IMAGE_DOS_HEADER {
      WORD e_magic;
      WORD e_cblp;
      WORD e_cp;
      WORD e_crlc;
      WORD e_cparhdr;
      WORD e_minalloc;
      WORD e_maxalloc;
      WORD e_ss;
      WORD e_sp;
      WORD e_csum;
      WORD e_ip;
      WORD e_cs;
      WORD e_lfarlc;
      WORD e_ovno;
      WORD e_res[4];
      WORD e_oemid;
      WORD e_oeminfo;
      WORD e_res2[10];
      LONG e_lfanew;
    } IMAGE_DOS_HEADER,*PIMAGE_DOS_HEADER;

    typedef struct _IMAGE_OS2_HEADER {
      WORD ne_magic;
      CHAR ne_ver;
      CHAR ne_rev;
      WORD ne_enttab;
      WORD ne_cbenttab;
      LONG ne_crc;
      WORD ne_flags;
      WORD ne_autodata;
      WORD ne_heap;
      WORD ne_stack;
      LONG ne_csip;
      LONG ne_sssp;
      WORD ne_cseg;
      WORD ne_cmod;
      WORD ne_cbnrestab;
      WORD ne_segtab;
      WORD ne_rsrctab;
      WORD ne_restab;
      WORD ne_modtab;
      WORD ne_imptab;
      LONG ne_nrestab;
      WORD ne_cmovent;
      WORD ne_align;
      WORD ne_cres;
      BYTE ne_exetyp;
      BYTE ne_flagsothers;
      WORD ne_pretthunks;
      WORD ne_psegrefbytes;
      WORD ne_swaparea;
      WORD ne_expver;
    } IMAGE_OS2_HEADER,*PIMAGE_OS2_HEADER;

    typedef struct _IMAGE_VXD_HEADER {
      WORD e32_magic;
      BYTE e32_border;
      BYTE e32_worder;
      DWORD e32_level;
      WORD e32_cpu;
      WORD e32_os;
      DWORD e32_ver;
      DWORD e32_mflags;
      DWORD e32_mpages;
      DWORD e32_startobj;
      DWORD e32_eip;
      DWORD e32_stackobj;
      DWORD e32_esp;
      DWORD e32_pagesize;
      DWORD e32_lastpagesize;
      DWORD e32_fixupsize;
      DWORD e32_fixupsum;
      DWORD e32_ldrsize;
      DWORD e32_ldrsum;
      DWORD e32_objtab;
      DWORD e32_objcnt;
      DWORD e32_objmap;
      DWORD e32_itermap;
      DWORD e32_rsrctab;
      DWORD e32_rsrccnt;
      DWORD e32_restab;
      DWORD e32_enttab;
      DWORD e32_dirtab;
      DWORD e32_dircnt;
      DWORD e32_fpagetab;
      DWORD e32_frectab;
      DWORD e32_impmod;
      DWORD e32_impmodcnt;
      DWORD e32_impproc;
      DWORD e32_pagesum;
      DWORD e32_datapage;
      DWORD e32_preload;
      DWORD e32_nrestab;
      DWORD e32_cbnrestab;
      DWORD e32_nressum;
      DWORD e32_autodata;
      DWORD e32_debuginfo;
      DWORD e32_debuglen;
      DWORD e32_instpreload;
      DWORD e32_instdemand;
      DWORD e32_heapsize;
      BYTE e32_res3[12];
      DWORD e32_winresoff;
      DWORD e32_winreslen;
      WORD e32_devid;
      WORD e32_ddkver;
    } IMAGE_VXD_HEADER,*PIMAGE_VXD_HEADER;








#pragma pack(pop)

    typedef struct _IMAGE_FILE_HEADER {
      WORD Machine;
      WORD NumberOfSections;
      DWORD TimeDateStamp;
      DWORD PointerToSymbolTable;
      DWORD NumberOfSymbols;
      WORD SizeOfOptionalHeader;
      WORD Characteristics;
    } IMAGE_FILE_HEADER,*PIMAGE_FILE_HEADER;
    typedef struct _IMAGE_DATA_DIRECTORY {
      DWORD VirtualAddress;
      DWORD Size;
    } IMAGE_DATA_DIRECTORY,*PIMAGE_DATA_DIRECTORY;



    typedef struct _IMAGE_OPTIONAL_HEADER {

      WORD Magic;
      BYTE MajorLinkerVersion;
      BYTE MinorLinkerVersion;
      DWORD SizeOfCode;
      DWORD SizeOfInitializedData;
      DWORD SizeOfUninitializedData;
      DWORD AddressOfEntryPoint;
      DWORD BaseOfCode;
      DWORD BaseOfData;
      DWORD ImageBase;
      DWORD SectionAlignment;
      DWORD FileAlignment;
      WORD MajorOperatingSystemVersion;
      WORD MinorOperatingSystemVersion;
      WORD MajorImageVersion;
      WORD MinorImageVersion;
      WORD MajorSubsystemVersion;
      WORD MinorSubsystemVersion;
      DWORD Win32VersionValue;
      DWORD SizeOfImage;
      DWORD SizeOfHeaders;
      DWORD CheckSum;
      WORD Subsystem;
      WORD DllCharacteristics;
      DWORD SizeOfStackReserve;
      DWORD SizeOfStackCommit;
      DWORD SizeOfHeapReserve;
      DWORD SizeOfHeapCommit;
      DWORD LoaderFlags;
      DWORD NumberOfRvaAndSizes;
      IMAGE_DATA_DIRECTORY DataDirectory[16];
    } IMAGE_OPTIONAL_HEADER32,*PIMAGE_OPTIONAL_HEADER32;

    typedef struct _IMAGE_ROM_OPTIONAL_HEADER {
      WORD Magic;
      BYTE MajorLinkerVersion;
      BYTE MinorLinkerVersion;
      DWORD SizeOfCode;
      DWORD SizeOfInitializedData;
      DWORD SizeOfUninitializedData;
      DWORD AddressOfEntryPoint;
      DWORD BaseOfCode;
      DWORD BaseOfData;
      DWORD BaseOfBss;
      DWORD GprMask;
      DWORD CprMask[4];
      DWORD GpValue;
    } IMAGE_ROM_OPTIONAL_HEADER,*PIMAGE_ROM_OPTIONAL_HEADER;

    typedef struct _IMAGE_OPTIONAL_HEADER64 {
      WORD Magic;
      BYTE MajorLinkerVersion;
      BYTE MinorLinkerVersion;
      DWORD SizeOfCode;
      DWORD SizeOfInitializedData;
      DWORD SizeOfUninitializedData;
      DWORD AddressOfEntryPoint;
      DWORD BaseOfCode;
      ULONGLONG ImageBase;
      DWORD SectionAlignment;
      DWORD FileAlignment;
      WORD MajorOperatingSystemVersion;
      WORD MinorOperatingSystemVersion;
      WORD MajorImageVersion;
      WORD MinorImageVersion;
      WORD MajorSubsystemVersion;
      WORD MinorSubsystemVersion;
      DWORD Win32VersionValue;
      DWORD SizeOfImage;
      DWORD SizeOfHeaders;
      DWORD CheckSum;
      WORD Subsystem;
      WORD DllCharacteristics;
      ULONGLONG SizeOfStackReserve;
      ULONGLONG SizeOfStackCommit;
      ULONGLONG SizeOfHeapReserve;
      ULONGLONG SizeOfHeapCommit;
      DWORD LoaderFlags;
      DWORD NumberOfRvaAndSizes;
      IMAGE_DATA_DIRECTORY DataDirectory[16];
    } IMAGE_OPTIONAL_HEADER64,*PIMAGE_OPTIONAL_HEADER64;
    typedef IMAGE_OPTIONAL_HEADER32 IMAGE_OPTIONAL_HEADER;
    typedef PIMAGE_OPTIONAL_HEADER32 PIMAGE_OPTIONAL_HEADER;




    typedef struct _IMAGE_NT_HEADERS64 {
      DWORD Signature;
      IMAGE_FILE_HEADER FileHeader;
      IMAGE_OPTIONAL_HEADER64 OptionalHeader;
    } IMAGE_NT_HEADERS64,*PIMAGE_NT_HEADERS64;

    typedef struct _IMAGE_NT_HEADERS {
      DWORD Signature;
      IMAGE_FILE_HEADER FileHeader;
      IMAGE_OPTIONAL_HEADER32 OptionalHeader;
    } IMAGE_NT_HEADERS32,*PIMAGE_NT_HEADERS32;

    typedef struct _IMAGE_ROM_HEADERS {
      IMAGE_FILE_HEADER FileHeader;
      IMAGE_ROM_OPTIONAL_HEADER OptionalHeader;
    } IMAGE_ROM_HEADERS,*PIMAGE_ROM_HEADERS;





    typedef IMAGE_NT_HEADERS32 IMAGE_NT_HEADERS;
    typedef PIMAGE_NT_HEADERS32 PIMAGE_NT_HEADERS;
    typedef struct ANON_OBJECT_HEADER {
      WORD Sig1;
      WORD Sig2;
      WORD Version;
      WORD Machine;
      DWORD TimeDateStamp;
      CLSID ClassID;
      DWORD SizeOfData;
    } ANON_OBJECT_HEADER;

    typedef struct ANON_OBJECT_HEADER_V2 {
      WORD Sig1;
      WORD Sig2;
      WORD Version;
      WORD Machine;
      DWORD TimeDateStamp;
      CLSID ClassID;
      DWORD SizeOfData;
      DWORD Flags;
      DWORD MetaDataSize;
      DWORD MetaDataOffset;
    } ANON_OBJECT_HEADER_V2;

    typedef struct ANON_OBJECT_HEADER_BIGOBJ {
      WORD Sig1;
      WORD Sig2;
      WORD Version;
      WORD Machine;
      DWORD TimeDateStamp;
      CLSID ClassID;
      DWORD SizeOfData;
      DWORD Flags;
      DWORD MetaDataSize;
      DWORD MetaDataOffset;
      DWORD NumberOfSections;
      DWORD PointerToSymbolTable;
      DWORD NumberOfSymbols;
    } ANON_OBJECT_HEADER_BIGOBJ;



    typedef struct _IMAGE_SECTION_HEADER {
      BYTE Name[8];
      union {
 DWORD PhysicalAddress;
 DWORD VirtualSize;
      } Misc;
      DWORD VirtualAddress;
      DWORD SizeOfRawData;
      DWORD PointerToRawData;
      DWORD PointerToRelocations;
      DWORD PointerToLinenumbers;
      WORD NumberOfRelocations;
      WORD NumberOfLinenumbers;
      DWORD Characteristics;
    } IMAGE_SECTION_HEADER,*PIMAGE_SECTION_HEADER;






#pragma pack(push,2)
 typedef struct _IMAGE_SYMBOL {
      union {
 BYTE ShortName[8];
 struct {
   DWORD Short;
   DWORD Long;
 } Name;
 DWORD LongName[2];
      } N;
      DWORD Value;
      SHORT SectionNumber;
      WORD Type;
      BYTE StorageClass;
      BYTE NumberOfAuxSymbols;
    } IMAGE_SYMBOL;
    typedef IMAGE_SYMBOL *PIMAGE_SYMBOL;



    typedef struct _IMAGE_SYMBOL_EX {
      union {
 BYTE ShortName[8];
 struct {
   DWORD Short;
   DWORD Long;
 } Name;
 DWORD LongName[2];
      } N;
      DWORD Value;
      LONG SectionNumber;
      WORD Type;
      BYTE StorageClass;
      BYTE NumberOfAuxSymbols;
    } IMAGE_SYMBOL_EX, *PIMAGE_SYMBOL_EX;






#pragma pack(push,2)
 typedef struct IMAGE_AUX_SYMBOL_TOKEN_DEF {
      BYTE bAuxType;
      BYTE bReserved;
      DWORD SymbolTableIndex;
      BYTE rgbReserved[12];
    } IMAGE_AUX_SYMBOL_TOKEN_DEF, *PIMAGE_AUX_SYMBOL_TOKEN_DEF;







#pragma pack(pop)

    typedef union _IMAGE_AUX_SYMBOL {
      struct {
 DWORD TagIndex;
 union {
   struct {
     WORD Linenumber;
     WORD Size;
   } LnSz;
   DWORD TotalSize;
 } Misc;
 union {
   struct {
     DWORD PointerToLinenumber;
     DWORD PointerToNextFunction;
   } Function;
   struct {
     WORD Dimension[4];
   } Array;
 } FcnAry;
 WORD TvIndex;
      } Sym;
      struct {
 BYTE Name[18];
      } File;
      struct {
 DWORD Length;
 WORD NumberOfRelocations;
 WORD NumberOfLinenumbers;
 DWORD CheckSum;
 SHORT Number;
 BYTE Selection;
      } Section;
      IMAGE_AUX_SYMBOL_TOKEN_DEF TokenDef;
      struct {
 DWORD crc;
 BYTE rgbReserved[14];
      } CRC;
    } IMAGE_AUX_SYMBOL, *PIMAGE_AUX_SYMBOL;

    typedef union _IMAGE_AUX_SYMBOL_EX {
      struct {
 DWORD WeakDefaultSymIndex;
 DWORD WeakSearchType;
 BYTE rgbReserved[12];
      } Sym;
      struct {
 BYTE Name[sizeof (IMAGE_SYMBOL_EX)];
      } File;
      struct {
 DWORD Length;
 WORD NumberOfRelocations;
 WORD NumberOfLinenumbers;
 DWORD CheckSum;
 SHORT Number;
 BYTE Selection;
 BYTE bReserved;
 SHORT HighNumber;
 BYTE rgbReserved[2];
      } Section;
      __extension__ struct {
 IMAGE_AUX_SYMBOL_TOKEN_DEF TokenDef;
 BYTE rgbReserved[2];
      };
      struct {
 DWORD crc;
 BYTE rgbReserved[16];
      } CRC;
    } IMAGE_AUX_SYMBOL_EX, *PIMAGE_AUX_SYMBOL_EX;



    typedef enum IMAGE_AUX_SYMBOL_TYPE {
      IMAGE_AUX_SYMBOL_TYPE_TOKEN_DEF = 1
    } IMAGE_AUX_SYMBOL_TYPE;
    typedef struct _IMAGE_RELOCATION {
      __extension__ union {
 DWORD VirtualAddress;
 DWORD RelocCount;
      } ;
      DWORD SymbolTableIndex;
      WORD Type;
    } IMAGE_RELOCATION;
    typedef IMAGE_RELOCATION *PIMAGE_RELOCATION;
    typedef struct _IMAGE_LINENUMBER {
      union {
 DWORD SymbolTableIndex;
 DWORD VirtualAddress;
      } Type;
      WORD Linenumber;
    } IMAGE_LINENUMBER;
    typedef IMAGE_LINENUMBER *PIMAGE_LINENUMBER;










#pragma pack(pop)

    typedef struct _IMAGE_BASE_RELOCATION {
      DWORD VirtualAddress;
      DWORD SizeOfBlock;
    } IMAGE_BASE_RELOCATION;
    typedef IMAGE_BASE_RELOCATION *PIMAGE_BASE_RELOCATION;
    typedef struct _IMAGE_ARCHIVE_MEMBER_HEADER {
      BYTE Name[16];
      BYTE Date[12];
      BYTE UserID[6];
      BYTE GroupID[6];
      BYTE Mode[8];
      BYTE Size[10];
      BYTE EndHeader[2];
    } IMAGE_ARCHIVE_MEMBER_HEADER,*PIMAGE_ARCHIVE_MEMBER_HEADER;



    typedef struct _IMAGE_EXPORT_DIRECTORY {
      DWORD Characteristics;
      DWORD TimeDateStamp;
      WORD MajorVersion;
      WORD MinorVersion;
      DWORD Name;
      DWORD Base;
      DWORD NumberOfFunctions;
      DWORD NumberOfNames;
      DWORD AddressOfFunctions;
      DWORD AddressOfNames;
      DWORD AddressOfNameOrdinals;
    } IMAGE_EXPORT_DIRECTORY,*PIMAGE_EXPORT_DIRECTORY;

    typedef struct _IMAGE_IMPORT_BY_NAME {
      WORD Hint;
      BYTE Name[1];
    } IMAGE_IMPORT_BY_NAME,*PIMAGE_IMPORT_BY_NAME;








#pragma pack(push,8)

    typedef struct _IMAGE_THUNK_DATA64 {
      union {
 ULONGLONG ForwarderString;
 ULONGLONG Function;
 ULONGLONG Ordinal;
 ULONGLONG AddressOfData;
      } u1;
    } IMAGE_THUNK_DATA64;
    typedef IMAGE_THUNK_DATA64 *PIMAGE_THUNK_DATA64;








#pragma pack(pop)

    typedef struct _IMAGE_THUNK_DATA32 {
      union {
 DWORD ForwarderString;
 DWORD Function;
 DWORD Ordinal;
 DWORD AddressOfData;
      } u1;
    } IMAGE_THUNK_DATA32;
    typedef IMAGE_THUNK_DATA32 *PIMAGE_THUNK_DATA32;
    typedef void ( *PIMAGE_TLS_CALLBACK)(PVOID DllHandle,DWORD Reason,PVOID Reserved);

    typedef struct _IMAGE_TLS_DIRECTORY64 {
      ULONGLONG StartAddressOfRawData;
      ULONGLONG EndAddressOfRawData;
      ULONGLONG AddressOfIndex;
      ULONGLONG AddressOfCallBacks;
      DWORD SizeOfZeroFill;
      DWORD Characteristics;
    } IMAGE_TLS_DIRECTORY64;
    typedef IMAGE_TLS_DIRECTORY64 *PIMAGE_TLS_DIRECTORY64;

    typedef struct _IMAGE_TLS_DIRECTORY32 {
      DWORD StartAddressOfRawData;
      DWORD EndAddressOfRawData;
      DWORD AddressOfIndex;
      DWORD AddressOfCallBacks;
      DWORD SizeOfZeroFill;
      DWORD Characteristics;
    } IMAGE_TLS_DIRECTORY32;
    typedef IMAGE_TLS_DIRECTORY32 *PIMAGE_TLS_DIRECTORY32;
    typedef IMAGE_THUNK_DATA32 IMAGE_THUNK_DATA;
    typedef PIMAGE_THUNK_DATA32 PIMAGE_THUNK_DATA;

    typedef IMAGE_TLS_DIRECTORY32 IMAGE_TLS_DIRECTORY;
    typedef PIMAGE_TLS_DIRECTORY32 PIMAGE_TLS_DIRECTORY;


    typedef struct _IMAGE_IMPORT_DESCRIPTOR {
      __extension__ union {
 DWORD Characteristics;
 DWORD OriginalFirstThunk;
      } ;
      DWORD TimeDateStamp;

      DWORD ForwarderChain;
      DWORD Name;
      DWORD FirstThunk;
    } IMAGE_IMPORT_DESCRIPTOR;
    typedef IMAGE_IMPORT_DESCRIPTOR *PIMAGE_IMPORT_DESCRIPTOR;

    typedef struct _IMAGE_BOUND_IMPORT_DESCRIPTOR {
      DWORD TimeDateStamp;
      WORD OffsetModuleName;
      WORD NumberOfModuleForwarderRefs;
    } IMAGE_BOUND_IMPORT_DESCRIPTOR,*PIMAGE_BOUND_IMPORT_DESCRIPTOR;

    typedef struct _IMAGE_BOUND_FORWARDER_REF {
      DWORD TimeDateStamp;
      WORD OffsetModuleName;
      WORD Reserved;
    } IMAGE_BOUND_FORWARDER_REF,*PIMAGE_BOUND_FORWARDER_REF;

    typedef struct _IMAGE_DELAYLOAD_DESCRIPTOR {
      union {
 DWORD AllAttributes;
 __extension__ struct {
   DWORD RvaBased : 1;
   DWORD ReservedAttributes : 31;
 };
      } Attributes;
      DWORD DllNameRVA;
      DWORD ModuleHandleRVA;
      DWORD ImportAddressTableRVA;
      DWORD ImportNameTableRVA;
      DWORD BoundImportAddressTableRVA;
      DWORD UnloadInformationTableRVA;
      DWORD TimeDateStamp;
    } IMAGE_DELAYLOAD_DESCRIPTOR,*PIMAGE_DELAYLOAD_DESCRIPTOR;
    typedef const IMAGE_DELAYLOAD_DESCRIPTOR *PCIMAGE_DELAYLOAD_DESCRIPTOR;

    typedef struct _IMAGE_RESOURCE_DIRECTORY {
      DWORD Characteristics;
      DWORD TimeDateStamp;
      WORD MajorVersion;
      WORD MinorVersion;
      WORD NumberOfNamedEntries;
      WORD NumberOfIdEntries;
    } IMAGE_RESOURCE_DIRECTORY,*PIMAGE_RESOURCE_DIRECTORY;




    typedef struct _IMAGE_RESOURCE_DIRECTORY_ENTRY {
      __extension__ union {
 __extension__ struct {
   DWORD NameOffset:31;
   DWORD NameIsString:1;
 } ;
 DWORD Name;
 WORD Id;
      } ;
      __extension__ union {
 DWORD OffsetToData;
 __extension__ struct {
   DWORD OffsetToDirectory:31;
   DWORD DataIsDirectory:1;
 } ;
      } ;
    } IMAGE_RESOURCE_DIRECTORY_ENTRY,*PIMAGE_RESOURCE_DIRECTORY_ENTRY;

    typedef struct _IMAGE_RESOURCE_DIRECTORY_STRING {
      WORD Length;
      CHAR NameString[1];
    } IMAGE_RESOURCE_DIRECTORY_STRING,*PIMAGE_RESOURCE_DIRECTORY_STRING;

    typedef struct _IMAGE_RESOURCE_DIR_STRING_U {
      WORD Length;
      WCHAR NameString[1];
    } IMAGE_RESOURCE_DIR_STRING_U,*PIMAGE_RESOURCE_DIR_STRING_U;

    typedef struct _IMAGE_RESOURCE_DATA_ENTRY {
      DWORD OffsetToData;
      DWORD Size;
      DWORD CodePage;
      DWORD Reserved;
    } IMAGE_RESOURCE_DATA_ENTRY,*PIMAGE_RESOURCE_DATA_ENTRY;

    typedef struct {
      DWORD Size;
      DWORD TimeDateStamp;
      WORD MajorVersion;
      WORD MinorVersion;
      DWORD GlobalFlagsClear;
      DWORD GlobalFlagsSet;
      DWORD CriticalSectionDefaultTimeout;
      DWORD DeCommitFreeBlockThreshold;
      DWORD DeCommitTotalFreeThreshold;
      DWORD LockPrefixTable;
      DWORD MaximumAllocationSize;
      DWORD VirtualMemoryThreshold;
      DWORD ProcessHeapFlags;
      DWORD ProcessAffinityMask;
      WORD CSDVersion;
      WORD Reserved1;
      DWORD EditList;
      DWORD SecurityCookie;
      DWORD SEHandlerTable;
      DWORD SEHandlerCount;
    } IMAGE_LOAD_CONFIG_DIRECTORY32,*PIMAGE_LOAD_CONFIG_DIRECTORY32;

    typedef struct {
      DWORD Size;
      DWORD TimeDateStamp;
      WORD MajorVersion;
      WORD MinorVersion;
      DWORD GlobalFlagsClear;
      DWORD GlobalFlagsSet;
      DWORD CriticalSectionDefaultTimeout;
      ULONGLONG DeCommitFreeBlockThreshold;
      ULONGLONG DeCommitTotalFreeThreshold;
      ULONGLONG LockPrefixTable;
      ULONGLONG MaximumAllocationSize;
      ULONGLONG VirtualMemoryThreshold;
      ULONGLONG ProcessAffinityMask;
      DWORD ProcessHeapFlags;
      WORD CSDVersion;
      WORD Reserved1;
      ULONGLONG EditList;
      ULONGLONG SecurityCookie;
      ULONGLONG SEHandlerTable;
      ULONGLONG SEHandlerCount;
    } IMAGE_LOAD_CONFIG_DIRECTORY64,*PIMAGE_LOAD_CONFIG_DIRECTORY64;





    typedef IMAGE_LOAD_CONFIG_DIRECTORY32 IMAGE_LOAD_CONFIG_DIRECTORY;
    typedef PIMAGE_LOAD_CONFIG_DIRECTORY32 PIMAGE_LOAD_CONFIG_DIRECTORY;


    typedef struct _IMAGE_CE_RUNTIME_FUNCTION_ENTRY {
      DWORD FuncStart;
      DWORD PrologLen : 8;
      DWORD FuncLen : 22;
      DWORD ThirtyTwoBit : 1;
      DWORD ExceptionFlag : 1;
    } IMAGE_CE_RUNTIME_FUNCTION_ENTRY,*PIMAGE_CE_RUNTIME_FUNCTION_ENTRY;

    typedef struct _IMAGE_ALPHA64_RUNTIME_FUNCTION_ENTRY {
      ULONGLONG BeginAddress;
      ULONGLONG EndAddress;
      ULONGLONG ExceptionHandler;
      ULONGLONG HandlerData;
      ULONGLONG PrologEndAddress;
    } IMAGE_ALPHA64_RUNTIME_FUNCTION_ENTRY,*PIMAGE_ALPHA64_RUNTIME_FUNCTION_ENTRY;

    typedef struct _IMAGE_ALPHA_RUNTIME_FUNCTION_ENTRY {
      DWORD BeginAddress;
      DWORD EndAddress;
      DWORD ExceptionHandler;
      DWORD HandlerData;
      DWORD PrologEndAddress;
    } IMAGE_ALPHA_RUNTIME_FUNCTION_ENTRY,*PIMAGE_ALPHA_RUNTIME_FUNCTION_ENTRY;

    typedef struct _IMAGE_ARM_RUNTIME_FUNCTION_ENTRY {
      DWORD BeginAddress;
      __extension__ union {
 DWORD UnwindData;
 __extension__ struct {
   DWORD Flag : 2;
   DWORD FunctionLength : 11;
   DWORD Ret : 2;
   DWORD H : 1;
   DWORD Reg : 3;
   DWORD R : 1;
   DWORD L : 1;
   DWORD C : 1;
   DWORD StackAdjust : 10;
 } ;
      } ;
    } IMAGE_ARM_RUNTIME_FUNCTION_ENTRY,*PIMAGE_ARM_RUNTIME_FUNCTION_ENTRY;

    typedef struct _IMAGE_ARM64_RUNTIME_FUNCTION_ENTRY {
      DWORD BeginAddress;
      __extension__ union {
 DWORD UnwindData;
 __extension__ struct {
   DWORD Flag : 2;
   DWORD FunctionLength : 11;
   DWORD RegF : 3;
   DWORD RegI : 4;
   DWORD H : 1;
   DWORD CR : 2;
   DWORD FrameSize : 9;
 } ;
      } ;
    } IMAGE_ARM64_RUNTIME_FUNCTION_ENTRY,*PIMAGE_ARM64_RUNTIME_FUNCTION_ENTRY;

    typedef struct _IMAGE_RUNTIME_FUNCTION_ENTRY {
      DWORD BeginAddress;
      DWORD EndAddress;
      __extension__ union {
 DWORD UnwindInfoAddress;
 DWORD UnwindData;
      } ;
    } _IMAGE_RUNTIME_FUNCTION_ENTRY,*_PIMAGE_RUNTIME_FUNCTION_ENTRY;

    typedef _IMAGE_RUNTIME_FUNCTION_ENTRY IMAGE_IA64_RUNTIME_FUNCTION_ENTRY;
    typedef _PIMAGE_RUNTIME_FUNCTION_ENTRY PIMAGE_IA64_RUNTIME_FUNCTION_ENTRY;
    typedef IMAGE_ARM_RUNTIME_FUNCTION_ENTRY IMAGE_RUNTIME_FUNCTION_ENTRY;
    typedef PIMAGE_ARM_RUNTIME_FUNCTION_ENTRY PIMAGE_RUNTIME_FUNCTION_ENTRY;





    typedef struct _IMAGE_DEBUG_DIRECTORY {
      DWORD Characteristics;
      DWORD TimeDateStamp;
      WORD MajorVersion;
      WORD MinorVersion;
      DWORD Type;
      DWORD SizeOfData;
      DWORD AddressOfRawData;
      DWORD PointerToRawData;
    } IMAGE_DEBUG_DIRECTORY,*PIMAGE_DEBUG_DIRECTORY;
    typedef struct _IMAGE_COFF_SYMBOLS_HEADER {
      DWORD NumberOfSymbols;
      DWORD LvaToFirstSymbol;
      DWORD NumberOfLinenumbers;
      DWORD LvaToFirstLinenumber;
      DWORD RvaToFirstByteOfCode;
      DWORD RvaToLastByteOfCode;
      DWORD RvaToFirstByteOfData;
      DWORD RvaToLastByteOfData;
    } IMAGE_COFF_SYMBOLS_HEADER,*PIMAGE_COFF_SYMBOLS_HEADER;






    typedef struct _FPO_DATA {
      DWORD ulOffStart;
      DWORD cbProcSize;
      DWORD cdwLocals;
      WORD cdwParams;
      WORD cbProlog : 8;
      WORD cbRegs : 3;
      WORD fHasSEH : 1;
      WORD fUseBP : 1;
      WORD reserved : 1;
      WORD cbFrame : 2;
    } FPO_DATA,*PFPO_DATA;




    typedef struct _IMAGE_DEBUG_MISC {
      DWORD DataType;
      DWORD Length;
      BOOLEAN Unicode;
      BYTE Reserved[3];
      BYTE Data[1];
    } IMAGE_DEBUG_MISC,*PIMAGE_DEBUG_MISC;

    typedef struct _IMAGE_FUNCTION_ENTRY {
      DWORD StartingAddress;
      DWORD EndingAddress;
      DWORD EndOfPrologue;
    } IMAGE_FUNCTION_ENTRY,*PIMAGE_FUNCTION_ENTRY;

    typedef struct _IMAGE_FUNCTION_ENTRY64 {
      ULONGLONG StartingAddress;
      ULONGLONG EndingAddress;
      __extension__ union {
 ULONGLONG EndOfPrologue;
 ULONGLONG UnwindInfoAddress;
      } ;
    } IMAGE_FUNCTION_ENTRY64,*PIMAGE_FUNCTION_ENTRY64;

    typedef struct _IMAGE_SEPARATE_DEBUG_HEADER {
      WORD Signature;
      WORD Flags;
      WORD Machine;
      WORD Characteristics;
      DWORD TimeDateStamp;
      DWORD CheckSum;
      DWORD ImageBase;
      DWORD SizeOfImage;
      DWORD NumberOfSections;
      DWORD ExportedNamesSize;
      DWORD DebugDirectorySize;
      DWORD SectionAlignment;
      DWORD Reserved[2];
    } IMAGE_SEPARATE_DEBUG_HEADER,*PIMAGE_SEPARATE_DEBUG_HEADER;

    typedef struct _NON_PAGED_DEBUG_INFO {
      WORD Signature;
      WORD Flags;
      DWORD Size;
      WORD Machine;
      WORD Characteristics;
      DWORD TimeDateStamp;
      DWORD CheckSum;
      DWORD SizeOfImage;
      ULONGLONG ImageBase;
    } NON_PAGED_DEBUG_INFO,*PNON_PAGED_DEBUG_INFO;







    typedef struct _ImageArchitectureHeader {
      unsigned int AmaskValue: 1;
      int Adummy1 : 7;
      unsigned int AmaskShift : 8;
      int Adummy2 : 16;
      DWORD FirstEntryRVA;
    } IMAGE_ARCHITECTURE_HEADER,*PIMAGE_ARCHITECTURE_HEADER;

    typedef struct _ImageArchitectureEntry {
      DWORD FixupInstRVA;
      DWORD NewInst;
    } IMAGE_ARCHITECTURE_ENTRY,*PIMAGE_ARCHITECTURE_ENTRY;







#pragma pack(pop)



    typedef struct IMPORT_OBJECT_HEADER {
      WORD Sig1;
      WORD Sig2;
      WORD Version;
      WORD Machine;
      DWORD TimeDateStamp;
      DWORD SizeOfData;
      __extension__ union {
 WORD Ordinal;
 WORD Hint;
      };
      WORD Type : 2;
      WORD NameType : 3;
      WORD Reserved : 11;
    } IMPORT_OBJECT_HEADER;

    typedef enum IMPORT_OBJECT_TYPE {
      IMPORT_OBJECT_CODE = 0,IMPORT_OBJECT_DATA = 1,IMPORT_OBJECT_CONST = 2
    } IMPORT_OBJECT_TYPE;

    typedef enum IMPORT_OBJECT_NAME_TYPE {
      IMPORT_OBJECT_ORDINAL = 0,IMPORT_OBJECT_NAME = 1,IMPORT_OBJECT_NAME_NO_PREFIX = 2,IMPORT_OBJECT_NAME_UNDECORATE = 3
    } IMPORT_OBJECT_NAME_TYPE;



    typedef enum ReplacesCorHdrNumericDefines {
      COMIMAGE_FLAGS_ILONLY = 0x00000001,COMIMAGE_FLAGS_32BITREQUIRED = 0x00000002,COMIMAGE_FLAGS_IL_LIBRARY = 0x00000004,
      COMIMAGE_FLAGS_STRONGNAMESIGNED = 0x00000008,COMIMAGE_FLAGS_TRACKDEBUGDATA = 0x00010000,COR_VERSION_MAJOR_V2 = 2,
      COR_VERSION_MAJOR = COR_VERSION_MAJOR_V2,COR_VERSION_MINOR = 0,COR_DELETED_NAME_LENGTH = 8,COR_VTABLEGAP_NAME_LENGTH = 8,
      NATIVE_TYPE_MAX_CB = 1,COR_ILMETHOD_SECT_SMALL_MAX_DATASIZE= 0xFF,IMAGE_COR_MIH_METHODRVA = 0x01,IMAGE_COR_MIH_EHRVA = 0x02,
      IMAGE_COR_MIH_BASICBLOCK = 0x08,COR_VTABLE_32BIT =0x01,COR_VTABLE_64BIT =0x02,COR_VTABLE_FROM_UNMANAGED = 0x04,
      COR_VTABLE_CALL_MOST_DERIVED = 0x10,IMAGE_COR_EATJ_THUNK_SIZE = 32,MAX_CLASS_NAME =1024,MAX_PACKAGE_NAME = 1024
    } ReplacesCorHdrNumericDefines;

    typedef struct IMAGE_COR20_HEADER {
      DWORD cb;
      WORD MajorRuntimeVersion;
      WORD MinorRuntimeVersion;
      IMAGE_DATA_DIRECTORY MetaData;
      DWORD Flags;
      __extension__ union {
 DWORD EntryPointToken;
 DWORD EntryPointRVA;
      } ;
      IMAGE_DATA_DIRECTORY Resources;
      IMAGE_DATA_DIRECTORY StrongNameSignature;
      IMAGE_DATA_DIRECTORY CodeManagerTable;
      IMAGE_DATA_DIRECTORY VTableFixups;
      IMAGE_DATA_DIRECTORY ExportAddressTableJumps;
      IMAGE_DATA_DIRECTORY ManagedNativeHeader;
    } IMAGE_COR20_HEADER,*PIMAGE_COR20_HEADER;



    __attribute__((dllimport)) WORD RtlCaptureStackBackTrace (DWORD FramesToSkip, DWORD FramesToCapture, PVOID *BackTrace, PDWORD BackTraceHash);
    __attribute__((dllimport)) void RtlCaptureContext (PCONTEXT ContextRecord);
    __attribute__((dllimport)) SIZE_T RtlCompareMemory (const void *Source1, const void *Source2, SIZE_T Length);
    __attribute__((dllimport)) BOOLEAN __attribute__((__cdecl__)) RtlAddFunctionTable (PRUNTIME_FUNCTION FunctionTable, DWORD EntryCount, DWORD BaseAddress);
    __attribute__((dllimport)) BOOLEAN __attribute__((__cdecl__)) RtlDeleteFunctionTable (PRUNTIME_FUNCTION FunctionTable);
    __attribute__((dllimport)) BOOLEAN __attribute__((__cdecl__)) RtlInstallFunctionTableCallback (DWORD TableIdentifier, DWORD BaseAddress, DWORD Length, PGET_RUNTIME_FUNCTION_CALLBACK Callback, PVOID Context, PCWSTR OutOfProcessCallbackDll);
    __attribute__((dllimport)) void __attribute__((__cdecl__)) RtlRestoreContext (PCONTEXT ContextRecord, struct _EXCEPTION_RECORD *ExceptionRecord);
    __attribute__((dllimport)) PEXCEPTION_ROUTINE RtlVirtualUnwind (DWORD HandlerType, DWORD ImageBase, DWORD ControlPc, PRUNTIME_FUNCTION FunctionEntry, PCONTEXT ContextRecord, PVOID *HandlerData, PDWORD EstablisherFrame, PKNONVOLATILE_CONTEXT_POINTERS ContextPointers);
    __attribute__((dllimport)) void RtlUnwind (PVOID TargetFrame, PVOID TargetIp, PEXCEPTION_RECORD ExceptionRecord, PVOID ReturnValue);
    __attribute__((dllimport)) PVOID RtlPcToFileHeader (PVOID PcValue, PVOID *BaseOfImage);





    __attribute__((dllimport)) PRUNTIME_FUNCTION RtlLookupFunctionEntry (ULONG_PTR ControlPc, PDWORD ImageBase, PUNWIND_HISTORY_TABLE HistoryTable);
    __attribute__((dllimport)) void RtlUnwindEx (PVOID TargetFrame, PVOID TargetIp, PEXCEPTION_RECORD ExceptionRecord, PVOID ReturnValue, PCONTEXT ContextRecord, PUNWIND_HISTORY_TABLE HistoryTable);
    typedef struct _SINGLE_LIST_ENTRY SLIST_ENTRY,*PSLIST_ENTRY;

    typedef union _SLIST_HEADER {
      ULONGLONG Alignment;
      __extension__ struct {
 SLIST_ENTRY Next;
 WORD Depth;
 WORD Sequence;
      } ;
    } SLIST_HEADER,*PSLIST_HEADER;





    __attribute__((dllimport)) void RtlInitializeSListHead (PSLIST_HEADER ListHead);
    __attribute__((dllimport)) PSLIST_ENTRY RtlFirstEntrySList (const SLIST_HEADER *ListHead);
    __attribute__((dllimport)) PSLIST_ENTRY RtlInterlockedPopEntrySList (PSLIST_HEADER ListHead);
    __attribute__((dllimport)) PSLIST_ENTRY RtlInterlockedPushEntrySList (PSLIST_HEADER ListHead, PSLIST_ENTRY ListEntry);
    __attribute__((dllimport)) PSLIST_ENTRY RtlInterlockedPushListSListEx (PSLIST_HEADER ListHead, PSLIST_ENTRY List, PSLIST_ENTRY ListEnd, DWORD Count);
    __attribute__((dllimport)) PSLIST_ENTRY RtlInterlockedFlushSList (PSLIST_HEADER ListHead);
    __attribute__((dllimport)) WORD RtlQueryDepthSList (PSLIST_HEADER ListHead);





typedef struct _RTL_RUN_ONCE { PVOID Ptr; } RTL_RUN_ONCE, *PRTL_RUN_ONCE;
typedef DWORD ( *PRTL_RUN_ONCE_INIT_FN)(PRTL_RUN_ONCE, PVOID, PVOID *);
  typedef struct _RTL_BARRIER {
    DWORD Reserved1;
    DWORD Reserved2;
    ULONG_PTR Reserved3[2];
    DWORD Reserved4;
    DWORD Reserved5;
  } RTL_BARRIER,*PRTL_BARRIER;
    PVOID RtlSecureZeroMemory(PVOID ptr,SIZE_T cnt);


    extern __inline __attribute__((__gnu_inline__)) PVOID RtlSecureZeroMemory(PVOID ptr,SIZE_T cnt) {
      volatile char *vptr =(volatile char *)ptr;



      while(cnt) {
 *vptr++ = 0;
 cnt--;
      }

      return ptr;
    }


    typedef struct _MESSAGE_RESOURCE_ENTRY {
      WORD Length;
      WORD Flags;
      BYTE Text[1];
    } MESSAGE_RESOURCE_ENTRY,*PMESSAGE_RESOURCE_ENTRY;
    typedef struct _MESSAGE_RESOURCE_BLOCK {
      DWORD LowId;
      DWORD HighId;
      DWORD OffsetToEntries;
    } MESSAGE_RESOURCE_BLOCK,*PMESSAGE_RESOURCE_BLOCK;

    typedef struct _MESSAGE_RESOURCE_DATA {
      DWORD NumberOfBlocks;
      MESSAGE_RESOURCE_BLOCK Blocks[1];
    } MESSAGE_RESOURCE_DATA,*PMESSAGE_RESOURCE_DATA;

    typedef struct _OSVERSIONINFOA {
      DWORD dwOSVersionInfoSize;
      DWORD dwMajorVersion;
      DWORD dwMinorVersion;
      DWORD dwBuildNumber;
      DWORD dwPlatformId;
      CHAR szCSDVersion[128];
    } OSVERSIONINFOA,*POSVERSIONINFOA,*LPOSVERSIONINFOA;

    typedef struct _OSVERSIONINFOW {
      DWORD dwOSVersionInfoSize;
      DWORD dwMajorVersion;
      DWORD dwMinorVersion;
      DWORD dwBuildNumber;
      DWORD dwPlatformId;
      WCHAR szCSDVersion[128];
    } OSVERSIONINFOW,*POSVERSIONINFOW,*LPOSVERSIONINFOW,RTL_OSVERSIONINFOW,*PRTL_OSVERSIONINFOW;

    typedef OSVERSIONINFOA OSVERSIONINFO;
    typedef POSVERSIONINFOA POSVERSIONINFO;
    typedef LPOSVERSIONINFOA LPOSVERSIONINFO;

    typedef struct _OSVERSIONINFOEXA {
      DWORD dwOSVersionInfoSize;
      DWORD dwMajorVersion;
      DWORD dwMinorVersion;
      DWORD dwBuildNumber;
      DWORD dwPlatformId;
      CHAR szCSDVersion[128];
      WORD wServicePackMajor;
      WORD wServicePackMinor;
      WORD wSuiteMask;
      BYTE wProductType;
      BYTE wReserved;
    } OSVERSIONINFOEXA,*POSVERSIONINFOEXA,*LPOSVERSIONINFOEXA;

    typedef struct _OSVERSIONINFOEXW {
      DWORD dwOSVersionInfoSize;
      DWORD dwMajorVersion;
      DWORD dwMinorVersion;
      DWORD dwBuildNumber;
      DWORD dwPlatformId;
      WCHAR szCSDVersion[128];
      WORD wServicePackMajor;
      WORD wServicePackMinor;
      WORD wSuiteMask;
      BYTE wProductType;
      BYTE wReserved;
    } OSVERSIONINFOEXW,*POSVERSIONINFOEXW,*LPOSVERSIONINFOEXW,RTL_OSVERSIONINFOEXW,*PRTL_OSVERSIONINFOEXW;

    typedef OSVERSIONINFOEXA OSVERSIONINFOEX;
    typedef POSVERSIONINFOEXA POSVERSIONINFOEX;
    typedef LPOSVERSIONINFOEXA LPOSVERSIONINFOEX;
    __attribute__((dllimport)) ULONGLONG VerSetConditionMask (ULONGLONG ConditionMask, DWORD TypeMask, BYTE Condition);





    __attribute__((dllimport)) BOOLEAN RtlGetProductInfo (DWORD OSMajorVersion, DWORD OSMinorVersion, DWORD SpMajorVersion, DWORD SpMinorVersion, PDWORD ReturnedProductType);





    typedef enum _RTL_UMS_THREAD_INFO_CLASS {
      UmsThreadInvalidInfoClass = 0,
      UmsThreadUserContext,
      UmsThreadPriority,
      UmsThreadAffinity,
      UmsThreadTeb,
      UmsThreadIsSuspended,
      UmsThreadIsTerminated,
      UmsThreadMaxInfoClass
    } RTL_UMS_THREAD_INFO_CLASS,*PRTL_UMS_THREAD_INFO_CLASS;

    typedef enum _RTL_UMS_SCHEDULER_REASON {
      UmsSchedulerStartup = 0,
      UmsSchedulerThreadBlocked,
      UmsSchedulerThreadYield,
    } RTL_UMS_SCHEDULER_REASON,*PRTL_UMS_SCHEDULER_REASON;

    typedef void RTL_UMS_SCHEDULER_ENTRY_POINT (RTL_UMS_SCHEDULER_REASON Reason, ULONG_PTR ActivationPayload, PVOID SchedulerParam);
    typedef RTL_UMS_SCHEDULER_ENTRY_POINT *PRTL_UMS_SCHEDULER_ENTRY_POINT;
    typedef struct _RTL_CRITICAL_SECTION_DEBUG {
      WORD Type;
      WORD CreatorBackTraceIndex;
      struct _RTL_CRITICAL_SECTION *CriticalSection;
      LIST_ENTRY ProcessLocksList;
      DWORD EntryCount;
      DWORD ContentionCount;
      DWORD Flags;
      WORD CreatorBackTraceIndexHigh;
      WORD SpareWORD;
    } RTL_CRITICAL_SECTION_DEBUG,*PRTL_CRITICAL_SECTION_DEBUG,RTL_RESOURCE_DEBUG,*PRTL_RESOURCE_DEBUG;






#pragma pack(push,8)
 typedef struct _RTL_CRITICAL_SECTION {
      PRTL_CRITICAL_SECTION_DEBUG DebugInfo;
      LONG LockCount;
      LONG RecursionCount;
      HANDLE OwningThread;
      HANDLE LockSemaphore;
      ULONG_PTR SpinCount;
    } RTL_CRITICAL_SECTION,*PRTL_CRITICAL_SECTION;







#pragma pack(pop)

    typedef struct _RTL_SRWLOCK { PVOID Ptr; } RTL_SRWLOCK,*PRTL_SRWLOCK;
    typedef struct _RTL_CONDITION_VARIABLE { PVOID Ptr; } RTL_CONDITION_VARIABLE,*PRTL_CONDITION_VARIABLE;






    typedef void ( *PAPCFUNC) (ULONG_PTR Parameter);
    typedef LONG ( *PVECTORED_EXCEPTION_HANDLER) (struct _EXCEPTION_POINTERS *ExceptionInfo);

    typedef enum _HEAP_INFORMATION_CLASS {
      HeapCompatibilityInformation,
      HeapEnableTerminationOnCorruption
    } HEAP_INFORMATION_CLASS;

    typedef void ( *WORKERCALLBACKFUNC) (PVOID);
    typedef void ( *APC_CALLBACK_FUNCTION) (DWORD, PVOID, PVOID);
    typedef void ( *WAITORTIMERCALLBACKFUNC) (PVOID, BOOLEAN);
    typedef WAITORTIMERCALLBACKFUNC WAITORTIMERCALLBACK;
    typedef void ( *PFLS_CALLBACK_FUNCTION) (PVOID lpFlsData);
    typedef BOOLEAN ( *PSECURE_MEMORY_CACHE_CALLBACK) (PVOID Addr, SIZE_T Range);
    typedef enum _ACTIVATION_CONTEXT_INFO_CLASS {
      ActivationContextBasicInformation = 1,
      ActivationContextDetailedInformation = 2,
      AssemblyDetailedInformationInActivationContext = 3,
      FileInformationInAssemblyOfAssemblyInActivationContext = 4,
      RunlevelInformationInActivationContext = 5,
      CompatibilityInformationInActivationContext = 6,
      ActivationContextManifestResourceName = 7,
      MaxActivationContextInfoClass,
      AssemblyDetailedInformationInActivationContxt = 3,
      FileInformationInAssemblyOfAssemblyInActivationContxt = 4
    } ACTIVATION_CONTEXT_INFO_CLASS;

    typedef enum {
      ACTCTX_RUN_LEVEL_UNSPECIFIED = 0,
      ACTCTX_RUN_LEVEL_AS_INVOKER,
      ACTCTX_RUN_LEVEL_HIGHEST_AVAILABLE,
      ACTCTX_RUN_LEVEL_REQUIRE_ADMIN,
      ACTCTX_RUN_LEVEL_NUMBERS
    } ACTCTX_REQUESTED_RUN_LEVEL;

    typedef enum {
      ACTCTX_COMPATIBILITY_ELEMENT_TYPE_UNKNOWN = 0,
      ACTCTX_COMPATIBILITY_ELEMENT_TYPE_OS,
      ACTCTX_COMPATIBILITY_ELEMENT_TYPE_MITIGATION
    } ACTCTX_COMPATIBILITY_ELEMENT_TYPE;

    typedef struct _ACTIVATION_CONTEXT_QUERY_INDEX {
      DWORD ulAssemblyIndex;
      DWORD ulFileIndexInAssembly;
    } ACTIVATION_CONTEXT_QUERY_INDEX,*PACTIVATION_CONTEXT_QUERY_INDEX;

    typedef struct _ASSEMBLY_FILE_DETAILED_INFORMATION {
      DWORD ulFlags;
      DWORD ulFilenameLength;
      DWORD ulPathLength;
      PCWSTR lpFileName;
      PCWSTR lpFilePath;
    } ASSEMBLY_FILE_DETAILED_INFORMATION,*PASSEMBLY_FILE_DETAILED_INFORMATION;

    typedef struct _ACTIVATION_CONTEXT_ASSEMBLY_DETAILED_INFORMATION {
      DWORD ulFlags;
      DWORD ulEncodedAssemblyIdentityLength;
      DWORD ulManifestPathType;
      DWORD ulManifestPathLength;
      LARGE_INTEGER liManifestLastWriteTime;
      DWORD ulPolicyPathType;
      DWORD ulPolicyPathLength;
      LARGE_INTEGER liPolicyLastWriteTime;
      DWORD ulMetadataSatelliteRosterIndex;
      DWORD ulManifestVersionMajor;
      DWORD ulManifestVersionMinor;
      DWORD ulPolicyVersionMajor;
      DWORD ulPolicyVersionMinor;
      DWORD ulAssemblyDirectoryNameLength;
      PCWSTR lpAssemblyEncodedAssemblyIdentity;
      PCWSTR lpAssemblyManifestPath;
      PCWSTR lpAssemblyPolicyPath;
      PCWSTR lpAssemblyDirectoryName;
      DWORD ulFileCount;
    } ACTIVATION_CONTEXT_ASSEMBLY_DETAILED_INFORMATION,*PACTIVATION_CONTEXT_ASSEMBLY_DETAILED_INFORMATION;

    typedef struct _ACTIVATION_CONTEXT_RUN_LEVEL_INFORMATION {
      DWORD ulFlags;
      ACTCTX_REQUESTED_RUN_LEVEL RunLevel;
      DWORD UiAccess;
    } ACTIVATION_CONTEXT_RUN_LEVEL_INFORMATION,*PACTIVATION_CONTEXT_RUN_LEVEL_INFORMATION;

    typedef struct _COMPATIBILITY_CONTEXT_ELEMENT {
      GUID Id;
      ACTCTX_COMPATIBILITY_ELEMENT_TYPE Type;
    } COMPATIBILITY_CONTEXT_ELEMENT,*PCOMPATIBILITY_CONTEXT_ELEMENT;



    typedef struct _ACTIVATION_CONTEXT_COMPATIBILITY_INFORMATION {
      DWORD ElementCount;
      COMPATIBILITY_CONTEXT_ELEMENT Elements[];
    } ACTIVATION_CONTEXT_COMPATIBILITY_INFORMATION,*PACTIVATION_CONTEXT_COMPATIBILITY_INFORMATION;



    typedef struct _SUPPORTED_OS_INFO {
      WORD OsCount;
      WORD MitigationExist;
      WORD OsList[(4)];
    } SUPPORTED_OS_INFO,*PSUPPORTED_OS_INFO;

    typedef struct _ACTIVATION_CONTEXT_DETAILED_INFORMATION {
      DWORD dwFlags;
      DWORD ulFormatVersion;
      DWORD ulAssemblyCount;
      DWORD ulRootManifestPathType;
      DWORD ulRootManifestPathChars;
      DWORD ulRootConfigurationPathType;
      DWORD ulRootConfigurationPathChars;
      DWORD ulAppDirPathType;
      DWORD ulAppDirPathChars;
      PCWSTR lpRootManifestPath;
      PCWSTR lpRootConfigurationPath;
      PCWSTR lpAppDirPath;
    } ACTIVATION_CONTEXT_DETAILED_INFORMATION,*PACTIVATION_CONTEXT_DETAILED_INFORMATION;

    typedef const struct _ACTIVATION_CONTEXT_QUERY_INDEX *PCACTIVATION_CONTEXT_QUERY_INDEX;
    typedef const ASSEMBLY_FILE_DETAILED_INFORMATION *PCASSEMBLY_FILE_DETAILED_INFORMATION;
    typedef const struct _ACTIVATION_CONTEXT_ASSEMBLY_DETAILED_INFORMATION *PCACTIVATION_CONTEXT_ASSEMBLY_DETAILED_INFORMATION;
    typedef const struct _ACTIVATION_CONTEXT_RUN_LEVEL_INFORMATION *PCACTIVATION_CONTEXT_RUN_LEVEL_INFORMATION;
    typedef const struct _COMPATIBILITY_CONTEXT_ELEMENT *PCCOMPATIBILITY_CONTEXT_ELEMENT;
    typedef const struct _ACTIVATION_CONTEXT_COMPATIBILITY_INFORMATION *PCACTIVATION_CONTEXT_COMPATIBILITY_INFORMATION;
    typedef const struct _ACTIVATION_CONTEXT_DETAILED_INFORMATION *PCACTIVATION_CONTEXT_DETAILED_INFORMATION;
    typedef void ( *RTL_VERIFIER_DLL_LOAD_CALLBACK) (PWSTR DllName,PVOID DllBase,SIZE_T DllSize,PVOID Reserved);
    typedef void ( *RTL_VERIFIER_DLL_UNLOAD_CALLBACK) (PWSTR DllName,PVOID DllBase,SIZE_T DllSize,PVOID Reserved);
    typedef void ( *RTL_VERIFIER_NTDLLHEAPFREE_CALLBACK)(PVOID AllocationBase,SIZE_T AllocationSize);

    typedef struct _RTL_VERIFIER_THUNK_DESCRIPTOR {
      PCHAR ThunkName;
      PVOID ThunkOldAddress;
      PVOID ThunkNewAddress;
    } RTL_VERIFIER_THUNK_DESCRIPTOR,*PRTL_VERIFIER_THUNK_DESCRIPTOR;

    typedef struct _RTL_VERIFIER_DLL_DESCRIPTOR {
      PWCHAR DllName;
      DWORD DllFlags;
      PVOID DllAddress;
      PRTL_VERIFIER_THUNK_DESCRIPTOR DllThunks;
    } RTL_VERIFIER_DLL_DESCRIPTOR,*PRTL_VERIFIER_DLL_DESCRIPTOR;

    typedef struct _RTL_VERIFIER_PROVIDER_DESCRIPTOR {
      DWORD Length;
      PRTL_VERIFIER_DLL_DESCRIPTOR ProviderDlls;
      RTL_VERIFIER_DLL_LOAD_CALLBACK ProviderDllLoadCallback;
      RTL_VERIFIER_DLL_UNLOAD_CALLBACK ProviderDllUnloadCallback;
      PWSTR VerifierImage;
      DWORD VerifierFlags;
      DWORD VerifierDebug;
      PVOID RtlpGetStackTraceAddress;
      PVOID RtlpDebugPageHeapCreate;
      PVOID RtlpDebugPageHeapDestroy;
      RTL_VERIFIER_NTDLLHEAPFREE_CALLBACK ProviderNtdllHeapFreeCallback;
    } RTL_VERIFIER_PROVIDER_DESCRIPTOR,*PRTL_VERIFIER_PROVIDER_DESCRIPTOR;
    void RtlApplicationVerifierStop(ULONG_PTR Code,PSTR Message,ULONG_PTR Param1,PSTR Description1,ULONG_PTR Param2,PSTR Description2,ULONG_PTR Param3,PSTR Description3,ULONG_PTR Param4,PSTR Description4);
    __attribute__((dllimport)) DWORD RtlSetHeapInformation(PVOID HeapHandle,HEAP_INFORMATION_CLASS HeapInformationClass,PVOID HeapInformation,SIZE_T HeapInformationLength);
    __attribute__((dllimport)) DWORD RtlQueryHeapInformation(PVOID HeapHandle,HEAP_INFORMATION_CLASS HeapInformationClass,PVOID HeapInformation,SIZE_T HeapInformationLength,PSIZE_T ReturnLength);
    DWORD RtlMultipleAllocateHeap(PVOID HeapHandle,DWORD Flags,SIZE_T Size,DWORD Count,PVOID *Array);
    DWORD RtlMultipleFreeHeap(PVOID HeapHandle,DWORD Flags,DWORD Count,PVOID *Array);

    typedef struct _HARDWARE_COUNTER_DATA {
      HARDWARE_COUNTER_TYPE Type;
      DWORD Reserved;
      DWORD64 Value;
    } HARDWARE_COUNTER_DATA,*PHARDWARE_COUNTER_DATA;

    typedef struct _PERFORMANCE_DATA {
      WORD Size;
      BYTE Version;
      BYTE HwCountersCount;
      DWORD ContextSwitchCount;
      DWORD64 WaitReasonBitMap;
      DWORD64 CycleTime;
      DWORD RetryCount;
      DWORD Reserved;
      HARDWARE_COUNTER_DATA HwCounters[16];
    } PERFORMANCE_DATA,*PPERFORMANCE_DATA;
    typedef struct _EVENTLOGRECORD {
      DWORD Length;
      DWORD Reserved;
      DWORD RecordNumber;
      DWORD TimeGenerated;
      DWORD TimeWritten;
      DWORD EventID;
      WORD EventType;
      WORD NumStrings;
      WORD EventCategory;
      WORD ReservedFlags;
      DWORD ClosingRecordNumber;
      DWORD StringOffset;
      DWORD UserSidLength;
      DWORD UserSidOffset;
      DWORD DataLength;
      DWORD DataOffset;
    } EVENTLOGRECORD,*PEVENTLOGRECORD;



    typedef struct _EVENTSFORLOGFILE {
      DWORD ulSize;
      WCHAR szLogicalLogFile[256];
      DWORD ulNumRecords;
      EVENTLOGRECORD pEventLogRecords[];
    } EVENTSFORLOGFILE,*PEVENTSFORLOGFILE;

    typedef struct _PACKEDEVENTINFO {
      DWORD ulSize;
      DWORD ulNumEventsForLogFile;
      DWORD ulOffsets[];
    } PACKEDEVENTINFO,*PPACKEDEVENTINFO;
    typedef enum _CM_SERVICE_NODE_TYPE {
      DriverType = 0x00000001,FileSystemType = 0x00000002,Win32ServiceOwnProcess = 0x00000010,
      Win32ServiceShareProcess = 0x00000020,AdapterType = 0x00000004,RecognizerType = 0x00000008
    } SERVICE_NODE_TYPE;

    typedef enum _CM_SERVICE_LOAD_TYPE {
      BootLoad = 0x00000000,SystemLoad = 0x00000001,AutoLoad = 0x00000002,DemandLoad = 0x00000003,
      DisableLoad = 0x00000004
    } SERVICE_LOAD_TYPE;

    typedef enum _CM_ERROR_CONTROL_TYPE {
      IgnoreError = 0x00000000,NormalError = 0x00000001,SevereError = 0x00000002,CriticalError = 0x00000003
    } SERVICE_ERROR_TYPE;
    typedef struct _TAPE_ERASE {
      DWORD Type;
      BOOLEAN Immediate;
    } TAPE_ERASE,*PTAPE_ERASE;
    typedef struct _TAPE_PREPARE {
      DWORD Operation;
      BOOLEAN Immediate;
    } TAPE_PREPARE,*PTAPE_PREPARE;






    typedef struct _TAPE_WRITE_MARKS {
      DWORD Type;
      DWORD Count;
      BOOLEAN Immediate;
    } TAPE_WRITE_MARKS,*PTAPE_WRITE_MARKS;





    typedef struct _TAPE_GET_POSITION {
      DWORD Type;
      DWORD Partition;
      LARGE_INTEGER Offset;
    } TAPE_GET_POSITION,*PTAPE_GET_POSITION;
    typedef struct _TAPE_SET_POSITION {
      DWORD Method;
      DWORD Partition;
      LARGE_INTEGER Offset;
      BOOLEAN Immediate;
    } TAPE_SET_POSITION,*PTAPE_SET_POSITION;
    typedef struct _TAPE_GET_DRIVE_PARAMETERS {
      BOOLEAN ECC;
      BOOLEAN Compression;
      BOOLEAN DataPadding;
      BOOLEAN ReportSetmarks;
      DWORD DefaultBlockSize;
      DWORD MaximumBlockSize;
      DWORD MinimumBlockSize;
      DWORD MaximumPartitionCount;
      DWORD FeaturesLow;
      DWORD FeaturesHigh;
      DWORD EOTWarningZoneSize;
    } TAPE_GET_DRIVE_PARAMETERS,*PTAPE_GET_DRIVE_PARAMETERS;

    typedef struct _TAPE_SET_DRIVE_PARAMETERS {
      BOOLEAN ECC;
      BOOLEAN Compression;
      BOOLEAN DataPadding;
      BOOLEAN ReportSetmarks;
      DWORD EOTWarningZoneSize;
    } TAPE_SET_DRIVE_PARAMETERS,*PTAPE_SET_DRIVE_PARAMETERS;

    typedef struct _TAPE_GET_MEDIA_PARAMETERS {
      LARGE_INTEGER Capacity;
      LARGE_INTEGER Remaining;
      DWORD BlockSize;
      DWORD PartitionCount;
      BOOLEAN WriteProtected;
    } TAPE_GET_MEDIA_PARAMETERS,*PTAPE_GET_MEDIA_PARAMETERS;

    typedef struct _TAPE_SET_MEDIA_PARAMETERS {
      DWORD BlockSize;
    } TAPE_SET_MEDIA_PARAMETERS,*PTAPE_SET_MEDIA_PARAMETERS;





    typedef struct _TAPE_CREATE_PARTITION {
      DWORD Method;
      DWORD Count;
      DWORD Size;
    } TAPE_CREATE_PARTITION,*PTAPE_CREATE_PARTITION;







    typedef struct _TAPE_WMI_OPERATIONS {
      DWORD Method;
      DWORD DataBufferSize;
      PVOID DataBuffer;
    } TAPE_WMI_OPERATIONS,*PTAPE_WMI_OPERATIONS;

    typedef enum _TAPE_DRIVE_PROBLEM_TYPE {
      TapeDriveProblemNone,TapeDriveReadWriteWarning,TapeDriveReadWriteError,TapeDriveReadWarning,TapeDriveWriteWarning,TapeDriveReadError,TapeDriveWriteError,TapeDriveHardwareError,TapeDriveUnsupportedMedia,TapeDriveScsiConnectionError,TapeDriveTimetoClean,TapeDriveCleanDriveNow,TapeDriveMediaLifeExpired,TapeDriveSnappedTape
    } TAPE_DRIVE_PROBLEM_TYPE;


  typedef DWORD TP_VERSION,*PTP_VERSION;
  typedef struct _TP_CALLBACK_INSTANCE TP_CALLBACK_INSTANCE,*PTP_CALLBACK_INSTANCE;
  typedef void ( *PTP_SIMPLE_CALLBACK) (PTP_CALLBACK_INSTANCE Instance, PVOID Context);
  typedef struct _TP_POOL TP_POOL,*PTP_POOL;

  typedef enum _TP_CALLBACK_PRIORITY {
    TP_CALLBACK_PRIORITY_HIGH,
    TP_CALLBACK_PRIORITY_NORMAL,
    TP_CALLBACK_PRIORITY_LOW,
    TP_CALLBACK_PRIORITY_INVALID,
    TP_CALLBACK_PRIORITY_COUNT = TP_CALLBACK_PRIORITY_INVALID
  } TP_CALLBACK_PRIORITY;

  typedef struct _TP_POOL_STACK_INFORMATION {
    SIZE_T StackReserve;
    SIZE_T StackCommit;
  } TP_POOL_STACK_INFORMATION, *PTP_POOL_STACK_INFORMATION;

  typedef struct _TP_CLEANUP_GROUP TP_CLEANUP_GROUP,*PTP_CLEANUP_GROUP;
  typedef void ( *PTP_CLEANUP_GROUP_CANCEL_CALLBACK) (PVOID ObjectContext, PVOID CleanupContext);
  typedef struct _TP_CALLBACK_ENVIRON_V1 {
    TP_VERSION Version;
    PTP_POOL Pool;
    PTP_CLEANUP_GROUP CleanupGroup;
    PTP_CLEANUP_GROUP_CANCEL_CALLBACK CleanupGroupCancelCallback;
    PVOID RaceDll;
    struct _ACTIVATION_CONTEXT *ActivationContext;
    PTP_SIMPLE_CALLBACK FinalizationCallback;
    union {
      DWORD Flags;
      struct {
 DWORD LongFunction : 1;
 DWORD Persistent : 1;
 DWORD Private : 30;
      } s;
    } u;
  } TP_CALLBACK_ENVIRON_V1;
  typedef TP_CALLBACK_ENVIRON_V1 TP_CALLBACK_ENVIRON,*PTP_CALLBACK_ENVIRON;


  typedef struct _TP_WORK TP_WORK,*PTP_WORK;
  typedef void ( *PTP_WORK_CALLBACK) (PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_WORK Work);
  typedef struct _TP_TIMER TP_TIMER,*PTP_TIMER;
  typedef void ( *PTP_TIMER_CALLBACK) (PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_TIMER Timer);
  typedef DWORD TP_WAIT_RESULT;
  typedef struct _TP_WAIT TP_WAIT,*PTP_WAIT;
  typedef void ( *PTP_WAIT_CALLBACK) (PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_WAIT Wait, TP_WAIT_RESULT WaitResult);
  typedef struct _TP_IO TP_IO,*PTP_IO;


    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpInitializeCallbackEnviron (PTP_CALLBACK_ENVIRON cbe) {
      cbe->Pool = ((void*)0);
      cbe->CleanupGroup = ((void*)0);
      cbe->CleanupGroupCancelCallback = ((void*)0);
      cbe->RaceDll = ((void*)0);
      cbe->ActivationContext = ((void*)0);
      cbe->FinalizationCallback = ((void*)0);
      cbe->u.Flags = 0;

      cbe->Version = 1;





    }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackThreadpool (PTP_CALLBACK_ENVIRON cbe, PTP_POOL pool) { cbe->Pool = pool; }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackCleanupGroup (PTP_CALLBACK_ENVIRON cbe, PTP_CLEANUP_GROUP cleanup_group, PTP_CLEANUP_GROUP_CANCEL_CALLBACK cleanup_group_cb) {
      cbe->CleanupGroup = cleanup_group;
      cbe->CleanupGroupCancelCallback = cleanup_group_cb;
    }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackActivationContext (PTP_CALLBACK_ENVIRON cbe, struct _ACTIVATION_CONTEXT *actx) { cbe->ActivationContext = actx; }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackNoActivationContext (PTP_CALLBACK_ENVIRON cbe) { cbe->ActivationContext = (struct _ACTIVATION_CONTEXT *) (LONG_PTR) -1; }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackLongFunction (PTP_CALLBACK_ENVIRON cbe) { cbe->u.s.LongFunction = 1; }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackRaceWithDll (PTP_CALLBACK_ENVIRON cbe, PVOID h) { cbe->RaceDll = h; }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackFinalizationCallback (PTP_CALLBACK_ENVIRON cbe, PTP_SIMPLE_CALLBACK fini_cb) { cbe->FinalizationCallback = fini_cb; }



    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpSetCallbackPersistent (PTP_CALLBACK_ENVIRON cbe) { cbe->u.s.Persistent = 1; }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void TpDestroyCallbackEnviron (PTP_CALLBACK_ENVIRON cbe) { {(cbe) = (cbe);}; }
    struct _TEB *NtCurrentTeb (void);
    PVOID GetCurrentFiber (void);
    PVOID GetFiberData (void);
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) struct _TEB *NtCurrentTeb(void) { struct _TEB *teb;
    __asm ("mrc p15, 0, %0, c13, c0, 2" : "=r" (teb));
    return teb; }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) PVOID GetCurrentFiber(void) { return (PVOID)(((PNT_TIB)NtCurrentTeb())->FiberData); }
    extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) PVOID GetFiberData (void) { return *(PVOID *)GetCurrentFiber (); }
  typedef GUID CRM_PROTOCOL_ID,*PCRM_PROTOCOL_ID;
  typedef ULONG NOTIFICATION_MASK;
  typedef struct _TRANSACTION_NOTIFICATION {
    PVOID TransactionKey;
    ULONG TransactionNotification;
    LARGE_INTEGER TmVirtualClock;
    ULONG ArgumentLength;
  } TRANSACTION_NOTIFICATION,*PTRANSACTION_NOTIFICATION;

  typedef struct _TRANSACTION_NOTIFICATION_RECOVERY_ARGUMENT {
    GUID EnlistmentId;
    GUID UOW;
  } TRANSACTION_NOTIFICATION_RECOVERY_ARGUMENT,*PTRANSACTION_NOTIFICATION_RECOVERY_ARGUMENT;



  typedef struct _TRANSACTION_NOTIFICATION_TM_ONLINE_ARGUMENT {
    GUID TmIdentity;
    ULONG Flags;
  } TRANSACTION_NOTIFICATION_TM_ONLINE_ARGUMENT,*PTRANSACTION_NOTIFICATION_TM_ONLINE_ARGUMENT;

  typedef ULONG SAVEPOINT_ID,*PSAVEPOINT_ID;

  typedef struct _TRANSACTION_NOTIFICATION_SAVEPOINT_ARGUMENT {
    SAVEPOINT_ID SavepointId;
  } TRANSACTION_NOTIFICATION_SAVEPOINT_ARGUMENT,*PTRANSACTION_NOTIFICATION_SAVEPOINT_ARGUMENT;

  typedef struct _TRANSACTION_NOTIFICATION_PROPAGATE_ARGUMENT {
    ULONG PropagationCookie;
    GUID UOW;
    GUID TmIdentity;
    ULONG BufferLength;
  } TRANSACTION_NOTIFICATION_PROPAGATE_ARGUMENT,*PTRANSACTION_NOTIFICATION_PROPAGATE_ARGUMENT;

  typedef struct _TRANSACTION_NOTIFICATION_MARSHAL_ARGUMENT {
    ULONG MarshalCookie;
    GUID UOW;
  } TRANSACTION_NOTIFICATION_MARSHAL_ARGUMENT,*PTRANSACTION_NOTIFICATION_MARSHAL_ARGUMENT;

  typedef TRANSACTION_NOTIFICATION_PROPAGATE_ARGUMENT TRANSACTION_NOTIFICATION_PROMOTE_ARGUMENT,*PTRANSACTION_NOTIFICATION_PROMOTE_ARGUMENT;







  typedef struct _KCRM_MARSHAL_HEADER {
    ULONG VersionMajor;
    ULONG VersionMinor;
    ULONG NumProtocols;
    ULONG Unused;
  } KCRM_MARSHAL_HEADER,*PKCRM_MARSHAL_HEADER,* PRKCRM_MARSHAL_HEADER;

  typedef struct _KCRM_TRANSACTION_BLOB {
    GUID UOW;
    GUID TmIdentity;
    ULONG IsolationLevel;
    ULONG IsolationFlags;
    ULONG Timeout;
    WCHAR Description[64];
  } KCRM_TRANSACTION_BLOB,*PKCRM_TRANSACTION_BLOB,* PRKCRM_TRANSACTION_BLOB;

  typedef struct _KCRM_PROTOCOL_BLOB {
    CRM_PROTOCOL_ID ProtocolId;
    ULONG StaticInfoLength;
    ULONG TransactionIdInfoLength;
    ULONG Unused1;
    ULONG Unused2;
  } KCRM_PROTOCOL_BLOB,*PKCRM_PROTOCOL_BLOB,* PRKCRM_PROTOCOL_BLOB;
      typedef enum _TRANSACTION_OUTCOME {
 TransactionOutcomeUndetermined = 1,
 TransactionOutcomeCommitted,
 TransactionOutcomeAborted,
      } TRANSACTION_OUTCOME;

      typedef enum _TRANSACTION_STATE {
 TransactionStateNormal = 1,
 TransactionStateIndoubt,
 TransactionStateCommittedNotify,
      } TRANSACTION_STATE;

      typedef struct _TRANSACTION_BASIC_INFORMATION {
 GUID TransactionId;
 DWORD State;
 DWORD Outcome;
      } TRANSACTION_BASIC_INFORMATION,*PTRANSACTION_BASIC_INFORMATION;

      typedef struct _TRANSACTIONMANAGER_BASIC_INFORMATION {
 GUID TmIdentity;
 LARGE_INTEGER VirtualClock;
      } TRANSACTIONMANAGER_BASIC_INFORMATION,*PTRANSACTIONMANAGER_BASIC_INFORMATION;

      typedef struct _TRANSACTIONMANAGER_LOG_INFORMATION {
 GUID LogIdentity;
      } TRANSACTIONMANAGER_LOG_INFORMATION,*PTRANSACTIONMANAGER_LOG_INFORMATION;

      typedef struct _TRANSACTIONMANAGER_LOGPATH_INFORMATION {
 DWORD LogPathLength;
 WCHAR LogPath[1];
      } TRANSACTIONMANAGER_LOGPATH_INFORMATION,*PTRANSACTIONMANAGER_LOGPATH_INFORMATION;

      typedef struct _TRANSACTIONMANAGER_RECOVERY_INFORMATION {
 ULONGLONG LastRecoveredLsn;
      } TRANSACTIONMANAGER_RECOVERY_INFORMATION,*PTRANSACTIONMANAGER_RECOVERY_INFORMATION;

      typedef struct _TRANSACTIONMANAGER_OLDEST_INFORMATION {
 GUID OldestTransactionGuid;
      } TRANSACTIONMANAGER_OLDEST_INFORMATION,*PTRANSACTIONMANAGER_OLDEST_INFORMATION;

      typedef struct _TRANSACTION_PROPERTIES_INFORMATION {
 DWORD IsolationLevel;
 DWORD IsolationFlags;
 LARGE_INTEGER Timeout;
 DWORD Outcome;
 DWORD DescriptionLength;
 WCHAR Description[1];
      } TRANSACTION_PROPERTIES_INFORMATION,*PTRANSACTION_PROPERTIES_INFORMATION;

      typedef struct _TRANSACTION_BIND_INFORMATION {
 HANDLE TmHandle;
      } TRANSACTION_BIND_INFORMATION,*PTRANSACTION_BIND_INFORMATION;

      typedef struct _TRANSACTION_ENLISTMENT_PAIR {
 GUID EnlistmentId;
 GUID ResourceManagerId;
      } TRANSACTION_ENLISTMENT_PAIR,*PTRANSACTION_ENLISTMENT_PAIR;

      typedef struct _TRANSACTION_ENLISTMENTS_INFORMATION {
 DWORD NumberOfEnlistments;
 TRANSACTION_ENLISTMENT_PAIR EnlistmentPair[1];
      } TRANSACTION_ENLISTMENTS_INFORMATION,*PTRANSACTION_ENLISTMENTS_INFORMATION;

      typedef struct _TRANSACTION_SUPERIOR_ENLISTMENT_INFORMATION {
 TRANSACTION_ENLISTMENT_PAIR SuperiorEnlistmentPair;
      } TRANSACTION_SUPERIOR_ENLISTMENT_INFORMATION,*PTRANSACTION_SUPERIOR_ENLISTMENT_INFORMATION;

      typedef struct _RESOURCEMANAGER_BASIC_INFORMATION {
 GUID ResourceManagerId;
 DWORD DescriptionLength;
 WCHAR Description[1];
      } RESOURCEMANAGER_BASIC_INFORMATION,*PRESOURCEMANAGER_BASIC_INFORMATION;

      typedef struct _RESOURCEMANAGER_COMPLETION_INFORMATION {
 HANDLE IoCompletionPortHandle;
 ULONG_PTR CompletionKey;
      } RESOURCEMANAGER_COMPLETION_INFORMATION,*PRESOURCEMANAGER_COMPLETION_INFORMATION;

      typedef enum _TRANSACTION_INFORMATION_CLASS {
 TransactionBasicInformation,
 TransactionPropertiesInformation,
 TransactionEnlistmentInformation,
 TransactionSuperiorEnlistmentInformation,
 TransactionBindInformation,
 TransactionDTCPrivateInformation
      } TRANSACTION_INFORMATION_CLASS;

      typedef enum _TRANSACTIONMANAGER_INFORMATION_CLASS {
 TransactionManagerBasicInformation,
 TransactionManagerLogInformation,
 TransactionManagerLogPathInformation,
 TransactionManagerOnlineProbeInformation = 3,
 TransactionManagerRecoveryInformation = 4,
 TransactionManagerOldestTransactionInformation = 5
      } TRANSACTIONMANAGER_INFORMATION_CLASS;

      typedef enum _RESOURCEMANAGER_INFORMATION_CLASS {
 ResourceManagerBasicInformation,
 ResourceManagerCompletionInformation
      } RESOURCEMANAGER_INFORMATION_CLASS;

      typedef struct _ENLISTMENT_BASIC_INFORMATION {
 GUID EnlistmentId;
 GUID TransactionId;
 GUID ResourceManagerId;
      } ENLISTMENT_BASIC_INFORMATION,*PENLISTMENT_BASIC_INFORMATION;

      typedef struct _ENLISTMENT_CRM_INFORMATION {
 GUID CrmTransactionManagerId;
 GUID CrmResourceManagerId;
 GUID CrmEnlistmentId;
      } ENLISTMENT_CRM_INFORMATION,*PENLISTMENT_CRM_INFORMATION;

      typedef enum _ENLISTMENT_INFORMATION_CLASS {
 EnlistmentBasicInformation,
 EnlistmentRecoveryInformation,
 EnlistmentCrmInformation
      } ENLISTMENT_INFORMATION_CLASS;

      typedef struct _TRANSACTION_LIST_ENTRY {
         GUID UOW;
      } TRANSACTION_LIST_ENTRY,*PTRANSACTION_LIST_ENTRY;

      typedef struct _TRANSACTION_LIST_INFORMATION {
 DWORD NumberOfTransactions;
 TRANSACTION_LIST_ENTRY TransactionInformation[1];
      } TRANSACTION_LIST_INFORMATION,*PTRANSACTION_LIST_INFORMATION;

      typedef enum _KTMOBJECT_TYPE {
 KTMOBJECT_TRANSACTION,
 KTMOBJECT_TRANSACTION_MANAGER,
 KTMOBJECT_RESOURCE_MANAGER,
 KTMOBJECT_ENLISTMENT,
 KTMOBJECT_INVALID
      } KTMOBJECT_TYPE,*PKTMOBJECT_TYPE;

      typedef struct _KTMOBJECT_CURSOR {
 GUID LastQuery;
 DWORD ObjectIdCount;
 GUID ObjectIds[1];
      } KTMOBJECT_CURSOR,*PKTMOBJECT_CURSOR;
typedef struct _WOW64_FLOATING_SAVE_AREA {
  DWORD ControlWord;
  DWORD StatusWord;
  DWORD TagWord;
  DWORD ErrorOffset;
  DWORD ErrorSelector;
  DWORD DataOffset;
  DWORD DataSelector;
  BYTE RegisterArea[80];
  DWORD Cr0NpxState;
} WOW64_FLOATING_SAVE_AREA, *PWOW64_FLOATING_SAVE_AREA;








#pragma pack(push,4)
typedef struct _WOW64_CONTEXT {
  DWORD ContextFlags;
  DWORD Dr0;
  DWORD Dr1;
  DWORD Dr2;
  DWORD Dr3;
  DWORD Dr6;
  DWORD Dr7;
  WOW64_FLOATING_SAVE_AREA FloatSave;
  DWORD SegGs;
  DWORD SegFs;
  DWORD SegEs;
  DWORD SegDs;
  DWORD Edi;
  DWORD Esi;
  DWORD Ebx;
  DWORD Edx;
  DWORD Ecx;
  DWORD Eax;
  DWORD Ebp;
  DWORD Eip;
  DWORD SegCs;
  DWORD EFlags;
  DWORD Esp;
  DWORD SegSs;
  BYTE ExtendedRegisters[512];
} WOW64_CONTEXT, *PWOW64_CONTEXT;







#pragma pack(pop)

typedef struct _WOW64_LDT_ENTRY {
  WORD LimitLow;
  WORD BaseLow;
  __extension__ union {
    struct {
      BYTE BaseMid;
      BYTE Flags1;
      BYTE Flags2;
      BYTE BaseHi;
    } Bytes;
    struct {
      DWORD BaseMid :8;
      DWORD Type :5;
      DWORD Dpl :2;
      DWORD Pres :1;
      DWORD LimitHi :4;
      DWORD Sys :1;
      DWORD Reserved_0 :1;
      DWORD Default_Big :1;
      DWORD Granularity :1;
      DWORD BaseHi :8;
    } Bits;
  } HighWord;
} WOW64_LDT_ENTRY, *PWOW64_LDT_ENTRY;

    typedef struct _WOW64_DESCRIPTOR_TABLE_ENTRY {
      DWORD Selector;
      WOW64_LDT_ENTRY Descriptor;
    } WOW64_DESCRIPTOR_TABLE_ENTRY,*PWOW64_DESCRIPTOR_TABLE_ENTRY;


  typedef UINT_PTR WPARAM;
  typedef LONG_PTR LPARAM;
  typedef LONG_PTR LRESULT;
  typedef HANDLE *SPHANDLE;
  typedef HANDLE *LPHANDLE;
  typedef HANDLE HGLOBAL;
  typedef HANDLE HLOCAL;
  typedef HANDLE GLOBALHANDLE;
  typedef HANDLE LOCALHANDLE;





  typedef int ( *FARPROC) ();
  typedef int ( *NEARPROC) ();
  typedef int ( *PROC) ();


  typedef WORD ATOM;

  typedef int HFILE;
  struct HINSTANCE__ { int unused; }; typedef struct HINSTANCE__ *HINSTANCE;
  struct HKEY__ { int unused; }; typedef struct HKEY__ *HKEY;
  typedef HKEY *PHKEY;
  struct HKL__ { int unused; }; typedef struct HKL__ *HKL;
  struct HLSURF__ { int unused; }; typedef struct HLSURF__ *HLSURF;
  struct HMETAFILE__ { int unused; }; typedef struct HMETAFILE__ *HMETAFILE;
  typedef HINSTANCE HMODULE;
  struct HRGN__ { int unused; }; typedef struct HRGN__ *HRGN;
  struct HRSRC__ { int unused; }; typedef struct HRSRC__ *HRSRC;
  struct HSPRITE__ { int unused; }; typedef struct HSPRITE__ *HSPRITE;
  struct HSTR__ { int unused; }; typedef struct HSTR__ *HSTR;
  struct HTASK__ { int unused; }; typedef struct HTASK__ *HTASK;
  struct HWINSTA__ { int unused; }; typedef struct HWINSTA__ *HWINSTA;

  typedef struct _FILETIME {
    DWORD dwLowDateTime;
    DWORD dwHighDateTime;
  } FILETIME,*PFILETIME,*LPFILETIME;
struct HWND__ { int unused; }; typedef struct HWND__ *HWND;
struct HHOOK__ { int unused; }; typedef struct HHOOK__ *HHOOK;
  typedef void *HGDIOBJ;




struct HACCEL__ { int unused; }; typedef struct HACCEL__ *HACCEL;
struct HBITMAP__ { int unused; }; typedef struct HBITMAP__ *HBITMAP;
struct HBRUSH__ { int unused; }; typedef struct HBRUSH__ *HBRUSH;
struct HCOLORSPACE__ { int unused; }; typedef struct HCOLORSPACE__ *HCOLORSPACE;
struct HDC__ { int unused; }; typedef struct HDC__ *HDC;
struct HGLRC__ { int unused; }; typedef struct HGLRC__ *HGLRC;
struct HDESK__ { int unused; }; typedef struct HDESK__ *HDESK;
struct HENHMETAFILE__ { int unused; }; typedef struct HENHMETAFILE__ *HENHMETAFILE;
struct HFONT__ { int unused; }; typedef struct HFONT__ *HFONT;
struct HICON__ { int unused; }; typedef struct HICON__ *HICON;
struct HMENU__ { int unused; }; typedef struct HMENU__ *HMENU;
struct HPALETTE__ { int unused; }; typedef struct HPALETTE__ *HPALETTE;
struct HPEN__ { int unused; }; typedef struct HPEN__ *HPEN;
struct HMONITOR__ { int unused; }; typedef struct HMONITOR__ *HMONITOR;

struct HWINEVENTHOOK__ { int unused; }; typedef struct HWINEVENTHOOK__ *HWINEVENTHOOK;

typedef HICON HCURSOR;
typedef DWORD COLORREF;



struct HUMPD__ { int unused; }; typedef struct HUMPD__ *HUMPD;

typedef DWORD *LPCOLORREF;





typedef struct tagRECT {
  LONG left;
  LONG top;
  LONG right;
  LONG bottom;
} RECT,*PRECT,*NPRECT,*LPRECT;

typedef const RECT *LPCRECT;

typedef struct _RECTL {
  LONG left;
  LONG top;
  LONG right;
  LONG bottom;
} RECTL,*PRECTL,*LPRECTL;

typedef const RECTL *LPCRECTL;

typedef struct tagPOINT {
  LONG x;
  LONG y;
} POINT,*PPOINT,*NPPOINT,*LPPOINT;

typedef struct _POINTL {
  LONG x;
  LONG y;
} POINTL,*PPOINTL;

typedef struct tagSIZE {
  LONG cx;
  LONG cy;
} SIZE,*PSIZE,*LPSIZE;

typedef SIZE SIZEL;
typedef SIZE *PSIZEL,*LPSIZEL;

typedef struct tagPOINTS {
  SHORT x;
  SHORT y;
} POINTS,*PPOINTS,*LPPOINTS;


  typedef struct _SECURITY_ATTRIBUTES {
    DWORD nLength;
    LPVOID lpSecurityDescriptor;
    WINBOOL bInheritHandle;
  } SECURITY_ATTRIBUTES, *PSECURITY_ATTRIBUTES, *LPSECURITY_ATTRIBUTES;

  typedef struct _OVERLAPPED {
    ULONG_PTR Internal;
    ULONG_PTR InternalHigh;
    __extension__ union {
      struct {
 DWORD Offset;
 DWORD OffsetHigh;
      } ;
      PVOID Pointer;
    } ;
    HANDLE hEvent;
  } OVERLAPPED, *LPOVERLAPPED;

  typedef struct _OVERLAPPED_ENTRY {
    ULONG_PTR lpCompletionKey;
    LPOVERLAPPED lpOverlapped;
    ULONG_PTR Internal;
    DWORD dwNumberOfBytesTransferred;
  } OVERLAPPED_ENTRY, *LPOVERLAPPED_ENTRY;
  typedef struct _SYSTEMTIME {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
  } SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;


  typedef struct _WIN32_FIND_DATAA {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwReserved0;
    DWORD dwReserved1;
    CHAR cFileName[260];
    CHAR cAlternateFileName[14];
  } WIN32_FIND_DATAA, *PWIN32_FIND_DATAA, *LPWIN32_FIND_DATAA;

  typedef struct _WIN32_FIND_DATAW {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwReserved0;
    DWORD dwReserved1;
    WCHAR cFileName[260];
    WCHAR cAlternateFileName[14];
  } WIN32_FIND_DATAW, *PWIN32_FIND_DATAW, *LPWIN32_FIND_DATAW;

  typedef WIN32_FIND_DATAA WIN32_FIND_DATA;
  typedef PWIN32_FIND_DATAA PWIN32_FIND_DATA;
  typedef LPWIN32_FIND_DATAA LPWIN32_FIND_DATA;

  typedef enum _FINDEX_INFO_LEVELS {
    FindExInfoStandard,
    FindExInfoBasic,
    FindExInfoMaxInfoLevel
  } FINDEX_INFO_LEVELS;




  typedef enum _FINDEX_SEARCH_OPS {
    FindExSearchNameMatch,
    FindExSearchLimitToDirectories,
    FindExSearchLimitToDevices,
    FindExSearchMaxSearchOp
  } FINDEX_SEARCH_OPS;

  typedef enum _GET_FILEEX_INFO_LEVELS {
    GetFileExInfoStandard,
    GetFileExMaxInfoLevel
  } GET_FILEEX_INFO_LEVELS;


  typedef enum _FILE_INFO_BY_HANDLE_CLASS {
    FileBasicInfo ,
    FileStandardInfo,
    FileNameInfo,
    FileRenameInfo,
    FileDispositionInfo,
    FileAllocationInfo,
    FileEndOfFileInfo,
    FileStreamInfo,
    FileCompressionInfo,
    FileAttributeTagInfo,
    FileIdBothDirectoryInfo,
    FileIdBothDirectoryRestartInfo,
    FileIoPriorityHintInfo,
    FileRemoteProtocolInfo,
    FileFullDirectoryInfo,
    FileFullDirectoryRestartInfo,







    MaximumFileInfoByHandleClass
  } FILE_INFO_BY_HANDLE_CLASS, *PFILE_INFO_BY_HANDLE_CLASS;


  typedef RTL_CRITICAL_SECTION CRITICAL_SECTION;
  typedef PRTL_CRITICAL_SECTION PCRITICAL_SECTION;
  typedef PRTL_CRITICAL_SECTION LPCRITICAL_SECTION;
  typedef RTL_CRITICAL_SECTION_DEBUG CRITICAL_SECTION_DEBUG;
  typedef PRTL_CRITICAL_SECTION_DEBUG PCRITICAL_SECTION_DEBUG;
  typedef PRTL_CRITICAL_SECTION_DEBUG LPCRITICAL_SECTION_DEBUG;

  typedef void ( *LPOVERLAPPED_COMPLETION_ROUTINE) (DWORD dwErrorCode, DWORD dwNumberOfBytesTransfered, LPOVERLAPPED lpOverlapped);




  typedef struct _PROCESS_HEAP_ENTRY {
    PVOID lpData;
    DWORD cbData;
    BYTE cbOverhead;
    BYTE iRegionIndex;
    WORD wFlags;
    __extension__ union {
      struct {
 HANDLE hMem;
 DWORD dwReserved[3];
      } Block;
      struct {
 DWORD dwCommittedSize;
 DWORD dwUnCommittedSize;
 LPVOID lpFirstBlock;
 LPVOID lpLastBlock;
      } Region;
    } ;
  } PROCESS_HEAP_ENTRY,*LPPROCESS_HEAP_ENTRY,*PPROCESS_HEAP_ENTRY;







  typedef struct _REASON_CONTEXT {
    ULONG Version;
    DWORD Flags;
    union {
      struct {
 HMODULE LocalizedReasonModule;
 ULONG LocalizedReasonId;
 ULONG ReasonStringCount;
 LPWSTR *ReasonStrings;
      } Detailed;
      LPWSTR SimpleReasonString;
    } Reason;
  } REASON_CONTEXT, *PREASON_CONTEXT;
  typedef DWORD ( *PTHREAD_START_ROUTINE) (LPVOID lpThreadParameter);
  typedef PTHREAD_START_ROUTINE LPTHREAD_START_ROUTINE;

  typedef struct _EXCEPTION_DEBUG_INFO {
    EXCEPTION_RECORD ExceptionRecord;
    DWORD dwFirstChance;
  } EXCEPTION_DEBUG_INFO, *LPEXCEPTION_DEBUG_INFO;

  typedef struct _CREATE_THREAD_DEBUG_INFO {
    HANDLE hThread;
    LPVOID lpThreadLocalBase;
    LPTHREAD_START_ROUTINE lpStartAddress;
  } CREATE_THREAD_DEBUG_INFO, *LPCREATE_THREAD_DEBUG_INFO;

  typedef struct _CREATE_PROCESS_DEBUG_INFO {
    HANDLE hFile;
    HANDLE hProcess;
    HANDLE hThread;
    LPVOID lpBaseOfImage;
    DWORD dwDebugInfoFileOffset;
    DWORD nDebugInfoSize;
    LPVOID lpThreadLocalBase;
    LPTHREAD_START_ROUTINE lpStartAddress;
    LPVOID lpImageName;
    WORD fUnicode;
  } CREATE_PROCESS_DEBUG_INFO, *LPCREATE_PROCESS_DEBUG_INFO;

  typedef struct _EXIT_THREAD_DEBUG_INFO {
    DWORD dwExitCode;
  } EXIT_THREAD_DEBUG_INFO, *LPEXIT_THREAD_DEBUG_INFO;

  typedef struct _EXIT_PROCESS_DEBUG_INFO {
    DWORD dwExitCode;
  } EXIT_PROCESS_DEBUG_INFO, *LPEXIT_PROCESS_DEBUG_INFO;

  typedef struct _LOAD_DLL_DEBUG_INFO {
    HANDLE hFile;
    LPVOID lpBaseOfDll;
    DWORD dwDebugInfoFileOffset;
    DWORD nDebugInfoSize;
    LPVOID lpImageName;
    WORD fUnicode;
  } LOAD_DLL_DEBUG_INFO, *LPLOAD_DLL_DEBUG_INFO;

  typedef struct _UNLOAD_DLL_DEBUG_INFO {
    LPVOID lpBaseOfDll;
  } UNLOAD_DLL_DEBUG_INFO, *LPUNLOAD_DLL_DEBUG_INFO;

  typedef struct _OUTPUT_DEBUG_STRING_INFO {
    LPSTR lpDebugStringData;
    WORD fUnicode;
    WORD nDebugStringLength;
  } OUTPUT_DEBUG_STRING_INFO, *LPOUTPUT_DEBUG_STRING_INFO;

  typedef struct _RIP_INFO {
    DWORD dwError;
    DWORD dwType;
  } RIP_INFO, *LPRIP_INFO;

  typedef struct _DEBUG_EVENT {
    DWORD dwDebugEventCode;
    DWORD dwProcessId;
    DWORD dwThreadId;
    union {
      EXCEPTION_DEBUG_INFO Exception;
      CREATE_THREAD_DEBUG_INFO CreateThread;
      CREATE_PROCESS_DEBUG_INFO CreateProcessInfo;
      EXIT_THREAD_DEBUG_INFO ExitThread;
      EXIT_PROCESS_DEBUG_INFO ExitProcess;
      LOAD_DLL_DEBUG_INFO LoadDll;
      UNLOAD_DLL_DEBUG_INFO UnloadDll;
      OUTPUT_DEBUG_STRING_INFO DebugString;
      RIP_INFO RipInfo;
    } u;
  } DEBUG_EVENT, *LPDEBUG_EVENT;


  typedef PCONTEXT LPCONTEXT;
  typedef struct _CONTRACT_DESCRIPTION CONTRACT_DESCRIPTION;
  typedef struct _BEM_REFERENCE BEM_REFERENCE;
  typedef void ( *BEM_FREE_INTERFACE_CALLBACK) (void *interfaceInstance);

  HRESULT BemCreateReference (const GUID *const iid, void *interfaceInstance, BEM_FREE_INTERFACE_CALLBACK freeCallback, BEM_REFERENCE **reference);
  HRESULT BemCreateContractFrom (LPCWSTR dllPath, const GUID *const extensionId, const CONTRACT_DESCRIPTION *contractDescription, void *hostContract, void **contract);
  HRESULT BemCopyReference (BEM_REFERENCE *reference, BEM_REFERENCE **copiedReference);
  void BemFreeReference (BEM_REFERENCE *reference);
  void BemFreeContract (void *contract);
  __attribute__((dllimport)) WINBOOL IsDebuggerPresent (void);
  __attribute__((dllimport)) void OutputDebugStringA (LPCSTR lpOutputString);
  __attribute__((dllimport)) void OutputDebugStringW (LPCWSTR lpOutputString);





  __attribute__((dllimport)) void DebugBreak (void);
  __attribute__((dllimport)) WINBOOL ContinueDebugEvent (DWORD dwProcessId, DWORD dwThreadId, DWORD dwContinueStatus);
  __attribute__((dllimport)) WINBOOL WaitForDebugEvent (LPDEBUG_EVENT lpDebugEvent, DWORD dwMilliseconds);
  __attribute__((dllimport)) WINBOOL DebugActiveProcess (DWORD dwProcessId);
  __attribute__((dllimport)) WINBOOL DebugActiveProcessStop (DWORD dwProcessId);
  __attribute__((dllimport)) WINBOOL CheckRemoteDebuggerPresent (HANDLE hProcess, PBOOL pbDebuggerPresent);
typedef LONG ( *PTOP_LEVEL_EXCEPTION_FILTER) (struct _EXCEPTION_POINTERS *ExceptionInfo);
typedef PTOP_LEVEL_EXCEPTION_FILTER LPTOP_LEVEL_EXCEPTION_FILTER;
    __attribute__((dllimport)) UINT SetErrorMode (UINT uMode);
    __attribute__((dllimport)) LPTOP_LEVEL_EXCEPTION_FILTER SetUnhandledExceptionFilter (LPTOP_LEVEL_EXCEPTION_FILTER lpTopLevelExceptionFilter);
    __attribute__((dllimport)) LONG UnhandledExceptionFilter (struct _EXCEPTION_POINTERS *ExceptionInfo);


    __attribute__((dllimport)) PVOID AddVectoredExceptionHandler (ULONG First, PVECTORED_EXCEPTION_HANDLER Handler);
  __attribute__((dllimport)) ULONG RemoveVectoredExceptionHandler (PVOID Handle);
  __attribute__((dllimport)) PVOID AddVectoredContinueHandler (ULONG First, PVECTORED_EXCEPTION_HANDLER Handler);
  __attribute__((dllimport)) ULONG RemoveVectoredContinueHandler (PVOID Handle);

  __attribute__((dllimport)) UINT GetErrorMode (void);
  __attribute__((dllimport)) void RaiseException (DWORD dwExceptionCode, DWORD dwExceptionFlags, DWORD nNumberOfArguments, const ULONG_PTR *lpArguments);
  __attribute__((dllimport)) DWORD GetLastError (void);
  __attribute__((dllimport)) void SetLastError (DWORD dwErrCode);
  __attribute__((dllimport)) DWORD FlsAlloc (PFLS_CALLBACK_FUNCTION lpCallback);
  __attribute__((dllimport)) PVOID FlsGetValue (DWORD dwFlsIndex);
  __attribute__((dllimport)) WINBOOL FlsSetValue (DWORD dwFlsIndex, PVOID lpFlsData);
  __attribute__((dllimport)) WINBOOL FlsFree (DWORD dwFlsIndex);





  __attribute__((dllimport)) WINBOOL IsThreadAFiber (void);
__attribute__((dllimport)) HANDLE CreateFileW (LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);

__attribute__((dllimport)) DWORD GetFileAttributesW (LPCWSTR lpFileName);

__attribute__((dllimport)) DWORD GetFileSize (HANDLE hFile, LPDWORD lpFileSizeHigh);
__attribute__((dllimport)) DWORD SetFilePointer (HANDLE hFile, LONG lDistanceToMove, PLONG lpDistanceToMoveHigh, DWORD dwMoveMethod);


  typedef struct _BY_HANDLE_FILE_INFORMATION {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD dwVolumeSerialNumber;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD nNumberOfLinks;
    DWORD nFileIndexHigh;
    DWORD nFileIndexLow;
  } BY_HANDLE_FILE_INFORMATION, *PBY_HANDLE_FILE_INFORMATION,
    *LPBY_HANDLE_FILE_INFORMATION;

  __attribute__((dllimport)) LONG CompareFileTime (const FILETIME *lpFileTime1, const FILETIME *lpFileTime2);
  __attribute__((dllimport)) HANDLE CreateFileA (LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);
  __attribute__((dllimport)) WINBOOL DefineDosDeviceW (DWORD dwFlags, LPCWSTR lpDeviceName, LPCWSTR lpTargetPath);
  __attribute__((dllimport)) WINBOOL DeleteVolumeMountPointW (LPCWSTR lpszVolumeMountPoint);
  __attribute__((dllimport)) WINBOOL FileTimeToLocalFileTime (const FILETIME *lpFileTime, LPFILETIME lpLocalFileTime);
  __attribute__((dllimport)) WINBOOL FindCloseChangeNotification (HANDLE hChangeHandle);
  __attribute__((dllimport)) HANDLE FindFirstChangeNotificationA (LPCSTR lpPathName, WINBOOL bWatchSubtree, DWORD dwNotifyFilter);
  __attribute__((dllimport)) HANDLE FindFirstChangeNotificationW (LPCWSTR lpPathName, WINBOOL bWatchSubtree, DWORD dwNotifyFilter);
  __attribute__((dllimport)) HANDLE FindFirstFileA (LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);
  __attribute__((dllimport)) HANDLE FindFirstFileW (LPCWSTR lpFileName, LPWIN32_FIND_DATAW lpFindFileData);
  __attribute__((dllimport)) HANDLE FindFirstVolumeW (LPWSTR lpszVolumeName, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL FindNextChangeNotification (HANDLE hChangeHandle);
  __attribute__((dllimport)) WINBOOL FindNextVolumeW (HANDLE hFindVolume, LPWSTR lpszVolumeName, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL FindVolumeClose (HANDLE hFindVolume);
  __attribute__((dllimport)) WINBOOL GetDiskFreeSpaceA (LPCSTR lpRootPathName, LPDWORD lpSectorsPerCluster, LPDWORD lpBytesPerSector, LPDWORD lpNumberOfFreeClusters, LPDWORD lpTotalNumberOfClusters);
  __attribute__((dllimport)) WINBOOL GetDiskFreeSpaceW (LPCWSTR lpRootPathName, LPDWORD lpSectorsPerCluster, LPDWORD lpBytesPerSector, LPDWORD lpNumberOfFreeClusters, LPDWORD lpTotalNumberOfClusters);
  __attribute__((dllimport)) UINT GetDriveTypeA (LPCSTR lpRootPathName);
  __attribute__((dllimport)) UINT GetDriveTypeW (LPCWSTR lpRootPathName);
  __attribute__((dllimport)) DWORD GetFileAttributesA (LPCSTR lpFileName);
  __attribute__((dllimport)) WINBOOL GetFileInformationByHandle (HANDLE hFile, LPBY_HANDLE_FILE_INFORMATION lpFileInformation);
  __attribute__((dllimport)) WINBOOL GetFileSizeEx (HANDLE hFile, PLARGE_INTEGER lpFileSize);
  __attribute__((dllimport)) WINBOOL GetFileTime (HANDLE hFile, LPFILETIME lpCreationTime, LPFILETIME lpLastAccessTime, LPFILETIME lpLastWriteTime);
  __attribute__((dllimport)) DWORD GetFileType (HANDLE hFile);
  __attribute__((dllimport)) DWORD GetFullPathNameA (LPCSTR lpFileName, DWORD nBufferLength, LPSTR lpBuffer, LPSTR *lpFilePart);
  __attribute__((dllimport)) DWORD GetFullPathNameW (LPCWSTR lpFileName, DWORD nBufferLength, LPWSTR lpBuffer, LPWSTR *lpFilePart);
  __attribute__((dllimport)) DWORD GetLogicalDrives (void);
  __attribute__((dllimport)) DWORD GetLogicalDriveStringsW (DWORD nBufferLength, LPWSTR lpBuffer);
  __attribute__((dllimport)) DWORD GetLongPathNameA (LPCSTR lpszShortPath, LPSTR lpszLongPath, DWORD cchBuffer);
  __attribute__((dllimport)) DWORD GetLongPathNameW (LPCWSTR lpszShortPath, LPWSTR lpszLongPath, DWORD cchBuffer);
  __attribute__((dllimport)) DWORD GetShortPathNameW (LPCWSTR lpszLongPath, LPWSTR lpszShortPath, DWORD cchBuffer);
  __attribute__((dllimport)) UINT GetTempFileNameW (LPCWSTR lpPathName, LPCWSTR lpPrefixString, UINT uUnique, LPWSTR lpTempFileName);
  __attribute__((dllimport)) WINBOOL GetVolumeInformationW (LPCWSTR lpRootPathName, LPWSTR lpVolumeNameBuffer, DWORD nVolumeNameSize, LPDWORD lpVolumeSerialNumber, LPDWORD lpMaximumComponentLength, LPDWORD lpFileSystemFlags, LPWSTR lpFileSystemNameBuffer, DWORD nFileSystemNameSize);
  __attribute__((dllimport)) WINBOOL GetVolumePathNameW (LPCWSTR lpszFileName, LPWSTR lpszVolumePathName, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL LocalFileTimeToFileTime (const FILETIME *lpLocalFileTime, LPFILETIME lpFileTime);
  __attribute__((dllimport)) WINBOOL LockFile (HANDLE hFile, DWORD dwFileOffsetLow, DWORD dwFileOffsetHigh, DWORD nNumberOfBytesToLockLow, DWORD nNumberOfBytesToLockHigh);
  __attribute__((dllimport)) DWORD QueryDosDeviceW (LPCWSTR lpDeviceName, LPWSTR lpTargetPath, DWORD ucchMax);
  __attribute__((dllimport)) WINBOOL ReadFileEx (HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead, LPOVERLAPPED lpOverlapped, LPOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine);
  __attribute__((dllimport)) WINBOOL ReadFileScatter (HANDLE hFile, FILE_SEGMENT_ELEMENT aSegmentArray[], DWORD nNumberOfBytesToRead, LPDWORD lpReserved, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL SetFileTime (HANDLE hFile, const FILETIME *lpCreationTime, const FILETIME *lpLastAccessTime, const FILETIME *lpLastWriteTime);
  __attribute__((dllimport)) WINBOOL SetFileValidData (HANDLE hFile, LONGLONG ValidDataLength);
  __attribute__((dllimport)) WINBOOL UnlockFile (HANDLE hFile, DWORD dwFileOffsetLow, DWORD dwFileOffsetHigh, DWORD nNumberOfBytesToUnlockLow, DWORD nNumberOfBytesToUnlockHigh);
  __attribute__((dllimport)) WINBOOL WriteFileEx (HANDLE hFile, LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite, LPOVERLAPPED lpOverlapped, LPOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine);
  __attribute__((dllimport)) WINBOOL WriteFileGather (HANDLE hFile, FILE_SEGMENT_ELEMENT aSegmentArray[], DWORD nNumberOfBytesToWrite, LPDWORD lpReserved, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL GetVolumeNameForVolumeMountPointW (LPCWSTR lpszVolumeMountPoint, LPWSTR lpszVolumeName, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL GetVolumePathNamesForVolumeNameW (LPCWSTR lpszVolumeName, LPWCH lpszVolumePathNames, DWORD cchBufferLength, PDWORD lpcchReturnLength);
  __attribute__((dllimport)) DWORD GetFinalPathNameByHandleA (HANDLE hFile, LPSTR lpszFilePath, DWORD cchFilePath, DWORD dwFlags);
  __attribute__((dllimport)) DWORD GetFinalPathNameByHandleW (HANDLE hFile, LPWSTR lpszFilePath, DWORD cchFilePath, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL GetVolumeInformationByHandleW (HANDLE hFile, LPWSTR lpVolumeNameBuffer, DWORD nVolumeNameSize, LPDWORD lpVolumeSerialNumber, LPDWORD lpMaximumComponentLength, LPDWORD lpFileSystemFlags, LPWSTR lpFileSystemNameBuffer, DWORD nFileSystemNameSize);






  typedef struct _WIN32_FILE_ATTRIBUTE_DATA {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
  } WIN32_FILE_ATTRIBUTE_DATA, *LPWIN32_FILE_ATTRIBUTE_DATA;
  __attribute__((dllimport)) WINBOOL CreateDirectoryA (LPCSTR lpPathName, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) WINBOOL CreateDirectoryW (LPCWSTR lpPathName, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) WINBOOL DeleteFileA (LPCSTR lpFileName);
  __attribute__((dllimport)) WINBOOL DeleteFileW (LPCWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL FindClose (HANDLE hFindFile);
  __attribute__((dllimport)) HANDLE FindFirstFileExA (LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags);
  __attribute__((dllimport)) HANDLE FindFirstFileExW (LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags);
  __attribute__((dllimport)) WINBOOL FindNextFileA (HANDLE hFindFile, LPWIN32_FIND_DATAA lpFindFileData);
  __attribute__((dllimport)) WINBOOL FindNextFileW (HANDLE hFindFile, LPWIN32_FIND_DATAW lpFindFileData);
  __attribute__((dllimport)) WINBOOL FlushFileBuffers (HANDLE hFile);
  __attribute__((dllimport)) WINBOOL GetDiskFreeSpaceExA (LPCSTR lpDirectoryName, PULARGE_INTEGER lpFreeBytesAvailableToCaller, PULARGE_INTEGER lpTotalNumberOfBytes, PULARGE_INTEGER lpTotalNumberOfFreeBytes);
  __attribute__((dllimport)) WINBOOL GetDiskFreeSpaceExW (LPCWSTR lpDirectoryName, PULARGE_INTEGER lpFreeBytesAvailableToCaller, PULARGE_INTEGER lpTotalNumberOfBytes, PULARGE_INTEGER lpTotalNumberOfFreeBytes);
  __attribute__((dllimport)) DWORD GetFileType (HANDLE hFile);
  __attribute__((dllimport)) WINBOOL GetFileAttributesExA (LPCSTR lpFileName, GET_FILEEX_INFO_LEVELS fInfoLevelId, LPVOID lpFileInformation);
  __attribute__((dllimport)) WINBOOL GetFileAttributesExW (LPCWSTR lpFileName, GET_FILEEX_INFO_LEVELS fInfoLevelId, LPVOID lpFileInformation);
  __attribute__((dllimport)) DWORD GetTempPathW (DWORD nBufferLength, LPWSTR lpBuffer);
  __attribute__((dllimport)) WINBOOL LockFileEx (HANDLE hFile, DWORD dwFlags, DWORD dwReserved, DWORD nNumberOfBytesToLockLow, DWORD nNumberOfBytesToLockHigh, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL ReadFile (HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead, LPDWORD lpNumberOfBytesRead, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL RemoveDirectoryA (LPCSTR lpPathName);
  __attribute__((dllimport)) WINBOOL RemoveDirectoryW (LPCWSTR lpPathName);
  __attribute__((dllimport)) WINBOOL SetEndOfFile (HANDLE hFile);
  __attribute__((dllimport)) WINBOOL SetFileAttributesA (LPCSTR lpFileName, DWORD dwFileAttributes);
  __attribute__((dllimport)) WINBOOL SetFileAttributesW (LPCWSTR lpFileName, DWORD dwFileAttributes);
  __attribute__((dllimport)) WINBOOL SetFilePointerEx (HANDLE hFile, LARGE_INTEGER liDistanceToMove, PLARGE_INTEGER lpNewFilePointer, DWORD dwMoveMethod);
  __attribute__((dllimport)) WINBOOL UnlockFileEx (HANDLE hFile, DWORD dwReserved, DWORD nNumberOfBytesToUnlockLow, DWORD nNumberOfBytesToUnlockHigh, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL WriteFile (HANDLE hFile, LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite, LPDWORD lpNumberOfBytesWritten, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL SetFileInformationByHandle (HANDLE hFile, FILE_INFO_BY_HANDLE_CLASS FileInformationClass, LPVOID lpFileInformation, DWORD dwBufferSize);
  __attribute__((dllimport)) WINBOOL CloseHandle (HANDLE hObject);
  __attribute__((dllimport)) WINBOOL DuplicateHandle (HANDLE hSourceProcessHandle, HANDLE hSourceHandle, HANDLE hTargetProcessHandle, LPHANDLE lpTargetHandle, DWORD dwDesiredAccess, WINBOOL bInheritHandle, DWORD dwOptions);



  __attribute__((dllimport)) WINBOOL GetHandleInformation (HANDLE hObject, LPDWORD lpdwFlags);
  __attribute__((dllimport)) WINBOOL SetHandleInformation (HANDLE hObject, DWORD dwMask, DWORD dwFlags);
  typedef struct _HEAP_SUMMARY {
    DWORD cb;
    SIZE_T cbAllocated;
    SIZE_T cbCommitted;
    SIZE_T cbReserved;
    SIZE_T cbMaxReserve;
  } HEAP_SUMMARY,*PHEAP_SUMMARY;

  typedef PHEAP_SUMMARY LPHEAP_SUMMARY;

  __attribute__((dllimport)) HANDLE HeapCreate (DWORD flOptions, SIZE_T dwInitialSize, SIZE_T dwMaximumSize);
  __attribute__((dllimport)) WINBOOL HeapDestroy (HANDLE hHeap);
  __attribute__((dllimport)) WINBOOL HeapValidate (HANDLE hHeap, DWORD dwFlags, LPCVOID lpMem);
  __attribute__((dllimport)) SIZE_T HeapCompact (HANDLE hHeap, DWORD dwFlags);
  WINBOOL HeapSummary (HANDLE hHeap, DWORD dwFlags, LPHEAP_SUMMARY lpSummary);
  __attribute__((dllimport)) DWORD GetProcessHeaps (DWORD NumberOfHeaps, PHANDLE ProcessHeaps);
  __attribute__((dllimport)) WINBOOL HeapLock (HANDLE hHeap);
  __attribute__((dllimport)) WINBOOL HeapUnlock (HANDLE hHeap);
  __attribute__((dllimport)) WINBOOL HeapWalk (HANDLE hHeap, LPPROCESS_HEAP_ENTRY lpEntry);
  __attribute__((dllimport)) WINBOOL HeapSetInformation (HANDLE HeapHandle, HEAP_INFORMATION_CLASS HeapInformationClass, PVOID HeapInformation, SIZE_T HeapInformationLength);
  __attribute__((dllimport)) WINBOOL HeapQueryInformation (HANDLE HeapHandle, HEAP_INFORMATION_CLASS HeapInformationClass, PVOID HeapInformation, SIZE_T HeapInformationLength, PSIZE_T ReturnLength);



  __attribute__((dllimport)) LPVOID HeapAlloc (HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes);
  __attribute__((dllimport)) LPVOID HeapReAlloc (HANDLE hHeap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes);
  __attribute__((dllimport)) WINBOOL HeapFree (HANDLE hHeap, DWORD dwFlags, LPVOID lpMem);
  __attribute__((dllimport)) SIZE_T HeapSize (HANDLE hHeap, DWORD dwFlags, LPCVOID lpMem);
  __attribute__((dllimport)) HANDLE GetProcessHeap (void);
  __attribute__((dllimport)) WINBOOL GetOverlappedResult (HANDLE hFile, LPOVERLAPPED lpOverlapped, LPDWORD lpNumberOfBytesTransferred, WINBOOL bWait);
  __attribute__((dllimport)) HANDLE CreateIoCompletionPort (HANDLE FileHandle, HANDLE ExistingCompletionPort, ULONG_PTR CompletionKey, DWORD NumberOfConcurrentThreads);
  __attribute__((dllimport)) WINBOOL GetQueuedCompletionStatus (HANDLE CompletionPort, LPDWORD lpNumberOfBytesTransferred, PULONG_PTR lpCompletionKey, LPOVERLAPPED *lpOverlapped, DWORD dwMilliseconds);
  __attribute__((dllimport)) WINBOOL PostQueuedCompletionStatus (HANDLE CompletionPort, DWORD dwNumberOfBytesTransferred, ULONG_PTR dwCompletionKey, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL DeviceIoControl (HANDLE hDevice, DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesReturned, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL CancelIo (HANDLE hFile);

  __attribute__((dllimport)) WINBOOL GetQueuedCompletionStatusEx (HANDLE CompletionPort, LPOVERLAPPED_ENTRY lpCompletionPortEntries, ULONG ulCount, PULONG ulNumEntriesRemoved, DWORD dwMilliseconds, WINBOOL fAlertable);
  __attribute__((dllimport)) WINBOOL CancelIoEx (HANDLE hFile, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL CancelSynchronousIo (HANDLE hThread);




  __attribute__((dllimport)) WINBOOL GetOverlappedResultEx (HANDLE hFile, LPOVERLAPPED lpOverlapped, LPDWORD lpNumberOfBytesTransferred, DWORD dwMilliseconds, WINBOOL bAlertable);
  __attribute__((dllimport)) void InitializeSListHead (PSLIST_HEADER ListHead);
  __attribute__((dllimport)) PSLIST_ENTRY InterlockedPopEntrySList (PSLIST_HEADER ListHead);
  __attribute__((dllimport)) PSLIST_ENTRY InterlockedPushEntrySList (PSLIST_HEADER ListHead, PSLIST_ENTRY ListEntry);
  __attribute__((dllimport)) PSLIST_ENTRY InterlockedFlushSList (PSLIST_HEADER ListHead);
  __attribute__((dllimport)) USHORT QueryDepthSList (PSLIST_HEADER ListHead);
  __attribute__((dllimport)) WINBOOL IsProcessInJob (HANDLE ProcessHandle, HANDLE JobHandle, PBOOL Result);
  typedef struct tagENUMUILANG {
    ULONG NumOfEnumUILang;
    ULONG SizeOfEnumUIBuffer;
    LANGID *pEnumUIBuffer;
  } ENUMUILANG, *PENUMUILANG;


  typedef WINBOOL ( *ENUMRESLANGPROCA) (HMODULE hModule, LPCSTR lpType, LPCSTR lpName, WORD wLanguage, LONG_PTR lParam);
  typedef WINBOOL ( *ENUMRESLANGPROCW) (HMODULE hModule, LPCWSTR lpType, LPCWSTR lpName, WORD wLanguage, LONG_PTR lParam);
  typedef WINBOOL ( *ENUMRESNAMEPROCA) (HMODULE hModule, LPCSTR lpType, LPSTR lpName, LONG_PTR lParam);
  typedef WINBOOL ( *ENUMRESNAMEPROCW) (HMODULE hModule, LPCWSTR lpType, LPWSTR lpName, LONG_PTR lParam);
  typedef WINBOOL ( *ENUMRESTYPEPROCA) (HMODULE hModule, LPSTR lpType, LONG_PTR lParam);
  typedef WINBOOL ( *ENUMRESTYPEPROCW) (HMODULE hModule, LPWSTR lpType, LONG_PTR lParam);
  typedef WINBOOL ( *PGET_MODULE_HANDLE_EXA) (DWORD dwFlags, LPCSTR lpModuleName, HMODULE *phModule);
  typedef WINBOOL ( *PGET_MODULE_HANDLE_EXW) (DWORD dwFlags, LPCWSTR lpModuleName, HMODULE *phModule);


  typedef PVOID DLL_DIRECTORY_COOKIE, *PDLL_DIRECTORY_COOKIE;
  __attribute__((dllimport)) HRSRC FindResourceExW (HMODULE hModule, LPCWSTR lpType, LPCWSTR lpName, WORD wLanguage);
  __attribute__((dllimport)) __attribute__((noreturn)) void FreeLibraryAndExitThread (HMODULE hLibModule, DWORD dwExitCode);
  __attribute__((dllimport)) WINBOOL FreeResource (HGLOBAL hResData);
  __attribute__((dllimport)) HMODULE GetModuleHandleA (LPCSTR lpModuleName);
  __attribute__((dllimport)) HMODULE GetModuleHandleW (LPCWSTR lpModuleName);
  __attribute__((dllimport)) HMODULE LoadLibraryExA (LPCSTR lpLibFileName, HANDLE hFile, DWORD dwFlags);
  __attribute__((dllimport)) HMODULE LoadLibraryExW (LPCWSTR lpLibFileName, HANDLE hFile, DWORD dwFlags);
  __attribute__((dllimport)) HGLOBAL LoadResource (HMODULE hModule, HRSRC hResInfo);
  __attribute__((dllimport)) int LoadStringA (HINSTANCE hInstance, UINT uID, LPSTR lpBuffer, int cchBufferMax);
  __attribute__((dllimport)) int LoadStringW (HINSTANCE hInstance, UINT uID, LPWSTR lpBuffer, int cchBufferMax);
  __attribute__((dllimport)) LPVOID LockResource (HGLOBAL hResData);
  __attribute__((dllimport)) DWORD SizeofResource (HMODULE hModule, HRSRC hResInfo);
  __attribute__((dllimport)) DLL_DIRECTORY_COOKIE AddDllDirectory (PCWSTR NewDirectory);
  __attribute__((dllimport)) WINBOOL RemoveDllDirectory (DLL_DIRECTORY_COOKIE Cookie);
  __attribute__((dllimport)) WINBOOL SetDefaultDllDirectories (DWORD DirectoryFlags);
  __attribute__((dllimport)) WINBOOL GetModuleHandleExA (DWORD dwFlags, LPCSTR lpModuleName, HMODULE *phModule);
  __attribute__((dllimport)) WINBOOL GetModuleHandleExW (DWORD dwFlags, LPCWSTR lpModuleName, HMODULE *phModule);
  __attribute__((dllimport)) WINBOOL EnumResourceLanguagesA(HMODULE hModule,LPCSTR lpType,LPCSTR lpName,ENUMRESLANGPROCA lpEnumFunc,LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumResourceLanguagesW(HMODULE hModule,LPCWSTR lpType,LPCWSTR lpName,ENUMRESLANGPROCW lpEnumFunc,LONG_PTR lParam);



  __attribute__((dllimport)) WINBOOL EnumResourceLanguagesExA (HMODULE hModule, LPCSTR lpType, LPCSTR lpName, ENUMRESLANGPROCA lpEnumFunc, LONG_PTR lParam, DWORD dwFlags, LANGID LangId);
  __attribute__((dllimport)) WINBOOL EnumResourceLanguagesExW (HMODULE hModule, LPCWSTR lpType, LPCWSTR lpName, ENUMRESLANGPROCW lpEnumFunc, LONG_PTR lParam, DWORD dwFlags, LANGID LangId);
  __attribute__((dllimport)) WINBOOL EnumResourceNamesExA (HMODULE hModule, LPCSTR lpType, ENUMRESNAMEPROCA lpEnumFunc, LONG_PTR lParam, DWORD dwFlags, LANGID LangId);
  __attribute__((dllimport)) WINBOOL EnumResourceNamesExW (HMODULE hModule, LPCWSTR lpType, ENUMRESNAMEPROCW lpEnumFunc, LONG_PTR lParam, DWORD dwFlags, LANGID LangId);
  __attribute__((dllimport)) WINBOOL EnumResourceTypesExA (HMODULE hModule, ENUMRESTYPEPROCA lpEnumFunc, LONG_PTR lParam, DWORD dwFlags, LANGID LangId);
  __attribute__((dllimport)) WINBOOL EnumResourceTypesExW (HMODULE hModule, ENUMRESTYPEPROCW lpEnumFunc, LONG_PTR lParam, DWORD dwFlags, LANGID LangId);
  __attribute__((dllimport)) WINBOOL QueryOptionalDelayLoadedAPI (HMODULE CallerModule, LPCSTR lpDllName, LPCSTR lpProcName, DWORD Reserved);
  __attribute__((dllimport)) WINBOOL DisableThreadLibraryCalls (HMODULE hLibModule);
  __attribute__((dllimport)) WINBOOL FreeLibrary (HMODULE hLibModule);
  __attribute__((dllimport)) FARPROC GetProcAddress (HMODULE hModule, LPCSTR lpProcName);
  __attribute__((dllimport)) DWORD GetModuleFileNameA (HMODULE hModule, LPSTR lpFilename, DWORD nSize);
  __attribute__((dllimport)) DWORD GetModuleFileNameW (HMODULE hModule, LPWSTR lpFilename, DWORD nSize);
  typedef enum _MEMORY_RESOURCE_NOTIFICATION_TYPE {
    LowMemoryResourceNotification,
    HighMemoryResourceNotification
  } MEMORY_RESOURCE_NOTIFICATION_TYPE;
    __attribute__((dllimport)) WINBOOL VirtualFree (LPVOID lpAddress, SIZE_T dwSize, DWORD dwFreeType);
  __attribute__((dllimport)) SIZE_T VirtualQuery (LPCVOID lpAddress, PMEMORY_BASIC_INFORMATION lpBuffer, SIZE_T dwLength);
  __attribute__((dllimport)) WINBOOL FlushViewOfFile (LPCVOID lpBaseAddress, SIZE_T dwNumberOfBytesToFlush);
  __attribute__((dllimport)) WINBOOL UnmapViewOfFile (LPCVOID lpBaseAddress);
  __attribute__((dllimport)) HANDLE CreateFileMappingFromApp (HANDLE hFile, PSECURITY_ATTRIBUTES SecurityAttributes, ULONG PageProtection, ULONG64 MaximumSize, PCWSTR Name);
  __attribute__((dllimport)) PVOID MapViewOfFileFromApp (HANDLE hFileMappingObject, ULONG DesiredAccess, ULONG64 FileOffset, SIZE_T NumberOfBytesToMap);






  __attribute__((dllimport)) WINBOOL VirtualProtect (LPVOID lpAddress, SIZE_T dwSize, DWORD flNewProtect, PDWORD lpflOldProtect);
  __attribute__((dllimport)) LPVOID VirtualAlloc (LPVOID lpAddress, SIZE_T dwSize, DWORD flAllocationType, DWORD flProtect);
  __attribute__((dllimport)) LPVOID VirtualAllocEx (HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD flAllocationType, DWORD flProtect);
  __attribute__((dllimport)) WINBOOL VirtualFreeEx (HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD dwFreeType);
  __attribute__((dllimport)) WINBOOL VirtualProtectEx (HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD flNewProtect, PDWORD lpflOldProtect);
  __attribute__((dllimport)) SIZE_T VirtualQueryEx (HANDLE hProcess, LPCVOID lpAddress, PMEMORY_BASIC_INFORMATION lpBuffer, SIZE_T dwLength);
  __attribute__((dllimport)) WINBOOL ReadProcessMemory (HANDLE hProcess, LPCVOID lpBaseAddress, LPVOID lpBuffer, SIZE_T nSize, SIZE_T *lpNumberOfBytesRead);
  __attribute__((dllimport)) WINBOOL WriteProcessMemory (HANDLE hProcess, LPVOID lpBaseAddress, LPCVOID lpBuffer, SIZE_T nSize, SIZE_T *lpNumberOfBytesWritten);
  __attribute__((dllimport)) HANDLE CreateFileMappingW (HANDLE hFile, LPSECURITY_ATTRIBUTES lpFileMappingAttributes, DWORD flProtect, DWORD dwMaximumSizeHigh, DWORD dwMaximumSizeLow, LPCWSTR lpName);
  __attribute__((dllimport)) HANDLE OpenFileMappingW (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCWSTR lpName);
  __attribute__((dllimport)) LPVOID MapViewOfFile (HANDLE hFileMappingObject, DWORD dwDesiredAccess, DWORD dwFileOffsetHigh, DWORD dwFileOffsetLow, SIZE_T dwNumberOfBytesToMap);
  __attribute__((dllimport)) LPVOID MapViewOfFileEx (HANDLE hFileMappingObject, DWORD dwDesiredAccess, DWORD dwFileOffsetHigh, DWORD dwFileOffsetLow, SIZE_T dwNumberOfBytesToMap, LPVOID lpBaseAddress);
  __attribute__((dllimport)) SIZE_T GetLargePageMinimum (void);
  __attribute__((dllimport)) WINBOOL GetProcessWorkingSetSizeEx (HANDLE hProcess, PSIZE_T lpMinimumWorkingSetSize, PSIZE_T lpMaximumWorkingSetSize, PDWORD Flags);
  __attribute__((dllimport)) WINBOOL SetProcessWorkingSetSizeEx (HANDLE hProcess, SIZE_T dwMinimumWorkingSetSize, SIZE_T dwMaximumWorkingSetSize, DWORD Flags);
  __attribute__((dllimport)) WINBOOL VirtualLock (LPVOID lpAddress, SIZE_T dwSize);
  __attribute__((dllimport)) WINBOOL VirtualUnlock (LPVOID lpAddress, SIZE_T dwSize);
  __attribute__((dllimport)) UINT GetWriteWatch (DWORD dwFlags, PVOID lpBaseAddress, SIZE_T dwRegionSize, PVOID *lpAddresses, ULONG_PTR *lpdwCount, LPDWORD lpdwGranularity);
  __attribute__((dllimport)) UINT ResetWriteWatch (LPVOID lpBaseAddress, SIZE_T dwRegionSize);
  __attribute__((dllimport)) HANDLE CreateMemoryResourceNotification (MEMORY_RESOURCE_NOTIFICATION_TYPE NotificationType);
  __attribute__((dllimport)) WINBOOL QueryMemoryResourceNotification (HANDLE ResourceNotificationHandle, PBOOL ResourceState);
  __attribute__((dllimport)) WINBOOL GetSystemFileCacheSize (PSIZE_T lpMinimumFileCacheSize, PSIZE_T lpMaximumFileCacheSize, PDWORD lpFlags);
  __attribute__((dllimport)) WINBOOL SetSystemFileCacheSize (SIZE_T MinimumFileCacheSize, SIZE_T MaximumFileCacheSize, DWORD Flags);







  __attribute__((dllimport)) HANDLE CreateFileMappingNumaW (HANDLE hFile, LPSECURITY_ATTRIBUTES lpFileMappingAttributes, DWORD flProtect, DWORD dwMaximumSizeHigh, DWORD dwMaximumSizeLow, LPCWSTR lpName, DWORD nndPreferred);
  __attribute__((dllimport)) WINBOOL ImpersonateNamedPipeClient (HANDLE hNamedPipe);
  __attribute__((dllimport)) WINBOOL CreatePipe (PHANDLE hReadPipe, PHANDLE hWritePipe, LPSECURITY_ATTRIBUTES lpPipeAttributes, DWORD nSize);
  __attribute__((dllimport)) WINBOOL ConnectNamedPipe (HANDLE hNamedPipe, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) WINBOOL DisconnectNamedPipe (HANDLE hNamedPipe);
  __attribute__((dllimport)) WINBOOL SetNamedPipeHandleState (HANDLE hNamedPipe, LPDWORD lpMode, LPDWORD lpMaxCollectionCount, LPDWORD lpCollectDataTimeout);
  __attribute__((dllimport)) WINBOOL PeekNamedPipe (HANDLE hNamedPipe, LPVOID lpBuffer, DWORD nBufferSize, LPDWORD lpBytesRead, LPDWORD lpTotalBytesAvail, LPDWORD lpBytesLeftThisMessage);
  __attribute__((dllimport)) WINBOOL TransactNamedPipe (HANDLE hNamedPipe, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesRead, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) HANDLE CreateNamedPipeW (LPCWSTR lpName, DWORD dwOpenMode, DWORD dwPipeMode, DWORD nMaxInstances, DWORD nOutBufferSize, DWORD nInBufferSize, DWORD nDefaultTimeOut, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) WINBOOL WaitNamedPipeW (LPCWSTR lpNamedPipeName, DWORD nTimeOut);

  __attribute__((dllimport)) WINBOOL GetNamedPipeClientComputerNameW (HANDLE Pipe, LPWSTR ClientComputerName, ULONG ClientComputerNameLength);
  __attribute__((dllimport)) HANDLE CreatePrivateNamespaceW (LPSECURITY_ATTRIBUTES lpPrivateNamespaceAttributes, LPVOID lpBoundaryDescriptor, LPCWSTR lpAliasPrefix);
  __attribute__((dllimport)) HANDLE OpenPrivateNamespaceW (LPVOID lpBoundaryDescriptor, LPCWSTR lpAliasPrefix);




  __attribute__((dllimport)) BOOLEAN ClosePrivateNamespace (HANDLE Handle, ULONG Flags);
  __attribute__((dllimport)) HANDLE CreateBoundaryDescriptorW (LPCWSTR Name, ULONG Flags);




  __attribute__((dllimport)) WINBOOL AddSIDToBoundaryDescriptor (HANDLE *BoundaryDescriptor, PSID RequiredSid);
  __attribute__((dllimport)) void DeleteBoundaryDescriptor (HANDLE BoundaryDescriptor);
  __attribute__((dllimport)) LPCH GetEnvironmentStrings (void);
  __attribute__((dllimport)) LPWCH GetEnvironmentStringsW (void);
  __attribute__((dllimport)) WINBOOL SetEnvironmentStringsW (LPWCH NewEnvironment);
  __attribute__((dllimport)) WINBOOL FreeEnvironmentStringsA (LPCH penv);
  __attribute__((dllimport)) WINBOOL FreeEnvironmentStringsW (LPWCH penv);
  __attribute__((dllimport)) HANDLE GetStdHandle (DWORD nStdHandle);
  __attribute__((dllimport)) WINBOOL SetStdHandle (DWORD nStdHandle, HANDLE hHandle);

  __attribute__((dllimport)) WINBOOL SetStdHandleEx (DWORD nStdHandle, HANDLE hHandle, PHANDLE phPrevValue);

  __attribute__((dllimport)) LPSTR GetCommandLineA (void);
  __attribute__((dllimport)) LPWSTR GetCommandLineW (void);
  __attribute__((dllimport)) DWORD GetEnvironmentVariableA (LPCSTR lpName, LPSTR lpBuffer, DWORD nSize);
  __attribute__((dllimport)) DWORD GetEnvironmentVariableW (LPCWSTR lpName, LPWSTR lpBuffer, DWORD nSize);
  __attribute__((dllimport)) WINBOOL SetEnvironmentVariableA (LPCSTR lpName, LPCSTR lpValue);
  __attribute__((dllimport)) WINBOOL SetEnvironmentVariableW (LPCWSTR lpName, LPCWSTR lpValue);
  __attribute__((dllimport)) DWORD ExpandEnvironmentStringsA (LPCSTR lpSrc, LPSTR lpDst, DWORD nSize);
  __attribute__((dllimport)) DWORD ExpandEnvironmentStringsW (LPCWSTR lpSrc, LPWSTR lpDst, DWORD nSize);
  __attribute__((dllimport)) WINBOOL SetCurrentDirectoryA (LPCSTR lpPathName);
  __attribute__((dllimport)) WINBOOL SetCurrentDirectoryW (LPCWSTR lpPathName);
  __attribute__((dllimport)) DWORD GetCurrentDirectoryA (DWORD nBufferLength, LPSTR lpBuffer);
  __attribute__((dllimport)) DWORD GetCurrentDirectoryW (DWORD nBufferLength, LPWSTR lpBuffer);
  __attribute__((dllimport)) DWORD SearchPathW (LPCWSTR lpPath, LPCWSTR lpFileName, LPCWSTR lpExtension, DWORD nBufferLength, LPWSTR lpBuffer, LPWSTR *lpFilePart);
  __attribute__((dllimport)) DWORD SearchPathA (LPCSTR lpPath, LPCSTR lpFileName, LPCSTR lpExtension, DWORD nBufferLength, LPSTR lpBuffer, LPSTR *lpFilePart);
  __attribute__((dllimport)) WINBOOL NeedCurrentDirectoryForExePathA (LPCSTR ExeName);
  __attribute__((dllimport)) WINBOOL NeedCurrentDirectoryForExePathW (LPCWSTR ExeName);
__attribute__((dllimport)) WINBOOL TerminateProcess (HANDLE hProcess, UINT uExitCode);



  typedef struct _PROCESS_INFORMATION {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
    DWORD dwThreadId;
  } PROCESS_INFORMATION, *PPROCESS_INFORMATION, *LPPROCESS_INFORMATION;

  typedef struct _STARTUPINFOA {
    DWORD cb;
    LPSTR lpReserved;
    LPSTR lpDesktop;
    LPSTR lpTitle;
    DWORD dwX;
    DWORD dwY;
    DWORD dwXSize;
    DWORD dwYSize;
    DWORD dwXCountChars;
    DWORD dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    WORD wShowWindow;
    WORD cbReserved2;
    LPBYTE lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
  } STARTUPINFOA, *LPSTARTUPINFOA;

  typedef struct _STARTUPINFOW {
    DWORD cb;
    LPWSTR lpReserved;
    LPWSTR lpDesktop;
    LPWSTR lpTitle;
    DWORD dwX;
    DWORD dwY;
    DWORD dwXSize;
    DWORD dwYSize;
    DWORD dwXCountChars;
    DWORD dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    WORD wShowWindow;
    WORD cbReserved2;
    LPBYTE lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
  } STARTUPINFOW, *LPSTARTUPINFOW;

  typedef STARTUPINFOA STARTUPINFO;
  typedef LPSTARTUPINFOA LPSTARTUPINFO;

  typedef struct _PROC_THREAD_ATTRIBUTE_LIST *PPROC_THREAD_ATTRIBUTE_LIST, *LPPROC_THREAD_ATTRIBUTE_LIST;

  __attribute__((dllimport)) DWORD QueueUserAPC (PAPCFUNC pfnAPC, HANDLE hThread, ULONG_PTR dwData);
  __attribute__((dllimport)) WINBOOL GetProcessTimes (HANDLE hProcess, LPFILETIME lpCreationTime, LPFILETIME lpExitTime, LPFILETIME lpKernelTime, LPFILETIME lpUserTime);
  __attribute__((dllimport)) __attribute__((noreturn)) void ExitProcess (UINT uExitCode);
  __attribute__((dllimport)) WINBOOL GetExitCodeProcess (HANDLE hProcess, LPDWORD lpExitCode);
  __attribute__((dllimport)) WINBOOL SwitchToThread (void);
  __attribute__((dllimport)) HANDLE CreateRemoteThread (HANDLE hProcess, LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId);
  __attribute__((dllimport)) HANDLE OpenThread (DWORD dwDesiredAccess, WINBOOL bInheritHandle, DWORD dwThreadId);
  __attribute__((dllimport)) WINBOOL SetThreadPriorityBoost (HANDLE hThread, WINBOOL bDisablePriorityBoost);
  __attribute__((dllimport)) WINBOOL GetThreadPriorityBoost (HANDLE hThread, PBOOL pDisablePriorityBoost);
  __attribute__((dllimport)) WINBOOL TerminateThread (HANDLE hThread, DWORD dwExitCode);
  __attribute__((dllimport)) WINBOOL SetProcessShutdownParameters (DWORD dwLevel, DWORD dwFlags);
  __attribute__((dllimport)) DWORD GetProcessVersion (DWORD ProcessId);
  __attribute__((dllimport)) void GetStartupInfoW (LPSTARTUPINFOW lpStartupInfo);
  __attribute__((dllimport)) WINBOOL SetThreadToken (PHANDLE Thread, HANDLE Token);
  __attribute__((dllimport)) WINBOOL OpenProcessToken (HANDLE ProcessHandle, DWORD DesiredAccess, PHANDLE TokenHandle);
  __attribute__((dllimport)) WINBOOL OpenThreadToken (HANDLE ThreadHandle, DWORD DesiredAccess, WINBOOL OpenAsSelf, PHANDLE TokenHandle);
  __attribute__((dllimport)) WINBOOL SetPriorityClass (HANDLE hProcess, DWORD dwPriorityClass);
  __attribute__((dllimport)) WINBOOL SetThreadStackGuarantee (PULONG StackSizeInBytes);
  __attribute__((dllimport)) DWORD GetPriorityClass (HANDLE hProcess);
  __attribute__((dllimport)) WINBOOL ProcessIdToSessionId (DWORD dwProcessId, DWORD *pSessionId);
  __attribute__((dllimport)) DWORD GetProcessId (HANDLE Process);
  __attribute__((dllimport)) DWORD GetThreadId (HANDLE Thread);
  __attribute__((dllimport)) HANDLE CreateRemoteThreadEx (HANDLE hProcess, LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList, LPDWORD lpThreadId);
  __attribute__((dllimport)) WINBOOL GetThreadContext (HANDLE hThread, LPCONTEXT lpContext);
  __attribute__((dllimport)) WINBOOL SetThreadContext (HANDLE hThread, const CONTEXT *lpContext);
  __attribute__((dllimport)) WINBOOL FlushInstructionCache (HANDLE hProcess, LPCVOID lpBaseAddress, SIZE_T dwSize);
  __attribute__((dllimport)) WINBOOL GetThreadTimes (HANDLE hThread, LPFILETIME lpCreationTime, LPFILETIME lpExitTime, LPFILETIME lpKernelTime, LPFILETIME lpUserTime);
  __attribute__((dllimport)) HANDLE OpenProcess (DWORD dwDesiredAccess, WINBOOL bInheritHandle, DWORD dwProcessId);
  __attribute__((dllimport)) WINBOOL GetProcessHandleCount (HANDLE hProcess, PDWORD pdwHandleCount);
  __attribute__((dllimport)) DWORD GetCurrentProcessorNumber (void);






  __attribute__((dllimport)) WINBOOL CreateProcessA (LPCSTR lpApplicationName, LPSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes, WINBOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCSTR lpCurrentDirectory, LPSTARTUPINFOA lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation);
  __attribute__((dllimport)) WINBOOL CreateProcessW (LPCWSTR lpApplicationName, LPWSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes, WINBOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCWSTR lpCurrentDirectory, LPSTARTUPINFOW lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation);




  __attribute__((dllimport)) WINBOOL CreateProcessAsUserW (HANDLE hToken, LPCWSTR lpApplicationName, LPWSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes, WINBOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCWSTR lpCurrentDirectory, LPSTARTUPINFOW lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation);
  __attribute__((dllimport)) DWORD GetProcessIdOfThread (HANDLE Thread);
  __attribute__((dllimport)) WINBOOL InitializeProcThreadAttributeList (LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList, DWORD dwAttributeCount, DWORD dwFlags, PSIZE_T lpSize);
  __attribute__((dllimport)) void DeleteProcThreadAttributeList (LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList);
  __attribute__((dllimport)) WINBOOL SetProcessAffinityUpdateMode (HANDLE hProcess, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL QueryProcessAffinityUpdateMode (HANDLE hProcess, LPDWORD lpdwFlags);
  __attribute__((dllimport)) WINBOOL UpdateProcThreadAttribute (LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList, DWORD dwFlags, DWORD_PTR Attribute, PVOID lpValue, SIZE_T cbSize, PVOID lpPreviousValue, PSIZE_T lpReturnSize);
  __attribute__((dllimport)) HANDLE GetCurrentProcess (void);
  __attribute__((dllimport)) DWORD GetCurrentProcessId (void);
  __attribute__((dllimport)) HANDLE GetCurrentThread (void);
  __attribute__((dllimport)) DWORD GetCurrentThreadId (void);
  WINBOOL IsProcessorFeaturePresent (DWORD ProcessorFeature);

  __attribute__((dllimport)) void FlushProcessWriteBuffers (void);

  __attribute__((dllimport)) HANDLE CreateThread (LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId);
  __attribute__((dllimport)) WINBOOL SetThreadPriority (HANDLE hThread, int nPriority);
  __attribute__((dllimport)) int GetThreadPriority (HANDLE hThread);
  __attribute__((dllimport)) __attribute__((noreturn)) void ExitThread (DWORD dwExitCode);
  __attribute__((dllimport)) WINBOOL GetExitCodeThread (HANDLE hThread, LPDWORD lpExitCode);




  __attribute__((dllimport)) DWORD SuspendThread (HANDLE hThread);
  __attribute__((dllimport)) DWORD ResumeThread (HANDLE hThread);
  __attribute__((dllimport)) DWORD TlsAlloc (void);
  __attribute__((dllimport)) LPVOID TlsGetValue (DWORD dwTlsIndex);
  __attribute__((dllimport)) WINBOOL TlsSetValue (DWORD dwTlsIndex, LPVOID lpTlsValue);
  __attribute__((dllimport)) WINBOOL TlsFree (DWORD dwTlsIndex);
  __attribute__((dllimport)) WINBOOL QueryPerformanceCounter (LARGE_INTEGER *lpPerformanceCount);
  __attribute__((dllimport)) WINBOOL QueryPerformanceFrequency (LARGE_INTEGER *lpFrequency);
  __attribute__((dllimport)) WINBOOL QueryThreadCycleTime (HANDLE ThreadHandle, PULONG64 CycleTime);
  __attribute__((dllimport)) WINBOOL QueryProcessCycleTime (HANDLE ProcessHandle, PULONG64 CycleTime);
  __attribute__((dllimport)) WINBOOL QueryIdleProcessorCycleTime (PULONG BufferLength, PULONG64 ProcessorIdleCycleTime);
  __attribute__((dllimport)) WINBOOL AccessCheck (PSECURITY_DESCRIPTOR pSecurityDescriptor, HANDLE ClientToken, DWORD DesiredAccess, PGENERIC_MAPPING GenericMapping, PPRIVILEGE_SET PrivilegeSet, LPDWORD PrivilegeSetLength, LPDWORD GrantedAccess, LPBOOL AccessStatus);
  __attribute__((dllimport)) WINBOOL AccessCheckAndAuditAlarmW (LPCWSTR SubsystemName, LPVOID HandleId, LPWSTR ObjectTypeName, LPWSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, DWORD DesiredAccess, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccess, LPBOOL AccessStatus, LPBOOL pfGenerateOnClose);




  __attribute__((dllimport)) WINBOOL AccessCheckByType (PSECURITY_DESCRIPTOR pSecurityDescriptor, PSID PrincipalSelfSid, HANDLE ClientToken, DWORD DesiredAccess, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, PPRIVILEGE_SET PrivilegeSet, LPDWORD PrivilegeSetLength, LPDWORD GrantedAccess, LPBOOL AccessStatus);
  __attribute__((dllimport)) WINBOOL AccessCheckByTypeResultList (PSECURITY_DESCRIPTOR pSecurityDescriptor, PSID PrincipalSelfSid, HANDLE ClientToken, DWORD DesiredAccess, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, PPRIVILEGE_SET PrivilegeSet, LPDWORD PrivilegeSetLength, LPDWORD GrantedAccessList, LPDWORD AccessStatusList);
  __attribute__((dllimport)) WINBOOL AccessCheckByTypeAndAuditAlarmW (LPCWSTR SubsystemName, LPVOID HandleId, LPCWSTR ObjectTypeName, LPCWSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, PSID PrincipalSelfSid, DWORD DesiredAccess, AUDIT_EVENT_TYPE AuditType, DWORD Flags, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccess, LPBOOL AccessStatus, LPBOOL pfGenerateOnClose);




  __attribute__((dllimport)) WINBOOL AccessCheckByTypeResultListAndAuditAlarmW (LPCWSTR SubsystemName, LPVOID HandleId, LPCWSTR ObjectTypeName, LPCWSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, PSID PrincipalSelfSid, DWORD DesiredAccess, AUDIT_EVENT_TYPE AuditType, DWORD Flags, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccessList, LPDWORD AccessStatusList, LPBOOL pfGenerateOnClose);




  __attribute__((dllimport)) WINBOOL AccessCheckByTypeResultListAndAuditAlarmByHandleW (LPCWSTR SubsystemName, LPVOID HandleId, HANDLE ClientToken, LPCWSTR ObjectTypeName, LPCWSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, PSID PrincipalSelfSid, DWORD DesiredAccess, AUDIT_EVENT_TYPE AuditType, DWORD Flags, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccessList, LPDWORD AccessStatusList, LPBOOL pfGenerateOnClose);




  __attribute__((dllimport)) WINBOOL AddAccessAllowedAce (PACL pAcl, DWORD dwAceRevision, DWORD AccessMask, PSID pSid);
  __attribute__((dllimport)) WINBOOL AddAccessAllowedAceEx (PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD AccessMask, PSID pSid);
  __attribute__((dllimport)) WINBOOL AddAccessAllowedObjectAce (PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD AccessMask, GUID *ObjectTypeGuid, GUID *InheritedObjectTypeGuid, PSID pSid);
  __attribute__((dllimport)) WINBOOL AddAccessDeniedAce (PACL pAcl, DWORD dwAceRevision, DWORD AccessMask, PSID pSid);
  __attribute__((dllimport)) WINBOOL AddAccessDeniedAceEx (PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD AccessMask, PSID pSid);
  __attribute__((dllimport)) WINBOOL AddAccessDeniedObjectAce (PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD AccessMask, GUID *ObjectTypeGuid, GUID *InheritedObjectTypeGuid, PSID pSid);
  __attribute__((dllimport)) WINBOOL AddAce (PACL pAcl, DWORD dwAceRevision, DWORD dwStartingAceIndex, LPVOID pAceList, DWORD nAceListLength);
  __attribute__((dllimport)) WINBOOL AddAuditAccessAce (PACL pAcl, DWORD dwAceRevision, DWORD dwAccessMask, PSID pSid, WINBOOL bAuditSuccess, WINBOOL bAuditFailure);
  __attribute__((dllimport)) WINBOOL AddAuditAccessAceEx (PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD dwAccessMask, PSID pSid, WINBOOL bAuditSuccess, WINBOOL bAuditFailure);
  __attribute__((dllimport)) WINBOOL AddAuditAccessObjectAce (PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD AccessMask, GUID *ObjectTypeGuid, GUID *InheritedObjectTypeGuid, PSID pSid, WINBOOL bAuditSuccess, WINBOOL bAuditFailure);

  __attribute__((dllimport)) WINBOOL AddMandatoryAce (PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD MandatoryPolicy, PSID pLabelSid);







  __attribute__((dllimport)) WINBOOL AdjustTokenGroups (HANDLE TokenHandle, WINBOOL ResetToDefault, PTOKEN_GROUPS NewState, DWORD BufferLength, PTOKEN_GROUPS PreviousState, PDWORD ReturnLength);
  __attribute__((dllimport)) WINBOOL AdjustTokenPrivileges (HANDLE TokenHandle, WINBOOL DisableAllPrivileges, PTOKEN_PRIVILEGES NewState, DWORD BufferLength, PTOKEN_PRIVILEGES PreviousState, PDWORD ReturnLength);
  __attribute__((dllimport)) WINBOOL AllocateAndInitializeSid (PSID_IDENTIFIER_AUTHORITY pIdentifierAuthority, BYTE nSubAuthorityCount, DWORD nSubAuthority0, DWORD nSubAuthority1, DWORD nSubAuthority2, DWORD nSubAuthority3, DWORD nSubAuthority4, DWORD nSubAuthority5, DWORD nSubAuthority6, DWORD nSubAuthority7, PSID *pSid);
  __attribute__((dllimport)) WINBOOL AllocateLocallyUniqueId (PLUID Luid);
  __attribute__((dllimport)) WINBOOL AreAllAccessesGranted (DWORD GrantedAccess, DWORD DesiredAccess);
  __attribute__((dllimport)) WINBOOL AreAnyAccessesGranted (DWORD GrantedAccess, DWORD DesiredAccess);
  __attribute__((dllimport)) WINBOOL CheckTokenMembership (HANDLE TokenHandle, PSID SidToCheck, PBOOL IsMember);







  __attribute__((dllimport)) WINBOOL ConvertToAutoInheritPrivateObjectSecurity (PSECURITY_DESCRIPTOR ParentDescriptor, PSECURITY_DESCRIPTOR CurrentSecurityDescriptor, PSECURITY_DESCRIPTOR *NewSecurityDescriptor, GUID *ObjectType, BOOLEAN IsDirectoryObject, PGENERIC_MAPPING GenericMapping);
  __attribute__((dllimport)) WINBOOL CopySid (DWORD nDestinationSidLength, PSID pDestinationSid, PSID pSourceSid);
  __attribute__((dllimport)) WINBOOL CreatePrivateObjectSecurity (PSECURITY_DESCRIPTOR ParentDescriptor, PSECURITY_DESCRIPTOR CreatorDescriptor, PSECURITY_DESCRIPTOR *NewDescriptor, WINBOOL IsDirectoryObject, HANDLE Token, PGENERIC_MAPPING GenericMapping);
  __attribute__((dllimport)) WINBOOL CreatePrivateObjectSecurityEx (PSECURITY_DESCRIPTOR ParentDescriptor, PSECURITY_DESCRIPTOR CreatorDescriptor, PSECURITY_DESCRIPTOR *NewDescriptor, GUID *ObjectType, WINBOOL IsContainerObject, ULONG AutoInheritFlags, HANDLE Token, PGENERIC_MAPPING GenericMapping);
  __attribute__((dllimport)) WINBOOL CreatePrivateObjectSecurityWithMultipleInheritance (PSECURITY_DESCRIPTOR ParentDescriptor, PSECURITY_DESCRIPTOR CreatorDescriptor, PSECURITY_DESCRIPTOR *NewDescriptor, GUID **ObjectTypes, ULONG GuidCount, WINBOOL IsContainerObject, ULONG AutoInheritFlags, HANDLE Token, PGENERIC_MAPPING GenericMapping);
  __attribute__((dllimport)) WINBOOL CreateRestrictedToken (HANDLE ExistingTokenHandle, DWORD Flags, DWORD DisableSidCount, PSID_AND_ATTRIBUTES SidsToDisable, DWORD DeletePrivilegeCount, PLUID_AND_ATTRIBUTES PrivilegesToDelete, DWORD RestrictedSidCount, PSID_AND_ATTRIBUTES SidsToRestrict, PHANDLE NewTokenHandle);
  __attribute__((dllimport)) WINBOOL CreateWellKnownSid (WELL_KNOWN_SID_TYPE WellKnownSidType, PSID DomainSid, PSID pSid, DWORD *cbSid);
  __attribute__((dllimport)) WINBOOL EqualDomainSid (PSID pSid1, PSID pSid2, WINBOOL *pfEqual);

  __attribute__((dllimport)) WINBOOL DeleteAce (PACL pAcl, DWORD dwAceIndex);
  __attribute__((dllimport)) WINBOOL DestroyPrivateObjectSecurity (PSECURITY_DESCRIPTOR *ObjectDescriptor);
  __attribute__((dllimport)) WINBOOL DuplicateToken (HANDLE ExistingTokenHandle, SECURITY_IMPERSONATION_LEVEL ImpersonationLevel, PHANDLE DuplicateTokenHandle);
  __attribute__((dllimport)) WINBOOL DuplicateTokenEx (HANDLE hExistingToken, DWORD dwDesiredAccess, LPSECURITY_ATTRIBUTES lpTokenAttributes, SECURITY_IMPERSONATION_LEVEL ImpersonationLevel, TOKEN_TYPE TokenType, PHANDLE phNewToken);
  __attribute__((dllimport)) WINBOOL EqualPrefixSid (PSID pSid1, PSID pSid2);
  __attribute__((dllimport)) WINBOOL EqualSid (PSID pSid1, PSID pSid2);
  __attribute__((dllimport)) WINBOOL FindFirstFreeAce (PACL pAcl, LPVOID *pAce);
  __attribute__((dllimport)) PVOID FreeSid (PSID pSid);
  __attribute__((dllimport)) WINBOOL GetAce (PACL pAcl, DWORD dwAceIndex, LPVOID *pAce);
  __attribute__((dllimport)) WINBOOL GetAclInformation (PACL pAcl, LPVOID pAclInformation, DWORD nAclInformationLength, ACL_INFORMATION_CLASS dwAclInformationClass);
  __attribute__((dllimport)) WINBOOL GetFileSecurityW (LPCWSTR lpFileName, SECURITY_INFORMATION RequestedInformation, PSECURITY_DESCRIPTOR pSecurityDescriptor, DWORD nLength, LPDWORD lpnLengthNeeded);




  __attribute__((dllimport)) WINBOOL GetKernelObjectSecurity (HANDLE Handle, SECURITY_INFORMATION RequestedInformation, PSECURITY_DESCRIPTOR pSecurityDescriptor, DWORD nLength, LPDWORD lpnLengthNeeded);
  __attribute__((dllimport)) DWORD GetLengthSid (PSID pSid);
  __attribute__((dllimport)) WINBOOL GetPrivateObjectSecurity (PSECURITY_DESCRIPTOR ObjectDescriptor, SECURITY_INFORMATION SecurityInformation, PSECURITY_DESCRIPTOR ResultantDescriptor, DWORD DescriptorLength, PDWORD ReturnLength);
  __attribute__((dllimport)) WINBOOL GetSecurityDescriptorControl (PSECURITY_DESCRIPTOR pSecurityDescriptor, PSECURITY_DESCRIPTOR_CONTROL pControl, LPDWORD lpdwRevision);
  __attribute__((dllimport)) WINBOOL GetSecurityDescriptorDacl (PSECURITY_DESCRIPTOR pSecurityDescriptor, LPBOOL lpbDaclPresent, PACL *pDacl, LPBOOL lpbDaclDefaulted);
  __attribute__((dllimport)) WINBOOL GetSecurityDescriptorGroup (PSECURITY_DESCRIPTOR pSecurityDescriptor, PSID *pGroup, LPBOOL lpbGroupDefaulted);
  __attribute__((dllimport)) DWORD GetSecurityDescriptorLength (PSECURITY_DESCRIPTOR pSecurityDescriptor);
  __attribute__((dllimport)) WINBOOL GetSecurityDescriptorOwner (PSECURITY_DESCRIPTOR pSecurityDescriptor, PSID *pOwner, LPBOOL lpbOwnerDefaulted);
  __attribute__((dllimport)) DWORD GetSecurityDescriptorRMControl (PSECURITY_DESCRIPTOR SecurityDescriptor, PUCHAR RMControl);
  __attribute__((dllimport)) WINBOOL GetSecurityDescriptorSacl (PSECURITY_DESCRIPTOR pSecurityDescriptor, LPBOOL lpbSaclPresent, PACL *pSacl, LPBOOL lpbSaclDefaulted);
  __attribute__((dllimport)) PSID_IDENTIFIER_AUTHORITY GetSidIdentifierAuthority (PSID pSid);
  __attribute__((dllimport)) DWORD GetSidLengthRequired (UCHAR nSubAuthorityCount);
  __attribute__((dllimport)) PDWORD GetSidSubAuthority (PSID pSid, DWORD nSubAuthority);
  __attribute__((dllimport)) PUCHAR GetSidSubAuthorityCount (PSID pSid);
  __attribute__((dllimport)) WINBOOL GetTokenInformation (HANDLE TokenHandle, TOKEN_INFORMATION_CLASS TokenInformationClass, LPVOID TokenInformation, DWORD TokenInformationLength, PDWORD ReturnLength);
  __attribute__((dllimport)) WINBOOL GetWindowsAccountDomainSid (PSID pSid, PSID pDomainSid, DWORD *cbDomainSid);
  __attribute__((dllimport)) WINBOOL ImpersonateAnonymousToken (HANDLE ThreadHandle);
  __attribute__((dllimport)) WINBOOL ImpersonateLoggedOnUser (HANDLE hToken);
  __attribute__((dllimport)) WINBOOL ImpersonateSelf (SECURITY_IMPERSONATION_LEVEL ImpersonationLevel);
  __attribute__((dllimport)) WINBOOL InitializeAcl (PACL pAcl, DWORD nAclLength, DWORD dwAclRevision);
  __attribute__((dllimport)) WINBOOL InitializeSecurityDescriptor (PSECURITY_DESCRIPTOR pSecurityDescriptor, DWORD dwRevision);
  __attribute__((dllimport)) WINBOOL InitializeSid (PSID Sid, PSID_IDENTIFIER_AUTHORITY pIdentifierAuthority, BYTE nSubAuthorityCount);
  __attribute__((dllimport)) WINBOOL IsTokenRestricted (HANDLE TokenHandle);
  __attribute__((dllimport)) WINBOOL IsValidAcl (PACL pAcl);
  __attribute__((dllimport)) WINBOOL IsValidSecurityDescriptor (PSECURITY_DESCRIPTOR pSecurityDescriptor);
  __attribute__((dllimport)) WINBOOL IsValidSid (PSID pSid);
  __attribute__((dllimport)) WINBOOL IsWellKnownSid (PSID pSid, WELL_KNOWN_SID_TYPE WellKnownSidType);
  __attribute__((dllimport)) WINBOOL MakeAbsoluteSD (PSECURITY_DESCRIPTOR pSelfRelativeSecurityDescriptor, PSECURITY_DESCRIPTOR pAbsoluteSecurityDescriptor, LPDWORD lpdwAbsoluteSecurityDescriptorSize, PACL pDacl, LPDWORD lpdwDaclSize, PACL pSacl, LPDWORD lpdwSaclSize, PSID pOwner, LPDWORD lpdwOwnerSize, PSID pPrimaryGroup, LPDWORD lpdwPrimaryGroupSize);
  __attribute__((dllimport)) WINBOOL MakeSelfRelativeSD (PSECURITY_DESCRIPTOR pAbsoluteSecurityDescriptor, PSECURITY_DESCRIPTOR pSelfRelativeSecurityDescriptor, LPDWORD lpdwBufferLength);
  __attribute__((dllimport)) void MapGenericMask (PDWORD AccessMask, PGENERIC_MAPPING GenericMapping);
  __attribute__((dllimport)) WINBOOL ObjectCloseAuditAlarmW (LPCWSTR SubsystemName, LPVOID HandleId, WINBOOL GenerateOnClose);




  __attribute__((dllimport)) WINBOOL ObjectDeleteAuditAlarmW (LPCWSTR SubsystemName, LPVOID HandleId, WINBOOL GenerateOnClose);




  __attribute__((dllimport)) WINBOOL ObjectOpenAuditAlarmW (LPCWSTR SubsystemName, LPVOID HandleId, LPWSTR ObjectTypeName, LPWSTR ObjectName, PSECURITY_DESCRIPTOR pSecurityDescriptor, HANDLE ClientToken, DWORD DesiredAccess, DWORD GrantedAccess, PPRIVILEGE_SET Privileges, WINBOOL ObjectCreation, WINBOOL AccessGranted, LPBOOL GenerateOnClose);




  __attribute__((dllimport)) WINBOOL ObjectPrivilegeAuditAlarmW (LPCWSTR SubsystemName, LPVOID HandleId, HANDLE ClientToken, DWORD DesiredAccess, PPRIVILEGE_SET Privileges, WINBOOL AccessGranted);




  __attribute__((dllimport)) WINBOOL PrivilegeCheck (HANDLE ClientToken, PPRIVILEGE_SET RequiredPrivileges, LPBOOL pfResult);
  __attribute__((dllimport)) WINBOOL PrivilegedServiceAuditAlarmW (LPCWSTR SubsystemName, LPCWSTR ServiceName, HANDLE ClientToken, PPRIVILEGE_SET Privileges, WINBOOL AccessGranted);





  __attribute__((dllimport)) void QuerySecurityAccessMask (SECURITY_INFORMATION SecurityInformation, LPDWORD DesiredAccess);


  __attribute__((dllimport)) WINBOOL RevertToSelf (void);
  __attribute__((dllimport)) WINBOOL SetAclInformation (PACL pAcl, LPVOID pAclInformation, DWORD nAclInformationLength, ACL_INFORMATION_CLASS dwAclInformationClass);
  __attribute__((dllimport)) WINBOOL SetFileSecurityW (LPCWSTR lpFileName, SECURITY_INFORMATION SecurityInformation, PSECURITY_DESCRIPTOR pSecurityDescriptor);




  __attribute__((dllimport)) WINBOOL SetKernelObjectSecurity (HANDLE Handle, SECURITY_INFORMATION SecurityInformation, PSECURITY_DESCRIPTOR SecurityDescriptor);
  __attribute__((dllimport)) WINBOOL SetPrivateObjectSecurity (SECURITY_INFORMATION SecurityInformation, PSECURITY_DESCRIPTOR ModificationDescriptor, PSECURITY_DESCRIPTOR *ObjectsSecurityDescriptor, PGENERIC_MAPPING GenericMapping, HANDLE Token);
  __attribute__((dllimport)) WINBOOL SetPrivateObjectSecurityEx (SECURITY_INFORMATION SecurityInformation, PSECURITY_DESCRIPTOR ModificationDescriptor, PSECURITY_DESCRIPTOR *ObjectsSecurityDescriptor, ULONG AutoInheritFlags, PGENERIC_MAPPING GenericMapping, HANDLE Token);


  __attribute__((dllimport)) void SetSecurityAccessMask (SECURITY_INFORMATION SecurityInformation, LPDWORD DesiredAccess);


  __attribute__((dllimport)) WINBOOL SetSecurityDescriptorControl (PSECURITY_DESCRIPTOR pSecurityDescriptor, SECURITY_DESCRIPTOR_CONTROL ControlBitsOfInterest, SECURITY_DESCRIPTOR_CONTROL ControlBitsToSet);
  __attribute__((dllimport)) WINBOOL SetSecurityDescriptorDacl (PSECURITY_DESCRIPTOR pSecurityDescriptor, WINBOOL bDaclPresent, PACL pDacl, WINBOOL bDaclDefaulted);
  __attribute__((dllimport)) WINBOOL SetSecurityDescriptorGroup (PSECURITY_DESCRIPTOR pSecurityDescriptor, PSID pGroup, WINBOOL bGroupDefaulted);
  __attribute__((dllimport)) WINBOOL SetSecurityDescriptorOwner (PSECURITY_DESCRIPTOR pSecurityDescriptor, PSID pOwner, WINBOOL bOwnerDefaulted);
  __attribute__((dllimport)) DWORD SetSecurityDescriptorRMControl (PSECURITY_DESCRIPTOR SecurityDescriptor, PUCHAR RMControl);
  __attribute__((dllimport)) WINBOOL SetSecurityDescriptorSacl (PSECURITY_DESCRIPTOR pSecurityDescriptor, WINBOOL bSaclPresent, PACL pSacl, WINBOOL bSaclDefaulted);
  __attribute__((dllimport)) WINBOOL SetTokenInformation (HANDLE TokenHandle, TOKEN_INFORMATION_CLASS TokenInformationClass, LPVOID TokenInformation, DWORD TokenInformationLength);
  typedef RTL_SRWLOCK SRWLOCK, *PSRWLOCK;

  typedef RTL_RUN_ONCE INIT_ONCE;
  typedef PRTL_RUN_ONCE PINIT_ONCE;
  typedef PRTL_RUN_ONCE LPINIT_ONCE;

  typedef WINBOOL ( *PINIT_ONCE_FN) (PINIT_ONCE InitOnce, PVOID Parameter, PVOID *Context);
  typedef RTL_CONDITION_VARIABLE CONDITION_VARIABLE, *PCONDITION_VARIABLE;

  __attribute__((dllimport)) void EnterCriticalSection (LPCRITICAL_SECTION lpCriticalSection);
  __attribute__((dllimport)) void LeaveCriticalSection (LPCRITICAL_SECTION lpCriticalSection);
  __attribute__((dllimport)) WINBOOL TryEnterCriticalSection (LPCRITICAL_SECTION lpCriticalSection);
  __attribute__((dllimport)) void DeleteCriticalSection (LPCRITICAL_SECTION lpCriticalSection);
  __attribute__((dllimport)) WINBOOL SetEvent (HANDLE hEvent);
  __attribute__((dllimport)) WINBOOL ResetEvent (HANDLE hEvent);
  __attribute__((dllimport)) WINBOOL ReleaseSemaphore (HANDLE hSemaphore, LONG lReleaseCount, LPLONG lpPreviousCount);
  __attribute__((dllimport)) WINBOOL ReleaseMutex (HANDLE hMutex);
  __attribute__((dllimport)) DWORD WaitForSingleObjectEx (HANDLE hHandle, DWORD dwMilliseconds, WINBOOL bAlertable);
  __attribute__((dllimport)) DWORD WaitForMultipleObjectsEx (DWORD nCount, const HANDLE *lpHandles, WINBOOL bWaitAll, DWORD dwMilliseconds, WINBOOL bAlertable);
  __attribute__((dllimport)) HANDLE OpenMutexW (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCWSTR lpName);
  __attribute__((dllimport)) HANDLE OpenEventA (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE OpenEventW (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCWSTR lpName);
  __attribute__((dllimport)) HANDLE OpenSemaphoreW (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCWSTR lpName);
  WINBOOL WaitOnAddress (volatile void *Address, PVOID CompareAddress, SIZE_T AddressSize, DWORD dwMilliseconds);
  void WakeByAddressSingle (PVOID Address);
  void WakeByAddressAll (PVOID Address);






  __attribute__((dllimport)) void InitializeSRWLock (PSRWLOCK SRWLock);
  void ReleaseSRWLockExclusive (PSRWLOCK SRWLock);
  void ReleaseSRWLockShared (PSRWLOCK SRWLock);
  void AcquireSRWLockExclusive (PSRWLOCK SRWLock);
  void AcquireSRWLockShared (PSRWLOCK SRWLock);
  __attribute__((dllimport)) BOOLEAN TryAcquireSRWLockExclusive (PSRWLOCK SRWLock);
  __attribute__((dllimport)) BOOLEAN TryAcquireSRWLockShared (PSRWLOCK SRWLock);
  __attribute__((dllimport)) WINBOOL InitializeCriticalSectionEx (LPCRITICAL_SECTION lpCriticalSection, DWORD dwSpinCount, DWORD Flags);
  __attribute__((dllimport)) void InitOnceInitialize (PINIT_ONCE InitOnce);
  __attribute__((dllimport)) WINBOOL InitOnceExecuteOnce (PINIT_ONCE InitOnce, PINIT_ONCE_FN InitFn, PVOID Parameter, LPVOID *Context);
  __attribute__((dllimport)) WINBOOL InitOnceBeginInitialize (LPINIT_ONCE lpInitOnce, DWORD dwFlags, PBOOL fPending, LPVOID *lpContext);
  __attribute__((dllimport)) WINBOOL InitOnceComplete (LPINIT_ONCE lpInitOnce, DWORD dwFlags, LPVOID lpContext);
  __attribute__((dllimport)) void InitializeConditionVariable (PCONDITION_VARIABLE ConditionVariable);
  __attribute__((dllimport)) void WakeConditionVariable (PCONDITION_VARIABLE ConditionVariable);
  __attribute__((dllimport)) void WakeAllConditionVariable (PCONDITION_VARIABLE ConditionVariable);
  __attribute__((dllimport)) WINBOOL SleepConditionVariableCS (PCONDITION_VARIABLE ConditionVariable, PCRITICAL_SECTION CriticalSection, DWORD dwMilliseconds);
  __attribute__((dllimport)) WINBOOL SleepConditionVariableSRW (PCONDITION_VARIABLE ConditionVariable, PSRWLOCK SRWLock, DWORD dwMilliseconds, ULONG Flags);
  __attribute__((dllimport)) HANDLE CreateMutexExA (LPSECURITY_ATTRIBUTES lpMutexAttributes, LPCSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
  __attribute__((dllimport)) HANDLE CreateMutexExW (LPSECURITY_ATTRIBUTES lpMutexAttributes, LPCWSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
  __attribute__((dllimport)) HANDLE CreateEventExA (LPSECURITY_ATTRIBUTES lpEventAttributes, LPCSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
  __attribute__((dllimport)) HANDLE CreateEventExW (LPSECURITY_ATTRIBUTES lpEventAttributes, LPCWSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
  __attribute__((dllimport)) HANDLE CreateSemaphoreExW (LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, LONG lInitialCount, LONG lMaximumCount, LPCWSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
  typedef void ( *PTIMERAPCROUTINE) (LPVOID lpArgToCompletionRoutine, DWORD dwTimerLowValue, DWORD dwTimerHighValue);

  typedef RTL_BARRIER SYNCHRONIZATION_BARRIER;
  typedef PRTL_BARRIER PSYNCHRONIZATION_BARRIER;
  typedef PRTL_BARRIER LPSYNCHRONIZATION_BARRIER;





  __attribute__((dllimport)) void InitializeCriticalSection (LPCRITICAL_SECTION lpCriticalSection);
  __attribute__((dllimport)) WINBOOL InitializeCriticalSectionAndSpinCount (LPCRITICAL_SECTION lpCriticalSection, DWORD dwSpinCount);
  __attribute__((dllimport)) DWORD SetCriticalSectionSpinCount (LPCRITICAL_SECTION lpCriticalSection, DWORD dwSpinCount);
  __attribute__((dllimport)) DWORD WaitForSingleObject (HANDLE hHandle, DWORD dwMilliseconds);
  __attribute__((dllimport)) DWORD SleepEx (DWORD dwMilliseconds, WINBOOL bAlertable);
  __attribute__((dllimport)) HANDLE CreateMutexA (LPSECURITY_ATTRIBUTES lpMutexAttributes, WINBOOL bInitialOwner, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE CreateMutexW (LPSECURITY_ATTRIBUTES lpMutexAttributes, WINBOOL bInitialOwner, LPCWSTR lpName);
  __attribute__((dllimport)) HANDLE CreateEventA (LPSECURITY_ATTRIBUTES lpEventAttributes, WINBOOL bManualReset, WINBOOL bInitialState, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE CreateEventW (LPSECURITY_ATTRIBUTES lpEventAttributes, WINBOOL bManualReset, WINBOOL bInitialState, LPCWSTR lpName);
  __attribute__((dllimport)) WINBOOL SetWaitableTimer (HANDLE hTimer, const LARGE_INTEGER *lpDueTime, LONG lPeriod, PTIMERAPCROUTINE pfnCompletionRoutine, LPVOID lpArgToCompletionRoutine, WINBOOL fResume);
  __attribute__((dllimport)) WINBOOL CancelWaitableTimer (HANDLE hTimer);
  __attribute__((dllimport)) HANDLE OpenWaitableTimerW (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCWSTR lpTimerName);
  WINBOOL EnterSynchronizationBarrier (LPSYNCHRONIZATION_BARRIER lpBarrier, DWORD dwFlags);
  WINBOOL InitializeSynchronizationBarrier (LPSYNCHRONIZATION_BARRIER lpBarrier, LONG lTotalThreads, LONG lSpinCount);
  WINBOOL DeleteSynchronizationBarrier (LPSYNCHRONIZATION_BARRIER lpBarrier);
  __attribute__((dllimport)) void Sleep (DWORD dwMilliseconds);
  __attribute__((dllimport)) DWORD SignalObjectAndWait (HANDLE hObjectToSignal, HANDLE hObjectToWaitOn, DWORD dwMilliseconds, WINBOOL bAlertable);


  __attribute__((dllimport)) HANDLE CreateWaitableTimerExW (LPSECURITY_ATTRIBUTES lpTimerAttributes, LPCWSTR lpTimerName, DWORD dwFlags, DWORD dwDesiredAccess);
  typedef struct _SYSTEM_INFO {
    __extension__ union {
      DWORD dwOemId;
      __extension__ struct {
 WORD wProcessorArchitecture;
 WORD wReserved;
      } ;
    } ;
    DWORD dwPageSize;
    LPVOID lpMinimumApplicationAddress;
    LPVOID lpMaximumApplicationAddress;
    DWORD_PTR dwActiveProcessorMask;
    DWORD dwNumberOfProcessors;
    DWORD dwProcessorType;
    DWORD dwAllocationGranularity;
    WORD wProcessorLevel;
    WORD wProcessorRevision;
  } SYSTEM_INFO, *LPSYSTEM_INFO;

  __attribute__((dllimport)) void GetSystemTime (LPSYSTEMTIME lpSystemTime);
  __attribute__((dllimport)) void GetSystemTimeAsFileTime (LPFILETIME lpSystemTimeAsFileTime);
  __attribute__((dllimport)) void GetLocalTime (LPSYSTEMTIME lpSystemTime);
  __attribute__((dllimport)) void GetNativeSystemInfo (LPSYSTEM_INFO lpSystemInfo);

  __attribute__((dllimport)) ULONGLONG GetTickCount64 (void);





  typedef struct _MEMORYSTATUSEX {
    DWORD dwLength;
    DWORD dwMemoryLoad;
    DWORDLONG ullTotalPhys;
    DWORDLONG ullAvailPhys;
    DWORDLONG ullTotalPageFile;
    DWORDLONG ullAvailPageFile;
    DWORDLONG ullTotalVirtual;
    DWORDLONG ullAvailVirtual;
    DWORDLONG ullAvailExtendedVirtual;
  } MEMORYSTATUSEX,*LPMEMORYSTATUSEX;

  __attribute__((dllimport)) void GetSystemInfo (LPSYSTEM_INFO lpSystemInfo);
  __attribute__((dllimport)) WINBOOL GlobalMemoryStatusEx (LPMEMORYSTATUSEX lpBuffer);
  __attribute__((dllimport)) DWORD GetTickCount (void);
  __attribute__((dllimport)) void GetSystemTimePreciseAsFileTime (LPFILETIME lpSystemTimeAsFileTime);
  __attribute__((dllimport)) WINBOOL GetVersionExA (LPOSVERSIONINFOA lpVersionInformation);
  __attribute__((dllimport)) WINBOOL GetVersionExW (LPOSVERSIONINFOW lpVersionInformation);




  typedef enum _COMPUTER_NAME_FORMAT {
    ComputerNameNetBIOS,
    ComputerNameDnsHostname,
    ComputerNameDnsDomain,
    ComputerNameDnsFullyQualified,
    ComputerNamePhysicalNetBIOS,
    ComputerNamePhysicalDnsHostname,
    ComputerNamePhysicalDnsDomain,
    ComputerNamePhysicalDnsFullyQualified,
    ComputerNameMax
  } COMPUTER_NAME_FORMAT;

  __attribute__((dllimport)) DWORD GetVersion (void);

  __attribute__((dllimport)) WINBOOL SetLocalTime (const SYSTEMTIME *lpSystemTime);
  __attribute__((dllimport)) WINBOOL GetSystemTimeAdjustment (PDWORD lpTimeAdjustment, PDWORD lpTimeIncrement, PBOOL lpTimeAdjustmentDisabled);
  __attribute__((dllimport)) UINT GetSystemDirectoryA (LPSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) UINT GetSystemDirectoryW (LPWSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) UINT GetWindowsDirectoryA (LPSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) UINT GetWindowsDirectoryW (LPWSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) UINT GetSystemWindowsDirectoryA (LPSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) UINT GetSystemWindowsDirectoryW (LPWSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) WINBOOL GetComputerNameExA (COMPUTER_NAME_FORMAT NameType, LPSTR lpBuffer, LPDWORD nSize);
  __attribute__((dllimport)) WINBOOL GetComputerNameExW (COMPUTER_NAME_FORMAT NameType, LPWSTR lpBuffer, LPDWORD nSize);
  __attribute__((dllimport)) WINBOOL SetComputerNameExW (COMPUTER_NAME_FORMAT NameType, LPCWSTR lpBuffer);
  __attribute__((dllimport)) WINBOOL SetSystemTime (const SYSTEMTIME *lpSystemTime);
  __attribute__((dllimport)) WINBOOL GetLogicalProcessorInformation (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION Buffer, PDWORD ReturnedLength);
  __attribute__((dllimport)) ULONGLONG VerSetConditionMask (ULONGLONG ConditionMask, ULONG TypeMask, UCHAR Condition);
  __attribute__((dllimport)) UINT EnumSystemFirmwareTables (DWORD FirmwareTableProviderSignature, PVOID pFirmwareTableEnumBuffer, DWORD BufferSize);
  __attribute__((dllimport)) UINT GetSystemFirmwareTable (DWORD FirmwareTableProviderSignature, DWORD FirmwareTableID, PVOID pFirmwareTableBuffer, DWORD BufferSize);

  __attribute__((dllimport)) WINBOOL GetProductInfo (DWORD dwOSMajorVersion, DWORD dwOSMinorVersion, DWORD dwSpMajorVersion, DWORD dwSpMinorVersion, PDWORD pdwReturnedProductType);
  __attribute__((dllimport)) WINBOOL GetNumaHighestNodeNumber (PULONG HighestNodeNumber);
  typedef void ( *PTP_WIN32_IO_CALLBACK) (PTP_CALLBACK_INSTANCE Instance, PVOID Context, PVOID Overlapped, ULONG IoResult, ULONG_PTR NumberOfBytesTransferred, PTP_IO Io);


  __attribute__((dllimport)) PTP_POOL CreateThreadpool (PVOID reserved);
  __attribute__((dllimport)) void SetThreadpoolThreadMaximum (PTP_POOL ptpp, DWORD cthrdMost);
  __attribute__((dllimport)) WINBOOL SetThreadpoolThreadMinimum (PTP_POOL ptpp, DWORD cthrdMic);
  __attribute__((dllimport)) WINBOOL SetThreadpoolStackInformation (PTP_POOL ptpp, PTP_POOL_STACK_INFORMATION ptpsi);
  __attribute__((dllimport)) WINBOOL QueryThreadpoolStackInformation (PTP_POOL ptpp, PTP_POOL_STACK_INFORMATION ptpsi);
  __attribute__((dllimport)) void CloseThreadpool (PTP_POOL ptpp);
  __attribute__((dllimport)) PTP_CLEANUP_GROUP CreateThreadpoolCleanupGroup (void);
  __attribute__((dllimport)) void CloseThreadpoolCleanupGroupMembers (PTP_CLEANUP_GROUP ptpcg, WINBOOL fCancelPendingCallbacks, PVOID pvCleanupContext);
  __attribute__((dllimport)) void CloseThreadpoolCleanupGroup (PTP_CLEANUP_GROUP ptpcg);
  __attribute__((dllimport)) void SetEventWhenCallbackReturns (PTP_CALLBACK_INSTANCE pci, HANDLE evt);
  __attribute__((dllimport)) void ReleaseSemaphoreWhenCallbackReturns (PTP_CALLBACK_INSTANCE pci, HANDLE sem, DWORD crel);
  __attribute__((dllimport)) void ReleaseMutexWhenCallbackReturns (PTP_CALLBACK_INSTANCE pci, HANDLE mut);
  __attribute__((dllimport)) void LeaveCriticalSectionWhenCallbackReturns (PTP_CALLBACK_INSTANCE pci, PCRITICAL_SECTION pcs);
  __attribute__((dllimport)) void FreeLibraryWhenCallbackReturns (PTP_CALLBACK_INSTANCE pci, HMODULE mod);
  __attribute__((dllimport)) WINBOOL CallbackMayRunLong (PTP_CALLBACK_INSTANCE pci);
  __attribute__((dllimport)) void DisassociateCurrentThreadFromCallback (PTP_CALLBACK_INSTANCE pci);
  __attribute__((dllimport)) WINBOOL TrySubmitThreadpoolCallback (PTP_SIMPLE_CALLBACK pfns, PVOID pv, PTP_CALLBACK_ENVIRON pcbe);
  __attribute__((dllimport)) PTP_WORK CreateThreadpoolWork (PTP_WORK_CALLBACK pfnwk, PVOID pv, PTP_CALLBACK_ENVIRON pcbe);
  __attribute__((dllimport)) void SubmitThreadpoolWork (PTP_WORK pwk);
  __attribute__((dllimport)) void WaitForThreadpoolWorkCallbacks (PTP_WORK pwk, WINBOOL fCancelPendingCallbacks);
  __attribute__((dllimport)) void CloseThreadpoolWork (PTP_WORK pwk);
  __attribute__((dllimport)) PTP_TIMER CreateThreadpoolTimer (PTP_TIMER_CALLBACK pfnti, PVOID pv, PTP_CALLBACK_ENVIRON pcbe);
  __attribute__((dllimport)) void SetThreadpoolTimer (PTP_TIMER pti, PFILETIME pftDueTime, DWORD msPeriod, DWORD msWindowLength);
  __attribute__((dllimport)) WINBOOL IsThreadpoolTimerSet (PTP_TIMER pti);
  __attribute__((dllimport)) void WaitForThreadpoolTimerCallbacks (PTP_TIMER pti, WINBOOL fCancelPendingCallbacks);
  __attribute__((dllimport)) void CloseThreadpoolTimer (PTP_TIMER pti);
  __attribute__((dllimport)) PTP_WAIT CreateThreadpoolWait (PTP_WAIT_CALLBACK pfnwa, PVOID pv, PTP_CALLBACK_ENVIRON pcbe);
  __attribute__((dllimport)) void SetThreadpoolWait (PTP_WAIT pwa, HANDLE h, PFILETIME pftTimeout);
  __attribute__((dllimport)) void WaitForThreadpoolWaitCallbacks (PTP_WAIT pwa, WINBOOL fCancelPendingCallbacks);
  __attribute__((dllimport)) void CloseThreadpoolWait (PTP_WAIT pwa);
  __attribute__((dllimport)) PTP_IO CreateThreadpoolIo (HANDLE fl, PTP_WIN32_IO_CALLBACK pfnio, PVOID pv, PTP_CALLBACK_ENVIRON pcbe);
  __attribute__((dllimport)) void StartThreadpoolIo (PTP_IO pio);
  __attribute__((dllimport)) void CancelThreadpoolIo (PTP_IO pio);
  __attribute__((dllimport)) void WaitForThreadpoolIoCallbacks (PTP_IO pio, WINBOOL fCancelPendingCallbacks);
  __attribute__((dllimport)) void CloseThreadpoolIo (PTP_IO pio);
  __attribute__((dllimport)) WINBOOL SetThreadpoolTimerEx (PTP_TIMER pti, PFILETIME pftDueTime, DWORD msPeriod, DWORD msWindowLength);
  __attribute__((dllimport)) WINBOOL SetThreadpoolWaitEx (PTP_WAIT pwa, HANDLE h, PFILETIME pftTimeout, PVOID Reserved);
  __attribute__((dllimport)) WINBOOL CreateTimerQueueTimer (PHANDLE phNewTimer, HANDLE TimerQueue, WAITORTIMERCALLBACK Callback, PVOID Parameter, DWORD DueTime, DWORD Period, ULONG Flags);
  __attribute__((dllimport)) WINBOOL DeleteTimerQueueTimer (HANDLE TimerQueue, HANDLE Timer, HANDLE CompletionEvent);



  __attribute__((dllimport)) WINBOOL QueueUserWorkItem (LPTHREAD_START_ROUTINE Function, PVOID Context, ULONG Flags);
  __attribute__((dllimport)) WINBOOL UnregisterWaitEx (HANDLE WaitHandle, HANDLE CompletionEvent);
  __attribute__((dllimport)) HANDLE CreateTimerQueue (void);
  __attribute__((dllimport)) WINBOOL ChangeTimerQueueTimer (HANDLE TimerQueue, HANDLE Timer, ULONG DueTime, ULONG Period);
  __attribute__((dllimport)) WINBOOL DeleteTimerQueueEx (HANDLE TimerQueue, HANDLE CompletionEvent);
  __attribute__((dllimport)) PVOID EncodePointer (PVOID Ptr);
  __attribute__((dllimport)) PVOID DecodePointer (PVOID Ptr);



  __attribute__((dllimport)) PVOID EncodeSystemPointer (PVOID Ptr);
  __attribute__((dllimport)) PVOID DecodeSystemPointer (PVOID Ptr);
  __attribute__((dllimport)) WINBOOL Beep (DWORD dwFreq, DWORD dwDuration);
  __attribute__((dllimport)) WINBOOL Wow64DisableWow64FsRedirection (PVOID *OldValue);
  __attribute__((dllimport)) WINBOOL Wow64RevertWow64FsRedirection (PVOID OlValue);
  __attribute__((dllimport)) WINBOOL IsWow64Process (HANDLE hProcess, PBOOL Wow64Process);







  typedef void ( *PFIBER_START_ROUTINE) (LPVOID lpFiberParameter);
  typedef PFIBER_START_ROUTINE LPFIBER_START_ROUTINE;




  typedef LPVOID LPLDT_ENTRY;
  typedef struct _COMMPROP {
    WORD wPacketLength;
    WORD wPacketVersion;
    DWORD dwServiceMask;
    DWORD dwReserved1;
    DWORD dwMaxTxQueue;
    DWORD dwMaxRxQueue;
    DWORD dwMaxBaud;
    DWORD dwProvSubType;
    DWORD dwProvCapabilities;
    DWORD dwSettableParams;
    DWORD dwSettableBaud;
    WORD wSettableData;
    WORD wSettableStopParity;
    DWORD dwCurrentTxQueue;
    DWORD dwCurrentRxQueue;
    DWORD dwProvSpec1;
    DWORD dwProvSpec2;
    WCHAR wcProvChar[1];
  } COMMPROP,*LPCOMMPROP;



  typedef struct _COMSTAT {
    DWORD fCtsHold : 1;
    DWORD fDsrHold : 1;
    DWORD fRlsdHold : 1;
    DWORD fXoffHold : 1;
    DWORD fXoffSent : 1;
    DWORD fEof : 1;
    DWORD fTxim : 1;
    DWORD fReserved : 25;
    DWORD cbInQue;
    DWORD cbOutQue;
  } COMSTAT,*LPCOMSTAT;
  typedef struct _DCB {
    DWORD DCBlength;
    DWORD BaudRate;
    DWORD fBinary: 1;
    DWORD fParity: 1;
    DWORD fOutxCtsFlow:1;
    DWORD fOutxDsrFlow:1;
    DWORD fDtrControl:2;
    DWORD fDsrSensitivity:1;
    DWORD fTXContinueOnXoff: 1;
    DWORD fOutX: 1;
    DWORD fInX: 1;
    DWORD fErrorChar: 1;
    DWORD fNull: 1;
    DWORD fRtsControl:2;
    DWORD fAbortOnError:1;
    DWORD fDummy2:17;
    WORD wReserved;
    WORD XonLim;
    WORD XoffLim;
    BYTE ByteSize;
    BYTE Parity;
    BYTE StopBits;
    char XonChar;
    char XoffChar;
    char ErrorChar;
    char EofChar;
    char EvtChar;
    WORD wReserved1;
  } DCB,*LPDCB;

  typedef struct _COMMTIMEOUTS {
    DWORD ReadIntervalTimeout;
    DWORD ReadTotalTimeoutMultiplier;
    DWORD ReadTotalTimeoutConstant;
    DWORD WriteTotalTimeoutMultiplier;
    DWORD WriteTotalTimeoutConstant;
  } COMMTIMEOUTS,*LPCOMMTIMEOUTS;

  typedef struct _COMMCONFIG {
    DWORD dwSize;
    WORD wVersion;
    WORD wReserved;
    DCB dcb;
    DWORD dwProviderSubType;
    DWORD dwProviderOffset;
    DWORD dwProviderSize;
    WCHAR wcProviderData[1];
  } COMMCONFIG,*LPCOMMCONFIG;
  typedef struct _MEMORYSTATUS {
    DWORD dwLength;
    DWORD dwMemoryLoad;
    SIZE_T dwTotalPhys;
    SIZE_T dwAvailPhys;
    SIZE_T dwTotalPageFile;
    SIZE_T dwAvailPageFile;
    SIZE_T dwTotalVirtual;
    SIZE_T dwAvailVirtual;
  } MEMORYSTATUS,*LPMEMORYSTATUS;
  typedef struct _JIT_DEBUG_INFO {
    DWORD dwSize;
    DWORD dwProcessorArchitecture;
    DWORD dwThreadID;
    DWORD dwReserved0;
    ULONG64 lpExceptionAddress;
    ULONG64 lpExceptionRecord;
    ULONG64 lpContextRecord;
  } JIT_DEBUG_INFO,*LPJIT_DEBUG_INFO;

  typedef JIT_DEBUG_INFO JIT_DEBUG_INFO32, *LPJIT_DEBUG_INFO32;
  typedef JIT_DEBUG_INFO JIT_DEBUG_INFO64, *LPJIT_DEBUG_INFO64;


  typedef PEXCEPTION_RECORD LPEXCEPTION_RECORD;
  typedef PEXCEPTION_POINTERS LPEXCEPTION_POINTERS;
  typedef struct _OFSTRUCT {
    BYTE cBytes;
    BYTE fFixedDisk;
    WORD nErrCode;
    WORD Reserved1;
    WORD Reserved2;
    CHAR szPathName[128];
  } OFSTRUCT, *LPOFSTRUCT,*POFSTRUCT;
  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) LONGLONG _InterlockedAnd64 (LONGLONG volatile *Destination, LONGLONG Value) {
    LONGLONG Old;

    do {
      Old = *Destination;
    } while (_InterlockedCompareExchange64 (Destination, Old &Value, Old) != Old);
    return Old;
  }

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) LONGLONG _InterlockedOr64 (LONGLONG volatile *Destination, LONGLONG Value) {
    LONGLONG Old;

    do {
      Old = *Destination;
    } while (_InterlockedCompareExchange64 (Destination, Old | Value, Old) != Old);
    return Old;
  }

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) LONGLONG _InterlockedXor64 (LONGLONG volatile *Destination, LONGLONG Value) {
    LONGLONG Old;

    do {
      Old = *Destination;
    } while (_InterlockedCompareExchange64 (Destination, Old ^ Value, Old) != Old);
    return Old;
  }

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) LONGLONG _InterlockedIncrement64 (LONGLONG volatile *Addend) {
    LONGLONG Old;

    do {
      Old = *Addend;
    } while (_InterlockedCompareExchange64 (Addend, Old + 1, Old) != Old);
    return Old + 1;
  }

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) LONGLONG _InterlockedDecrement64 (LONGLONG volatile *Addend) {
    LONGLONG Old;

    do {
      Old = *Addend;
    } while (_InterlockedCompareExchange64 (Addend, Old - 1, Old) != Old);
    return Old - 1;
  }

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) LONGLONG _InterlockedExchange64 (LONGLONG volatile *Target, LONGLONG Value) {
    LONGLONG Old;

    do {
      Old = *Target;
    } while (_InterlockedCompareExchange64 (Target, Value, Old) != Old);
    return Old;
  }

  extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) LONGLONG _InterlockedExchangeAdd64 (LONGLONG volatile *Addend, LONGLONG Value) {
    LONGLONG Old;

    do {
      Old = *Addend;
    } while (_InterlockedCompareExchange64 (Addend, Old + Value, Old) != Old);
    return Old;
  }
  __attribute__((dllimport)) HLOCAL LocalAlloc (UINT uFlags, SIZE_T uBytes);
  __attribute__((dllimport)) HLOCAL LocalFree (HLOCAL hMem);


  int WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd);
  int wWinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nShowCmd);
  __attribute__((dllimport)) HGLOBAL GlobalAlloc (UINT uFlags, SIZE_T dwBytes);
  __attribute__((dllimport)) HGLOBAL GlobalReAlloc (HGLOBAL hMem, SIZE_T dwBytes, UINT uFlags);
  __attribute__((dllimport)) SIZE_T GlobalSize (HGLOBAL hMem);
  __attribute__((dllimport)) UINT GlobalFlags (HGLOBAL hMem);
  __attribute__((dllimport)) LPVOID GlobalLock (HGLOBAL hMem);
  __attribute__((dllimport)) HGLOBAL GlobalHandle (LPCVOID pMem);
  __attribute__((dllimport)) WINBOOL GlobalUnlock (HGLOBAL hMem);
  __attribute__((dllimport)) HGLOBAL GlobalFree (HGLOBAL hMem);
  __attribute__((dllimport)) SIZE_T GlobalCompact (DWORD dwMinFree);
  __attribute__((dllimport)) void GlobalFix (HGLOBAL hMem);
  __attribute__((dllimport)) void GlobalUnfix (HGLOBAL hMem);
  __attribute__((dllimport)) LPVOID GlobalWire (HGLOBAL hMem);
  __attribute__((dllimport)) WINBOOL GlobalUnWire (HGLOBAL hMem);
  __attribute__((dllimport)) void GlobalMemoryStatus (LPMEMORYSTATUS lpBuffer);
  __attribute__((dllimport)) HLOCAL LocalReAlloc (HLOCAL hMem, SIZE_T uBytes, UINT uFlags);
  __attribute__((dllimport)) LPVOID LocalLock (HLOCAL hMem);
  __attribute__((dllimport)) HLOCAL LocalHandle (LPCVOID pMem);
  __attribute__((dllimport)) WINBOOL LocalUnlock (HLOCAL hMem);
  __attribute__((dllimport)) SIZE_T LocalSize (HLOCAL hMem);
  __attribute__((dllimport)) UINT LocalFlags (HLOCAL hMem);
  __attribute__((dllimport)) SIZE_T LocalShrink (HLOCAL hMem, UINT cbNewSize);
  __attribute__((dllimport)) SIZE_T LocalCompact (UINT uMinFree);

  __attribute__((dllimport)) LPVOID VirtualAllocExNuma (HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD flAllocationType, DWORD flProtect, DWORD nndPreferred);
  __attribute__((dllimport)) WINBOOL GetBinaryTypeA (LPCSTR lpApplicationName, LPDWORD lpBinaryType);
  __attribute__((dllimport)) WINBOOL GetBinaryTypeW (LPCWSTR lpApplicationName, LPDWORD lpBinaryType);
  __attribute__((dllimport)) DWORD GetShortPathNameA (LPCSTR lpszLongPath, LPSTR lpszShortPath, DWORD cchBuffer);

  __attribute__((dllimport)) DWORD GetLongPathNameTransactedA (LPCSTR lpszShortPath, LPSTR lpszLongPath, DWORD cchBuffer, HANDLE hTransaction);
  __attribute__((dllimport)) DWORD GetLongPathNameTransactedW (LPCWSTR lpszShortPath, LPWSTR lpszLongPath, DWORD cchBuffer, HANDLE hTransaction);

  __attribute__((dllimport)) WINBOOL GetProcessAffinityMask (HANDLE hProcess, PDWORD_PTR lpProcessAffinityMask, PDWORD_PTR lpSystemAffinityMask);
  __attribute__((dllimport)) WINBOOL SetProcessAffinityMask (HANDLE hProcess, DWORD_PTR dwProcessAffinityMask);
  __attribute__((dllimport)) WINBOOL GetProcessIoCounters (HANDLE hProcess, PIO_COUNTERS lpIoCounters);
  __attribute__((dllimport)) WINBOOL GetProcessWorkingSetSize (HANDLE hProcess, PSIZE_T lpMinimumWorkingSetSize, PSIZE_T lpMaximumWorkingSetSize);
  __attribute__((dllimport)) WINBOOL SetProcessWorkingSetSize (HANDLE hProcess, SIZE_T dwMinimumWorkingSetSize, SIZE_T dwMaximumWorkingSetSize);
  __attribute__((dllimport)) void FatalExit (int ExitCode);
  __attribute__((dllimport)) WINBOOL SetEnvironmentStringsA (LPCH NewEnvironment);
  __attribute__((dllimport)) void RaiseFailFastException (PEXCEPTION_RECORD pExceptionRecord, PCONTEXT pContextRecord, DWORD dwFlags);
  __attribute__((dllimport)) DWORD SetThreadIdealProcessor (HANDLE hThread, DWORD dwIdealProcessor);






  __attribute__((dllimport)) LPVOID CreateFiber (SIZE_T dwStackSize, LPFIBER_START_ROUTINE lpStartAddress, LPVOID lpParameter);
  __attribute__((dllimport)) LPVOID CreateFiberEx (SIZE_T dwStackCommitSize, SIZE_T dwStackReserveSize, DWORD dwFlags, LPFIBER_START_ROUTINE lpStartAddress, LPVOID lpParameter);
  __attribute__((dllimport)) void DeleteFiber (LPVOID lpFiber);
  __attribute__((dllimport)) LPVOID ConvertThreadToFiber (LPVOID lpParameter);
  __attribute__((dllimport)) LPVOID ConvertThreadToFiberEx (LPVOID lpParameter, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL ConvertFiberToThread (void);
  __attribute__((dllimport)) void SwitchToFiber (LPVOID lpFiber);
  __attribute__((dllimport)) DWORD_PTR SetThreadAffinityMask (HANDLE hThread, DWORD_PTR dwThreadAffinityMask);



  typedef enum _THREAD_INFORMATION_CLASS {
    ThreadMemoryPriority,
    ThreadAbsoluteCpuPriority,
    ThreadInformationClassMax
  } THREAD_INFORMATION_CLASS;

  typedef enum _PROCESS_INFORMATION_CLASS {
    ProcessMemoryPriority,
    ProcessInformationClassMax
  } PROCESS_INFORMATION_CLASS;
  __attribute__((dllimport)) WINBOOL SetProcessDEPPolicy (DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL GetProcessDEPPolicy (HANDLE hProcess, LPDWORD lpFlags, PBOOL lpPermanent);


  __attribute__((dllimport)) WINBOOL SetProcessPriorityBoost (HANDLE hProcess, WINBOOL bDisablePriorityBoost);
  __attribute__((dllimport)) WINBOOL GetProcessPriorityBoost (HANDLE hProcess, PBOOL pDisablePriorityBoost);
  __attribute__((dllimport)) WINBOOL RequestWakeupLatency (LATENCY_TIME latency);
  __attribute__((dllimport)) WINBOOL IsSystemResumeAutomatic (void);
  __attribute__((dllimport)) WINBOOL GetThreadIOPendingFlag (HANDLE hThread, PBOOL lpIOIsPending);
  __attribute__((dllimport)) WINBOOL GetThreadSelectorEntry (HANDLE hThread, DWORD dwSelector, LPLDT_ENTRY lpSelectorEntry);
  __attribute__((dllimport)) EXECUTION_STATE SetThreadExecutionState (EXECUTION_STATE esFlags);
  __attribute__((dllimport)) WINBOOL SetFileCompletionNotificationModes (HANDLE FileHandle, UCHAR Flags);
  __attribute__((dllimport)) WINBOOL SetFileIoOverlappedRange (HANDLE FileHandle, PUCHAR OverlappedRangeStart, ULONG Length);







  __attribute__((dllimport)) DWORD GetThreadErrorMode (void);
  __attribute__((dllimport)) WINBOOL SetThreadErrorMode (DWORD dwNewMode, LPDWORD lpOldMode);


  __attribute__((dllimport)) WINBOOL Wow64GetThreadContext (HANDLE hThread, PWOW64_CONTEXT lpContext);
  __attribute__((dllimport)) WINBOOL Wow64SetThreadContext (HANDLE hThread, const WOW64_CONTEXT *lpContext);






  __attribute__((dllimport)) DWORD Wow64SuspendThread (HANDLE hThread);

  __attribute__((dllimport)) WINBOOL DebugSetProcessKillOnExit (WINBOOL KillOnExit);
  __attribute__((dllimport)) WINBOOL DebugBreakProcess (HANDLE Process);







  __attribute__((dllimport)) DWORD WaitForMultipleObjects (DWORD nCount, const HANDLE *lpHandles, WINBOOL bWaitAll, DWORD dwMilliseconds);



  typedef enum _DEP_SYSTEM_POLICY_TYPE {
    DEPPolicyAlwaysOff = 0,
    DEPPolicyAlwaysOn,
    DEPPolicyOptIn,
    DEPPolicyOptOut,
    DEPTotalPolicyCount
  } DEP_SYSTEM_POLICY_TYPE;
  __attribute__((dllimport)) WINBOOL PulseEvent (HANDLE hEvent);
  __attribute__((dllimport)) ATOM GlobalDeleteAtom (ATOM nAtom);
  __attribute__((dllimport)) WINBOOL InitAtomTable (DWORD nSize);
  __attribute__((dllimport)) ATOM DeleteAtom (ATOM nAtom);
  __attribute__((dllimport)) UINT SetHandleCount (UINT uNumber);
  __attribute__((dllimport)) WINBOOL RequestDeviceWakeup (HANDLE hDevice);
  __attribute__((dllimport)) WINBOOL CancelDeviceWakeupRequest (HANDLE hDevice);
  __attribute__((dllimport)) WINBOOL GetDevicePowerState (HANDLE hDevice, WINBOOL *pfOn);
  __attribute__((dllimport)) WINBOOL SetMessageWaitingIndicator (HANDLE hMsgIndicator, ULONG ulMsgCount);
  __attribute__((dllimport)) WINBOOL SetFileShortNameA (HANDLE hFile, LPCSTR lpShortName);
  __attribute__((dllimport)) WINBOOL SetFileShortNameW (HANDLE hFile, LPCWSTR lpShortName);
  __attribute__((dllimport)) DWORD LoadModule (LPCSTR lpModuleName, LPVOID lpParameterBlock);
  __attribute__((dllimport)) UINT WinExec (LPCSTR lpCmdLine, UINT uCmdShow);
  __attribute__((dllimport)) WINBOOL ClearCommBreak (HANDLE hFile);
  __attribute__((dllimport)) WINBOOL ClearCommError (HANDLE hFile, LPDWORD lpErrors, LPCOMSTAT lpStat);
  __attribute__((dllimport)) WINBOOL SetupComm (HANDLE hFile, DWORD dwInQueue, DWORD dwOutQueue);
  __attribute__((dllimport)) WINBOOL EscapeCommFunction (HANDLE hFile, DWORD dwFunc);
  __attribute__((dllimport)) WINBOOL GetCommConfig (HANDLE hCommDev, LPCOMMCONFIG lpCC, LPDWORD lpdwSize);
  __attribute__((dllimport)) WINBOOL GetCommMask (HANDLE hFile, LPDWORD lpEvtMask);
  __attribute__((dllimport)) WINBOOL GetCommProperties (HANDLE hFile, LPCOMMPROP lpCommProp);
  __attribute__((dllimport)) WINBOOL GetCommModemStatus (HANDLE hFile, LPDWORD lpModemStat);
  __attribute__((dllimport)) WINBOOL GetCommState (HANDLE hFile, LPDCB lpDCB);
  __attribute__((dllimport)) WINBOOL GetCommTimeouts (HANDLE hFile, LPCOMMTIMEOUTS lpCommTimeouts);
  __attribute__((dllimport)) WINBOOL PurgeComm (HANDLE hFile, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL SetCommBreak (HANDLE hFile);
  __attribute__((dllimport)) WINBOOL SetCommConfig (HANDLE hCommDev, LPCOMMCONFIG lpCC, DWORD dwSize);
  __attribute__((dllimport)) WINBOOL SetCommMask (HANDLE hFile, DWORD dwEvtMask);
  __attribute__((dllimport)) WINBOOL SetCommState (HANDLE hFile, LPDCB lpDCB);
  __attribute__((dllimport)) WINBOOL SetCommTimeouts (HANDLE hFile, LPCOMMTIMEOUTS lpCommTimeouts);
  __attribute__((dllimport)) WINBOOL TransmitCommChar (HANDLE hFile, char cChar);
  __attribute__((dllimport)) WINBOOL WaitCommEvent (HANDLE hFile, LPDWORD lpEvtMask, LPOVERLAPPED lpOverlapped);
  __attribute__((dllimport)) DWORD SetTapePosition (HANDLE hDevice, DWORD dwPositionMethod, DWORD dwPartition, DWORD dwOffsetLow, DWORD dwOffsetHigh, WINBOOL bImmediate);
  __attribute__((dllimport)) DWORD GetTapePosition (HANDLE hDevice, DWORD dwPositionType, LPDWORD lpdwPartition, LPDWORD lpdwOffsetLow, LPDWORD lpdwOffsetHigh);
  __attribute__((dllimport)) DWORD PrepareTape (HANDLE hDevice, DWORD dwOperation, WINBOOL bImmediate);
  __attribute__((dllimport)) DWORD EraseTape (HANDLE hDevice, DWORD dwEraseType, WINBOOL bImmediate);
  __attribute__((dllimport)) DWORD CreateTapePartition (HANDLE hDevice, DWORD dwPartitionMethod, DWORD dwCount, DWORD dwSize);
  __attribute__((dllimport)) DWORD WriteTapemark (HANDLE hDevice, DWORD dwTapemarkType, DWORD dwTapemarkCount, WINBOOL bImmediate);
  __attribute__((dllimport)) DWORD GetTapeStatus (HANDLE hDevice);
  __attribute__((dllimport)) DWORD GetTapeParameters (HANDLE hDevice, DWORD dwOperation, LPDWORD lpdwSize, LPVOID lpTapeInformation);
  __attribute__((dllimport)) DWORD SetTapeParameters (HANDLE hDevice, DWORD dwOperation, LPVOID lpTapeInformation);
  __attribute__((dllimport)) DEP_SYSTEM_POLICY_TYPE GetSystemDEPPolicy (void);
  __attribute__((dllimport)) WINBOOL GetSystemRegistryQuota (PDWORD pdwQuotaAllowed, PDWORD pdwQuotaUsed);
  WINBOOL GetSystemTimes (LPFILETIME lpIdleTime, LPFILETIME lpKernelTime, LPFILETIME lpUserTime);
  __attribute__((dllimport)) WINBOOL FileTimeToDosDateTime (const FILETIME *lpFileTime, LPWORD lpFatDate, LPWORD lpFatTime);
  __attribute__((dllimport)) WINBOOL DosDateTimeToFileTime (WORD wFatDate, WORD wFatTime, LPFILETIME lpFileTime);
  __attribute__((dllimport)) WINBOOL SetSystemTimeAdjustment (DWORD dwTimeAdjustment, WINBOOL bTimeAdjustmentDisabled);






  __attribute__((dllimport)) int MulDiv (int nNumber, int nNumerator, int nDenominator);


  __attribute__((dllimport)) DWORD FormatMessageA (DWORD dwFlags, LPCVOID lpSource, DWORD dwMessageId, DWORD dwLanguageId, LPSTR lpBuffer, DWORD nSize, va_list *Arguments);
  __attribute__((dllimport)) DWORD FormatMessageW (DWORD dwFlags, LPCVOID lpSource, DWORD dwMessageId, DWORD dwLanguageId, LPWSTR lpBuffer, DWORD nSize, va_list *Arguments);
  typedef DWORD ( *PFE_EXPORT_FUNC) (PBYTE pbData, PVOID pvCallbackContext, ULONG ulLength);
  typedef DWORD ( *PFE_IMPORT_FUNC) (PBYTE pbData, PVOID pvCallbackContext, PULONG ulLength);
  __attribute__((dllimport)) WINBOOL GetNamedPipeInfo (HANDLE hNamedPipe, LPDWORD lpFlags, LPDWORD lpOutBufferSize, LPDWORD lpInBufferSize, LPDWORD lpMaxInstances);
  __attribute__((dllimport)) HANDLE CreateMailslotA (LPCSTR lpName, DWORD nMaxMessageSize, DWORD lReadTimeout, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) HANDLE CreateMailslotW (LPCWSTR lpName, DWORD nMaxMessageSize, DWORD lReadTimeout, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) WINBOOL GetMailslotInfo (HANDLE hMailslot, LPDWORD lpMaxMessageSize, LPDWORD lpNextSize, LPDWORD lpMessageCount, LPDWORD lpReadTimeout);
  __attribute__((dllimport)) WINBOOL SetMailslotInfo (HANDLE hMailslot, DWORD lReadTimeout);
  __attribute__((dllimport)) WINBOOL EncryptFileA (LPCSTR lpFileName);
  __attribute__((dllimport)) WINBOOL EncryptFileW (LPCWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL DecryptFileA (LPCSTR lpFileName, DWORD dwReserved);
  __attribute__((dllimport)) WINBOOL DecryptFileW (LPCWSTR lpFileName, DWORD dwReserved);
  __attribute__((dllimport)) WINBOOL FileEncryptionStatusA (LPCSTR lpFileName, LPDWORD lpStatus);
  __attribute__((dllimport)) WINBOOL FileEncryptionStatusW (LPCWSTR lpFileName, LPDWORD lpStatus);
  __attribute__((dllimport)) DWORD OpenEncryptedFileRawA (LPCSTR lpFileName, ULONG ulFlags, PVOID *pvContext);
  __attribute__((dllimport)) DWORD OpenEncryptedFileRawW (LPCWSTR lpFileName, ULONG ulFlags, PVOID *pvContext);
  __attribute__((dllimport)) DWORD ReadEncryptedFileRaw (PFE_EXPORT_FUNC pfExportCallback, PVOID pvCallbackContext, PVOID pvContext);
  __attribute__((dllimport)) DWORD WriteEncryptedFileRaw (PFE_IMPORT_FUNC pfImportCallback, PVOID pvCallbackContext, PVOID pvContext);
  __attribute__((dllimport)) void CloseEncryptedFileRaw (PVOID pvContext);
  __attribute__((dllimport)) int lstrcmpA (LPCSTR lpString1, LPCSTR lpString2);
  __attribute__((dllimport)) int lstrcmpW (LPCWSTR lpString1, LPCWSTR lpString2);
  __attribute__((dllimport)) int lstrcmpiA (LPCSTR lpString1, LPCSTR lpString2);
  __attribute__((dllimport)) int lstrcmpiW (LPCWSTR lpString1, LPCWSTR lpString2);
  __attribute__((dllimport)) LPSTR lstrcpynA (LPSTR lpString1, LPCSTR lpString2, int iMaxLength);
  __attribute__((dllimport)) LPWSTR lstrcpynW (LPWSTR lpString1, LPCWSTR lpString2, int iMaxLength);
  __attribute__((dllimport)) LPSTR lstrcpyA (LPSTR lpString1, LPCSTR lpString2);
  __attribute__((dllimport)) LPWSTR lstrcpyW (LPWSTR lpString1, LPCWSTR lpString2);
  __attribute__((dllimport)) LPSTR lstrcatA (LPSTR lpString1, LPCSTR lpString2);
  __attribute__((dllimport)) LPWSTR lstrcatW (LPWSTR lpString1, LPCWSTR lpString2);
  __attribute__((dllimport)) int lstrlenA (LPCSTR lpString);
  __attribute__((dllimport)) int lstrlenW (LPCWSTR lpString);
  __attribute__((dllimport)) HFILE OpenFile (LPCSTR lpFileName, LPOFSTRUCT lpReOpenBuff, UINT uStyle);
  __attribute__((dllimport)) HFILE _lopen (LPCSTR lpPathName, int iReadWrite);
  __attribute__((dllimport)) HFILE _lcreat (LPCSTR lpPathName, int iAttribute);
  __attribute__((dllimport)) UINT _lread (HFILE hFile, LPVOID lpBuffer, UINT uBytes);
  __attribute__((dllimport)) UINT _lwrite (HFILE hFile, LPCCH lpBuffer, UINT uBytes);
  __attribute__((dllimport)) long _hread (HFILE hFile, LPVOID lpBuffer, long lBytes);
  __attribute__((dllimport)) long _hwrite (HFILE hFile, LPCCH lpBuffer, long lBytes);
  __attribute__((dllimport)) HFILE _lclose (HFILE hFile);
  __attribute__((dllimport)) LONG _llseek (HFILE hFile, LONG lOffset, int iOrigin);
  __attribute__((dllimport)) WINBOOL IsTextUnicode (const void *lpv, int iSize, LPINT lpiResult);
  __attribute__((dllimport)) DWORD SignalObjectAndWait (HANDLE hObjectToSignal, HANDLE hObjectToWaitOn, DWORD dwMilliseconds, WINBOOL bAlertable);
  __attribute__((dllimport)) WINBOOL BackupRead (HANDLE hFile, LPBYTE lpBuffer, DWORD nNumberOfBytesToRead, LPDWORD lpNumberOfBytesRead, WINBOOL bAbort, WINBOOL bProcessSecurity, LPVOID *lpContext);
  __attribute__((dllimport)) WINBOOL BackupSeek (HANDLE hFile, DWORD dwLowBytesToSeek, DWORD dwHighBytesToSeek, LPDWORD lpdwLowByteSeeked, LPDWORD lpdwHighByteSeeked, LPVOID *lpContext);
  __attribute__((dllimport)) WINBOOL BackupWrite (HANDLE hFile, LPBYTE lpBuffer, DWORD nNumberOfBytesToWrite, LPDWORD lpNumberOfBytesWritten, WINBOOL bAbort, WINBOOL bProcessSecurity, LPVOID *lpContext);
  typedef struct _WIN32_STREAM_ID {
    DWORD dwStreamId;
    DWORD dwStreamAttributes;
    LARGE_INTEGER Size;
    DWORD dwStreamNameSize;
    WCHAR cStreamName[1];
  } WIN32_STREAM_ID,*LPWIN32_STREAM_ID;
  typedef struct _STARTUPINFOEXA {
    STARTUPINFOA StartupInfo;
    LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList;
  } STARTUPINFOEXA,*LPSTARTUPINFOEXA;

  typedef struct _STARTUPINFOEXW {
    STARTUPINFOW StartupInfo;
    LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList;
  } STARTUPINFOEXW,*LPSTARTUPINFOEXW;

  typedef STARTUPINFOEXA STARTUPINFOEX;
  typedef LPSTARTUPINFOEXA LPSTARTUPINFOEX;







  __attribute__((dllimport)) HANDLE CreateSemaphoreW (LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, LONG lInitialCount, LONG lMaximumCount, LPCWSTR lpName);

  __attribute__((dllimport)) HMODULE LoadLibraryW (LPCWSTR lpLibFileName);


  __attribute__((dllimport)) HANDLE OpenMutexA (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE CreateSemaphoreA (LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, LONG lInitialCount, LONG lMaximumCount, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE OpenSemaphoreA (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE CreateWaitableTimerA (LPSECURITY_ATTRIBUTES lpTimerAttributes, WINBOOL bManualReset, LPCSTR lpTimerName);
  __attribute__((dllimport)) HANDLE CreateWaitableTimerW (LPSECURITY_ATTRIBUTES lpTimerAttributes, WINBOOL bManualReset, LPCWSTR lpTimerName);
  __attribute__((dllimport)) HANDLE OpenWaitableTimerA (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCSTR lpTimerName);
  __attribute__((dllimport)) HANDLE CreateFileMappingA (HANDLE hFile, LPSECURITY_ATTRIBUTES lpFileMappingAttributes, DWORD flProtect, DWORD dwMaximumSizeHigh, DWORD dwMaximumSizeLow, LPCSTR lpName);

  __attribute__((dllimport)) HANDLE CreateSemaphoreExA (LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, LONG lInitialCount, LONG lMaximumCount, LPCSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
  __attribute__((dllimport)) HANDLE CreateWaitableTimerExA (LPSECURITY_ATTRIBUTES lpTimerAttributes, LPCSTR lpTimerName, DWORD dwFlags, DWORD dwDesiredAccess);
  __attribute__((dllimport)) HANDLE CreateFileMappingNumaA (HANDLE hFile, LPSECURITY_ATTRIBUTES lpFileMappingAttributes, DWORD flProtect, DWORD dwMaximumSizeHigh, DWORD dwMaximumSizeLow, LPCSTR lpName, DWORD nndPreferred);

  __attribute__((dllimport)) HANDLE OpenFileMappingA (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCSTR lpName);
  __attribute__((dllimport)) DWORD GetLogicalDriveStringsA (DWORD nBufferLength, LPSTR lpBuffer);
  __attribute__((dllimport)) HMODULE LoadLibraryA (LPCSTR lpLibFileName);
  __attribute__((dllimport)) WINBOOL QueryFullProcessImageNameA (HANDLE hProcess, DWORD dwFlags, LPSTR lpExeName, PDWORD lpdwSize);
  __attribute__((dllimport)) WINBOOL QueryFullProcessImageNameW (HANDLE hProcess, DWORD dwFlags, LPWSTR lpExeName, PDWORD lpdwSize);
  typedef enum _PROC_THREAD_ATTRIBUTE_NUM {
    ProcThreadAttributeParentProcess = 0,
    ProcThreadAttributeHandleList = 2
  } PROC_THREAD_ATTRIBUTE_NUM;
  __attribute__((dllimport)) WINBOOL GetProcessShutdownParameters (LPDWORD lpdwLevel, LPDWORD lpdwFlags);
  __attribute__((dllimport)) void FatalAppExitA (UINT uAction, LPCSTR lpMessageText);
  __attribute__((dllimport)) void FatalAppExitW (UINT uAction, LPCWSTR lpMessageText);
  __attribute__((dllimport)) void GetStartupInfoA (LPSTARTUPINFOA lpStartupInfo);
  __attribute__((dllimport)) DWORD GetFirmwareEnvironmentVariableA (LPCSTR lpName, LPCSTR lpGuid, PVOID pBuffer, DWORD nSize);
  __attribute__((dllimport)) DWORD GetFirmwareEnvironmentVariableW (LPCWSTR lpName, LPCWSTR lpGuid, PVOID pBuffer, DWORD nSize);
  __attribute__((dllimport)) WINBOOL SetFirmwareEnvironmentVariableA (LPCSTR lpName, LPCSTR lpGuid, PVOID pValue, DWORD nSize);
  __attribute__((dllimport)) WINBOOL SetFirmwareEnvironmentVariableW (LPCWSTR lpName, LPCWSTR lpGuid, PVOID pValue, DWORD nSize);
  __attribute__((dllimport)) HRSRC FindResourceA (HMODULE hModule, LPCSTR lpName, LPCSTR lpType);
  __attribute__((dllimport)) HRSRC FindResourceW (HMODULE hModule, LPCWSTR lpName, LPCWSTR lpType);
  __attribute__((dllimport)) HRSRC FindResourceExA (HMODULE hModule, LPCSTR lpType, LPCSTR lpName, WORD wLanguage);
  __attribute__((dllimport)) WINBOOL EnumResourceTypesA (HMODULE hModule, ENUMRESTYPEPROCA lpEnumFunc, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumResourceTypesW (HMODULE hModule, ENUMRESTYPEPROCW lpEnumFunc, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumResourceNamesA (HMODULE hModule, LPCSTR lpType, ENUMRESNAMEPROCA lpEnumFunc, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumResourceNamesW (HMODULE hModule, LPCWSTR lpType, ENUMRESNAMEPROCW lpEnumFunc, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumResourceLanguagesA (HMODULE hModule, LPCSTR lpType, LPCSTR lpName, ENUMRESLANGPROCA lpEnumFunc, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumResourceLanguagesW (HMODULE hModule, LPCWSTR lpType, LPCWSTR lpName, ENUMRESLANGPROCW lpEnumFunc, LONG_PTR lParam);
  __attribute__((dllimport)) HANDLE BeginUpdateResourceA (LPCSTR pFileName, WINBOOL bDeleteExistingResources);
  __attribute__((dllimport)) HANDLE BeginUpdateResourceW (LPCWSTR pFileName, WINBOOL bDeleteExistingResources);
  __attribute__((dllimport)) WINBOOL UpdateResourceA (HANDLE hUpdate, LPCSTR lpType, LPCSTR lpName, WORD wLanguage, LPVOID lpData, DWORD cb);
  __attribute__((dllimport)) WINBOOL UpdateResourceW (HANDLE hUpdate, LPCWSTR lpType, LPCWSTR lpName, WORD wLanguage, LPVOID lpData, DWORD cb);
  __attribute__((dllimport)) WINBOOL EndUpdateResourceA (HANDLE hUpdate, WINBOOL fDiscard);
  __attribute__((dllimport)) WINBOOL EndUpdateResourceW (HANDLE hUpdate, WINBOOL fDiscard);
  __attribute__((dllimport)) ATOM GlobalAddAtomA (LPCSTR lpString);
  __attribute__((dllimport)) ATOM GlobalAddAtomW (LPCWSTR lpString);
  __attribute__((dllimport)) ATOM GlobalAddAtomExA (LPCSTR lpString, DWORD Flags);
  __attribute__((dllimport)) ATOM GlobalAddAtomExW (LPCWSTR lpString, DWORD Flags);
  __attribute__((dllimport)) ATOM GlobalFindAtomA (LPCSTR lpString);
  __attribute__((dllimport)) ATOM GlobalFindAtomW (LPCWSTR lpString);
  __attribute__((dllimport)) UINT GlobalGetAtomNameA (ATOM nAtom, LPSTR lpBuffer, int nSize);
  __attribute__((dllimport)) UINT GlobalGetAtomNameW (ATOM nAtom, LPWSTR lpBuffer, int nSize);
  __attribute__((dllimport)) ATOM AddAtomA (LPCSTR lpString);
  __attribute__((dllimport)) ATOM AddAtomW (LPCWSTR lpString);
  __attribute__((dllimport)) ATOM FindAtomA (LPCSTR lpString);
  __attribute__((dllimport)) ATOM FindAtomW (LPCWSTR lpString);
  __attribute__((dllimport)) UINT GetAtomNameA (ATOM nAtom, LPSTR lpBuffer, int nSize);
  __attribute__((dllimport)) UINT GetAtomNameW (ATOM nAtom, LPWSTR lpBuffer, int nSize);
  __attribute__((dllimport)) UINT GetProfileIntA (LPCSTR lpAppName, LPCSTR lpKeyName, INT nDefault);
  __attribute__((dllimport)) UINT GetProfileIntW (LPCWSTR lpAppName, LPCWSTR lpKeyName, INT nDefault);
  __attribute__((dllimport)) DWORD GetProfileStringA (LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpDefault, LPSTR lpReturnedString, DWORD nSize);
  __attribute__((dllimport)) DWORD GetProfileStringW (LPCWSTR lpAppName, LPCWSTR lpKeyName, LPCWSTR lpDefault, LPWSTR lpReturnedString, DWORD nSize);
  __attribute__((dllimport)) WINBOOL WriteProfileStringA (LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpString);
  __attribute__((dllimport)) WINBOOL WriteProfileStringW (LPCWSTR lpAppName, LPCWSTR lpKeyName, LPCWSTR lpString);
  __attribute__((dllimport)) DWORD GetProfileSectionA (LPCSTR lpAppName, LPSTR lpReturnedString, DWORD nSize);
  __attribute__((dllimport)) DWORD GetProfileSectionW (LPCWSTR lpAppName, LPWSTR lpReturnedString, DWORD nSize);
  __attribute__((dllimport)) WINBOOL WriteProfileSectionA (LPCSTR lpAppName, LPCSTR lpString);
  __attribute__((dllimport)) WINBOOL WriteProfileSectionW (LPCWSTR lpAppName, LPCWSTR lpString);
  __attribute__((dllimport)) UINT GetPrivateProfileIntA (LPCSTR lpAppName, LPCSTR lpKeyName, INT nDefault, LPCSTR lpFileName);
  __attribute__((dllimport)) UINT GetPrivateProfileIntW (LPCWSTR lpAppName, LPCWSTR lpKeyName, INT nDefault, LPCWSTR lpFileName);
  __attribute__((dllimport)) DWORD GetPrivateProfileStringA (LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpDefault, LPSTR lpReturnedString, DWORD nSize, LPCSTR lpFileName);
  __attribute__((dllimport)) DWORD GetPrivateProfileStringW (LPCWSTR lpAppName, LPCWSTR lpKeyName, LPCWSTR lpDefault, LPWSTR lpReturnedString, DWORD nSize, LPCWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL WritePrivateProfileStringA (LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpString, LPCSTR lpFileName);
  __attribute__((dllimport)) WINBOOL WritePrivateProfileStringW (LPCWSTR lpAppName, LPCWSTR lpKeyName, LPCWSTR lpString, LPCWSTR lpFileName);
  __attribute__((dllimport)) DWORD GetPrivateProfileSectionA (LPCSTR lpAppName, LPSTR lpReturnedString, DWORD nSize, LPCSTR lpFileName);
  __attribute__((dllimport)) DWORD GetPrivateProfileSectionW (LPCWSTR lpAppName, LPWSTR lpReturnedString, DWORD nSize, LPCWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL WritePrivateProfileSectionA (LPCSTR lpAppName, LPCSTR lpString, LPCSTR lpFileName);
  __attribute__((dllimport)) WINBOOL WritePrivateProfileSectionW (LPCWSTR lpAppName, LPCWSTR lpString, LPCWSTR lpFileName);
  __attribute__((dllimport)) DWORD GetPrivateProfileSectionNamesA (LPSTR lpszReturnBuffer, DWORD nSize, LPCSTR lpFileName);
  __attribute__((dllimport)) DWORD GetPrivateProfileSectionNamesW (LPWSTR lpszReturnBuffer, DWORD nSize, LPCWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL GetPrivateProfileStructA (LPCSTR lpszSection, LPCSTR lpszKey, LPVOID lpStruct, UINT uSizeStruct, LPCSTR szFile);
  __attribute__((dllimport)) WINBOOL GetPrivateProfileStructW (LPCWSTR lpszSection, LPCWSTR lpszKey, LPVOID lpStruct, UINT uSizeStruct, LPCWSTR szFile);
  __attribute__((dllimport)) WINBOOL WritePrivateProfileStructA (LPCSTR lpszSection, LPCSTR lpszKey, LPVOID lpStruct, UINT uSizeStruct, LPCSTR szFile);
  __attribute__((dllimport)) WINBOOL WritePrivateProfileStructW (LPCWSTR lpszSection, LPCWSTR lpszKey, LPVOID lpStruct, UINT uSizeStruct, LPCWSTR szFile);
  __attribute__((dllimport)) DWORD GetTempPathA (DWORD nBufferLength, LPSTR lpBuffer);
  __attribute__((dllimport)) UINT GetTempFileNameA (LPCSTR lpPathName, LPCSTR lpPrefixString, UINT uUnique, LPSTR lpTempFileName);
  __attribute__((dllimport)) UINT GetSystemWow64DirectoryA (LPSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) UINT GetSystemWow64DirectoryW (LPWSTR lpBuffer, UINT uSize);



  __attribute__((dllimport)) BOOLEAN Wow64EnableWow64FsRedirection (BOOLEAN Wow64FsEnableRedirection);

  typedef UINT ( *PGET_SYSTEM_WOW64_DIRECTORY_A) (LPSTR lpBuffer, UINT uSize);
  typedef UINT ( *PGET_SYSTEM_WOW64_DIRECTORY_W) (LPWSTR lpBuffer, UINT uSize);
  __attribute__((dllimport)) WINBOOL SetDllDirectoryA (LPCSTR lpPathName);
  __attribute__((dllimport)) WINBOOL SetDllDirectoryW (LPCWSTR lpPathName);
  __attribute__((dllimport)) DWORD GetDllDirectoryA (DWORD nBufferLength, LPSTR lpBuffer);
  __attribute__((dllimport)) DWORD GetDllDirectoryW (DWORD nBufferLength, LPWSTR lpBuffer);
  __attribute__((dllimport)) WINBOOL SetSearchPathMode (DWORD Flags);



  __attribute__((dllimport)) WINBOOL CreateDirectoryExA (LPCSTR lpTemplateDirectory, LPCSTR lpNewDirectory, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) WINBOOL CreateDirectoryExW (LPCWSTR lpTemplateDirectory, LPCWSTR lpNewDirectory, LPSECURITY_ATTRIBUTES lpSecurityAttributes);




  __attribute__((dllimport)) WINBOOL CreateDirectoryTransactedA (LPCSTR lpTemplateDirectory, LPCSTR lpNewDirectory, LPSECURITY_ATTRIBUTES lpSecurityAttributes, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL CreateDirectoryTransactedW (LPCWSTR lpTemplateDirectory, LPCWSTR lpNewDirectory, LPSECURITY_ATTRIBUTES lpSecurityAttributes, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL RemoveDirectoryTransactedA (LPCSTR lpPathName, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL RemoveDirectoryTransactedW (LPCWSTR lpPathName, HANDLE hTransaction);
  __attribute__((dllimport)) DWORD GetFullPathNameTransactedA (LPCSTR lpFileName, DWORD nBufferLength, LPSTR lpBuffer, LPSTR *lpFilePart, HANDLE hTransaction);
  __attribute__((dllimport)) DWORD GetFullPathNameTransactedW (LPCWSTR lpFileName, DWORD nBufferLength, LPWSTR lpBuffer, LPWSTR *lpFilePart, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL DefineDosDeviceA (DWORD dwFlags, LPCSTR lpDeviceName, LPCSTR lpTargetPath);
  __attribute__((dllimport)) DWORD QueryDosDeviceA (LPCSTR lpDeviceName, LPSTR lpTargetPath, DWORD ucchMax);
  __attribute__((dllimport)) HANDLE CreateFileTransactedA (LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter);
  __attribute__((dllimport)) HANDLE CreateFileTransactedW (LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter);




  __attribute__((dllimport)) HANDLE ReOpenFile (HANDLE hOriginalFile, DWORD dwDesiredAccess, DWORD dwShareMode, DWORD dwFlagsAndAttributes);

  __attribute__((dllimport)) WINBOOL SetFileAttributesTransactedA (LPCSTR lpFileName, DWORD dwFileAttributes, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL SetFileAttributesTransactedW (LPCWSTR lpFileName, DWORD dwFileAttributes, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL GetFileAttributesTransactedA (LPCSTR lpFileName, GET_FILEEX_INFO_LEVELS fInfoLevelId, LPVOID lpFileInformation, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL GetFileAttributesTransactedW (LPCWSTR lpFileName, GET_FILEEX_INFO_LEVELS fInfoLevelId, LPVOID lpFileInformation, HANDLE hTransaction);






  __attribute__((dllimport)) DWORD GetCompressedFileSizeA (LPCSTR lpFileName, LPDWORD lpFileSizeHigh);
  __attribute__((dllimport)) DWORD GetCompressedFileSizeW (LPCWSTR lpFileName, LPDWORD lpFileSizeHigh);




  __attribute__((dllimport)) DWORD GetCompressedFileSizeTransactedA (LPCSTR lpFileName, LPDWORD lpFileSizeHigh, HANDLE hTransaction);
  __attribute__((dllimport)) DWORD GetCompressedFileSizeTransactedW (LPCWSTR lpFileName, LPDWORD lpFileSizeHigh, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL DeleteFileTransactedA (LPCSTR lpFileName, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL DeleteFileTransactedW (LPCWSTR lpFileName, HANDLE hTransaction);
  typedef DWORD ( *LPPROGRESS_ROUTINE) (LARGE_INTEGER TotalFileSize, LARGE_INTEGER TotalBytesTransferred, LARGE_INTEGER StreamSize, LARGE_INTEGER StreamBytesTransferred, DWORD dwStreamNumber, DWORD dwCallbackReason, HANDLE hSourceFile, HANDLE hDestinationFile, LPVOID lpData);

  __attribute__((dllimport)) WINBOOL CheckNameLegalDOS8Dot3A (LPCSTR lpName, LPSTR lpOemName, DWORD OemNameSize, PBOOL pbNameContainsSpaces, PBOOL pbNameLegal);
  __attribute__((dllimport)) WINBOOL CheckNameLegalDOS8Dot3W (LPCWSTR lpName, LPSTR lpOemName, DWORD OemNameSize, PBOOL pbNameContainsSpaces, PBOOL pbNameLegal);
  __attribute__((dllimport)) WINBOOL CopyFileA (LPCSTR lpExistingFileName, LPCSTR lpNewFileName, WINBOOL bFailIfExists);
  __attribute__((dllimport)) WINBOOL CopyFileW (LPCWSTR lpExistingFileName, LPCWSTR lpNewFileName, WINBOOL bFailIfExists);
  __attribute__((dllimport)) WINBOOL CopyFileExA (LPCSTR lpExistingFileName, LPCSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, LPBOOL pbCancel, DWORD dwCopyFlags);
  __attribute__((dllimport)) WINBOOL CopyFileExW (LPCWSTR lpExistingFileName, LPCWSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, LPBOOL pbCancel, DWORD dwCopyFlags);


  __attribute__((dllimport)) HANDLE FindFirstFileTransactedA (LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction);
  __attribute__((dllimport)) HANDLE FindFirstFileTransactedW (LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL CopyFileTransactedA (LPCSTR lpExistingFileName, LPCSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, LPBOOL pbCancel, DWORD dwCopyFlags, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL CopyFileTransactedW (LPCWSTR lpExistingFileName, LPCWSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, LPBOOL pbCancel, DWORD dwCopyFlags, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL MoveFileA (LPCSTR lpExistingFileName, LPCSTR lpNewFileName);
  __attribute__((dllimport)) WINBOOL MoveFileW (LPCWSTR lpExistingFileName, LPCWSTR lpNewFileName);





  __attribute__((dllimport)) WINBOOL MoveFileExA (LPCSTR lpExistingFileName, LPCSTR lpNewFileName, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL MoveFileExW (LPCWSTR lpExistingFileName, LPCWSTR lpNewFileName, DWORD dwFlags);





  __attribute__((dllimport)) WINBOOL MoveFileWithProgressA (LPCSTR lpExistingFileName, LPCSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL MoveFileWithProgressW (LPCWSTR lpExistingFileName, LPCWSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, DWORD dwFlags);




  __attribute__((dllimport)) WINBOOL MoveFileTransactedA (LPCSTR lpExistingFileName, LPCSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, DWORD dwFlags, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL MoveFileTransactedW (LPCWSTR lpExistingFileName, LPCWSTR lpNewFileName, LPPROGRESS_ROUTINE lpProgressRoutine, LPVOID lpData, DWORD dwFlags, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL ReplaceFileA (LPCSTR lpReplacedFileName, LPCSTR lpReplacementFileName, LPCSTR lpBackupFileName, DWORD dwReplaceFlags, LPVOID lpExclude, LPVOID lpReserved);
  __attribute__((dllimport)) WINBOOL ReplaceFileW (LPCWSTR lpReplacedFileName, LPCWSTR lpReplacementFileName, LPCWSTR lpBackupFileName, DWORD dwReplaceFlags, LPVOID lpExclude, LPVOID lpReserved);
  __attribute__((dllimport)) WINBOOL CreateHardLinkA (LPCSTR lpFileName, LPCSTR lpExistingFileName, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) WINBOOL CreateHardLinkW (LPCWSTR lpFileName, LPCWSTR lpExistingFileName, LPSECURITY_ATTRIBUTES lpSecurityAttributes);





  __attribute__((dllimport)) WINBOOL CreateHardLinkTransactedA (LPCSTR lpFileName, LPCSTR lpExistingFileName, LPSECURITY_ATTRIBUTES lpSecurityAttributes, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL CreateHardLinkTransactedW (LPCWSTR lpFileName, LPCWSTR lpExistingFileName, LPSECURITY_ATTRIBUTES lpSecurityAttributes, HANDLE hTransaction);




  typedef enum _STREAM_INFO_LEVELS {
    FindStreamInfoStandard,
    FindStreamInfoMaxInfoLevel
  } STREAM_INFO_LEVELS;

  typedef struct _WIN32_FIND_STREAM_DATA {
    LARGE_INTEGER StreamSize;
    WCHAR cStreamName[260 + 36];
  } WIN32_FIND_STREAM_DATA,*PWIN32_FIND_STREAM_DATA;

  __attribute__((dllimport)) HANDLE FindFirstStreamW (LPCWSTR lpFileName, STREAM_INFO_LEVELS InfoLevel, LPVOID lpFindStreamData, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL FindNextStreamW (HANDLE hFindStream, LPVOID lpFindStreamData);

  __attribute__((dllimport)) HANDLE FindFirstStreamTransactedW (LPCWSTR lpFileName, STREAM_INFO_LEVELS InfoLevel, LPVOID lpFindStreamData, DWORD dwFlags, HANDLE hTransaction);
  __attribute__((dllimport)) HANDLE FindFirstFileNameW (LPCWSTR lpFileName, DWORD dwFlags, LPDWORD StringLength, PWSTR LinkName);
  __attribute__((dllimport)) WINBOOL FindNextFileNameW (HANDLE hFindStream, LPDWORD StringLength, PWSTR LinkName);
  __attribute__((dllimport)) HANDLE FindFirstFileNameTransactedW (LPCWSTR lpFileName, DWORD dwFlags, LPDWORD StringLength, PWSTR LinkName, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL GetNamedPipeClientComputerNameA (HANDLE Pipe, LPSTR ClientComputerName, ULONG ClientComputerNameLength);
  __attribute__((dllimport)) WINBOOL GetNamedPipeClientProcessId (HANDLE Pipe, PULONG ClientProcessId);
  __attribute__((dllimport)) WINBOOL GetNamedPipeClientSessionId (HANDLE Pipe, PULONG ClientSessionId);
  __attribute__((dllimport)) WINBOOL GetNamedPipeServerProcessId (HANDLE Pipe, PULONG ServerProcessId);
  __attribute__((dllimport)) WINBOOL GetNamedPipeServerSessionId (HANDLE Pipe, PULONG ServerSessionId);
  __attribute__((dllimport)) WINBOOL SetFileBandwidthReservation (HANDLE hFile, DWORD nPeriodMilliseconds, DWORD nBytesPerPeriod, WINBOOL bDiscardable, LPDWORD lpTransferSize, LPDWORD lpNumOutstandingRequests);
  __attribute__((dllimport)) WINBOOL GetFileBandwidthReservation (HANDLE hFile, LPDWORD lpPeriodMilliseconds, LPDWORD lpBytesPerPeriod, LPBOOL pDiscardable, LPDWORD lpTransferSize, LPDWORD lpNumOutstandingRequests);

  __attribute__((dllimport)) HANDLE CreateNamedPipeA (LPCSTR lpName, DWORD dwOpenMode, DWORD dwPipeMode, DWORD nMaxInstances, DWORD nOutBufferSize, DWORD nInBufferSize, DWORD nDefaultTimeOut, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) WINBOOL GetNamedPipeHandleStateA (HANDLE hNamedPipe, LPDWORD lpState, LPDWORD lpCurInstances, LPDWORD lpMaxCollectionCount, LPDWORD lpCollectDataTimeout, LPSTR lpUserName, DWORD nMaxUserNameSize);
  __attribute__((dllimport)) WINBOOL GetNamedPipeHandleStateW (HANDLE hNamedPipe, LPDWORD lpState, LPDWORD lpCurInstances, LPDWORD lpMaxCollectionCount, LPDWORD lpCollectDataTimeout, LPWSTR lpUserName, DWORD nMaxUserNameSize);
  __attribute__((dllimport)) WINBOOL CallNamedPipeA (LPCSTR lpNamedPipeName, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesRead, DWORD nTimeOut);
  __attribute__((dllimport)) WINBOOL CallNamedPipeW (LPCWSTR lpNamedPipeName, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesRead, DWORD nTimeOut);
  __attribute__((dllimport)) WINBOOL WaitNamedPipeA (LPCSTR lpNamedPipeName, DWORD nTimeOut);
  __attribute__((dllimport)) WINBOOL SetVolumeLabelA (LPCSTR lpRootPathName, LPCSTR lpVolumeName);
  __attribute__((dllimport)) WINBOOL SetVolumeLabelW (LPCWSTR lpRootPathName, LPCWSTR lpVolumeName);
  __attribute__((dllimport)) void SetFileApisToOEM (void);
  __attribute__((dllimport)) void SetFileApisToANSI (void);
  __attribute__((dllimport)) WINBOOL AreFileApisANSI (void);
  __attribute__((dllimport)) WINBOOL GetVolumeInformationA (LPCSTR lpRootPathName, LPSTR lpVolumeNameBuffer, DWORD nVolumeNameSize, LPDWORD lpVolumeSerialNumber, LPDWORD lpMaximumComponentLength, LPDWORD lpFileSystemFlags, LPSTR lpFileSystemNameBuffer, DWORD nFileSystemNameSize);
  __attribute__((dllimport)) WINBOOL ClearEventLogA (HANDLE hEventLog, LPCSTR lpBackupFileName);
  __attribute__((dllimport)) WINBOOL ClearEventLogW (HANDLE hEventLog, LPCWSTR lpBackupFileName);
  __attribute__((dllimport)) WINBOOL BackupEventLogA (HANDLE hEventLog, LPCSTR lpBackupFileName);
  __attribute__((dllimport)) WINBOOL BackupEventLogW (HANDLE hEventLog, LPCWSTR lpBackupFileName);
  __attribute__((dllimport)) WINBOOL CloseEventLog (HANDLE hEventLog);
  __attribute__((dllimport)) WINBOOL DeregisterEventSource (HANDLE hEventLog);
  __attribute__((dllimport)) WINBOOL NotifyChangeEventLog (HANDLE hEventLog, HANDLE hEvent);
  __attribute__((dllimport)) WINBOOL GetNumberOfEventLogRecords (HANDLE hEventLog, PDWORD NumberOfRecords);
  __attribute__((dllimport)) WINBOOL GetOldestEventLogRecord (HANDLE hEventLog, PDWORD OldestRecord);
  __attribute__((dllimport)) HANDLE OpenEventLogA (LPCSTR lpUNCServerName, LPCSTR lpSourceName);
  __attribute__((dllimport)) HANDLE OpenEventLogW (LPCWSTR lpUNCServerName, LPCWSTR lpSourceName);
  __attribute__((dllimport)) HANDLE RegisterEventSourceA (LPCSTR lpUNCServerName, LPCSTR lpSourceName);
  __attribute__((dllimport)) HANDLE RegisterEventSourceW (LPCWSTR lpUNCServerName, LPCWSTR lpSourceName);
  __attribute__((dllimport)) HANDLE OpenBackupEventLogA (LPCSTR lpUNCServerName, LPCSTR lpFileName);
  __attribute__((dllimport)) HANDLE OpenBackupEventLogW (LPCWSTR lpUNCServerName, LPCWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL ReadEventLogA (HANDLE hEventLog, DWORD dwReadFlags, DWORD dwRecordOffset, LPVOID lpBuffer, DWORD nNumberOfBytesToRead, DWORD *pnBytesRead, DWORD *pnMinNumberOfBytesNeeded);
  __attribute__((dllimport)) WINBOOL ReadEventLogW (HANDLE hEventLog, DWORD dwReadFlags, DWORD dwRecordOffset, LPVOID lpBuffer, DWORD nNumberOfBytesToRead, DWORD *pnBytesRead, DWORD *pnMinNumberOfBytesNeeded);
  __attribute__((dllimport)) WINBOOL ReportEventA (HANDLE hEventLog, WORD wType, WORD wCategory, DWORD dwEventID, PSID lpUserSid, WORD wNumStrings, DWORD dwDataSize, LPCSTR *lpStrings, LPVOID lpRawData);
  __attribute__((dllimport)) WINBOOL ReportEventW (HANDLE hEventLog, WORD wType, WORD wCategory, DWORD dwEventID, PSID lpUserSid, WORD wNumStrings, DWORD dwDataSize, LPCWSTR *lpStrings, LPVOID lpRawData);
  typedef struct _EVENTLOG_FULL_INFORMATION {
    DWORD dwFull;
  } EVENTLOG_FULL_INFORMATION,*LPEVENTLOG_FULL_INFORMATION;

  __attribute__((dllimport)) WINBOOL GetEventLogInformation (HANDLE hEventLog, DWORD dwInfoLevel, LPVOID lpBuffer, DWORD cbBufSize, LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL AccessCheckAndAuditAlarmA (LPCSTR SubsystemName, LPVOID HandleId, LPSTR ObjectTypeName, LPSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, DWORD DesiredAccess, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccess, LPBOOL AccessStatus, LPBOOL pfGenerateOnClose);
  __attribute__((dllimport)) WINBOOL AccessCheckByTypeAndAuditAlarmA (LPCSTR SubsystemName, LPVOID HandleId, LPCSTR ObjectTypeName, LPCSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, PSID PrincipalSelfSid, DWORD DesiredAccess, AUDIT_EVENT_TYPE AuditType, DWORD Flags, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccess, LPBOOL AccessStatus, LPBOOL pfGenerateOnClose);
  __attribute__((dllimport)) WINBOOL AccessCheckByTypeResultListAndAuditAlarmA (LPCSTR SubsystemName, LPVOID HandleId, LPCSTR ObjectTypeName, LPCSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, PSID PrincipalSelfSid, DWORD DesiredAccess, AUDIT_EVENT_TYPE AuditType, DWORD Flags, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccess, LPDWORD AccessStatusList, LPBOOL pfGenerateOnClose);
  __attribute__((dllimport)) WINBOOL AccessCheckByTypeResultListAndAuditAlarmByHandleA (LPCSTR SubsystemName, LPVOID HandleId, HANDLE ClientToken, LPCSTR ObjectTypeName, LPCSTR ObjectName, PSECURITY_DESCRIPTOR SecurityDescriptor, PSID PrincipalSelfSid, DWORD DesiredAccess, AUDIT_EVENT_TYPE AuditType, DWORD Flags, POBJECT_TYPE_LIST ObjectTypeList, DWORD ObjectTypeListLength, PGENERIC_MAPPING GenericMapping, WINBOOL ObjectCreation, LPDWORD GrantedAccess, LPDWORD AccessStatusList, LPBOOL pfGenerateOnClose);
  __attribute__((dllimport)) WINBOOL ObjectOpenAuditAlarmA (LPCSTR SubsystemName, LPVOID HandleId, LPSTR ObjectTypeName, LPSTR ObjectName, PSECURITY_DESCRIPTOR pSecurityDescriptor, HANDLE ClientToken, DWORD DesiredAccess, DWORD GrantedAccess, PPRIVILEGE_SET Privileges, WINBOOL ObjectCreation, WINBOOL AccessGranted, LPBOOL GenerateOnClose);
  __attribute__((dllimport)) WINBOOL ObjectPrivilegeAuditAlarmA (LPCSTR SubsystemName, LPVOID HandleId, HANDLE ClientToken, DWORD DesiredAccess, PPRIVILEGE_SET Privileges, WINBOOL AccessGranted);
  __attribute__((dllimport)) WINBOOL ObjectCloseAuditAlarmA (LPCSTR SubsystemName, LPVOID HandleId, WINBOOL GenerateOnClose);
  __attribute__((dllimport)) WINBOOL ObjectDeleteAuditAlarmA (LPCSTR SubsystemName, LPVOID HandleId, WINBOOL GenerateOnClose);
  __attribute__((dllimport)) WINBOOL PrivilegedServiceAuditAlarmA (LPCSTR SubsystemName, LPCSTR ServiceName, HANDLE ClientToken, PPRIVILEGE_SET Privileges, WINBOOL AccessGranted);
  __attribute__((dllimport)) WINBOOL SetFileSecurityA (LPCSTR lpFileName, SECURITY_INFORMATION SecurityInformation, PSECURITY_DESCRIPTOR pSecurityDescriptor);
  __attribute__((dllimport)) WINBOOL GetFileSecurityA (LPCSTR lpFileName, SECURITY_INFORMATION RequestedInformation, PSECURITY_DESCRIPTOR pSecurityDescriptor, DWORD nLength, LPDWORD lpnLengthNeeded);
  __attribute__((dllimport)) WINBOOL ReadDirectoryChangesW (HANDLE hDirectory, LPVOID lpBuffer, DWORD nBufferLength, WINBOOL bWatchSubtree, DWORD dwNotifyFilter, LPDWORD lpBytesReturned, LPOVERLAPPED lpOverlapped, LPOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine);
  __attribute__((dllimport)) WINBOOL IsBadReadPtr (const void *lp, UINT_PTR ucb);
  __attribute__((dllimport)) WINBOOL IsBadWritePtr (LPVOID lp, UINT_PTR ucb);
  __attribute__((dllimport)) WINBOOL IsBadHugeReadPtr (const void *lp, UINT_PTR ucb);
  __attribute__((dllimport)) WINBOOL IsBadHugeWritePtr (LPVOID lp, UINT_PTR ucb);
  __attribute__((dllimport)) WINBOOL IsBadCodePtr (FARPROC lpfn);
  __attribute__((dllimport)) WINBOOL IsBadStringPtrA (LPCSTR lpsz, UINT_PTR ucchMax);
  __attribute__((dllimport)) WINBOOL IsBadStringPtrW (LPCWSTR lpsz, UINT_PTR ucchMax);

  __attribute__((dllimport)) LPVOID MapViewOfFileExNuma (HANDLE hFileMappingObject, DWORD dwDesiredAccess, DWORD dwFileOffsetHigh, DWORD dwFileOffsetLow, SIZE_T dwNumberOfBytesToMap, LPVOID lpBaseAddress, DWORD nndPreferred);




  __attribute__((dllimport)) WINBOOL LookupAccountSidA (LPCSTR lpSystemName, PSID Sid, LPSTR Name, LPDWORD cchName, LPSTR ReferencedDomainName, LPDWORD cchReferencedDomainName, PSID_NAME_USE peUse);
  __attribute__((dllimport)) WINBOOL LookupAccountSidW (LPCWSTR lpSystemName, PSID Sid, LPWSTR Name, LPDWORD cchName, LPWSTR ReferencedDomainName, LPDWORD cchReferencedDomainName, PSID_NAME_USE peUse);
  __attribute__((dllimport)) WINBOOL LookupAccountNameA (LPCSTR lpSystemName, LPCSTR lpAccountName, PSID Sid, LPDWORD cbSid, LPSTR ReferencedDomainName, LPDWORD cchReferencedDomainName, PSID_NAME_USE peUse);
  __attribute__((dllimport)) WINBOOL LookupAccountNameW (LPCWSTR lpSystemName, LPCWSTR lpAccountName, PSID Sid, LPDWORD cbSid, LPWSTR ReferencedDomainName, LPDWORD cchReferencedDomainName, PSID_NAME_USE peUse);
  __attribute__((dllimport)) WINBOOL LookupPrivilegeValueA (LPCSTR lpSystemName, LPCSTR lpName, PLUID lpLuid);
  __attribute__((dllimport)) WINBOOL LookupPrivilegeValueW (LPCWSTR lpSystemName, LPCWSTR lpName, PLUID lpLuid);
  __attribute__((dllimport)) WINBOOL LookupPrivilegeNameA (LPCSTR lpSystemName, PLUID lpLuid, LPSTR lpName, LPDWORD cchName);
  __attribute__((dllimport)) WINBOOL LookupPrivilegeNameW (LPCWSTR lpSystemName, PLUID lpLuid, LPWSTR lpName, LPDWORD cchName);
  __attribute__((dllimport)) WINBOOL LookupPrivilegeDisplayNameA (LPCSTR lpSystemName, LPCSTR lpName, LPSTR lpDisplayName, LPDWORD cchDisplayName, LPDWORD lpLanguageId);
  __attribute__((dllimport)) WINBOOL LookupPrivilegeDisplayNameW (LPCWSTR lpSystemName, LPCWSTR lpName, LPWSTR lpDisplayName, LPDWORD cchDisplayName, LPDWORD lpLanguageId);
  __attribute__((dllimport)) WINBOOL BuildCommDCBA (LPCSTR lpDef, LPDCB lpDCB);
  __attribute__((dllimport)) WINBOOL BuildCommDCBW (LPCWSTR lpDef, LPDCB lpDCB);
  __attribute__((dllimport)) WINBOOL BuildCommDCBAndTimeoutsA (LPCSTR lpDef, LPDCB lpDCB, LPCOMMTIMEOUTS lpCommTimeouts);
  __attribute__((dllimport)) WINBOOL BuildCommDCBAndTimeoutsW (LPCWSTR lpDef, LPDCB lpDCB, LPCOMMTIMEOUTS lpCommTimeouts);
  __attribute__((dllimport)) WINBOOL CommConfigDialogA (LPCSTR lpszName, HWND hWnd, LPCOMMCONFIG lpCC);
  __attribute__((dllimport)) WINBOOL CommConfigDialogW (LPCWSTR lpszName, HWND hWnd, LPCOMMCONFIG lpCC);
  __attribute__((dllimport)) WINBOOL GetDefaultCommConfigA (LPCSTR lpszName, LPCOMMCONFIG lpCC, LPDWORD lpdwSize);
  __attribute__((dllimport)) WINBOOL GetDefaultCommConfigW (LPCWSTR lpszName, LPCOMMCONFIG lpCC, LPDWORD lpdwSize);
  __attribute__((dllimport)) WINBOOL SetDefaultCommConfigA (LPCSTR lpszName, LPCOMMCONFIG lpCC, DWORD dwSize);
  __attribute__((dllimport)) WINBOOL SetDefaultCommConfigW (LPCWSTR lpszName, LPCOMMCONFIG lpCC, DWORD dwSize);
  __attribute__((dllimport)) WINBOOL GetComputerNameA (LPSTR lpBuffer, LPDWORD nSize);
  __attribute__((dllimport)) WINBOOL GetComputerNameW (LPWSTR lpBuffer, LPDWORD nSize);
  __attribute__((dllimport)) WINBOOL SetComputerNameA (LPCSTR lpComputerName);
  __attribute__((dllimport)) WINBOOL SetComputerNameW (LPCWSTR lpComputerName);
  __attribute__((dllimport)) WINBOOL SetComputerNameExA (COMPUTER_NAME_FORMAT NameType, LPCTSTR lpBuffer);
  __attribute__((dllimport)) WINBOOL DnsHostnameToComputerNameA (LPCSTR Hostname, LPSTR ComputerName, LPDWORD nSize);
  __attribute__((dllimport)) WINBOOL DnsHostnameToComputerNameW (LPCWSTR Hostname, LPWSTR ComputerName, LPDWORD nSize);
  __attribute__((dllimport)) WINBOOL GetUserNameA (LPSTR lpBuffer, LPDWORD pcbBuffer);
  __attribute__((dllimport)) WINBOOL GetUserNameW (LPWSTR lpBuffer, LPDWORD pcbBuffer);
  __attribute__((dllimport)) WINBOOL LogonUserA (LPCSTR lpszUsername, LPCSTR lpszDomain, LPCSTR lpszPassword, DWORD dwLogonType, DWORD dwLogonProvider, PHANDLE phToken);
  __attribute__((dllimport)) WINBOOL LogonUserW (LPCWSTR lpszUsername, LPCWSTR lpszDomain, LPCWSTR lpszPassword, DWORD dwLogonType, DWORD dwLogonProvider, PHANDLE phToken);
  __attribute__((dllimport)) WINBOOL LogonUserExA (LPCSTR lpszUsername, LPCSTR lpszDomain, LPCSTR lpszPassword, DWORD dwLogonType, DWORD dwLogonProvider, PHANDLE phToken, PSID *ppLogonSid, PVOID *ppProfileBuffer, LPDWORD pdwProfileLength, PQUOTA_LIMITS pQuotaLimits);
  __attribute__((dllimport)) WINBOOL LogonUserExW (LPCWSTR lpszUsername, LPCWSTR lpszDomain, LPCWSTR lpszPassword, DWORD dwLogonType, DWORD dwLogonProvider, PHANDLE phToken, PSID *ppLogonSid, PVOID *ppProfileBuffer, LPDWORD pdwProfileLength, PQUOTA_LIMITS pQuotaLimits);
  __attribute__((dllimport)) WINBOOL CreateProcessAsUserA (HANDLE hToken, LPCSTR lpApplicationName, LPSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes, WINBOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCSTR lpCurrentDirectory, LPSTARTUPINFOA lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation);
  __attribute__((dllimport)) WINBOOL CreateProcessWithLogonW (LPCWSTR lpUsername, LPCWSTR lpDomain, LPCWSTR lpPassword, DWORD dwLogonFlags, LPCWSTR lpApplicationName, LPWSTR lpCommandLine, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCWSTR lpCurrentDirectory, LPSTARTUPINFOW lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation);
  __attribute__((dllimport)) WINBOOL CreateProcessWithTokenW (HANDLE hToken, DWORD dwLogonFlags, LPCWSTR lpApplicationName, LPWSTR lpCommandLine, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCWSTR lpCurrentDirectory, LPSTARTUPINFOW lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation);
  __attribute__((dllimport)) WINBOOL IsTokenUntrusted (HANDLE TokenHandle);
  __attribute__((dllimport)) WINBOOL RegisterWaitForSingleObject (PHANDLE phNewWaitObject, HANDLE hObject, WAITORTIMERCALLBACK Callback, PVOID Context, ULONG dwMilliseconds, ULONG dwFlags);
  __attribute__((dllimport)) WINBOOL UnregisterWait (HANDLE WaitHandle);
  __attribute__((dllimport)) WINBOOL BindIoCompletionCallback (HANDLE FileHandle, LPOVERLAPPED_COMPLETION_ROUTINE Function, ULONG Flags);
  __attribute__((dllimport)) HANDLE SetTimerQueueTimer (HANDLE TimerQueue, WAITORTIMERCALLBACK Callback, PVOID Parameter, DWORD DueTime, DWORD Period, WINBOOL PreferIo);
  __attribute__((dllimport)) WINBOOL CancelTimerQueueTimer (HANDLE TimerQueue, HANDLE Timer);
  __attribute__((dllimport)) WINBOOL DeleteTimerQueue (HANDLE TimerQueue);




  __attribute__((dllimport)) HANDLE CreatePrivateNamespaceA (LPSECURITY_ATTRIBUTES lpPrivateNamespaceAttributes, LPVOID lpBoundaryDescriptor, LPCSTR lpAliasPrefix);
  __attribute__((dllimport)) HANDLE OpenPrivateNamespaceA (LPVOID lpBoundaryDescriptor, LPCSTR lpAliasPrefix);
  __attribute__((dllimport)) HANDLE CreateBoundaryDescriptorA (LPCSTR Name, ULONG Flags);
  __attribute__((dllimport)) WINBOOL AddIntegrityLabelToBoundaryDescriptor (HANDLE *BoundaryDescriptor, PSID IntegrityLabel);
  typedef struct tagHW_PROFILE_INFOA {
    DWORD dwDockInfo;
    CHAR szHwProfileGuid[39];
    CHAR szHwProfileName[80];
  } HW_PROFILE_INFOA,*LPHW_PROFILE_INFOA;

  typedef struct tagHW_PROFILE_INFOW {
    DWORD dwDockInfo;
    WCHAR szHwProfileGuid[39];
    WCHAR szHwProfileName[80];
  } HW_PROFILE_INFOW,*LPHW_PROFILE_INFOW;

  typedef HW_PROFILE_INFOA HW_PROFILE_INFO;
  typedef LPHW_PROFILE_INFOA LPHW_PROFILE_INFO;

  __attribute__((dllimport)) WINBOOL GetCurrentHwProfileA (LPHW_PROFILE_INFOA lpHwProfileInfo);
  __attribute__((dllimport)) WINBOOL GetCurrentHwProfileW (LPHW_PROFILE_INFOW lpHwProfileInfo);
  __attribute__((dllimport)) WINBOOL VerifyVersionInfoA (LPOSVERSIONINFOEXA lpVersionInformation, DWORD dwTypeMask, DWORDLONG dwlConditionMask);
  __attribute__((dllimport)) WINBOOL VerifyVersionInfoW (LPOSVERSIONINFOEXW lpVersionInformation, DWORD dwTypeMask, DWORDLONG dwlConditionMask);







  typedef struct _TIME_ZONE_INFORMATION {
    LONG Bias;
    WCHAR StandardName[32];
    SYSTEMTIME StandardDate;
    LONG StandardBias;
    WCHAR DaylightName[32];
    SYSTEMTIME DaylightDate;
    LONG DaylightBias;
  } TIME_ZONE_INFORMATION,*PTIME_ZONE_INFORMATION,*LPTIME_ZONE_INFORMATION;

  typedef struct _TIME_DYNAMIC_ZONE_INFORMATION {
    LONG Bias;
    WCHAR StandardName[32];
    SYSTEMTIME StandardDate;
    LONG StandardBias;
    WCHAR DaylightName[32];
    SYSTEMTIME DaylightDate;
    LONG DaylightBias;
    WCHAR TimeZoneKeyName[128];
    BOOLEAN DynamicDaylightTimeDisabled;
  } DYNAMIC_TIME_ZONE_INFORMATION,*PDYNAMIC_TIME_ZONE_INFORMATION;

  __attribute__((dllimport)) WINBOOL SystemTimeToTzSpecificLocalTime (const TIME_ZONE_INFORMATION *lpTimeZoneInformation, const SYSTEMTIME *lpUniversalTime, LPSYSTEMTIME lpLocalTime);
  __attribute__((dllimport)) WINBOOL TzSpecificLocalTimeToSystemTime (const TIME_ZONE_INFORMATION *lpTimeZoneInformation, const SYSTEMTIME *lpLocalTime, LPSYSTEMTIME lpUniversalTime);
  __attribute__((dllimport)) WINBOOL FileTimeToSystemTime (const FILETIME *lpFileTime, LPSYSTEMTIME lpSystemTime);
  __attribute__((dllimport)) WINBOOL SystemTimeToFileTime (const SYSTEMTIME *lpSystemTime, LPFILETIME lpFileTime);
  __attribute__((dllimport)) DWORD GetTimeZoneInformation (LPTIME_ZONE_INFORMATION lpTimeZoneInformation);

  __attribute__((dllimport)) DWORD GetDynamicTimeZoneInformation (PDYNAMIC_TIME_ZONE_INFORMATION pTimeZoneInformation);
  __attribute__((dllimport)) WINBOOL SetTimeZoneInformation (const TIME_ZONE_INFORMATION *lpTimeZoneInformation);

  __attribute__((dllimport)) WINBOOL SetDynamicTimeZoneInformation (const DYNAMIC_TIME_ZONE_INFORMATION *lpTimeZoneInformation);
  typedef struct _SYSTEM_POWER_STATUS {
    BYTE ACLineStatus;
    BYTE BatteryFlag;
    BYTE BatteryLifePercent;
    BYTE Reserved1;
    DWORD BatteryLifeTime;
    DWORD BatteryFullLifeTime;
  } SYSTEM_POWER_STATUS,*LPSYSTEM_POWER_STATUS;

  __attribute__((dllimport)) WINBOOL GetSystemPowerStatus (LPSYSTEM_POWER_STATUS lpSystemPowerStatus);
  __attribute__((dllimport)) WINBOOL SetSystemPowerState (WINBOOL fSuspend, WINBOOL fForce);
  __attribute__((dllimport)) WINBOOL AllocateUserPhysicalPages (HANDLE hProcess, PULONG_PTR NumberOfPages, PULONG_PTR PageArray);
  __attribute__((dllimport)) WINBOOL FreeUserPhysicalPages (HANDLE hProcess, PULONG_PTR NumberOfPages, PULONG_PTR PageArray);
  __attribute__((dllimport)) WINBOOL MapUserPhysicalPages (PVOID VirtualAddress, ULONG_PTR NumberOfPages, PULONG_PTR PageArray);
  __attribute__((dllimport)) WINBOOL MapUserPhysicalPagesScatter (PVOID *VirtualAddresses, ULONG_PTR NumberOfPages, PULONG_PTR PageArray);
  __attribute__((dllimport)) HANDLE CreateJobObjectA (LPSECURITY_ATTRIBUTES lpJobAttributes, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE CreateJobObjectW (LPSECURITY_ATTRIBUTES lpJobAttributes, LPCWSTR lpName);
  __attribute__((dllimport)) HANDLE OpenJobObjectA (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCSTR lpName);
  __attribute__((dllimport)) HANDLE OpenJobObjectW (DWORD dwDesiredAccess, WINBOOL bInheritHandle, LPCWSTR lpName);
  __attribute__((dllimport)) WINBOOL AssignProcessToJobObject (HANDLE hJob, HANDLE hProcess);
  __attribute__((dllimport)) WINBOOL TerminateJobObject (HANDLE hJob, UINT uExitCode);
  __attribute__((dllimport)) WINBOOL QueryInformationJobObject (HANDLE hJob, JOBOBJECTINFOCLASS JobObjectInformationClass, LPVOID lpJobObjectInformation, DWORD cbJobObjectInformationLength, LPDWORD lpReturnLength);
  __attribute__((dllimport)) WINBOOL SetInformationJobObject (HANDLE hJob, JOBOBJECTINFOCLASS JobObjectInformationClass, LPVOID lpJobObjectInformation, DWORD cbJobObjectInformationLength);
  __attribute__((dllimport)) WINBOOL CreateJobSet (ULONG NumJob, PJOB_SET_ARRAY UserJobSet, ULONG Flags);
  __attribute__((dllimport)) HANDLE FindFirstVolumeA (LPSTR lpszVolumeName, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL FindNextVolumeA (HANDLE hFindVolume, LPSTR lpszVolumeName, DWORD cchBufferLength);
  __attribute__((dllimport)) HANDLE FindFirstVolumeMountPointA (LPCSTR lpszRootPathName, LPSTR lpszVolumeMountPoint, DWORD cchBufferLength);
  __attribute__((dllimport)) HANDLE FindFirstVolumeMountPointW (LPCWSTR lpszRootPathName, LPWSTR lpszVolumeMountPoint, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL FindNextVolumeMountPointA (HANDLE hFindVolumeMountPoint, LPSTR lpszVolumeMountPoint, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL FindNextVolumeMountPointW (HANDLE hFindVolumeMountPoint, LPWSTR lpszVolumeMountPoint, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL FindVolumeMountPointClose (HANDLE hFindVolumeMountPoint);
  __attribute__((dllimport)) WINBOOL SetVolumeMountPointA (LPCSTR lpszVolumeMountPoint, LPCSTR lpszVolumeName);
  __attribute__((dllimport)) WINBOOL SetVolumeMountPointW (LPCWSTR lpszVolumeMountPoint, LPCWSTR lpszVolumeName);
  __attribute__((dllimport)) WINBOOL DeleteVolumeMountPointA (LPCSTR lpszVolumeMountPoint);
  __attribute__((dllimport)) WINBOOL GetVolumeNameForVolumeMountPointA (LPCSTR lpszVolumeMountPoint, LPSTR lpszVolumeName, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL GetVolumePathNameA (LPCSTR lpszFileName, LPSTR lpszVolumePathName, DWORD cchBufferLength);
  __attribute__((dllimport)) WINBOOL GetVolumePathNamesForVolumeNameA (LPCSTR lpszVolumeName, LPCH lpszVolumePathNames, DWORD cchBufferLength, PDWORD lpcchReturnLength);

  __attribute__((dllimport)) WINBOOL AllocateUserPhysicalPagesNuma (HANDLE hProcess, PULONG_PTR NumberOfPages, PULONG_PTR PageArray, DWORD nndPreferred);
  typedef struct tagACTCTXA {
    ULONG cbSize;
    DWORD dwFlags;
    LPCSTR lpSource;
    USHORT wProcessorArchitecture;
    LANGID wLangId;
    LPCSTR lpAssemblyDirectory;
    LPCSTR lpResourceName;
    LPCSTR lpApplicationName;
    HMODULE hModule;
  } ACTCTXA,*PACTCTXA;

  typedef struct tagACTCTXW {
    ULONG cbSize;
    DWORD dwFlags;
    LPCWSTR lpSource;
    USHORT wProcessorArchitecture;
    LANGID wLangId;
    LPCWSTR lpAssemblyDirectory;
    LPCWSTR lpResourceName;
    LPCWSTR lpApplicationName;
    HMODULE hModule;
  } ACTCTXW,*PACTCTXW;

  typedef ACTCTXA ACTCTX;
  typedef PACTCTXA PACTCTX;

  typedef const ACTCTXA *PCACTCTXA;
  typedef const ACTCTXW *PCACTCTXW;

  typedef PCACTCTXA PCACTCTX;

  __attribute__((dllimport)) HANDLE CreateActCtxA (PCACTCTXA pActCtx);
  __attribute__((dllimport)) HANDLE CreateActCtxW (PCACTCTXW pActCtx);
  __attribute__((dllimport)) void AddRefActCtx (HANDLE hActCtx);
  __attribute__((dllimport)) void ReleaseActCtx (HANDLE hActCtx);
  __attribute__((dllimport)) WINBOOL ZombifyActCtx (HANDLE hActCtx);
  __attribute__((dllimport)) WINBOOL ActivateActCtx (HANDLE hActCtx, ULONG_PTR *lpCookie);
  __attribute__((dllimport)) WINBOOL DeactivateActCtx (DWORD dwFlags, ULONG_PTR ulCookie);
  __attribute__((dllimport)) WINBOOL GetCurrentActCtx (HANDLE *lphActCtx);




  typedef struct tagACTCTX_SECTION_KEYED_DATA_2600 {
    ULONG cbSize;
    ULONG ulDataFormatVersion;
    PVOID lpData;
    ULONG ulLength;
    PVOID lpSectionGlobalData;
    ULONG ulSectionGlobalDataLength;
    PVOID lpSectionBase;
    ULONG ulSectionTotalLength;
    HANDLE hActCtx;
    ULONG ulAssemblyRosterIndex;
  } ACTCTX_SECTION_KEYED_DATA_2600,*PACTCTX_SECTION_KEYED_DATA_2600;

  typedef const ACTCTX_SECTION_KEYED_DATA_2600 *PCACTCTX_SECTION_KEYED_DATA_2600;

  typedef struct tagACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA {
    PVOID lpInformation;
    PVOID lpSectionBase;
    ULONG ulSectionLength;
    PVOID lpSectionGlobalDataBase;
    ULONG ulSectionGlobalDataLength;
  } ACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA,*PACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA;

  typedef const ACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA *PCACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA;

  typedef struct tagACTCTX_SECTION_KEYED_DATA {
    ULONG cbSize;
    ULONG ulDataFormatVersion;
    PVOID lpData;
    ULONG ulLength;
    PVOID lpSectionGlobalData;
    ULONG ulSectionGlobalDataLength;
    PVOID lpSectionBase;
    ULONG ulSectionTotalLength;
    HANDLE hActCtx;
    ULONG ulAssemblyRosterIndex;
    ULONG ulFlags;
    ACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA AssemblyMetadata;
  } ACTCTX_SECTION_KEYED_DATA,*PACTCTX_SECTION_KEYED_DATA;

  typedef const ACTCTX_SECTION_KEYED_DATA *PCACTCTX_SECTION_KEYED_DATA;





  __attribute__((dllimport)) WINBOOL FindActCtxSectionStringA (DWORD dwFlags, const GUID *lpExtensionGuid, ULONG ulSectionId, LPCSTR lpStringToFind, PACTCTX_SECTION_KEYED_DATA ReturnedData);
  __attribute__((dllimport)) WINBOOL FindActCtxSectionStringW (DWORD dwFlags, const GUID *lpExtensionGuid, ULONG ulSectionId, LPCWSTR lpStringToFind, PACTCTX_SECTION_KEYED_DATA ReturnedData);
  __attribute__((dllimport)) WINBOOL FindActCtxSectionGuid (DWORD dwFlags, const GUID *lpExtensionGuid, ULONG ulSectionId, const GUID *lpGuidToFind, PACTCTX_SECTION_KEYED_DATA ReturnedData);




  typedef struct _ACTIVATION_CONTEXT_BASIC_INFORMATION {
    HANDLE hActCtx;
    DWORD dwFlags;
  } ACTIVATION_CONTEXT_BASIC_INFORMATION,*PACTIVATION_CONTEXT_BASIC_INFORMATION;

  typedef const struct _ACTIVATION_CONTEXT_BASIC_INFORMATION *PCACTIVATION_CONTEXT_BASIC_INFORMATION;
  __attribute__((dllimport)) WINBOOL QueryActCtxW (DWORD dwFlags, HANDLE hActCtx, PVOID pvSubInstance, ULONG ulInfoClass, PVOID pvBuffer, SIZE_T cbBuffer, SIZE_T *pcbWrittenOrRequired);

  typedef WINBOOL ( *PQUERYACTCTXW_FUNC) (DWORD dwFlags, HANDLE hActCtx, PVOID pvSubInstance, ULONG ulInfoClass, PVOID pvBuffer, SIZE_T cbBuffer, SIZE_T *pcbWrittenOrRequired);

  __attribute__((dllimport)) DWORD WTSGetActiveConsoleSessionId (void);
  __attribute__((dllimport)) WINBOOL GetNumaProcessorNode (UCHAR Processor, PUCHAR NodeNumber);
  __attribute__((dllimport)) WINBOOL GetNumaNodeProcessorMask (UCHAR Node, PULONGLONG ProcessorMask);
  __attribute__((dllimport)) WINBOOL GetNumaAvailableMemoryNode (UCHAR Node, PULONGLONG AvailableBytes);

  __attribute__((dllimport)) WINBOOL GetNumaProximityNode (ULONG ProximityId, PUCHAR NodeNumber);
  typedef DWORD ( *APPLICATION_RECOVERY_CALLBACK) (PVOID pvParameter);
  __attribute__((dllimport)) HRESULT RegisterApplicationRecoveryCallback (APPLICATION_RECOVERY_CALLBACK pRecoveyCallback, PVOID pvParameter, DWORD dwPingInterval, DWORD dwFlags);
  __attribute__((dllimport)) HRESULT UnregisterApplicationRecoveryCallback (void);
  __attribute__((dllimport)) HRESULT RegisterApplicationRestart (PCWSTR pwzCommandline, DWORD dwFlags);
  __attribute__((dllimport)) HRESULT UnregisterApplicationRestart (void);
  __attribute__((dllimport)) HRESULT GetApplicationRecoveryCallback (HANDLE hProcess, APPLICATION_RECOVERY_CALLBACK *pRecoveryCallback, PVOID *ppvParameter, PDWORD pdwPingInterval, PDWORD pdwFlags);
  __attribute__((dllimport)) HRESULT GetApplicationRestartSettings (HANDLE hProcess, PWSTR pwzCommandline, PDWORD pcchSize, PDWORD pdwFlags);
  __attribute__((dllimport)) HRESULT ApplicationRecoveryInProgress (PBOOL pbCancelled);
  __attribute__((dllimport)) void ApplicationRecoveryFinished (WINBOOL bSuccess);





  typedef struct _FILE_BASIC_INFO {
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    DWORD FileAttributes;
  } FILE_BASIC_INFO,*PFILE_BASIC_INFO;

  typedef struct _FILE_STANDARD_INFO {
    LARGE_INTEGER AllocationSize;
    LARGE_INTEGER EndOfFile;
    DWORD NumberOfLinks;
    BOOLEAN DeletePending;
    BOOLEAN Directory;
  } FILE_STANDARD_INFO,*PFILE_STANDARD_INFO;

  typedef struct _FILE_NAME_INFO {
    DWORD FileNameLength;
    WCHAR FileName[1];
  } FILE_NAME_INFO,*PFILE_NAME_INFO;

  typedef struct _FILE_RENAME_INFO {
    BOOLEAN ReplaceIfExists;
    HANDLE RootDirectory;
    DWORD FileNameLength;
    WCHAR FileName[1];
  } FILE_RENAME_INFO,*PFILE_RENAME_INFO;

  typedef struct _FILE_ALLOCATION_INFO {
    LARGE_INTEGER AllocationSize;
  } FILE_ALLOCATION_INFO,*PFILE_ALLOCATION_INFO;

  typedef struct _FILE_END_OF_FILE_INFO {
    LARGE_INTEGER EndOfFile;
  } FILE_END_OF_FILE_INFO,*PFILE_END_OF_FILE_INFO;

  typedef struct _FILE_STREAM_INFO {
    DWORD NextEntryOffset;
    DWORD StreamNameLength;
    LARGE_INTEGER StreamSize;
    LARGE_INTEGER StreamAllocationSize;
    WCHAR StreamName[1];
  } FILE_STREAM_INFO,*PFILE_STREAM_INFO;

  typedef struct _FILE_COMPRESSION_INFO {
    LARGE_INTEGER CompressedFileSize;
    WORD CompressionFormat;
    UCHAR CompressionUnitShift;
    UCHAR ChunkShift;
    UCHAR ClusterShift;
    UCHAR Reserved[3];
  } FILE_COMPRESSION_INFO,*PFILE_COMPRESSION_INFO;

  typedef struct _FILE_ATTRIBUTE_TAG_INFO {
    DWORD FileAttributes;
    DWORD ReparseTag;
  } FILE_ATTRIBUTE_TAG_INFO,*PFILE_ATTRIBUTE_TAG_INFO;

  typedef struct _FILE_DISPOSITION_INFO {
    BOOLEAN DeleteFileA;
  } FILE_DISPOSITION_INFO,*PFILE_DISPOSITION_INFO;

  typedef struct _FILE_ID_BOTH_DIR_INFO {
    DWORD NextEntryOffset;
    DWORD FileIndex;
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    LARGE_INTEGER EndOfFile;
    LARGE_INTEGER AllocationSize;
    DWORD FileAttributes;
    DWORD FileNameLength;
    DWORD EaSize;
    CCHAR ShortNameLength;
    WCHAR ShortName[12];
    LARGE_INTEGER FileId;
    WCHAR FileName[1];
  } FILE_ID_BOTH_DIR_INFO,*PFILE_ID_BOTH_DIR_INFO;

  typedef struct _FILE_FULL_DIR_INFO {
    ULONG NextEntryOffset;
    ULONG FileIndex;
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    LARGE_INTEGER EndOfFile;
    LARGE_INTEGER AllocationSize;
    ULONG FileAttributes;
    ULONG FileNameLength;
    ULONG EaSize;
    WCHAR FileName[1];
  } FILE_FULL_DIR_INFO,*PFILE_FULL_DIR_INFO;

  typedef enum _PRIORITY_HINT {
    IoPriorityHintVeryLow = 0,
    IoPriorityHintLow,
    IoPriorityHintNormal,
    MaximumIoPriorityHintType
  } PRIORITY_HINT;

  typedef struct _FILE_IO_PRIORITY_HINT_INFO {
    PRIORITY_HINT PriorityHint;
  } FILE_IO_PRIORITY_HINT_INFO,*PFILE_IO_PRIORITY_HINT_INFO;
  typedef struct _FILE_REMOTE_PROTOCOL_INFO {
    USHORT StructureVersion;
    USHORT StructureSize;
    ULONG Protocol;
    USHORT ProtocolMajorVersion;
    USHORT ProtocolMinorVersion;
    USHORT ProtocolRevision;
    USHORT Reserved;
    ULONG Flags;
    struct {
      ULONG Reserved[8];
    } GenericReserved;

    struct {
      ULONG Reserved[16];
    } ProtocolSpecificReserved;
  } FILE_REMOTE_PROTOCOL_INFO,*PFILE_REMOTE_PROTOCOL_INFO;

  __attribute__((dllimport)) WINBOOL GetFileInformationByHandleEx (HANDLE hFile, FILE_INFO_BY_HANDLE_CLASS FileInformationClass, LPVOID lpFileInformation, DWORD dwBufferSize);



  typedef enum _FILE_ID_TYPE {
    FileIdType,
    ObjectIdType,
    ExtendedFileIdType,
    MaximumFileIdType
  } FILE_ID_TYPE,*PFILE_ID_TYPE;

  typedef struct FILE_ID_DESCRIPTOR {
    DWORD dwSize;
    FILE_ID_TYPE Type;
    __extension__ union {
      LARGE_INTEGER FileId;
      GUID ObjectId;



    } ;
  } FILE_ID_DESCRIPTOR,*LPFILE_ID_DESCRIPTOR;

  __attribute__((dllimport)) HANDLE OpenFileById (HANDLE hVolumeHint, LPFILE_ID_DESCRIPTOR lpFileId, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwFlagsAndAttributes);
  __attribute__((dllimport)) BOOLEAN CreateSymbolicLinkA (LPCSTR lpSymlinkFileName, LPCSTR lpTargetFileName, DWORD dwFlags);
  __attribute__((dllimport)) BOOLEAN CreateSymbolicLinkW (LPCWSTR lpSymlinkFileName, LPCWSTR lpTargetFileName, DWORD dwFlags);
  __attribute__((dllimport)) BOOLEAN CreateSymbolicLinkTransactedA (LPCSTR lpSymlinkFileName, LPCSTR lpTargetFileName, DWORD dwFlags, HANDLE hTransaction);
  __attribute__((dllimport)) BOOLEAN CreateSymbolicLinkTransactedW (LPCWSTR lpSymlinkFileName, LPCWSTR lpTargetFileName, DWORD dwFlags, HANDLE hTransaction);
  __attribute__((dllimport)) WINBOOL QueryActCtxSettingsW (DWORD dwFlags, HANDLE hActCtx, PCWSTR settingsNameSpace, PCWSTR settingName, PWSTR pvBuffer, SIZE_T dwBuffer, SIZE_T *pdwWrittenOrRequired);
  __attribute__((dllimport)) WINBOOL ReplacePartitionUnit (PWSTR TargetPartition, PWSTR SparePartition, ULONG Flags);
  __attribute__((dllimport)) WINBOOL AddSecureMemoryCacheCallback (PSECURE_MEMORY_CACHE_CALLBACK pfnCallBack);
  __attribute__((dllimport)) WINBOOL RemoveSecureMemoryCacheCallback (PSECURE_MEMORY_CACHE_CALLBACK pfnCallBack);
  __attribute__((dllimport)) WINBOOL CopyContext (PCONTEXT Destination, DWORD ContextFlags, PCONTEXT Source);



  __attribute__((dllimport)) WINBOOL InitializeContext (PVOID Buffer, DWORD ContextFlags, PCONTEXT *Context, PDWORD ContextLength);
  typedef struct _DRAWPATRECT {
    POINT ptPosition;
    POINT ptSize;
    WORD wStyle;
    WORD wPattern;
  } DRAWPATRECT,*PDRAWPATRECT;
  typedef struct _PSINJECTDATA {
    DWORD DataBytes;
    WORD InjectionPoint;
    WORD PageNumber;
  } PSINJECTDATA,*PPSINJECTDATA;
  typedef struct _PSFEATURE_OUTPUT {
    WINBOOL bPageIndependent;
    WINBOOL bSetPageDevice;
  } PSFEATURE_OUTPUT,*PPSFEATURE_OUTPUT;

  typedef struct _PSFEATURE_CUSTPAPER {
    LONG lOrientation;
    LONG lWidth;
    LONG lHeight;
    LONG lWidthOffset;
    LONG lHeightOffset;
  } PSFEATURE_CUSTPAPER,*PPSFEATURE_CUSTPAPER;
  typedef struct tagXFORM {
    FLOAT eM11;
    FLOAT eM12;
    FLOAT eM21;
    FLOAT eM22;
    FLOAT eDx;
    FLOAT eDy;
  } XFORM,*PXFORM,*LPXFORM;

  typedef struct tagBITMAP {
    LONG bmType;
    LONG bmWidth;
    LONG bmHeight;
    LONG bmWidthBytes;
    WORD bmPlanes;
    WORD bmBitsPixel;
    LPVOID bmBits;
  } BITMAP,*PBITMAP,*NPBITMAP,*LPBITMAP;








#pragma pack(push,1)
 typedef struct tagRGBTRIPLE {
    BYTE rgbtBlue;
    BYTE rgbtGreen;
    BYTE rgbtRed;
  } RGBTRIPLE;







#pragma pack(pop)

  typedef struct tagRGBQUAD {
    BYTE rgbBlue;
    BYTE rgbGreen;
    BYTE rgbRed;
    BYTE rgbReserved;
  } RGBQUAD;



  typedef RGBQUAD *LPRGBQUAD;
  typedef LONG LCSCSTYPE;


  typedef LONG LCSGAMUTMATCH;
  typedef long FXPT16DOT16,*LPFXPT16DOT16;
  typedef long FXPT2DOT30,*LPFXPT2DOT30;

  typedef struct tagCIEXYZ {
    FXPT2DOT30 ciexyzX;
    FXPT2DOT30 ciexyzY;
    FXPT2DOT30 ciexyzZ;
  } CIEXYZ;


  typedef CIEXYZ *LPCIEXYZ;


  typedef struct tagICEXYZTRIPLE {
    CIEXYZ ciexyzRed;
    CIEXYZ ciexyzGreen;
    CIEXYZ ciexyzBlue;
  } CIEXYZTRIPLE;


  typedef CIEXYZTRIPLE *LPCIEXYZTRIPLE;



  typedef struct tagLOGCOLORSPACEA {
    DWORD lcsSignature;
    DWORD lcsVersion;
    DWORD lcsSize;
    LCSCSTYPE lcsCSType;
    LCSGAMUTMATCH lcsIntent;
    CIEXYZTRIPLE lcsEndpoints;
    DWORD lcsGammaRed;
    DWORD lcsGammaGreen;
    DWORD lcsGammaBlue;
    CHAR lcsFilename[260];
  } LOGCOLORSPACEA,*LPLOGCOLORSPACEA;

  typedef struct tagLOGCOLORSPACEW {
    DWORD lcsSignature;
    DWORD lcsVersion;
    DWORD lcsSize;
    LCSCSTYPE lcsCSType;
    LCSGAMUTMATCH lcsIntent;
    CIEXYZTRIPLE lcsEndpoints;
    DWORD lcsGammaRed;
    DWORD lcsGammaGreen;
    DWORD lcsGammaBlue;
    WCHAR lcsFilename[260];
  } LOGCOLORSPACEW,*LPLOGCOLORSPACEW;

  typedef LOGCOLORSPACEA LOGCOLORSPACE;
  typedef LPLOGCOLORSPACEA LPLOGCOLORSPACE;



  typedef struct tagBITMAPCOREHEADER {
    DWORD bcSize;
    WORD bcWidth;
    WORD bcHeight;
    WORD bcPlanes;
    WORD bcBitCount;
  } BITMAPCOREHEADER,*LPBITMAPCOREHEADER,*PBITMAPCOREHEADER;



  typedef struct tagBITMAPINFOHEADER {
    DWORD biSize;
    LONG biWidth;
    LONG biHeight;
    WORD biPlanes;
    WORD biBitCount;
    DWORD biCompression;
    DWORD biSizeImage;
    LONG biXPelsPerMeter;
    LONG biYPelsPerMeter;
    DWORD biClrUsed;
    DWORD biClrImportant;
  } BITMAPINFOHEADER,*LPBITMAPINFOHEADER,*PBITMAPINFOHEADER;



  typedef struct {
    DWORD bV4Size;
    LONG bV4Width;
    LONG bV4Height;
    WORD bV4Planes;
    WORD bV4BitCount;
    DWORD bV4V4Compression;
    DWORD bV4SizeImage;
    LONG bV4XPelsPerMeter;
    LONG bV4YPelsPerMeter;
    DWORD bV4ClrUsed;
    DWORD bV4ClrImportant;
    DWORD bV4RedMask;
    DWORD bV4GreenMask;
    DWORD bV4BlueMask;
    DWORD bV4AlphaMask;
    DWORD bV4CSType;
    CIEXYZTRIPLE bV4Endpoints;
    DWORD bV4GammaRed;
    DWORD bV4GammaGreen;
    DWORD bV4GammaBlue;
  } BITMAPV4HEADER,*LPBITMAPV4HEADER,*PBITMAPV4HEADER;

  typedef struct {
    DWORD bV5Size;
    LONG bV5Width;
    LONG bV5Height;
    WORD bV5Planes;
    WORD bV5BitCount;
    DWORD bV5Compression;
    DWORD bV5SizeImage;
    LONG bV5XPelsPerMeter;
    LONG bV5YPelsPerMeter;
    DWORD bV5ClrUsed;
    DWORD bV5ClrImportant;
    DWORD bV5RedMask;
    DWORD bV5GreenMask;
    DWORD bV5BlueMask;
    DWORD bV5AlphaMask;
    DWORD bV5CSType;
    CIEXYZTRIPLE bV5Endpoints;
    DWORD bV5GammaRed;
    DWORD bV5GammaGreen;
    DWORD bV5GammaBlue;
    DWORD bV5Intent;
    DWORD bV5ProfileData;
    DWORD bV5ProfileSize;
    DWORD bV5Reserved;
  } BITMAPV5HEADER,*LPBITMAPV5HEADER,*PBITMAPV5HEADER;
  typedef struct tagBITMAPINFO {
    BITMAPINFOHEADER bmiHeader;
    RGBQUAD bmiColors[1];
  } BITMAPINFO,*LPBITMAPINFO,*PBITMAPINFO;



  typedef struct tagBITMAPCOREINFO {
    BITMAPCOREHEADER bmciHeader;
    RGBTRIPLE bmciColors[1];
  } BITMAPCOREINFO,*LPBITMAPCOREINFO,*PBITMAPCOREINFO;








#pragma pack(push,2)
 typedef struct tagBITMAPFILEHEADER {
    WORD bfType;
    DWORD bfSize;
    WORD bfReserved1;
    WORD bfReserved2;
    DWORD bfOffBits;
  } BITMAPFILEHEADER,*LPBITMAPFILEHEADER,*PBITMAPFILEHEADER;







#pragma pack(pop)







  typedef struct tagFONTSIGNATURE {
    DWORD fsUsb[4];
    DWORD fsCsb[2];
  } FONTSIGNATURE,*PFONTSIGNATURE,*LPFONTSIGNATURE;

  typedef struct tagCHARSETINFO {
    UINT ciCharset;
    UINT ciACP;
    FONTSIGNATURE fs;
  } CHARSETINFO,*PCHARSETINFO,*NPCHARSETINFO,*LPCHARSETINFO;
  typedef struct tagLOCALESIGNATURE {
    DWORD lsUsb[4];
    DWORD lsCsbDefault[2];
    DWORD lsCsbSupported[2];
  } LOCALESIGNATURE,*PLOCALESIGNATURE,*LPLOCALESIGNATURE;





  typedef struct tagHANDLETABLE {
    HGDIOBJ objectHandle[1];
  } HANDLETABLE,*PHANDLETABLE,*LPHANDLETABLE;

  typedef struct tagMETARECORD {
    DWORD rdSize;
    WORD rdFunction;
    WORD rdParm[1];
  } METARECORD;


  typedef struct tagMETARECORD *PMETARECORD;


  typedef struct tagMETARECORD *LPMETARECORD;

  typedef struct tagMETAFILEPICT {
    LONG mm;
    LONG xExt;
    LONG yExt;
    HMETAFILE hMF;
  } METAFILEPICT,*LPMETAFILEPICT;










#pragma pack(push,2)
 typedef struct tagMETAHEADER {
    WORD mtType;
    WORD mtHeaderSize;
    WORD mtVersion;
    DWORD mtSize;
    WORD mtNoObjects;
    DWORD mtMaxRecord;
    WORD mtNoParameters;
  } METAHEADER;
  typedef struct tagMETAHEADER *PMETAHEADER;
  typedef struct tagMETAHEADER *LPMETAHEADER;








#pragma pack(pop)



  typedef struct tagENHMETARECORD {
    DWORD iType;
    DWORD nSize;
    DWORD dParm[1];
  } ENHMETARECORD,*PENHMETARECORD,*LPENHMETARECORD;

  typedef struct tagENHMETAHEADER {
    DWORD iType;
    DWORD nSize;
    RECTL rclBounds;
    RECTL rclFrame;
    DWORD dSignature;
    DWORD nVersion;
    DWORD nBytes;
    DWORD nRecords;
    WORD nHandles;
    WORD sReserved;
    DWORD nDescription;
    DWORD offDescription;
    DWORD nPalEntries;
    SIZEL szlDevice;
    SIZEL szlMillimeters;
    DWORD cbPixelFormat;
    DWORD offPixelFormat;
    DWORD bOpenGL;
    SIZEL szlMicrometers;
  } ENHMETAHEADER,*PENHMETAHEADER,*LPENHMETAHEADER;
  typedef BYTE BCHAR;













#pragma pack(push,4)

  typedef struct tagTEXTMETRICA {
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    BYTE tmFirstChar;
    BYTE tmLastChar;
    BYTE tmDefaultChar;
    BYTE tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
  } TEXTMETRICA,*PTEXTMETRICA,*NPTEXTMETRICA,*LPTEXTMETRICA;

  typedef struct tagTEXTMETRICW {
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    WCHAR tmFirstChar;
    WCHAR tmLastChar;
    WCHAR tmDefaultChar;
    WCHAR tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
  } TEXTMETRICW,*PTEXTMETRICW,*NPTEXTMETRICW,*LPTEXTMETRICW;

  typedef TEXTMETRICA TEXTMETRIC;
  typedef PTEXTMETRICA PTEXTMETRIC;
  typedef NPTEXTMETRICA NPTEXTMETRIC;
  typedef LPTEXTMETRICA LPTEXTMETRIC;







#pragma pack(pop)






#pragma pack(push,4)
 typedef struct tagNEWTEXTMETRICA {
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    BYTE tmFirstChar;
    BYTE tmLastChar;
    BYTE tmDefaultChar;
    BYTE tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
    DWORD ntmFlags;
    UINT ntmSizeEM;
    UINT ntmCellHeight;
    UINT ntmAvgWidth;
  } NEWTEXTMETRICA,*PNEWTEXTMETRICA,*NPNEWTEXTMETRICA,*LPNEWTEXTMETRICA;

  typedef struct tagNEWTEXTMETRICW {
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    WCHAR tmFirstChar;
    WCHAR tmLastChar;
    WCHAR tmDefaultChar;
    WCHAR tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
    DWORD ntmFlags;
    UINT ntmSizeEM;
    UINT ntmCellHeight;
    UINT ntmAvgWidth;
  } NEWTEXTMETRICW,*PNEWTEXTMETRICW,*NPNEWTEXTMETRICW,*LPNEWTEXTMETRICW;

  typedef NEWTEXTMETRICA NEWTEXTMETRIC;
  typedef PNEWTEXTMETRICA PNEWTEXTMETRIC;
  typedef NPNEWTEXTMETRICA NPNEWTEXTMETRIC;
  typedef LPNEWTEXTMETRICA LPNEWTEXTMETRIC;








#pragma pack(pop)

  typedef struct tagNEWTEXTMETRICEXA {
    NEWTEXTMETRICA ntmTm;
    FONTSIGNATURE ntmFontSig;
  } NEWTEXTMETRICEXA;

  typedef struct tagNEWTEXTMETRICEXW {
    NEWTEXTMETRICW ntmTm;
    FONTSIGNATURE ntmFontSig;
  } NEWTEXTMETRICEXW;

  typedef NEWTEXTMETRICEXA NEWTEXTMETRICEX;




  typedef struct tagPELARRAY {
    LONG paXCount;
    LONG paYCount;
    LONG paXExt;
    LONG paYExt;
    BYTE paRGBs;
  } PELARRAY,*PPELARRAY,*NPPELARRAY,*LPPELARRAY;


  typedef struct tagLOGBRUSH {
    UINT lbStyle;
    COLORREF lbColor;
    ULONG_PTR lbHatch;
  } LOGBRUSH,*PLOGBRUSH,*NPLOGBRUSH,*LPLOGBRUSH;

  typedef struct tagLOGBRUSH32 {
    UINT lbStyle;
    COLORREF lbColor;
    ULONG lbHatch;
  } LOGBRUSH32,*PLOGBRUSH32,*NPLOGBRUSH32,*LPLOGBRUSH32;


  typedef LOGBRUSH PATTERN;
  typedef PATTERN *PPATTERN;
  typedef PATTERN *NPPATTERN;
  typedef PATTERN *LPPATTERN;



  typedef struct tagLOGPEN {
    UINT lopnStyle;
    POINT lopnWidth;
    COLORREF lopnColor;
  } LOGPEN,*PLOGPEN,*NPLOGPEN,*LPLOGPEN;



  typedef struct tagEXTLOGPEN {
    DWORD elpPenStyle;
    DWORD elpWidth;
    UINT elpBrushStyle;
    COLORREF elpColor;
    ULONG_PTR elpHatch;
    DWORD elpNumEntries;
    DWORD elpStyleEntry[1];
  } EXTLOGPEN,*PEXTLOGPEN,*NPEXTLOGPEN,*LPEXTLOGPEN;



  typedef struct tagEXTLOGPEN32 {
    DWORD elpPenStyle;
    DWORD elpWidth;
    UINT elpBrushStyle;
    COLORREF elpColor;
    ULONG elpHatch;
    DWORD elpNumEntries;
    DWORD elpStyleEntry[1];
  } EXTLOGPEN32, *PEXTLOGPEN32, *NPEXTLOGPEN32, *LPEXTLOGPEN32;



  typedef struct tagPALETTEENTRY {
    BYTE peRed;
    BYTE peGreen;
    BYTE peBlue;
    BYTE peFlags;
  } PALETTEENTRY,*PPALETTEENTRY,*LPPALETTEENTRY;




  typedef struct tagLOGPALETTE {
    WORD palVersion;
    WORD palNumEntries;
    PALETTEENTRY palPalEntry[1];
  } LOGPALETTE,*PLOGPALETTE,*NPLOGPALETTE,*LPLOGPALETTE;






  typedef struct tagLOGFONTA {
    LONG lfHeight;
    LONG lfWidth;
    LONG lfEscapement;
    LONG lfOrientation;
    LONG lfWeight;
    BYTE lfItalic;
    BYTE lfUnderline;
    BYTE lfStrikeOut;
    BYTE lfCharSet;
    BYTE lfOutPrecision;
    BYTE lfClipPrecision;
    BYTE lfQuality;
    BYTE lfPitchAndFamily;
    CHAR lfFaceName[32];
  } LOGFONTA,*PLOGFONTA,*NPLOGFONTA,*LPLOGFONTA;

  typedef struct tagLOGFONTW {
    LONG lfHeight;
    LONG lfWidth;
    LONG lfEscapement;
    LONG lfOrientation;
    LONG lfWeight;
    BYTE lfItalic;
    BYTE lfUnderline;
    BYTE lfStrikeOut;
    BYTE lfCharSet;
    BYTE lfOutPrecision;
    BYTE lfClipPrecision;
    BYTE lfQuality;
    BYTE lfPitchAndFamily;
    WCHAR lfFaceName[32];
  } LOGFONTW,*PLOGFONTW,*NPLOGFONTW,*LPLOGFONTW;

  typedef LOGFONTA LOGFONT;
  typedef PLOGFONTA PLOGFONT;
  typedef NPLOGFONTA NPLOGFONT;
  typedef LPLOGFONTA LPLOGFONT;





  typedef struct tagENUMLOGFONTA {
    LOGFONTA elfLogFont;
    BYTE elfFullName[64];
    BYTE elfStyle[32];
  } ENUMLOGFONTA,*LPENUMLOGFONTA;

  typedef struct tagENUMLOGFONTW {
    LOGFONTW elfLogFont;
    WCHAR elfFullName[64];
    WCHAR elfStyle[32];
  } ENUMLOGFONTW,*LPENUMLOGFONTW;

  typedef ENUMLOGFONTA ENUMLOGFONT;
  typedef LPENUMLOGFONTA LPENUMLOGFONT;

  typedef struct tagENUMLOGFONTEXA {
    LOGFONTA elfLogFont;
    BYTE elfFullName[64];
    BYTE elfStyle[32];
    BYTE elfScript[32];
  } ENUMLOGFONTEXA,*LPENUMLOGFONTEXA;

  typedef struct tagENUMLOGFONTEXW {
    LOGFONTW elfLogFont;
    WCHAR elfFullName[64];
    WCHAR elfStyle[32];
    WCHAR elfScript[32];
  } ENUMLOGFONTEXW,*LPENUMLOGFONTEXW;

  typedef ENUMLOGFONTEXA ENUMLOGFONTEX;
  typedef LPENUMLOGFONTEXA LPENUMLOGFONTEX;
  typedef struct tagPANOSE {
    BYTE bFamilyType;
    BYTE bSerifStyle;
    BYTE bWeight;
    BYTE bProportion;
    BYTE bContrast;
    BYTE bStrokeVariation;
    BYTE bArmStyle;
    BYTE bLetterform;
    BYTE bMidline;
    BYTE bXHeight;
  } PANOSE,*LPPANOSE;
  typedef struct tagEXTLOGFONTA {
    LOGFONTA elfLogFont;
    BYTE elfFullName[64];
    BYTE elfStyle[32];
    DWORD elfVersion;
    DWORD elfStyleSize;
    DWORD elfMatch;
    DWORD elfReserved;
    BYTE elfVendorId[4];
    DWORD elfCulture;
    PANOSE elfPanose;
  } EXTLOGFONTA,*PEXTLOGFONTA,*NPEXTLOGFONTA,*LPEXTLOGFONTA;

  typedef struct tagEXTLOGFONTW {
    LOGFONTW elfLogFont;
    WCHAR elfFullName[64];
    WCHAR elfStyle[32];
    DWORD elfVersion;
    DWORD elfStyleSize;
    DWORD elfMatch;
    DWORD elfReserved;
    BYTE elfVendorId[4];
    DWORD elfCulture;
    PANOSE elfPanose;
  } EXTLOGFONTW,*PEXTLOGFONTW,*NPEXTLOGFONTW,*LPEXTLOGFONTW;

  typedef EXTLOGFONTA EXTLOGFONT;
  typedef PEXTLOGFONTA PEXTLOGFONT;
  typedef NPEXTLOGFONTA NPEXTLOGFONT;
  typedef LPEXTLOGFONTA LPEXTLOGFONT;
  typedef struct _devicemodeA {
    BYTE dmDeviceName[32];
    WORD dmSpecVersion;
    WORD dmDriverVersion;
    WORD dmSize;
    WORD dmDriverExtra;
    DWORD dmFields;
    __extension__ union {
      __extension__ struct {
 short dmOrientation;
 short dmPaperSize;
 short dmPaperLength;
 short dmPaperWidth;
 short dmScale;
 short dmCopies;
 short dmDefaultSource;
 short dmPrintQuality;
      };
      struct {
 POINTL dmPosition;
 DWORD dmDisplayOrientation;
 DWORD dmDisplayFixedOutput;
      };
    };
    short dmColor;
    short dmDuplex;
    short dmYResolution;
    short dmTTOption;
    short dmCollate;
    BYTE dmFormName[32];
    WORD dmLogPixels;
    DWORD dmBitsPerPel;
    DWORD dmPelsWidth;
    DWORD dmPelsHeight;
    __extension__ union {
      DWORD dmDisplayFlags;
      DWORD dmNup;
    };
    DWORD dmDisplayFrequency;
    DWORD dmICMMethod;
    DWORD dmICMIntent;
    DWORD dmMediaType;
    DWORD dmDitherType;
    DWORD dmReserved1;
    DWORD dmReserved2;
    DWORD dmPanningWidth;
    DWORD dmPanningHeight;
  } DEVMODEA,*PDEVMODEA,*NPDEVMODEA,*LPDEVMODEA;

  typedef struct _devicemodeW {
    WCHAR dmDeviceName[32];
    WORD dmSpecVersion;
    WORD dmDriverVersion;
    WORD dmSize;
    WORD dmDriverExtra;
    DWORD dmFields;
    __extension__ union {
      __extension__ struct {
 short dmOrientation;
 short dmPaperSize;
 short dmPaperLength;
 short dmPaperWidth;
 short dmScale;
 short dmCopies;
 short dmDefaultSource;
 short dmPrintQuality;
      };
      __extension__ struct {
 POINTL dmPosition;
 DWORD dmDisplayOrientation;
 DWORD dmDisplayFixedOutput;
      };
    };
    short dmColor;
    short dmDuplex;
    short dmYResolution;
    short dmTTOption;
    short dmCollate;
    WCHAR dmFormName[32];
    WORD dmLogPixels;
    DWORD dmBitsPerPel;
    DWORD dmPelsWidth;
    DWORD dmPelsHeight;
    __extension__ union {
      DWORD dmDisplayFlags;
      DWORD dmNup;
    };
    DWORD dmDisplayFrequency;
    DWORD dmICMMethod;
    DWORD dmICMIntent;
    DWORD dmMediaType;
    DWORD dmDitherType;
    DWORD dmReserved1;
    DWORD dmReserved2;
    DWORD dmPanningWidth;
    DWORD dmPanningHeight;
  } DEVMODEW,*PDEVMODEW,*NPDEVMODEW,*LPDEVMODEW;

  typedef DEVMODEA DEVMODE;
  typedef PDEVMODEA PDEVMODE;
  typedef NPDEVMODEA NPDEVMODE;
  typedef LPDEVMODEA LPDEVMODE;
  typedef struct _DISPLAY_DEVICEA {
    DWORD cb;
    CHAR DeviceName[32];
    CHAR DeviceString[128];
    DWORD StateFlags;
    CHAR DeviceID[128];
    CHAR DeviceKey[128];
  } DISPLAY_DEVICEA,*PDISPLAY_DEVICEA,*LPDISPLAY_DEVICEA;

  typedef struct _DISPLAY_DEVICEW {
    DWORD cb;
    WCHAR DeviceName[32];
    WCHAR DeviceString[128];
    DWORD StateFlags;
    WCHAR DeviceID[128];
    WCHAR DeviceKey[128];
  } DISPLAY_DEVICEW,*PDISPLAY_DEVICEW,*LPDISPLAY_DEVICEW;

  typedef DISPLAY_DEVICEA DISPLAY_DEVICE;
  typedef PDISPLAY_DEVICEA PDISPLAY_DEVICE;
  typedef LPDISPLAY_DEVICEA LPDISPLAY_DEVICE;
  typedef struct _RGNDATAHEADER {
    DWORD dwSize;
    DWORD iType;
    DWORD nCount;
    DWORD nRgnSize;
    RECT rcBound;
  } RGNDATAHEADER,*PRGNDATAHEADER;

  typedef struct _RGNDATA {
    RGNDATAHEADER rdh;
    char Buffer[1];
  } RGNDATA,*PRGNDATA,*NPRGNDATA,*LPRGNDATA;





  typedef struct _ABC {
    int abcA;
    UINT abcB;
    int abcC;
  } ABC,*PABC,*NPABC,*LPABC;

  typedef struct _ABCFLOAT {
    FLOAT abcfA;
    FLOAT abcfB;
    FLOAT abcfC;
  } ABCFLOAT,*PABCFLOAT,*NPABCFLOAT,*LPABCFLOAT;





  typedef struct _OUTLINETEXTMETRICA {
    UINT otmSize;
    TEXTMETRICA otmTextMetrics;
    BYTE otmFiller;
    PANOSE otmPanoseNumber;
    UINT otmfsSelection;
    UINT otmfsType;
    int otmsCharSlopeRise;
    int otmsCharSlopeRun;
    int otmItalicAngle;
    UINT otmEMSquare;
    int otmAscent;
    int otmDescent;
    UINT otmLineGap;
    UINT otmsCapEmHeight;
    UINT otmsXHeight;
    RECT otmrcFontBox;
    int otmMacAscent;
    int otmMacDescent;
    UINT otmMacLineGap;
    UINT otmusMinimumPPEM;
    POINT otmptSubscriptSize;
    POINT otmptSubscriptOffset;
    POINT otmptSuperscriptSize;
    POINT otmptSuperscriptOffset;
    UINT otmsStrikeoutSize;
    int otmsStrikeoutPosition;
    int otmsUnderscoreSize;
    int otmsUnderscorePosition;
    PSTR otmpFamilyName;
    PSTR otmpFaceName;
    PSTR otmpStyleName;
    PSTR otmpFullName;
  } OUTLINETEXTMETRICA,*POUTLINETEXTMETRICA,*NPOUTLINETEXTMETRICA,*LPOUTLINETEXTMETRICA;

  typedef struct _OUTLINETEXTMETRICW {
    UINT otmSize;
    TEXTMETRICW otmTextMetrics;
    BYTE otmFiller;
    PANOSE otmPanoseNumber;
    UINT otmfsSelection;
    UINT otmfsType;
    int otmsCharSlopeRise;
    int otmsCharSlopeRun;
    int otmItalicAngle;
    UINT otmEMSquare;
    int otmAscent;
    int otmDescent;
    UINT otmLineGap;
    UINT otmsCapEmHeight;
    UINT otmsXHeight;
    RECT otmrcFontBox;
    int otmMacAscent;
    int otmMacDescent;
    UINT otmMacLineGap;
    UINT otmusMinimumPPEM;
    POINT otmptSubscriptSize;
    POINT otmptSubscriptOffset;
    POINT otmptSuperscriptSize;
    POINT otmptSuperscriptOffset;
    UINT otmsStrikeoutSize;
    int otmsStrikeoutPosition;
    int otmsUnderscoreSize;
    int otmsUnderscorePosition;
    PSTR otmpFamilyName;
    PSTR otmpFaceName;
    PSTR otmpStyleName;
    PSTR otmpFullName;
  } OUTLINETEXTMETRICW,*POUTLINETEXTMETRICW,*NPOUTLINETEXTMETRICW,*LPOUTLINETEXTMETRICW;

  typedef OUTLINETEXTMETRICA OUTLINETEXTMETRIC;
  typedef POUTLINETEXTMETRICA POUTLINETEXTMETRIC;
  typedef NPOUTLINETEXTMETRICA NPOUTLINETEXTMETRIC;
  typedef LPOUTLINETEXTMETRICA LPOUTLINETEXTMETRIC;




  typedef struct tagPOLYTEXTA {
    int x;
    int y;
    UINT n;
    LPCSTR lpstr;
    UINT uiFlags;
    RECT rcl;
    int *pdx;
  } POLYTEXTA,*PPOLYTEXTA,*NPPOLYTEXTA,*LPPOLYTEXTA;

  typedef struct tagPOLYTEXTW {
    int x;
    int y;
    UINT n;
    LPCWSTR lpstr;
    UINT uiFlags;
    RECT rcl;
    int *pdx;
  } POLYTEXTW,*PPOLYTEXTW,*NPPOLYTEXTW,*LPPOLYTEXTW;

  typedef POLYTEXTA POLYTEXT;
  typedef PPOLYTEXTA PPOLYTEXT;
  typedef NPPOLYTEXTA NPPOLYTEXT;
  typedef LPPOLYTEXTA LPPOLYTEXT;



  typedef struct _FIXED {
    WORD fract;
    short value;
  } FIXED;

  typedef struct _MAT2 {
    FIXED eM11;
    FIXED eM12;
    FIXED eM21;
    FIXED eM22;
  } MAT2,*LPMAT2;

  typedef struct _GLYPHMETRICS {
    UINT gmBlackBoxX;
    UINT gmBlackBoxY;
    POINT gmptGlyphOrigin;
    short gmCellIncX;
    short gmCellIncY;
  } GLYPHMETRICS,*LPGLYPHMETRICS;
  typedef struct tagPOINTFX {
    FIXED x;
    FIXED y;
  } POINTFX,*LPPOINTFX;

  typedef struct tagTTPOLYCURVE {
    WORD wType;
    WORD cpfx;
    POINTFX apfx[1];
  } TTPOLYCURVE,*LPTTPOLYCURVE;

  typedef struct tagTTPOLYGONHEADER {
    DWORD cb;
    DWORD dwType;
    POINTFX pfxStart;
  } TTPOLYGONHEADER,*LPTTPOLYGONHEADER;
  typedef struct tagGCP_RESULTSA {
    DWORD lStructSize;
    LPSTR lpOutString;
    UINT *lpOrder;
    int *lpDx;
    int *lpCaretPos;
    LPSTR lpClass;
    LPWSTR lpGlyphs;
    UINT nGlyphs;
    int nMaxFit;
  } GCP_RESULTSA,*LPGCP_RESULTSA;
  typedef struct tagGCP_RESULTSW {
    DWORD lStructSize;
    LPWSTR lpOutString;
    UINT *lpOrder;
    int *lpDx;
    int *lpCaretPos;
    LPSTR lpClass;
    LPWSTR lpGlyphs;
    UINT nGlyphs;
    int nMaxFit;
  } GCP_RESULTSW,*LPGCP_RESULTSW;

  typedef GCP_RESULTSA GCP_RESULTS;
  typedef LPGCP_RESULTSA LPGCP_RESULTS;

  typedef struct _RASTERIZER_STATUS {
    short nSize;
    short wFlags;
    short nLanguageID;
  } RASTERIZER_STATUS,*LPRASTERIZER_STATUS;






  typedef struct tagPIXELFORMATDESCRIPTOR {
    WORD nSize;
    WORD nVersion;
    DWORD dwFlags;
    BYTE iPixelType;
    BYTE cColorBits;
    BYTE cRedBits;
    BYTE cRedShift;
    BYTE cGreenBits;
    BYTE cGreenShift;
    BYTE cBlueBits;
    BYTE cBlueShift;
    BYTE cAlphaBits;
    BYTE cAlphaShift;
    BYTE cAccumBits;
    BYTE cAccumRedBits;
    BYTE cAccumGreenBits;
    BYTE cAccumBlueBits;
    BYTE cAccumAlphaBits;
    BYTE cDepthBits;
    BYTE cStencilBits;
    BYTE cAuxBuffers;
    BYTE iLayerType;
    BYTE bReserved;
    DWORD dwLayerMask;
    DWORD dwVisibleMask;
    DWORD dwDamageMask;
  } PIXELFORMATDESCRIPTOR,*PPIXELFORMATDESCRIPTOR,*LPPIXELFORMATDESCRIPTOR;
  typedef int ( *OLDFONTENUMPROCA)(const LOGFONTA *,const TEXTMETRICA *,DWORD,LPARAM);
  typedef int ( *OLDFONTENUMPROCW)(const LOGFONTW *,const TEXTMETRICW *,DWORD,LPARAM);
  typedef OLDFONTENUMPROCA FONTENUMPROCA;
  typedef OLDFONTENUMPROCW FONTENUMPROCW;

  typedef FONTENUMPROCA FONTENUMPROC;

  typedef int ( *GOBJENUMPROC)(LPVOID,LPARAM);
  typedef void ( *LINEDDAPROC)(int,int,LPARAM);
  __attribute__((dllimport)) int AddFontResourceA(LPCSTR);
  __attribute__((dllimport)) int AddFontResourceW(LPCWSTR);
  __attribute__((dllimport)) WINBOOL AnimatePalette(HPALETTE hPal,UINT iStartIndex,UINT cEntries,const PALETTEENTRY *ppe);
  __attribute__((dllimport)) WINBOOL Arc(HDC hdc,int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4);
  __attribute__((dllimport)) WINBOOL BitBlt(HDC hdc,int x,int y,int cx,int cy,HDC hdcSrc,int x1,int y1,DWORD rop);
  __attribute__((dllimport)) WINBOOL CancelDC(HDC hdc);
  __attribute__((dllimport)) WINBOOL Chord(HDC hdc,int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4);
  __attribute__((dllimport)) int ChoosePixelFormat(HDC hdc,const PIXELFORMATDESCRIPTOR *ppfd);
  __attribute__((dllimport)) HMETAFILE CloseMetaFile(HDC hdc);
  __attribute__((dllimport)) int CombineRgn(HRGN hrgnDst,HRGN hrgnSrc1,HRGN hrgnSrc2,int iMode);
  __attribute__((dllimport)) HMETAFILE CopyMetaFileA(HMETAFILE,LPCSTR);
  __attribute__((dllimport)) HMETAFILE CopyMetaFileW(HMETAFILE,LPCWSTR);
  __attribute__((dllimport)) HBITMAP CreateBitmap(int nWidth,int nHeight,UINT nPlanes,UINT nBitCount,const void *lpBits);
  __attribute__((dllimport)) HBITMAP CreateBitmapIndirect(const BITMAP *pbm);
  __attribute__((dllimport)) HBRUSH CreateBrushIndirect(const LOGBRUSH *plbrush);
  __attribute__((dllimport)) HBITMAP CreateCompatibleBitmap(HDC hdc,int cx,int cy);
  __attribute__((dllimport)) HBITMAP CreateDiscardableBitmap(HDC hdc,int cx,int cy);
  __attribute__((dllimport)) HDC CreateCompatibleDC(HDC hdc);
  __attribute__((dllimport)) HDC CreateDCA(LPCSTR pwszDriver,LPCSTR pwszDevice,LPCSTR pszPort,const DEVMODEA *pdm);
  __attribute__((dllimport)) HDC CreateDCW(LPCWSTR pwszDriver,LPCWSTR pwszDevice,LPCWSTR pszPort,const DEVMODEW *pdm);
  __attribute__((dllimport)) HBITMAP CreateDIBitmap(HDC hdc,const BITMAPINFOHEADER *pbmih,DWORD flInit,const void *pjBits,const BITMAPINFO *pbmi,UINT iUsage);
  __attribute__((dllimport)) HBRUSH CreateDIBPatternBrush(HGLOBAL h,UINT iUsage);
  __attribute__((dllimport)) HBRUSH CreateDIBPatternBrushPt(const void *lpPackedDIB,UINT iUsage);
  __attribute__((dllimport)) HRGN CreateEllipticRgn(int x1,int y1,int x2,int y2);
  __attribute__((dllimport)) HRGN CreateEllipticRgnIndirect(const RECT *lprect);
  __attribute__((dllimport)) HFONT CreateFontIndirectA(const LOGFONTA *lplf);
  __attribute__((dllimport)) HFONT CreateFontIndirectW(const LOGFONTW *lplf);
  __attribute__((dllimport)) HFONT CreateFontA(int cHeight,int cWidth,int cEscapement,int cOrientation,int cWeight,DWORD bItalic,DWORD bUnderline,DWORD bStrikeOut,DWORD iCharSet,DWORD iOutPrecision,DWORD iClipPrecision,DWORD iQuality,DWORD iPitchAndFamily,LPCSTR pszFaceName);
  __attribute__((dllimport)) HFONT CreateFontW(int cHeight,int cWidth,int cEscapement,int cOrientation,int cWeight,DWORD bItalic,DWORD bUnderline,DWORD bStrikeOut,DWORD iCharSet,DWORD iOutPrecision,DWORD iClipPrecision,DWORD iQuality,DWORD iPitchAndFamily,LPCWSTR pszFaceName);
  __attribute__((dllimport)) HBRUSH CreateHatchBrush(int iHatch,COLORREF color);
  __attribute__((dllimport)) HDC CreateICA(LPCSTR pszDriver,LPCSTR pszDevice,LPCSTR pszPort,const DEVMODEA *pdm);
  __attribute__((dllimport)) HDC CreateICW(LPCWSTR pszDriver,LPCWSTR pszDevice,LPCWSTR pszPort,const DEVMODEW *pdm);
  __attribute__((dllimport)) HDC CreateMetaFileA(LPCSTR pszFile);
  __attribute__((dllimport)) HDC CreateMetaFileW(LPCWSTR pszFile);
  __attribute__((dllimport)) HPALETTE CreatePalette(const LOGPALETTE *plpal);
  __attribute__((dllimport)) HPEN CreatePen(int iStyle,int cWidth,COLORREF color);
  __attribute__((dllimport)) HPEN CreatePenIndirect(const LOGPEN *plpen);
  __attribute__((dllimport)) HRGN CreatePolyPolygonRgn(const POINT *pptl,const INT *pc,int cPoly,int iMode);
  __attribute__((dllimport)) HBRUSH CreatePatternBrush(HBITMAP hbm);
  __attribute__((dllimport)) HRGN CreateRectRgn(int x1,int y1,int x2,int y2);
  __attribute__((dllimport)) HRGN CreateRectRgnIndirect(const RECT *lprect);
  __attribute__((dllimport)) HRGN CreateRoundRectRgn(int x1,int y1,int x2,int y2,int w,int h);
  __attribute__((dllimport)) WINBOOL CreateScalableFontResourceA(DWORD fdwHidden,LPCSTR lpszFont,LPCSTR lpszFile,LPCSTR lpszPath);
  __attribute__((dllimport)) WINBOOL CreateScalableFontResourceW(DWORD fdwHidden,LPCWSTR lpszFont,LPCWSTR lpszFile,LPCWSTR lpszPath);
  __attribute__((dllimport)) HBRUSH CreateSolidBrush(COLORREF color);
  __attribute__((dllimport)) WINBOOL DeleteDC(HDC hdc);
  __attribute__((dllimport)) WINBOOL DeleteMetaFile(HMETAFILE hmf);
  __attribute__((dllimport)) WINBOOL DeleteObject(HGDIOBJ ho);
  __attribute__((dllimport)) int DescribePixelFormat(HDC hdc,int iPixelFormat,UINT nBytes,LPPIXELFORMATDESCRIPTOR ppfd);

  typedef UINT ( *LPFNDEVMODE)(HWND,HMODULE,LPDEVMODE,LPSTR,LPSTR,LPDEVMODE,LPSTR,UINT);
  typedef DWORD ( *LPFNDEVCAPS)(LPSTR,LPSTR,UINT,LPSTR,LPDEVMODE);
  __attribute__((dllimport)) int DeviceCapabilitiesA(LPCSTR pDevice,LPCSTR pPort,WORD fwCapability,LPSTR pOutput,const DEVMODEA *pDevMode);
  __attribute__((dllimport)) int DeviceCapabilitiesW(LPCWSTR pDevice,LPCWSTR pPort,WORD fwCapability,LPWSTR pOutput,const DEVMODEW *pDevMode);
  __attribute__((dllimport)) int DrawEscape(HDC hdc,int iEscape,int cjIn,LPCSTR lpIn);
  __attribute__((dllimport)) WINBOOL Ellipse(HDC hdc,int left,int top,int right,int bottom);
  __attribute__((dllimport)) int EnumFontFamiliesExA(HDC hdc,LPLOGFONTA lpLogfont,FONTENUMPROCA lpProc,LPARAM lParam,DWORD dwFlags);
  __attribute__((dllimport)) int EnumFontFamiliesExW(HDC hdc,LPLOGFONTW lpLogfont,FONTENUMPROCW lpProc,LPARAM lParam,DWORD dwFlags);
  __attribute__((dllimport)) int EnumFontFamiliesA(HDC hdc,LPCSTR lpLogfont,FONTENUMPROCA lpProc,LPARAM lParam);
  __attribute__((dllimport)) int EnumFontFamiliesW(HDC hdc,LPCWSTR lpLogfont,FONTENUMPROCW lpProc,LPARAM lParam);
  __attribute__((dllimport)) int EnumFontsA(HDC hdc,LPCSTR lpLogfont,FONTENUMPROCA lpProc,LPARAM lParam);
  __attribute__((dllimport)) int EnumFontsW(HDC hdc,LPCWSTR lpLogfont,FONTENUMPROCW lpProc,LPARAM lParam);
  __attribute__((dllimport)) int EnumObjects(HDC hdc,int nType,GOBJENUMPROC lpFunc,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EqualRgn(HRGN hrgn1,HRGN hrgn2);
  __attribute__((dllimport)) int Escape(HDC hdc,int iEscape,int cjIn,LPCSTR pvIn,LPVOID pvOut);
  __attribute__((dllimport)) int ExtEscape(HDC hdc,int iEscape,int cjInput,LPCSTR lpInData,int cjOutput,LPSTR lpOutData);
  __attribute__((dllimport)) int ExcludeClipRect(HDC hdc,int left,int top,int right,int bottom);
  __attribute__((dllimport)) HRGN ExtCreateRegion(const XFORM *lpx,DWORD nCount,const RGNDATA *lpData);
  __attribute__((dllimport)) WINBOOL ExtFloodFill(HDC hdc,int x,int y,COLORREF color,UINT type);
  __attribute__((dllimport)) WINBOOL FillRgn(HDC hdc,HRGN hrgn,HBRUSH hbr);
  __attribute__((dllimport)) WINBOOL FloodFill(HDC hdc,int x,int y,COLORREF color);
  __attribute__((dllimport)) WINBOOL FrameRgn(HDC hdc,HRGN hrgn,HBRUSH hbr,int w,int h);
  __attribute__((dllimport)) int GetROP2(HDC hdc);
  __attribute__((dllimport)) WINBOOL GetAspectRatioFilterEx(HDC hdc,LPSIZE lpsize);
  __attribute__((dllimport)) COLORREF GetBkColor(HDC hdc);
  __attribute__((dllimport)) COLORREF GetDCBrushColor(HDC hdc);
  __attribute__((dllimport)) COLORREF GetDCPenColor(HDC hdc);
  __attribute__((dllimport)) int GetBkMode(HDC hdc);
  __attribute__((dllimport)) LONG GetBitmapBits(HBITMAP hbit,LONG cb,LPVOID lpvBits);
  __attribute__((dllimport)) WINBOOL GetBitmapDimensionEx(HBITMAP hbit,LPSIZE lpsize);
  __attribute__((dllimport)) UINT GetBoundsRect(HDC hdc,LPRECT lprect,UINT flags);
  __attribute__((dllimport)) WINBOOL GetBrushOrgEx(HDC hdc,LPPOINT lppt);
  __attribute__((dllimport)) WINBOOL GetCharWidthA(HDC hdc,UINT iFirst,UINT iLast,LPINT lpBuffer);
  __attribute__((dllimport)) WINBOOL GetCharWidthW(HDC hdc,UINT iFirst,UINT iLast,LPINT lpBuffer);
  __attribute__((dllimport)) WINBOOL GetCharWidth32A(HDC hdc,UINT iFirst,UINT iLast,LPINT lpBuffer);
  __attribute__((dllimport)) WINBOOL GetCharWidth32W(HDC hdc,UINT iFirst,UINT iLast,LPINT lpBuffer);
  __attribute__((dllimport)) WINBOOL GetCharWidthFloatA(HDC hdc,UINT iFirst,UINT iLast,PFLOAT lpBuffer);
  __attribute__((dllimport)) WINBOOL GetCharWidthFloatW(HDC hdc,UINT iFirst,UINT iLast,PFLOAT lpBuffer);
  __attribute__((dllimport)) WINBOOL GetCharABCWidthsA(HDC hdc,UINT wFirst,UINT wLast,LPABC lpABC);
  __attribute__((dllimport)) WINBOOL GetCharABCWidthsW(HDC hdc,UINT wFirst,UINT wLast,LPABC lpABC);
  __attribute__((dllimport)) WINBOOL GetCharABCWidthsFloatA(HDC hdc,UINT iFirst,UINT iLast,LPABCFLOAT lpABC);
  __attribute__((dllimport)) WINBOOL GetCharABCWidthsFloatW(HDC hdc,UINT iFirst,UINT iLast,LPABCFLOAT lpABC);
  __attribute__((dllimport)) int GetClipBox(HDC hdc,LPRECT lprect);
  __attribute__((dllimport)) int GetClipRgn(HDC hdc,HRGN hrgn);
  __attribute__((dllimport)) int GetMetaRgn(HDC hdc,HRGN hrgn);
  __attribute__((dllimport)) HGDIOBJ GetCurrentObject(HDC hdc,UINT type);
  __attribute__((dllimport)) WINBOOL GetCurrentPositionEx(HDC hdc,LPPOINT lppt);
  __attribute__((dllimport)) int GetDeviceCaps(HDC hdc,int index);
  __attribute__((dllimport)) int GetDIBits(HDC hdc,HBITMAP hbm,UINT start,UINT cLines,LPVOID lpvBits,LPBITMAPINFO lpbmi,UINT usage);
  __attribute__((dllimport)) DWORD GetFontData (HDC hdc,DWORD dwTable,DWORD dwOffset,PVOID pvBuffer,DWORD cjBuffer);
  __attribute__((dllimport)) DWORD GetGlyphOutlineA(HDC hdc,UINT uChar,UINT fuFormat,LPGLYPHMETRICS lpgm,DWORD cjBuffer,LPVOID pvBuffer,const MAT2 *lpmat2);
  __attribute__((dllimport)) DWORD GetGlyphOutlineW(HDC hdc,UINT uChar,UINT fuFormat,LPGLYPHMETRICS lpgm,DWORD cjBuffer,LPVOID pvBuffer,const MAT2 *lpmat2);
  __attribute__((dllimport)) int GetGraphicsMode(HDC hdc);
  __attribute__((dllimport)) int GetMapMode(HDC hdc);
  __attribute__((dllimport)) UINT GetMetaFileBitsEx(HMETAFILE hMF,UINT cbBuffer,LPVOID lpData);
  __attribute__((dllimport)) HMETAFILE GetMetaFileA(LPCSTR lpName);
  __attribute__((dllimport)) HMETAFILE GetMetaFileW(LPCWSTR lpName);
  __attribute__((dllimport)) COLORREF GetNearestColor(HDC hdc,COLORREF color);
  __attribute__((dllimport)) UINT GetNearestPaletteIndex(HPALETTE h,COLORREF color);
  __attribute__((dllimport)) DWORD GetObjectType(HGDIOBJ h);





  __attribute__((dllimport)) UINT GetOutlineTextMetricsA(HDC hdc,UINT cjCopy,LPOUTLINETEXTMETRICA potm);
  __attribute__((dllimport)) UINT GetOutlineTextMetricsW(HDC hdc,UINT cjCopy,LPOUTLINETEXTMETRICW potm);







  __attribute__((dllimport)) UINT GetPaletteEntries(HPALETTE hpal,UINT iStart,UINT cEntries,LPPALETTEENTRY pPalEntries);
  __attribute__((dllimport)) COLORREF GetPixel(HDC hdc,int x,int y);
  __attribute__((dllimport)) int GetPixelFormat(HDC hdc);
  __attribute__((dllimport)) int GetPolyFillMode(HDC hdc);
  __attribute__((dllimport)) WINBOOL GetRasterizerCaps(LPRASTERIZER_STATUS lpraststat,UINT cjBytes);
  __attribute__((dllimport)) int GetRandomRgn (HDC hdc,HRGN hrgn,INT i);
  __attribute__((dllimport)) DWORD GetRegionData(HRGN hrgn,DWORD nCount,LPRGNDATA lpRgnData);
  __attribute__((dllimport)) int GetRgnBox(HRGN hrgn,LPRECT lprc);
  __attribute__((dllimport)) HGDIOBJ GetStockObject(int i);
  __attribute__((dllimport)) int GetStretchBltMode(HDC hdc);
  __attribute__((dllimport)) UINT GetSystemPaletteEntries(HDC hdc,UINT iStart,UINT cEntries,LPPALETTEENTRY pPalEntries);
  __attribute__((dllimport)) UINT GetSystemPaletteUse(HDC hdc);
  __attribute__((dllimport)) int GetTextCharacterExtra(HDC hdc);
  __attribute__((dllimport)) UINT GetTextAlign(HDC hdc);
  __attribute__((dllimport)) COLORREF GetTextColor(HDC hdc);
  __attribute__((dllimport)) WINBOOL GetTextExtentPointA(HDC hdc,LPCSTR lpString,int c,LPSIZE lpsz);
  __attribute__((dllimport)) WINBOOL GetTextExtentPointW(HDC hdc,LPCWSTR lpString,int c,LPSIZE lpsz);
  __attribute__((dllimport)) WINBOOL GetTextExtentPoint32A(HDC hdc,LPCSTR lpString,int c,LPSIZE psizl);
  __attribute__((dllimport)) WINBOOL GetTextExtentPoint32W(HDC hdc,LPCWSTR lpString,int c,LPSIZE psizl);
  __attribute__((dllimport)) WINBOOL GetTextExtentExPointA(HDC hdc,LPCSTR lpszString,int cchString,int nMaxExtent,LPINT lpnFit,LPINT lpnDx,LPSIZE lpSize);
  __attribute__((dllimport)) WINBOOL GetTextExtentExPointW(HDC hdc,LPCWSTR lpszString,int cchString,int nMaxExtent,LPINT lpnFit,LPINT lpnDx,LPSIZE lpSize);
  __attribute__((dllimport)) int GetTextCharset(HDC hdc);
  __attribute__((dllimport)) int GetTextCharsetInfo(HDC hdc,LPFONTSIGNATURE lpSig,DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL TranslateCharsetInfo(DWORD *lpSrc,LPCHARSETINFO lpCs,DWORD dwFlags);
  __attribute__((dllimport)) DWORD GetFontLanguageInfo(HDC hdc);
  __attribute__((dllimport)) DWORD GetCharacterPlacementA(HDC hdc,LPCSTR lpString,int nCount,int nMexExtent,LPGCP_RESULTSA lpResults,DWORD dwFlags);
  __attribute__((dllimport)) DWORD GetCharacterPlacementW(HDC hdc,LPCWSTR lpString,int nCount,int nMexExtent,LPGCP_RESULTSW lpResults,DWORD dwFlags);

  typedef struct tagWCRANGE {
    WCHAR wcLow;
    USHORT cGlyphs;
  } WCRANGE,*PWCRANGE,*LPWCRANGE;

  typedef struct tagGLYPHSET {
    DWORD cbThis;
    DWORD flAccel;
    DWORD cGlyphsSupported;
    DWORD cRanges;
    WCRANGE ranges[1];
  } GLYPHSET,*PGLYPHSET,*LPGLYPHSET;







  __attribute__((dllimport)) DWORD GetFontUnicodeRanges(HDC hdc,LPGLYPHSET lpgs);
  __attribute__((dllimport)) DWORD GetGlyphIndicesA(HDC hdc,LPCSTR lpstr,int c,LPWORD pgi,DWORD fl);
  __attribute__((dllimport)) DWORD GetGlyphIndicesW(HDC hdc,LPCWSTR lpstr,int c,LPWORD pgi,DWORD fl);
  __attribute__((dllimport)) WINBOOL GetTextExtentPointI(HDC hdc,LPWORD pgiIn,int cgi,LPSIZE psize);
  __attribute__((dllimport)) WINBOOL GetTextExtentExPointI (HDC hdc,LPWORD lpwszString,int cwchString,int nMaxExtent,LPINT lpnFit,LPINT lpnDx,LPSIZE lpSize);
  __attribute__((dllimport)) WINBOOL GetCharWidthI(HDC hdc,UINT giFirst,UINT cgi,LPWORD pgi,LPINT piWidths);
  __attribute__((dllimport)) WINBOOL GetCharABCWidthsI(HDC hdc,UINT giFirst,UINT cgi,LPWORD pgi,LPABC pabc);





  typedef struct tagDESIGNVECTOR {
    DWORD dvReserved;
    DWORD dvNumAxes;
    LONG dvValues[16];
  } DESIGNVECTOR,*PDESIGNVECTOR,*LPDESIGNVECTOR;




  __attribute__((dllimport)) int AddFontResourceExA(LPCSTR name,DWORD fl,PVOID res);
  __attribute__((dllimport)) int AddFontResourceExW(LPCWSTR name,DWORD fl,PVOID res);
  __attribute__((dllimport)) WINBOOL RemoveFontResourceExA(LPCSTR name,DWORD fl,PVOID pdv);
  __attribute__((dllimport)) WINBOOL RemoveFontResourceExW(LPCWSTR name,DWORD fl,PVOID pdv);
  __attribute__((dllimport)) HANDLE AddFontMemResourceEx(PVOID pFileView,DWORD cjSize,PVOID pvResrved,DWORD *pNumFonts);
  __attribute__((dllimport)) WINBOOL RemoveFontMemResourceEx(HANDLE h);






  typedef struct tagAXISINFOA {
    LONG axMinValue;
    LONG axMaxValue;
    BYTE axAxisName[16];
  } AXISINFOA,*PAXISINFOA,*LPAXISINFOA;

  typedef struct tagAXISINFOW {
    LONG axMinValue;
    LONG axMaxValue;
    WCHAR axAxisName[16];
  } AXISINFOW,*PAXISINFOW,*LPAXISINFOW;

  typedef AXISINFOA AXISINFO;
  typedef PAXISINFOA PAXISINFO;
  typedef LPAXISINFOA LPAXISINFO;

  typedef struct tagAXESLISTA {
    DWORD axlReserved;
    DWORD axlNumAxes;
    AXISINFOA axlAxisInfo[16];
  } AXESLISTA,*PAXESLISTA,*LPAXESLISTA;

  typedef struct tagAXESLISTW {
    DWORD axlReserved;
    DWORD axlNumAxes;
    AXISINFOW axlAxisInfo[16];
  } AXESLISTW,*PAXESLISTW,*LPAXESLISTW;

  typedef AXESLISTA AXESLIST;
  typedef PAXESLISTA PAXESLIST;
  typedef LPAXESLISTA LPAXESLIST;

  typedef struct tagENUMLOGFONTEXDVA {
    ENUMLOGFONTEXA elfEnumLogfontEx;
    DESIGNVECTOR elfDesignVector;
  } ENUMLOGFONTEXDVA,*PENUMLOGFONTEXDVA,*LPENUMLOGFONTEXDVA;

  typedef struct tagENUMLOGFONTEXDVW {
    ENUMLOGFONTEXW elfEnumLogfontEx;
    DESIGNVECTOR elfDesignVector;
  } ENUMLOGFONTEXDVW,*PENUMLOGFONTEXDVW,*LPENUMLOGFONTEXDVW;

  typedef ENUMLOGFONTEXDVA ENUMLOGFONTEXDV;
  typedef PENUMLOGFONTEXDVA PENUMLOGFONTEXDV;
  typedef LPENUMLOGFONTEXDVA LPENUMLOGFONTEXDV;



  __attribute__((dllimport)) HFONT CreateFontIndirectExA(const ENUMLOGFONTEXDVA *);
  __attribute__((dllimport)) HFONT CreateFontIndirectExW(const ENUMLOGFONTEXDVW *);


  typedef struct tagENUMTEXTMETRICA {
    NEWTEXTMETRICEXA etmNewTextMetricEx;
    AXESLISTA etmAxesList;
  } ENUMTEXTMETRICA,*PENUMTEXTMETRICA,*LPENUMTEXTMETRICA;
  typedef struct tagENUMTEXTMETRICW
  {
    NEWTEXTMETRICEXW etmNewTextMetricEx;
    AXESLISTW etmAxesList;
  } ENUMTEXTMETRICW,*PENUMTEXTMETRICW,*LPENUMTEXTMETRICW;

  typedef ENUMTEXTMETRICA ENUMTEXTMETRIC;
  typedef PENUMTEXTMETRICA PENUMTEXTMETRIC;
  typedef LPENUMTEXTMETRICA LPENUMTEXTMETRIC;





  __attribute__((dllimport)) WINBOOL GetViewportExtEx(HDC hdc,LPSIZE lpsize);
  __attribute__((dllimport)) WINBOOL GetViewportOrgEx(HDC hdc,LPPOINT lppoint);
  __attribute__((dllimport)) WINBOOL GetWindowExtEx(HDC hdc,LPSIZE lpsize);
  __attribute__((dllimport)) WINBOOL GetWindowOrgEx(HDC hdc,LPPOINT lppoint);
  __attribute__((dllimport)) int IntersectClipRect(HDC hdc,int left,int top,int right,int bottom);
  __attribute__((dllimport)) WINBOOL InvertRgn(HDC hdc,HRGN hrgn);
  __attribute__((dllimport)) WINBOOL LineDDA(int xStart,int yStart,int xEnd,int yEnd,LINEDDAPROC lpProc,LPARAM data);
  __attribute__((dllimport)) WINBOOL LineTo(HDC hdc,int x,int y);
  __attribute__((dllimport)) WINBOOL MaskBlt(HDC hdcDest,int xDest,int yDest,int width,int height,HDC hdcSrc,int xSrc,int ySrc,HBITMAP hbmMask,int xMask,int yMask,DWORD rop);
  __attribute__((dllimport)) WINBOOL PlgBlt(HDC hdcDest,const POINT *lpPoint,HDC hdcSrc,int xSrc,int ySrc,int width,int height,HBITMAP hbmMask,int xMask,int yMask);
  __attribute__((dllimport)) int OffsetClipRgn(HDC hdc,int x,int y);
  __attribute__((dllimport)) int OffsetRgn(HRGN hrgn,int x,int y);
  __attribute__((dllimport)) WINBOOL PatBlt(HDC hdc,int x,int y,int w,int h,DWORD rop);
  __attribute__((dllimport)) WINBOOL Pie(HDC hdc,int left,int top,int right,int bottom,int xr1,int yr1,int xr2,int yr2);
  __attribute__((dllimport)) WINBOOL PlayMetaFile(HDC hdc,HMETAFILE hmf);
  __attribute__((dllimport)) WINBOOL PaintRgn(HDC hdc,HRGN hrgn);
  __attribute__((dllimport)) WINBOOL PolyPolygon(HDC hdc,const POINT *apt,const INT *asz,int csz);
  __attribute__((dllimport)) WINBOOL PtInRegion(HRGN hrgn,int x,int y);
  __attribute__((dllimport)) WINBOOL PtVisible(HDC hdc,int x,int y);
  __attribute__((dllimport)) WINBOOL RectInRegion(HRGN hrgn,const RECT *lprect);
  __attribute__((dllimport)) WINBOOL RectVisible(HDC hdc,const RECT *lprect);
  __attribute__((dllimport)) WINBOOL Rectangle(HDC hdc,int left,int top,int right,int bottom);
  __attribute__((dllimport)) WINBOOL RestoreDC(HDC hdc,int nSavedDC);
  __attribute__((dllimport)) HDC ResetDCA(HDC hdc,const DEVMODEA *lpdm);
  __attribute__((dllimport)) HDC ResetDCW(HDC hdc,const DEVMODEW *lpdm);
  __attribute__((dllimport)) UINT RealizePalette(HDC hdc);
  __attribute__((dllimport)) WINBOOL RemoveFontResourceA(LPCSTR lpFileName);
  __attribute__((dllimport)) WINBOOL RemoveFontResourceW(LPCWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL RoundRect(HDC hdc,int left,int top,int right,int bottom,int width,int height);
  __attribute__((dllimport)) WINBOOL ResizePalette(HPALETTE hpal,UINT n);
  __attribute__((dllimport)) int SaveDC(HDC hdc);
  __attribute__((dllimport)) int SelectClipRgn(HDC hdc,HRGN hrgn);
  __attribute__((dllimport)) int ExtSelectClipRgn(HDC hdc,HRGN hrgn,int mode);
  __attribute__((dllimport)) int SetMetaRgn(HDC hdc);
  __attribute__((dllimport)) HGDIOBJ SelectObject(HDC hdc,HGDIOBJ h);
  __attribute__((dllimport)) HPALETTE SelectPalette(HDC hdc,HPALETTE hPal,WINBOOL bForceBkgd);
  __attribute__((dllimport)) COLORREF SetBkColor(HDC hdc,COLORREF color);
  __attribute__((dllimport)) COLORREF SetDCBrushColor(HDC hdc,COLORREF color);
  __attribute__((dllimport)) COLORREF SetDCPenColor(HDC hdc,COLORREF color);
  __attribute__((dllimport)) int SetBkMode(HDC hdc,int mode);
  __attribute__((dllimport)) LONG SetBitmapBits(HBITMAP hbm,DWORD cb,const void *pvBits);
  __attribute__((dllimport)) UINT SetBoundsRect(HDC hdc,const RECT *lprect,UINT flags);
  __attribute__((dllimport)) int SetDIBits(HDC hdc,HBITMAP hbm,UINT start,UINT cLines,const void *lpBits,const BITMAPINFO *lpbmi,UINT ColorUse);
  __attribute__((dllimport)) int SetDIBitsToDevice(HDC hdc,int xDest,int yDest,DWORD w,DWORD h,int xSrc,int ySrc,UINT StartScan,UINT cLines,const void *lpvBits,const BITMAPINFO *lpbmi,UINT ColorUse);
  __attribute__((dllimport)) DWORD SetMapperFlags(HDC hdc,DWORD flags);
  __attribute__((dllimport)) int SetGraphicsMode(HDC hdc,int iMode);
  __attribute__((dllimport)) int SetMapMode(HDC hdc,int iMode);
  __attribute__((dllimport)) DWORD SetLayout(HDC hdc,DWORD l);
  __attribute__((dllimport)) DWORD GetLayout(HDC hdc);
  __attribute__((dllimport)) HMETAFILE SetMetaFileBitsEx(UINT cbBuffer,const BYTE *lpData);
  __attribute__((dllimport)) UINT SetPaletteEntries(HPALETTE hpal,UINT iStart,UINT cEntries,const PALETTEENTRY *pPalEntries);
  __attribute__((dllimport)) COLORREF SetPixel(HDC hdc,int x,int y,COLORREF color);
  __attribute__((dllimport)) WINBOOL SetPixelV(HDC hdc,int x,int y,COLORREF color);
  __attribute__((dllimport)) WINBOOL SetPixelFormat(HDC hdc,int format,const PIXELFORMATDESCRIPTOR *ppfd);
  __attribute__((dllimport)) int SetPolyFillMode(HDC hdc,int mode);
  __attribute__((dllimport)) WINBOOL StretchBlt(HDC hdcDest,int xDest,int yDest,int wDest,int hDest,HDC hdcSrc,int xSrc,int ySrc,int wSrc,int hSrc,DWORD rop);
  __attribute__((dllimport)) WINBOOL SetRectRgn(HRGN hrgn,int left,int top,int right,int bottom);
  __attribute__((dllimport)) int StretchDIBits(HDC hdc,int xDest,int yDest,int DestWidth,int DestHeight,int xSrc,int ySrc,int SrcWidth,int SrcHeight,const void *lpBits,const BITMAPINFO *lpbmi,UINT iUsage,DWORD rop);
  __attribute__((dllimport)) int SetROP2(HDC hdc,int rop2);
  __attribute__((dllimport)) int SetStretchBltMode(HDC hdc,int mode);
  __attribute__((dllimport)) UINT SetSystemPaletteUse(HDC hdc,UINT use);
  __attribute__((dllimport)) int SetTextCharacterExtra(HDC hdc,int extra);
  __attribute__((dllimport)) COLORREF SetTextColor(HDC hdc,COLORREF color);
  __attribute__((dllimport)) UINT SetTextAlign(HDC hdc,UINT align);
  __attribute__((dllimport)) WINBOOL SetTextJustification(HDC hdc,int extra,int count);
  __attribute__((dllimport)) WINBOOL UpdateColors(HDC hdc);
  typedef USHORT COLOR16;

  typedef struct _TRIVERTEX {
    LONG x;
    LONG y;
    COLOR16 Red;
    COLOR16 Green;
    COLOR16 Blue;
    COLOR16 Alpha;
  } TRIVERTEX,*PTRIVERTEX,*LPTRIVERTEX;


  typedef struct _GRADIENT_TRIANGLE {
    ULONG Vertex1;
    ULONG Vertex2;
    ULONG Vertex3;
  } GRADIENT_TRIANGLE,*PGRADIENT_TRIANGLE,*LPGRADIENT_TRIANGLE;

  typedef struct _GRADIENT_RECT {
    ULONG UpperLeft;
    ULONG LowerRight;
  } GRADIENT_RECT,*PGRADIENT_RECT,*LPGRADIENT_RECT;


  typedef struct _BLENDFUNCTION {
    BYTE BlendOp;
    BYTE BlendFlags;
    BYTE SourceConstantAlpha;
    BYTE AlphaFormat;
  } BLENDFUNCTION,*PBLENDFUNCTION;





  __attribute__((dllimport)) WINBOOL AlphaBlend(HDC hdcDest,int xoriginDest,int yoriginDest,int wDest,int hDest,HDC hdcSrc,int xoriginSrc,int yoriginSrc,int wSrc,int hSrc,BLENDFUNCTION ftn);
  __attribute__((dllimport)) WINBOOL GdiAlphaBlend(HDC hdcDest,int xoriginDest,int yoriginDest,int wDest,int hDest,HDC hdcSrc,int xoriginSrc,int yoriginSrc,int wSrc,int hSrc,BLENDFUNCTION ftn);
  __attribute__((dllimport)) WINBOOL TransparentBlt(HDC hdcDest,int xoriginDest,int yoriginDest,int wDest,int hDest,HDC hdcSrc,int xoriginSrc,int yoriginSrc,int wSrc,int hSrc,UINT crTransparent);
  __attribute__((dllimport)) WINBOOL GdiTransparentBlt(HDC hdcDest,int xoriginDest,int yoriginDest,int wDest,int hDest,HDC hdcSrc,int xoriginSrc,int yoriginSrc,int wSrc,int hSrc,UINT crTransparent);






  __attribute__((dllimport)) WINBOOL GradientFill(HDC hdc,PTRIVERTEX pVertex,ULONG nVertex,PVOID pMesh,ULONG nMesh,ULONG ulMode);
  __attribute__((dllimport)) WINBOOL GdiGradientFill(HDC hdc,PTRIVERTEX pVertex,ULONG nVertex,PVOID pMesh,ULONG nMesh,ULONG ulMode);
  __attribute__((dllimport)) WINBOOL PlayMetaFileRecord(HDC hdc,LPHANDLETABLE lpHandleTable,LPMETARECORD lpMR,UINT noObjs);

  typedef int ( *MFENUMPROC)(HDC hdc,HANDLETABLE *lpht,METARECORD *lpMR,int nObj,LPARAM lParam);

  __attribute__((dllimport)) WINBOOL EnumMetaFile(HDC hdc,HMETAFILE hmf,MFENUMPROC lpProc,LPARAM lParam);

  typedef int ( *ENHMFENUMPROC)(HDC hdc,HANDLETABLE *lpht,const ENHMETARECORD *lpmr,int hHandles,LPARAM data);

  __attribute__((dllimport)) HENHMETAFILE CloseEnhMetaFile(HDC hdc);
  __attribute__((dllimport)) HENHMETAFILE CopyEnhMetaFileA(HENHMETAFILE hEnh,LPCSTR lpFileName);
  __attribute__((dllimport)) HENHMETAFILE CopyEnhMetaFileW(HENHMETAFILE hEnh,LPCWSTR lpFileName);
  __attribute__((dllimport)) HDC CreateEnhMetaFileA(HDC hdc,LPCSTR lpFilename,const RECT *lprc,LPCSTR lpDesc);
  __attribute__((dllimport)) HDC CreateEnhMetaFileW(HDC hdc,LPCWSTR lpFilename,const RECT *lprc,LPCWSTR lpDesc);
  __attribute__((dllimport)) WINBOOL DeleteEnhMetaFile(HENHMETAFILE hmf);
  __attribute__((dllimport)) WINBOOL EnumEnhMetaFile(HDC hdc,HENHMETAFILE hmf,ENHMFENUMPROC lpProc,LPVOID lpParam,const RECT *lpRect);
  __attribute__((dllimport)) HENHMETAFILE GetEnhMetaFileA(LPCSTR lpName);
  __attribute__((dllimport)) HENHMETAFILE GetEnhMetaFileW(LPCWSTR lpName);
  __attribute__((dllimport)) UINT GetEnhMetaFileBits(HENHMETAFILE hEMF,UINT nSize,LPBYTE lpData);
  __attribute__((dllimport)) UINT GetEnhMetaFileDescriptionA(HENHMETAFILE hemf,UINT cchBuffer,LPSTR lpDescription);
  __attribute__((dllimport)) UINT GetEnhMetaFileDescriptionW(HENHMETAFILE hemf,UINT cchBuffer,LPWSTR lpDescription);
  __attribute__((dllimport)) UINT GetEnhMetaFileHeader(HENHMETAFILE hemf,UINT nSize,LPENHMETAHEADER lpEnhMetaHeader);
  __attribute__((dllimport)) UINT GetEnhMetaFilePaletteEntries(HENHMETAFILE hemf,UINT nNumEntries,LPPALETTEENTRY lpPaletteEntries);
  __attribute__((dllimport)) UINT GetEnhMetaFilePixelFormat(HENHMETAFILE hemf,UINT cbBuffer,PIXELFORMATDESCRIPTOR *ppfd);
  __attribute__((dllimport)) UINT GetWinMetaFileBits(HENHMETAFILE hemf,UINT cbData16,LPBYTE pData16,INT iMapMode,HDC hdcRef);
  __attribute__((dllimport)) WINBOOL PlayEnhMetaFile(HDC hdc,HENHMETAFILE hmf,const RECT *lprect);
  __attribute__((dllimport)) WINBOOL PlayEnhMetaFileRecord(HDC hdc,LPHANDLETABLE pht,const ENHMETARECORD *pmr,UINT cht);
  __attribute__((dllimport)) HENHMETAFILE SetEnhMetaFileBits(UINT nSize,const BYTE *pb);
  __attribute__((dllimport)) HENHMETAFILE SetWinMetaFileBits(UINT nSize,const BYTE *lpMeta16Data,HDC hdcRef,const METAFILEPICT *lpMFP);
  __attribute__((dllimport)) WINBOOL GdiComment(HDC hdc,UINT nSize,const BYTE *lpData);





  __attribute__((dllimport)) WINBOOL GetTextMetricsA(HDC hdc,LPTEXTMETRICA lptm);
  __attribute__((dllimport)) WINBOOL GetTextMetricsW(HDC hdc,LPTEXTMETRICW lptm);


  typedef struct tagDIBSECTION {
    BITMAP dsBm;
    BITMAPINFOHEADER dsBmih;
    DWORD dsBitfields[3];
    HANDLE dshSection;
    DWORD dsOffset;
  } DIBSECTION,*LPDIBSECTION,*PDIBSECTION;

  __attribute__((dllimport)) WINBOOL AngleArc(HDC hdc,int x,int y,DWORD r,FLOAT StartAngle,FLOAT SweepAngle);
  __attribute__((dllimport)) WINBOOL PolyPolyline(HDC hdc,const POINT *apt,const DWORD *asz,DWORD csz);
  __attribute__((dllimport)) WINBOOL GetWorldTransform(HDC hdc,LPXFORM lpxf);
  __attribute__((dllimport)) WINBOOL SetWorldTransform(HDC hdc,const XFORM *lpxf);
  __attribute__((dllimport)) WINBOOL ModifyWorldTransform(HDC hdc,const XFORM *lpxf,DWORD mode);
  __attribute__((dllimport)) WINBOOL CombineTransform(LPXFORM lpxfOut,const XFORM *lpxf1,const XFORM *lpxf2);
  __attribute__((dllimport)) HBITMAP CreateDIBSection(HDC hdc,const BITMAPINFO *lpbmi,UINT usage,void **ppvBits,HANDLE hSection,DWORD offset);
  __attribute__((dllimport)) UINT GetDIBColorTable(HDC hdc,UINT iStart,UINT cEntries,RGBQUAD *prgbq);
  __attribute__((dllimport)) UINT SetDIBColorTable(HDC hdc,UINT iStart,UINT cEntries,const RGBQUAD *prgbq);
  typedef struct tagCOLORADJUSTMENT {
    WORD caSize;
    WORD caFlags;
    WORD caIlluminantIndex;
    WORD caRedGamma;
    WORD caGreenGamma;
    WORD caBlueGamma;
    WORD caReferenceBlack;
    WORD caReferenceWhite;
    SHORT caContrast;
    SHORT caBrightness;
    SHORT caColorfulness;
    SHORT caRedGreenTint;
  } COLORADJUSTMENT,*PCOLORADJUSTMENT,*LPCOLORADJUSTMENT;

  __attribute__((dllimport)) WINBOOL SetColorAdjustment(HDC hdc,const COLORADJUSTMENT *lpca);
  __attribute__((dllimport)) WINBOOL GetColorAdjustment(HDC hdc,LPCOLORADJUSTMENT lpca);
  __attribute__((dllimport)) HPALETTE CreateHalftonePalette(HDC hdc);

  typedef WINBOOL ( *ABORTPROC)(HDC,int);

  typedef struct _DOCINFOA {
    int cbSize;
    LPCSTR lpszDocName;
    LPCSTR lpszOutput;
    LPCSTR lpszDatatype;
    DWORD fwType;
  } DOCINFOA,*LPDOCINFOA;

  typedef struct _DOCINFOW {
    int cbSize;
    LPCWSTR lpszDocName;
    LPCWSTR lpszOutput;
    LPCWSTR lpszDatatype;
    DWORD fwType;
  } DOCINFOW,*LPDOCINFOW;

  typedef DOCINFOA DOCINFO;
  typedef LPDOCINFOA LPDOCINFO;
  __attribute__((dllimport)) int StartDocA(HDC hdc,const DOCINFOA *lpdi);
  __attribute__((dllimport)) int StartDocW(HDC hdc,const DOCINFOW *lpdi);
  __attribute__((dllimport)) int EndDoc(HDC hdc);
  __attribute__((dllimport)) int StartPage(HDC hdc);
  __attribute__((dllimport)) int EndPage(HDC hdc);
  __attribute__((dllimport)) int AbortDoc(HDC hdc);
  __attribute__((dllimport)) int SetAbortProc(HDC hdc,ABORTPROC lpProc);
  __attribute__((dllimport)) WINBOOL AbortPath(HDC hdc);
  __attribute__((dllimport)) WINBOOL ArcTo(HDC hdc,int left,int top,int right,int bottom,int xr1,int yr1,int xr2,int yr2);
  __attribute__((dllimport)) WINBOOL BeginPath(HDC hdc);
  __attribute__((dllimport)) WINBOOL CloseFigure(HDC hdc);
  __attribute__((dllimport)) WINBOOL EndPath(HDC hdc);
  __attribute__((dllimport)) WINBOOL FillPath(HDC hdc);
  __attribute__((dllimport)) WINBOOL FlattenPath(HDC hdc);
  __attribute__((dllimport)) int GetPath(HDC hdc,LPPOINT apt,LPBYTE aj,int cpt);
  __attribute__((dllimport)) HRGN PathToRegion(HDC hdc);
  __attribute__((dllimport)) WINBOOL PolyDraw(HDC hdc,const POINT *apt,const BYTE *aj,int cpt);
  __attribute__((dllimport)) WINBOOL SelectClipPath(HDC hdc,int mode);
  __attribute__((dllimport)) int SetArcDirection(HDC hdc,int dir);
  __attribute__((dllimport)) WINBOOL SetMiterLimit(HDC hdc,FLOAT limit,PFLOAT old);
  __attribute__((dllimport)) WINBOOL StrokeAndFillPath(HDC hdc);
  __attribute__((dllimport)) WINBOOL StrokePath(HDC hdc);
  __attribute__((dllimport)) WINBOOL WidenPath(HDC hdc);
  __attribute__((dllimport)) HPEN ExtCreatePen(DWORD iPenStyle,DWORD cWidth,const LOGBRUSH *plbrush,DWORD cStyle,const DWORD *pstyle);
  __attribute__((dllimport)) WINBOOL GetMiterLimit(HDC hdc,PFLOAT plimit);
  __attribute__((dllimport)) int GetArcDirection(HDC hdc);
  __attribute__((dllimport)) int GetObjectA(HANDLE h,int c,LPVOID pv);
  __attribute__((dllimport)) int GetObjectW(HANDLE h,int c,LPVOID pv);
  __attribute__((dllimport)) WINBOOL MoveToEx(HDC hdc,int x,int y,LPPOINT lppt);
  __attribute__((dllimport)) WINBOOL TextOutA(HDC hdc,int x,int y,LPCSTR lpString,int c);
  __attribute__((dllimport)) WINBOOL TextOutW(HDC hdc,int x,int y,LPCWSTR lpString,int c);
  __attribute__((dllimport)) WINBOOL ExtTextOutA(HDC hdc,int x,int y,UINT options,const RECT *lprect,LPCSTR lpString,UINT c,const INT *lpDx);
  __attribute__((dllimport)) WINBOOL ExtTextOutW(HDC hdc,int x,int y,UINT options,const RECT *lprect,LPCWSTR lpString,UINT c,const INT *lpDx);
  __attribute__((dllimport)) WINBOOL PolyTextOutA(HDC hdc,const POLYTEXTA *ppt,int nstrings);
  __attribute__((dllimport)) WINBOOL PolyTextOutW(HDC hdc,const POLYTEXTW *ppt,int nstrings);
  __attribute__((dllimport)) HRGN CreatePolygonRgn(const POINT *pptl,int cPoint,int iMode);
  __attribute__((dllimport)) WINBOOL DPtoLP(HDC hdc,LPPOINT lppt,int c);
  __attribute__((dllimport)) WINBOOL LPtoDP(HDC hdc,LPPOINT lppt,int c);
  __attribute__((dllimport)) WINBOOL Polygon(HDC hdc,const POINT *apt,int cpt);
  __attribute__((dllimport)) WINBOOL Polyline(HDC hdc,const POINT *apt,int cpt);
  __attribute__((dllimport)) WINBOOL PolyBezier(HDC hdc,const POINT *apt,DWORD cpt);
  __attribute__((dllimport)) WINBOOL PolyBezierTo(HDC hdc,const POINT *apt,DWORD cpt);
  __attribute__((dllimport)) WINBOOL PolylineTo(HDC hdc,const POINT *apt,DWORD cpt);
  __attribute__((dllimport)) WINBOOL SetViewportExtEx(HDC hdc,int x,int y,LPSIZE lpsz);
  __attribute__((dllimport)) WINBOOL SetViewportOrgEx(HDC hdc,int x,int y,LPPOINT lppt);
  __attribute__((dllimport)) WINBOOL SetWindowExtEx(HDC hdc,int x,int y,LPSIZE lpsz);
  __attribute__((dllimport)) WINBOOL SetWindowOrgEx(HDC hdc,int x,int y,LPPOINT lppt);
  __attribute__((dllimport)) WINBOOL OffsetViewportOrgEx(HDC hdc,int x,int y,LPPOINT lppt);
  __attribute__((dllimport)) WINBOOL OffsetWindowOrgEx(HDC hdc,int x,int y,LPPOINT lppt);
  __attribute__((dllimport)) WINBOOL ScaleViewportExtEx(HDC hdc,int xn,int dx,int yn,int yd,LPSIZE lpsz);
  __attribute__((dllimport)) WINBOOL ScaleWindowExtEx(HDC hdc,int xn,int xd,int yn,int yd,LPSIZE lpsz);
  __attribute__((dllimport)) WINBOOL SetBitmapDimensionEx(HBITMAP hbm,int w,int h,LPSIZE lpsz);
  __attribute__((dllimport)) WINBOOL SetBrushOrgEx(HDC hdc,int x,int y,LPPOINT lppt);
  __attribute__((dllimport)) int GetTextFaceA(HDC hdc,int c,LPSTR lpName);
  __attribute__((dllimport)) int GetTextFaceW(HDC hdc,int c,LPWSTR lpName);



  typedef struct tagKERNINGPAIR {
    WORD wFirst;
    WORD wSecond;
    int iKernAmount;
  } KERNINGPAIR,*LPKERNINGPAIR;



  __attribute__((dllimport)) DWORD GetKerningPairsA(HDC hdc,DWORD nPairs,LPKERNINGPAIR lpKernPair);
  __attribute__((dllimport)) DWORD GetKerningPairsW(HDC hdc,DWORD nPairs,LPKERNINGPAIR lpKernPair);
  __attribute__((dllimport)) WINBOOL GetDCOrgEx(HDC hdc,LPPOINT lppt);
  __attribute__((dllimport)) WINBOOL FixBrushOrgEx(HDC hdc,int x,int y,LPPOINT ptl);
  __attribute__((dllimport)) WINBOOL UnrealizeObject(HGDIOBJ h);
  __attribute__((dllimport)) WINBOOL GdiFlush(void);
  __attribute__((dllimport)) DWORD GdiSetBatchLimit(DWORD dw);
  __attribute__((dllimport)) DWORD GdiGetBatchLimit(void);






  typedef int ( *ICMENUMPROCA)(LPSTR,LPARAM);
  typedef int ( *ICMENUMPROCW)(LPWSTR,LPARAM);
  __attribute__((dllimport)) int SetICMMode(HDC hdc,int mode);
  __attribute__((dllimport)) WINBOOL CheckColorsInGamut(HDC hdc,LPVOID lpRGBTriple,LPVOID dlpBuffer,DWORD nCount);
  __attribute__((dllimport)) HCOLORSPACE GetColorSpace(HDC hdc);
  __attribute__((dllimport)) WINBOOL GetLogColorSpaceA(HCOLORSPACE hColorSpace,LPLOGCOLORSPACEA lpBuffer,DWORD nSize);
  __attribute__((dllimport)) WINBOOL GetLogColorSpaceW(HCOLORSPACE hColorSpace,LPLOGCOLORSPACEW lpBuffer,DWORD nSize);
  __attribute__((dllimport)) HCOLORSPACE CreateColorSpaceA(LPLOGCOLORSPACEA lplcs);
  __attribute__((dllimport)) HCOLORSPACE CreateColorSpaceW(LPLOGCOLORSPACEW lplcs);
  __attribute__((dllimport)) HCOLORSPACE SetColorSpace(HDC hdc,HCOLORSPACE hcs);
  __attribute__((dllimport)) WINBOOL DeleteColorSpace(HCOLORSPACE hcs);
  __attribute__((dllimport)) WINBOOL GetICMProfileA(HDC hdc,LPDWORD pBufSize,LPSTR pszFilename);
  __attribute__((dllimport)) WINBOOL GetICMProfileW(HDC hdc,LPDWORD pBufSize,LPWSTR pszFilename);
  __attribute__((dllimport)) WINBOOL SetICMProfileA(HDC hdc,LPSTR lpFileName);
  __attribute__((dllimport)) WINBOOL SetICMProfileW(HDC hdc,LPWSTR lpFileName);
  __attribute__((dllimport)) WINBOOL GetDeviceGammaRamp(HDC hdc,LPVOID lpRamp);
  __attribute__((dllimport)) WINBOOL SetDeviceGammaRamp(HDC hdc,LPVOID lpRamp);
  __attribute__((dllimport)) WINBOOL ColorMatchToTarget(HDC hdc,HDC hdcTarget,DWORD action);
  __attribute__((dllimport)) int EnumICMProfilesA(HDC hdc,ICMENUMPROCA lpProc,LPARAM lParam);
  __attribute__((dllimport)) int EnumICMProfilesW(HDC hdc,ICMENUMPROCW lpProc,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL UpdateICMRegKeyA(DWORD reserved,LPSTR lpszCMID,LPSTR lpszFileName,UINT command);
  __attribute__((dllimport)) WINBOOL UpdateICMRegKeyW(DWORD reserved,LPWSTR lpszCMID,LPWSTR lpszFileName,UINT command);
  __attribute__((dllimport)) WINBOOL ColorCorrectPalette(HDC hdc,HPALETTE hPal,DWORD deFirst,DWORD num);
  typedef struct tagEMR {
    DWORD iType;
    DWORD nSize;
  } EMR,*PEMR;

  typedef struct tagEMRTEXT {
    POINTL ptlReference;
    DWORD nChars;
    DWORD offString;
    DWORD fOptions;
    RECTL rcl;
    DWORD offDx;
  } EMRTEXT,*PEMRTEXT;

  typedef struct tagABORTPATH {
    EMR emr;
  } EMRABORTPATH,*PEMRABORTPATH,EMRBEGINPATH,*PEMRBEGINPATH,EMRENDPATH,*PEMRENDPATH,EMRCLOSEFIGURE,*PEMRCLOSEFIGURE,EMRFLATTENPATH,*PEMRFLATTENPATH,EMRWIDENPATH,*PEMRWIDENPATH,EMRSETMETARGN,*PEMRSETMETARGN,EMRSAVEDC,*PEMRSAVEDC,EMRREALIZEPALETTE,*PEMRREALIZEPALETTE;

  typedef struct tagEMRSELECTCLIPPATH {
    EMR emr;
    DWORD iMode;
  } EMRSELECTCLIPPATH,*PEMRSELECTCLIPPATH,EMRSETBKMODE,*PEMRSETBKMODE,EMRSETMAPMODE,*PEMRSETMAPMODE,EMRSETLAYOUT,*PEMRSETLAYOUT,
    EMRSETPOLYFILLMODE,*PEMRSETPOLYFILLMODE,EMRSETROP2,*PEMRSETROP2,EMRSETSTRETCHBLTMODE,*PEMRSETSTRETCHBLTMODE,EMRSETICMMODE,
    *PEMRSETICMMODE,EMRSETTEXTALIGN,*PEMRSETTEXTALIGN;

  typedef struct tagEMRSETMITERLIMIT {
    EMR emr;
    FLOAT eMiterLimit;
  } EMRSETMITERLIMIT,*PEMRSETMITERLIMIT;

  typedef struct tagEMRRESTOREDC {
    EMR emr;
    LONG iRelative;
  } EMRRESTOREDC,*PEMRRESTOREDC;

  typedef struct tagEMRSETARCDIRECTION {
    EMR emr;
    DWORD iArcDirection;

  } EMRSETARCDIRECTION,*PEMRSETARCDIRECTION;

  typedef struct tagEMRSETMAPPERFLAGS {
    EMR emr;
    DWORD dwFlags;
  } EMRSETMAPPERFLAGS,*PEMRSETMAPPERFLAGS;

  typedef struct tagEMRSETTEXTCOLOR {
    EMR emr;
    COLORREF crColor;
  } EMRSETBKCOLOR,*PEMRSETBKCOLOR,EMRSETTEXTCOLOR,*PEMRSETTEXTCOLOR;

  typedef struct tagEMRSELECTOBJECT {
    EMR emr;
    DWORD ihObject;
  } EMRSELECTOBJECT,*PEMRSELECTOBJECT,EMRDELETEOBJECT,*PEMRDELETEOBJECT;

  typedef struct tagEMRSELECTPALETTE {
    EMR emr;
    DWORD ihPal;
  } EMRSELECTPALETTE,*PEMRSELECTPALETTE;

  typedef struct tagEMRRESIZEPALETTE {
    EMR emr;
    DWORD ihPal;
    DWORD cEntries;
  } EMRRESIZEPALETTE,*PEMRRESIZEPALETTE;

  typedef struct tagEMRSETPALETTEENTRIES {
    EMR emr;
    DWORD ihPal;
    DWORD iStart;
    DWORD cEntries;
    PALETTEENTRY aPalEntries[1];
  } EMRSETPALETTEENTRIES,*PEMRSETPALETTEENTRIES;

  typedef struct tagEMRSETCOLORADJUSTMENT {
    EMR emr;
    COLORADJUSTMENT ColorAdjustment;
  } EMRSETCOLORADJUSTMENT,*PEMRSETCOLORADJUSTMENT;

  typedef struct tagEMRGDICOMMENT {
    EMR emr;
    DWORD cbData;
    BYTE Data[1];
  } EMRGDICOMMENT,*PEMRGDICOMMENT;

  typedef struct tagEMREOF {
    EMR emr;
    DWORD nPalEntries;
    DWORD offPalEntries;
    DWORD nSizeLast;
  } EMREOF,*PEMREOF;

  typedef struct tagEMRLINETO {
    EMR emr;
    POINTL ptl;
  } EMRLINETO,*PEMRLINETO,EMRMOVETOEX,*PEMRMOVETOEX;

  typedef struct tagEMROFFSETCLIPRGN {
    EMR emr;
    POINTL ptlOffset;
  } EMROFFSETCLIPRGN,*PEMROFFSETCLIPRGN;

  typedef struct tagEMRFILLPATH {
    EMR emr;
    RECTL rclBounds;
  } EMRFILLPATH,*PEMRFILLPATH,EMRSTROKEANDFILLPATH,*PEMRSTROKEANDFILLPATH,EMRSTROKEPATH,*PEMRSTROKEPATH;

  typedef struct tagEMREXCLUDECLIPRECT {
    EMR emr;
    RECTL rclClip;
  } EMREXCLUDECLIPRECT,*PEMREXCLUDECLIPRECT,EMRINTERSECTCLIPRECT,*PEMRINTERSECTCLIPRECT;

  typedef struct tagEMRSETVIEWPORTORGEX {
    EMR emr;
    POINTL ptlOrigin;
  } EMRSETVIEWPORTORGEX,*PEMRSETVIEWPORTORGEX,EMRSETWINDOWORGEX,*PEMRSETWINDOWORGEX,EMRSETBRUSHORGEX,*PEMRSETBRUSHORGEX;

  typedef struct tagEMRSETVIEWPORTEXTEX {
    EMR emr;
    SIZEL szlExtent;
  } EMRSETVIEWPORTEXTEX,*PEMRSETVIEWPORTEXTEX,EMRSETWINDOWEXTEX,*PEMRSETWINDOWEXTEX;

  typedef struct tagEMRSCALEVIEWPORTEXTEX {
    EMR emr;
    LONG xNum;
    LONG xDenom;
    LONG yNum;
    LONG yDenom;
  } EMRSCALEVIEWPORTEXTEX,*PEMRSCALEVIEWPORTEXTEX,EMRSCALEWINDOWEXTEX,*PEMRSCALEWINDOWEXTEX;

  typedef struct tagEMRSETWORLDTRANSFORM {
    EMR emr;
    XFORM xform;
  } EMRSETWORLDTRANSFORM,*PEMRSETWORLDTRANSFORM;

  typedef struct tagEMRMODIFYWORLDTRANSFORM {
    EMR emr;
    XFORM xform;
    DWORD iMode;
  } EMRMODIFYWORLDTRANSFORM,*PEMRMODIFYWORLDTRANSFORM;

  typedef struct tagEMRSETPIXELV {
    EMR emr;
    POINTL ptlPixel;
    COLORREF crColor;
  } EMRSETPIXELV,*PEMRSETPIXELV;

  typedef struct tagEMREXTFLOODFILL {
    EMR emr;
    POINTL ptlStart;
    COLORREF crColor;
    DWORD iMode;
  } EMREXTFLOODFILL,*PEMREXTFLOODFILL;

  typedef struct tagEMRELLIPSE {
    EMR emr;
    RECTL rclBox;
  } EMRELLIPSE,*PEMRELLIPSE,EMRRECTANGLE,*PEMRRECTANGLE;

  typedef struct tagEMRROUNDRECT {
    EMR emr;
    RECTL rclBox;
    SIZEL szlCorner;
  } EMRROUNDRECT,*PEMRROUNDRECT;

  typedef struct tagEMRARC {
    EMR emr;
    RECTL rclBox;
    POINTL ptlStart;
    POINTL ptlEnd;
  } EMRARC,*PEMRARC,EMRARCTO,*PEMRARCTO,EMRCHORD,*PEMRCHORD,EMRPIE,*PEMRPIE;

  typedef struct tagEMRANGLEARC {
    EMR emr;
    POINTL ptlCenter;
    DWORD nRadius;
    FLOAT eStartAngle;
    FLOAT eSweepAngle;
  } EMRANGLEARC,*PEMRANGLEARC;

  typedef struct tagEMRPOLYLINE {
    EMR emr;
    RECTL rclBounds;
    DWORD cptl;
    POINTL aptl[1];
  } EMRPOLYLINE,*PEMRPOLYLINE,EMRPOLYBEZIER,*PEMRPOLYBEZIER,EMRPOLYGON,*PEMRPOLYGON,EMRPOLYBEZIERTO,*PEMRPOLYBEZIERTO,EMRPOLYLINETO,*PEMRPOLYLINETO;

  typedef struct tagEMRPOLYLINE16 {
    EMR emr;
    RECTL rclBounds;
    DWORD cpts;
    POINTS apts[1];
  } EMRPOLYLINE16,*PEMRPOLYLINE16,EMRPOLYBEZIER16,*PEMRPOLYBEZIER16,EMRPOLYGON16,*PEMRPOLYGON16,EMRPOLYBEZIERTO16,*PEMRPOLYBEZIERTO16,EMRPOLYLINETO16,*PEMRPOLYLINETO16;

  typedef struct tagEMRPOLYDRAW {
    EMR emr;
    RECTL rclBounds;
    DWORD cptl;
    POINTL aptl[1];
    BYTE abTypes[1];
  } EMRPOLYDRAW,*PEMRPOLYDRAW;

  typedef struct tagEMRPOLYDRAW16 {
    EMR emr;
    RECTL rclBounds;
    DWORD cpts;
    POINTS apts[1];
    BYTE abTypes[1];
  } EMRPOLYDRAW16,*PEMRPOLYDRAW16;

  typedef struct tagEMRPOLYPOLYLINE {
    EMR emr;
    RECTL rclBounds;
    DWORD nPolys;
    DWORD cptl;
    DWORD aPolyCounts[1];
    POINTL aptl[1];
  } EMRPOLYPOLYLINE,*PEMRPOLYPOLYLINE,EMRPOLYPOLYGON,*PEMRPOLYPOLYGON;

  typedef struct tagEMRPOLYPOLYLINE16 {
    EMR emr;
    RECTL rclBounds;
    DWORD nPolys;
    DWORD cpts;
    DWORD aPolyCounts[1];
    POINTS apts[1];
  } EMRPOLYPOLYLINE16,*PEMRPOLYPOLYLINE16,EMRPOLYPOLYGON16,*PEMRPOLYPOLYGON16;

  typedef struct tagEMRINVERTRGN {
    EMR emr;
    RECTL rclBounds;
    DWORD cbRgnData;
    BYTE RgnData[1];
  } EMRINVERTRGN,*PEMRINVERTRGN,EMRPAINTRGN,*PEMRPAINTRGN;

  typedef struct tagEMRFILLRGN {
    EMR emr;
    RECTL rclBounds;
    DWORD cbRgnData;
    DWORD ihBrush;
    BYTE RgnData[1];
  } EMRFILLRGN,*PEMRFILLRGN;

  typedef struct tagEMRFRAMERGN {
    EMR emr;
    RECTL rclBounds;
    DWORD cbRgnData;
    DWORD ihBrush;
    SIZEL szlStroke;
    BYTE RgnData[1];
  } EMRFRAMERGN,*PEMRFRAMERGN;

  typedef struct tagEMREXTSELECTCLIPRGN {
    EMR emr;
    DWORD cbRgnData;
    DWORD iMode;
    BYTE RgnData[1];
  } EMREXTSELECTCLIPRGN,*PEMREXTSELECTCLIPRGN;

  typedef struct tagEMREXTTEXTOUTA {
    EMR emr;
    RECTL rclBounds;
    DWORD iGraphicsMode;
    FLOAT exScale;
    FLOAT eyScale;
    EMRTEXT emrtext;
  } EMREXTTEXTOUTA,*PEMREXTTEXTOUTA,EMREXTTEXTOUTW,*PEMREXTTEXTOUTW;

  typedef struct tagEMRPOLYTEXTOUTA {
    EMR emr;
    RECTL rclBounds;
    DWORD iGraphicsMode;
    FLOAT exScale;
    FLOAT eyScale;
    LONG cStrings;
    EMRTEXT aemrtext[1];
  } EMRPOLYTEXTOUTA,*PEMRPOLYTEXTOUTA,EMRPOLYTEXTOUTW,*PEMRPOLYTEXTOUTW;

  typedef struct tagEMRBITBLT {
    EMR emr;
    RECTL rclBounds;
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc;
    COLORREF crBkColorSrc;
    DWORD iUsageSrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
  } EMRBITBLT,*PEMRBITBLT;

  typedef struct tagEMRSTRETCHBLT {
    EMR emr;
    RECTL rclBounds;
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc;
    COLORREF crBkColorSrc;
    DWORD iUsageSrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
    LONG cxSrc;
    LONG cySrc;
  } EMRSTRETCHBLT,*PEMRSTRETCHBLT;

  typedef struct tagEMRMASKBLT {
    EMR emr;
    RECTL rclBounds;
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc;
    COLORREF crBkColorSrc;
    DWORD iUsageSrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
    LONG xMask;
    LONG yMask;
    DWORD iUsageMask;
    DWORD offBmiMask;
    DWORD cbBmiMask;
    DWORD offBitsMask;
    DWORD cbBitsMask;
  } EMRMASKBLT,*PEMRMASKBLT;

  typedef struct tagEMRPLGBLT {
    EMR emr;
    RECTL rclBounds;
    POINTL aptlDest[3];
    LONG xSrc;
    LONG ySrc;
    LONG cxSrc;
    LONG cySrc;
    XFORM xformSrc;
    COLORREF crBkColorSrc;
    DWORD iUsageSrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
    LONG xMask;
    LONG yMask;
    DWORD iUsageMask;
    DWORD offBmiMask;
    DWORD cbBmiMask;
    DWORD offBitsMask;
    DWORD cbBitsMask;
  } EMRPLGBLT,*PEMRPLGBLT;

  typedef struct tagEMRSETDIBITSTODEVICE {
    EMR emr;
    RECTL rclBounds;
    LONG xDest;
    LONG yDest;
    LONG xSrc;
    LONG ySrc;
    LONG cxSrc;
    LONG cySrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
    DWORD iUsageSrc;
    DWORD iStartScan;
    DWORD cScans;
  } EMRSETDIBITSTODEVICE,*PEMRSETDIBITSTODEVICE;

  typedef struct tagEMRSTRETCHDIBITS {
    EMR emr;
    RECTL rclBounds;
    LONG xDest;
    LONG yDest;
    LONG xSrc;
    LONG ySrc;
    LONG cxSrc;
    LONG cySrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
    DWORD iUsageSrc;
    DWORD dwRop;
    LONG cxDest;
    LONG cyDest;
  } EMRSTRETCHDIBITS,*PEMRSTRETCHDIBITS;

  typedef struct tagEMREXTCREATEFONTINDIRECTW {
    EMR emr;
    DWORD ihFont;
    EXTLOGFONTW elfw;
  } EMREXTCREATEFONTINDIRECTW,*PEMREXTCREATEFONTINDIRECTW;

  typedef struct tagEMRCREATEPALETTE {
    EMR emr;
    DWORD ihPal;
    LOGPALETTE lgpl;
  } EMRCREATEPALETTE,*PEMRCREATEPALETTE;

  typedef struct tagEMRCREATEPEN {
    EMR emr;
    DWORD ihPen;
    LOGPEN lopn;
  } EMRCREATEPEN,*PEMRCREATEPEN;

  typedef struct tagEMREXTCREATEPEN {
    EMR emr;
    DWORD ihPen;
    DWORD offBmi;
    DWORD cbBmi;
    DWORD offBits;
    DWORD cbBits;
    EXTLOGPEN elp;
  } EMREXTCREATEPEN,*PEMREXTCREATEPEN;

  typedef struct tagEMRCREATEBRUSHINDIRECT {
    EMR emr;
    DWORD ihBrush;
    LOGBRUSH32 lb;
  } EMRCREATEBRUSHINDIRECT,*PEMRCREATEBRUSHINDIRECT;

  typedef struct tagEMRCREATEMONOBRUSH {
    EMR emr;
    DWORD ihBrush;
    DWORD iUsage;
    DWORD offBmi;
    DWORD cbBmi;
    DWORD offBits;
    DWORD cbBits;
  } EMRCREATEMONOBRUSH,*PEMRCREATEMONOBRUSH;

  typedef struct tagEMRCREATEDIBPATTERNBRUSHPT {
    EMR emr;
    DWORD ihBrush;
    DWORD iUsage;
    DWORD offBmi;
    DWORD cbBmi;
    DWORD offBits;
    DWORD cbBits;
  } EMRCREATEDIBPATTERNBRUSHPT,*PEMRCREATEDIBPATTERNBRUSHPT;

  typedef struct tagEMRFORMAT {
    DWORD dSignature;
    DWORD nVersion;
    DWORD cbData;
    DWORD offData;
  } EMRFORMAT,*PEMRFORMAT;

  typedef struct tagEMRGLSRECORD {
    EMR emr;
    DWORD cbData;
    BYTE Data[1];
  } EMRGLSRECORD,*PEMRGLSRECORD;

  typedef struct tagEMRGLSBOUNDEDRECORD {
    EMR emr;
    RECTL rclBounds;
    DWORD cbData;
    BYTE Data[1];
  } EMRGLSBOUNDEDRECORD,*PEMRGLSBOUNDEDRECORD;

  typedef struct tagEMRPIXELFORMAT {
    EMR emr;
    PIXELFORMATDESCRIPTOR pfd;
  } EMRPIXELFORMAT,*PEMRPIXELFORMAT;

  typedef struct tagEMRCREATECOLORSPACE {
    EMR emr;
    DWORD ihCS;
    LOGCOLORSPACEA lcs;
  } EMRCREATECOLORSPACE,*PEMRCREATECOLORSPACE;

  typedef struct tagEMRSETCOLORSPACE {
    EMR emr;
    DWORD ihCS;
  } EMRSETCOLORSPACE,*PEMRSETCOLORSPACE,EMRSELECTCOLORSPACE,*PEMRSELECTCOLORSPACE,EMRDELETECOLORSPACE,*PEMRDELETECOLORSPACE;

  typedef struct tagEMREXTESCAPE {
    EMR emr;
    INT iEscape;
    INT cbEscData;
    BYTE EscData[1];
  } EMREXTESCAPE,*PEMREXTESCAPE,EMRDRAWESCAPE,*PEMRDRAWESCAPE;

  typedef struct tagEMRNAMEDESCAPE {
    EMR emr;
    INT iEscape;
    INT cbDriver;
    INT cbEscData;
    BYTE EscData[1];
  } EMRNAMEDESCAPE,*PEMRNAMEDESCAPE;



  typedef struct tagEMRSETICMPROFILE {
    EMR emr;
    DWORD dwFlags;
    DWORD cbName;
    DWORD cbData;
    BYTE Data[1];
  } EMRSETICMPROFILE,*PEMRSETICMPROFILE,EMRSETICMPROFILEA,*PEMRSETICMPROFILEA,EMRSETICMPROFILEW,*PEMRSETICMPROFILEW;



  typedef struct tagEMRCREATECOLORSPACEW {
    EMR emr;
    DWORD ihCS;
    LOGCOLORSPACEW lcs;
    DWORD dwFlags;
    DWORD cbData;
    BYTE Data[1];
  } EMRCREATECOLORSPACEW,*PEMRCREATECOLORSPACEW;



  typedef struct tagCOLORMATCHTOTARGET {
    EMR emr;
    DWORD dwAction;
    DWORD dwFlags;
    DWORD cbName;
    DWORD cbData;
    BYTE Data[1];
  } EMRCOLORMATCHTOTARGET,*PEMRCOLORMATCHTOTARGET;

  typedef struct tagCOLORCORRECTPALETTE {
    EMR emr;
    DWORD ihPalette;
    DWORD nFirstEntry;
    DWORD nPalEntries;
    DWORD nReserved;
  } EMRCOLORCORRECTPALETTE,*PEMRCOLORCORRECTPALETTE;

  typedef struct tagEMRALPHABLEND {
    EMR emr;
    RECTL rclBounds;
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc;
    COLORREF crBkColorSrc;
    DWORD iUsageSrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
    LONG cxSrc;
    LONG cySrc;
  } EMRALPHABLEND,*PEMRALPHABLEND;

  typedef struct tagEMRGRADIENTFILL {
    EMR emr;
    RECTL rclBounds;
    DWORD nVer;
    DWORD nTri;
    ULONG ulMode;
    TRIVERTEX Ver[1];
  } EMRGRADIENTFILL,*PEMRGRADIENTFILL;

  typedef struct tagEMRTRANSPARENTBLT {
    EMR emr;
    RECTL rclBounds;
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc;
    COLORREF crBkColorSrc;
    DWORD iUsageSrc;
    DWORD offBmiSrc;
    DWORD cbBmiSrc;
    DWORD offBitsSrc;
    DWORD cbBitsSrc;
    LONG cxSrc;
    LONG cySrc;
  } EMRTRANSPARENTBLT,*PEMRTRANSPARENTBLT;
  __attribute__((dllimport)) WINBOOL wglCopyContext(HGLRC,HGLRC,UINT);
  __attribute__((dllimport)) HGLRC wglCreateContext(HDC);
  __attribute__((dllimport)) HGLRC wglCreateLayerContext(HDC,int);
  __attribute__((dllimport)) WINBOOL wglDeleteContext(HGLRC);
  __attribute__((dllimport)) HGLRC wglGetCurrentContext(void);
  __attribute__((dllimport)) HDC wglGetCurrentDC(void);
  __attribute__((dllimport)) PROC wglGetProcAddress(LPCSTR);
  __attribute__((dllimport)) WINBOOL wglMakeCurrent(HDC,HGLRC);
  __attribute__((dllimport)) WINBOOL wglShareLists(HGLRC,HGLRC);
  __attribute__((dllimport)) WINBOOL wglUseFontBitmapsA(HDC,DWORD,DWORD,DWORD);
  __attribute__((dllimport)) WINBOOL wglUseFontBitmapsW(HDC,DWORD,DWORD,DWORD);
  __attribute__((dllimport)) WINBOOL SwapBuffers(HDC);

  typedef struct _POINTFLOAT {
    FLOAT x;
    FLOAT y;
  } POINTFLOAT,*PPOINTFLOAT;

  typedef struct _GLYPHMETRICSFLOAT {
    FLOAT gmfBlackBoxX;
    FLOAT gmfBlackBoxY;
    POINTFLOAT gmfptGlyphOrigin;
    FLOAT gmfCellIncX;
    FLOAT gmfCellIncY;
  } GLYPHMETRICSFLOAT,*PGLYPHMETRICSFLOAT,*LPGLYPHMETRICSFLOAT;






  __attribute__((dllimport)) WINBOOL wglUseFontOutlinesA(HDC,DWORD,DWORD,DWORD,FLOAT,FLOAT,int,LPGLYPHMETRICSFLOAT);
  __attribute__((dllimport)) WINBOOL wglUseFontOutlinesW(HDC,DWORD,DWORD,DWORD,FLOAT,FLOAT,int,LPGLYPHMETRICSFLOAT);

  typedef struct tagLAYERPLANEDESCRIPTOR {
    WORD nSize;
    WORD nVersion;
    DWORD dwFlags;
    BYTE iPixelType;
    BYTE cColorBits;
    BYTE cRedBits;
    BYTE cRedShift;
    BYTE cGreenBits;
    BYTE cGreenShift;
    BYTE cBlueBits;
    BYTE cBlueShift;
    BYTE cAlphaBits;
    BYTE cAlphaShift;
    BYTE cAccumBits;
    BYTE cAccumRedBits;
    BYTE cAccumGreenBits;
    BYTE cAccumBlueBits;
    BYTE cAccumAlphaBits;
    BYTE cDepthBits;
    BYTE cStencilBits;
    BYTE cAuxBuffers;
    BYTE iLayerPlane;
    BYTE bReserved;
    COLORREF crTransparent;
  } LAYERPLANEDESCRIPTOR,*PLAYERPLANEDESCRIPTOR,*LPLAYERPLANEDESCRIPTOR;
  __attribute__((dllimport)) WINBOOL wglDescribeLayerPlane(HDC,int,int,UINT,LPLAYERPLANEDESCRIPTOR);
  __attribute__((dllimport)) int wglSetLayerPaletteEntries(HDC,int,int,int,const COLORREF *);
  __attribute__((dllimport)) int wglGetLayerPaletteEntries(HDC,int,int,int,COLORREF *);
  __attribute__((dllimport)) WINBOOL wglRealizeLayerPalette(HDC,int,WINBOOL);
  __attribute__((dllimport)) WINBOOL wglSwapLayerBuffers(HDC,UINT);

  typedef struct _WGLSWAP {
    HDC hdc;
    UINT uiFlags;
  } WGLSWAP,*PWGLSWAP,*LPWGLSWAP;



  __attribute__((dllimport)) DWORD wglSwapMultipleBuffers(UINT,const WGLSWAP *);








  typedef HANDLE HDWP;
  typedef void MENUTEMPLATEA;
  typedef void MENUTEMPLATEW;
  typedef PVOID LPMENUTEMPLATEA;
  typedef PVOID LPMENUTEMPLATEW;

  typedef MENUTEMPLATEA MENUTEMPLATE;
  typedef LPMENUTEMPLATEA LPMENUTEMPLATE;

  typedef LRESULT ( *WNDPROC)(HWND,UINT,WPARAM,LPARAM);




  typedef INT_PTR ( *DLGPROC) (HWND, UINT, WPARAM, LPARAM);



  typedef void ( *TIMERPROC) (HWND, UINT, UINT_PTR, DWORD);
  typedef WINBOOL ( *GRAYSTRINGPROC) (HDC, LPARAM, int);
  typedef WINBOOL ( *WNDENUMPROC) (HWND, LPARAM);
  typedef LRESULT ( *HOOKPROC) (int code, WPARAM wParam, LPARAM lParam);
  typedef void ( *SENDASYNCPROC) (HWND, UINT, ULONG_PTR, LRESULT);

  typedef WINBOOL ( *PROPENUMPROCA) (HWND, LPCSTR, HANDLE);
  typedef WINBOOL ( *PROPENUMPROCW) (HWND, LPCWSTR, HANDLE);

  typedef WINBOOL ( *PROPENUMPROCEXA) (HWND, LPSTR, HANDLE, ULONG_PTR);
  typedef WINBOOL ( *PROPENUMPROCEXW) (HWND, LPWSTR, HANDLE, ULONG_PTR);

  typedef int ( *EDITWORDBREAKPROCA) (LPSTR lpch, int ichCurrent, int cch, int code);
  typedef int ( *EDITWORDBREAKPROCW) (LPWSTR lpch, int ichCurrent, int cch, int code);

  typedef WINBOOL ( *DRAWSTATEPROC) (HDC hdc, LPARAM lData, WPARAM wData, int cx, int cy);
  typedef PROPENUMPROCA PROPENUMPROC;
  typedef PROPENUMPROCEXA PROPENUMPROCEX;
  typedef EDITWORDBREAKPROCA EDITWORDBREAKPROC;


  typedef WINBOOL ( *NAMEENUMPROCA) (LPSTR, LPARAM);
  typedef WINBOOL ( *NAMEENUMPROCW) (LPWSTR, LPARAM);
  typedef NAMEENUMPROCA WINSTAENUMPROCA;
  typedef NAMEENUMPROCW WINSTAENUMPROCW;
  typedef NAMEENUMPROCA DESKTOPENUMPROCA;
  typedef NAMEENUMPROCW DESKTOPENUMPROCW;
  typedef WINSTAENUMPROCA WINSTAENUMPROC;
  typedef DESKTOPENUMPROCA DESKTOPENUMPROC;
  __attribute__((dllimport)) int wvsprintfA(LPSTR,LPCSTR,va_list arglist);
  __attribute__((dllimport)) int wvsprintfW(LPWSTR,LPCWSTR,va_list arglist);
  __attribute__((dllimport)) int __attribute__((__cdecl__)) wsprintfA(LPSTR,LPCSTR,...);
  __attribute__((dllimport)) int __attribute__((__cdecl__)) wsprintfW(LPWSTR,LPCWSTR,...);
  typedef struct tagCBT_CREATEWNDA {
    struct tagCREATESTRUCTA *lpcs;
    HWND hwndInsertAfter;
  } CBT_CREATEWNDA,*LPCBT_CREATEWNDA;

  typedef struct tagCBT_CREATEWNDW {
    struct tagCREATESTRUCTW *lpcs;
    HWND hwndInsertAfter;
  } CBT_CREATEWNDW,*LPCBT_CREATEWNDW;

  typedef CBT_CREATEWNDA CBT_CREATEWND;
  typedef LPCBT_CREATEWNDA LPCBT_CREATEWND;

  typedef struct tagCBTACTIVATESTRUCT {
    WINBOOL fMouse;
    HWND hWndActive;
  } CBTACTIVATESTRUCT,*LPCBTACTIVATESTRUCT;



  typedef struct tagWTSSESSION_NOTIFICATION {
    DWORD cbSize;
    DWORD dwSessionId;
  } WTSSESSION_NOTIFICATION,*PWTSSESSION_NOTIFICATION;
  typedef struct {
    HWND hwnd;
    RECT rc;
  } SHELLHOOKINFO,*LPSHELLHOOKINFO;

  typedef struct tagEVENTMSG {
    UINT message;
    UINT paramL;
    UINT paramH;
    DWORD time;
    HWND hwnd;
  } EVENTMSG,*PEVENTMSGMSG,*NPEVENTMSGMSG,*LPEVENTMSGMSG;

  typedef struct tagEVENTMSG *PEVENTMSG,*NPEVENTMSG,*LPEVENTMSG;

  typedef struct tagCWPSTRUCT {
    LPARAM lParam;
    WPARAM wParam;
    UINT message;
    HWND hwnd;
  } CWPSTRUCT,*PCWPSTRUCT,*NPCWPSTRUCT,*LPCWPSTRUCT;

  typedef struct tagCWPRETSTRUCT {
    LRESULT lResult;
    LPARAM lParam;
    WPARAM wParam;
    UINT message;
    HWND hwnd;
  } CWPRETSTRUCT,*PCWPRETSTRUCT,*NPCWPRETSTRUCT,*LPCWPRETSTRUCT;
  typedef struct tagKBDLLHOOKSTRUCT {
    DWORD vkCode;
    DWORD scanCode;
    DWORD flags;
    DWORD time;
    ULONG_PTR dwExtraInfo;
  } KBDLLHOOKSTRUCT,*LPKBDLLHOOKSTRUCT,*PKBDLLHOOKSTRUCT;

  typedef struct tagMSLLHOOKSTRUCT {
    POINT pt;
    DWORD mouseData;
    DWORD flags;
    DWORD time;
    ULONG_PTR dwExtraInfo;
  } MSLLHOOKSTRUCT,*LPMSLLHOOKSTRUCT,*PMSLLHOOKSTRUCT;

  typedef struct tagDEBUGHOOKINFO {
    DWORD idThread;
    DWORD idThreadInstaller;
    LPARAM lParam;
    WPARAM wParam;
    int code;
  } DEBUGHOOKINFO,*PDEBUGHOOKINFO,*NPDEBUGHOOKINFO,*LPDEBUGHOOKINFO;

  typedef struct tagMOUSEHOOKSTRUCT {
    POINT pt;
    HWND hwnd;
    UINT wHitTestCode;
    ULONG_PTR dwExtraInfo;
  } MOUSEHOOKSTRUCT,*LPMOUSEHOOKSTRUCT,*PMOUSEHOOKSTRUCT;






  typedef struct tagMOUSEHOOKSTRUCTEX {
    MOUSEHOOKSTRUCT __unnamed;
    DWORD mouseData;
  } MOUSEHOOKSTRUCTEX,*LPMOUSEHOOKSTRUCTEX,*PMOUSEHOOKSTRUCTEX;


  typedef struct tagHARDWAREHOOKSTRUCT {
    HWND hwnd;
    UINT message;
    WPARAM wParam;
    LPARAM lParam;
  } HARDWAREHOOKSTRUCT,*LPHARDWAREHOOKSTRUCT,*PHARDWAREHOOKSTRUCT;
  __attribute__((dllimport)) HKL LoadKeyboardLayoutA(LPCSTR pwszKLID,UINT Flags);
  __attribute__((dllimport)) HKL LoadKeyboardLayoutW(LPCWSTR pwszKLID,UINT Flags);
  __attribute__((dllimport)) HKL ActivateKeyboardLayout(HKL hkl,UINT Flags);
  __attribute__((dllimport)) int ToUnicodeEx(UINT wVirtKey,UINT wScanCode,const BYTE *lpKeyState,LPWSTR pwszBuff,int cchBuff,UINT wFlags,HKL dwhkl);
  __attribute__((dllimport)) WINBOOL UnloadKeyboardLayout(HKL hkl);
  __attribute__((dllimport)) WINBOOL GetKeyboardLayoutNameA(LPSTR pwszKLID);
  __attribute__((dllimport)) WINBOOL GetKeyboardLayoutNameW(LPWSTR pwszKLID);
  __attribute__((dllimport)) int GetKeyboardLayoutList(int nBuff,HKL *lpList);
  __attribute__((dllimport)) HKL GetKeyboardLayout(DWORD idThread);

  typedef struct tagMOUSEMOVEPOINT {
    int x;
    int y;
    DWORD time;
    ULONG_PTR dwExtraInfo;
  } MOUSEMOVEPOINT,*PMOUSEMOVEPOINT,*LPMOUSEMOVEPOINT;

  __attribute__((dllimport)) int GetMouseMovePointsEx(UINT cbSize,LPMOUSEMOVEPOINT lppt,LPMOUSEMOVEPOINT lpptBuf,int nBufPoints,DWORD resolution);
  __attribute__((dllimport)) HDESK CreateDesktopA(LPCSTR lpszDesktop,LPCSTR lpszDevice,LPDEVMODEA pDevmode,DWORD dwFlags,ACCESS_MASK dwDesiredAccess,LPSECURITY_ATTRIBUTES lpsa);
  __attribute__((dllimport)) HDESK CreateDesktopW(LPCWSTR lpszDesktop,LPCWSTR lpszDevice,LPDEVMODEW pDevmode,DWORD dwFlags,ACCESS_MASK dwDesiredAccess,LPSECURITY_ATTRIBUTES lpsa);
  __attribute__((dllimport)) HDESK CreateDesktopExA (LPCSTR lpszDesktop, LPCSTR lpszDevice, DEVMODEA *pDevmode, DWORD dwFlags, ACCESS_MASK dwDesiredAccess, LPSECURITY_ATTRIBUTES lpsa, ULONG ulHeapSize, PVOID pvoid);
  __attribute__((dllimport)) HDESK CreateDesktopExW (LPCWSTR lpszDesktop, LPCWSTR lpszDevice, DEVMODEW *pDevmode, DWORD dwFlags, ACCESS_MASK dwDesiredAccess, LPSECURITY_ATTRIBUTES lpsa, ULONG ulHeapSize, PVOID pvoid);






  __attribute__((dllimport)) HDESK OpenDesktopA(LPCSTR lpszDesktop,DWORD dwFlags,WINBOOL fInherit,ACCESS_MASK dwDesiredAccess);
  __attribute__((dllimport)) HDESK OpenDesktopW(LPCWSTR lpszDesktop,DWORD dwFlags,WINBOOL fInherit,ACCESS_MASK dwDesiredAccess);
  __attribute__((dllimport)) HDESK OpenInputDesktop(DWORD dwFlags,WINBOOL fInherit,ACCESS_MASK dwDesiredAccess);
  __attribute__((dllimport)) WINBOOL EnumDesktopsA(HWINSTA hwinsta,DESKTOPENUMPROCA lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EnumDesktopsW(HWINSTA hwinsta,DESKTOPENUMPROCW lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EnumDesktopWindows(HDESK hDesktop,WNDENUMPROC lpfn,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL SwitchDesktop(HDESK hDesktop);
  __attribute__((dllimport)) WINBOOL SetThreadDesktop(HDESK hDesktop);
  __attribute__((dllimport)) WINBOOL CloseDesktop(HDESK hDesktop);
  __attribute__((dllimport)) HDESK GetThreadDesktop(DWORD dwThreadId);
  __attribute__((dllimport)) HWINSTA CreateWindowStationA(LPCSTR lpwinsta,DWORD dwFlags,ACCESS_MASK dwDesiredAccess,LPSECURITY_ATTRIBUTES lpsa);
  __attribute__((dllimport)) HWINSTA CreateWindowStationW(LPCWSTR lpwinsta,DWORD dwFlags,ACCESS_MASK dwDesiredAccess,LPSECURITY_ATTRIBUTES lpsa);
  __attribute__((dllimport)) HWINSTA OpenWindowStationA(LPCSTR lpszWinSta,WINBOOL fInherit,ACCESS_MASK dwDesiredAccess);
  __attribute__((dllimport)) HWINSTA OpenWindowStationW(LPCWSTR lpszWinSta,WINBOOL fInherit,ACCESS_MASK dwDesiredAccess);
  __attribute__((dllimport)) WINBOOL EnumWindowStationsA(WINSTAENUMPROCA lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EnumWindowStationsW(WINSTAENUMPROCW lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL CloseWindowStation(HWINSTA hWinSta);
  __attribute__((dllimport)) WINBOOL SetProcessWindowStation(HWINSTA hWinSta);
  __attribute__((dllimport)) HWINSTA GetProcessWindowStation(void);





  __attribute__((dllimport)) WINBOOL SetUserObjectSecurity(HANDLE hObj,PSECURITY_INFORMATION pSIRequested,PSECURITY_DESCRIPTOR pSID);
  __attribute__((dllimport)) WINBOOL GetUserObjectSecurity(HANDLE hObj,PSECURITY_INFORMATION pSIRequested,PSECURITY_DESCRIPTOR pSID,DWORD nLength,LPDWORD lpnLengthNeeded);
  typedef struct tagUSEROBJECTFLAGS {
    WINBOOL fInherit;
    WINBOOL fReserved;
    DWORD dwFlags;
  } USEROBJECTFLAGS,*PUSEROBJECTFLAGS;




  __attribute__((dllimport)) WINBOOL GetUserObjectInformationA(HANDLE hObj,int nIndex,PVOID pvInfo,DWORD nLength,LPDWORD lpnLengthNeeded);
  __attribute__((dllimport)) WINBOOL GetUserObjectInformationW(HANDLE hObj,int nIndex,PVOID pvInfo,DWORD nLength,LPDWORD lpnLengthNeeded);
  __attribute__((dllimport)) WINBOOL SetUserObjectInformationA(HANDLE hObj,int nIndex,PVOID pvInfo,DWORD nLength);
  __attribute__((dllimport)) WINBOOL SetUserObjectInformationW(HANDLE hObj,int nIndex,PVOID pvInfo,DWORD nLength);




  typedef struct tagWNDCLASSEXA {
    UINT cbSize;
    UINT style;
    WNDPROC lpfnWndProc;
    int cbClsExtra;
    int cbWndExtra;
    HINSTANCE hInstance;
    HICON hIcon;
    HCURSOR hCursor;
    HBRUSH hbrBackground;
    LPCSTR lpszMenuName;
    LPCSTR lpszClassName;
    HICON hIconSm;
  } WNDCLASSEXA,*PWNDCLASSEXA,*NPWNDCLASSEXA,*LPWNDCLASSEXA;

  typedef struct tagWNDCLASSEXW {
    UINT cbSize;
    UINT style;
    WNDPROC lpfnWndProc;
    int cbClsExtra;
    int cbWndExtra;
    HINSTANCE hInstance;
    HICON hIcon;
    HCURSOR hCursor;
    HBRUSH hbrBackground;
    LPCWSTR lpszMenuName;
    LPCWSTR lpszClassName;
    HICON hIconSm;
  } WNDCLASSEXW,*PWNDCLASSEXW,*NPWNDCLASSEXW,*LPWNDCLASSEXW;

  typedef WNDCLASSEXA WNDCLASSEX;
  typedef PWNDCLASSEXA PWNDCLASSEX;
  typedef NPWNDCLASSEXA NPWNDCLASSEX;
  typedef LPWNDCLASSEXA LPWNDCLASSEX;

  typedef struct tagWNDCLASSA {
    UINT style;
    WNDPROC lpfnWndProc;
    int cbClsExtra;
    int cbWndExtra;
    HINSTANCE hInstance;
    HICON hIcon;
    HCURSOR hCursor;
    HBRUSH hbrBackground;
    LPCSTR lpszMenuName;
    LPCSTR lpszClassName;
  } WNDCLASSA,*PWNDCLASSA,*NPWNDCLASSA,*LPWNDCLASSA;

  typedef struct tagWNDCLASSW {
    UINT style;
    WNDPROC lpfnWndProc;
    int cbClsExtra;
    int cbWndExtra;
    HINSTANCE hInstance;
    HICON hIcon;
    HCURSOR hCursor;
    HBRUSH hbrBackground;
    LPCWSTR lpszMenuName;
    LPCWSTR lpszClassName;
  } WNDCLASSW,*PWNDCLASSW,*NPWNDCLASSW,*LPWNDCLASSW;

  typedef WNDCLASSA WNDCLASS;
  typedef PWNDCLASSA PWNDCLASS;
  typedef NPWNDCLASSA NPWNDCLASS;
  typedef LPWNDCLASSA LPWNDCLASS;

  __attribute__((dllimport)) WINBOOL IsHungAppWindow(HWND hwnd);
  __attribute__((dllimport)) void DisableProcessWindowsGhosting(void);




  typedef struct tagMSG {
    HWND hwnd;
    UINT message;
    WPARAM wParam;
    LPARAM lParam;
    DWORD time;
    POINT pt;
  } MSG,*PMSG,*NPMSG,*LPMSG;
  typedef struct tagMINMAXINFO {
    POINT ptReserved;
    POINT ptMaxSize;
    POINT ptMaxPosition;
    POINT ptMinTrackSize;
    POINT ptMaxTrackSize;
  } MINMAXINFO,*PMINMAXINFO,*LPMINMAXINFO;
  typedef struct tagCOPYDATASTRUCT {
    ULONG_PTR dwData;
    DWORD cbData;
    PVOID lpData;
  } COPYDATASTRUCT,*PCOPYDATASTRUCT;

  typedef struct tagMDINEXTMENU {
    HMENU hmenuIn;
    HMENU hmenuNext;
    HWND hwndNext;
  } MDINEXTMENU,*PMDINEXTMENU,*LPMDINEXTMENU;
  typedef struct {
    GUID PowerSetting;
    DWORD DataLength;
    UCHAR Data[1];
  } POWERBROADCAST_SETTING,*PPOWERBROADCAST_SETTING;
  __attribute__((dllimport)) UINT RegisterWindowMessageA(LPCSTR lpString);
  __attribute__((dllimport)) UINT RegisterWindowMessageW(LPCWSTR lpString);
  typedef struct tagWINDOWPOS {
    HWND hwnd;
    HWND hwndInsertAfter;
    int x;
    int y;
    int cx;
    int cy;
    UINT flags;
  } WINDOWPOS,*LPWINDOWPOS,*PWINDOWPOS;

  typedef struct tagNCCALCSIZE_PARAMS {
    RECT rgrc[3];
    PWINDOWPOS lppos;
  } NCCALCSIZE_PARAMS,*LPNCCALCSIZE_PARAMS;
  typedef struct tagTRACKMOUSEEVENT {
    DWORD cbSize;
    DWORD dwFlags;
    HWND hwndTrack;
    DWORD dwHoverTime;
  } TRACKMOUSEEVENT,*LPTRACKMOUSEEVENT;

  __attribute__((dllimport)) WINBOOL TrackMouseEvent(LPTRACKMOUSEEVENT lpEventTrack);
  __attribute__((dllimport)) WINBOOL DrawEdge(HDC hdc,LPRECT qrc,UINT edge,UINT grfFlags);
  __attribute__((dllimport)) WINBOOL DrawFrameControl(HDC,LPRECT,UINT,UINT);
  __attribute__((dllimport)) WINBOOL DrawCaption(HWND hwnd,HDC hdc,const RECT *lprect,UINT flags);






  __attribute__((dllimport)) WINBOOL DrawAnimatedRects(HWND hwnd,int idAni,const RECT *lprcFrom,const RECT *lprcTo);
  typedef struct tagACCEL {
    BYTE fVirt;
    WORD key;
    WORD cmd;
  } ACCEL,*LPACCEL;

  typedef struct tagPAINTSTRUCT {
    HDC hdc;
    WINBOOL fErase;
    RECT rcPaint;
    WINBOOL fRestore;
    WINBOOL fIncUpdate;
    BYTE rgbReserved[32];
  } PAINTSTRUCT,*PPAINTSTRUCT,*NPPAINTSTRUCT,*LPPAINTSTRUCT;

  typedef struct tagCREATESTRUCTA {
    LPVOID lpCreateParams;
    HINSTANCE hInstance;
    HMENU hMenu;
    HWND hwndParent;
    int cy;
    int cx;
    int y;
    int x;
    LONG style;
    LPCSTR lpszName;
    LPCSTR lpszClass;
    DWORD dwExStyle;
  } CREATESTRUCTA,*LPCREATESTRUCTA;

  typedef struct tagCREATESTRUCTW {
    LPVOID lpCreateParams;
    HINSTANCE hInstance;
    HMENU hMenu;
    HWND hwndParent;
    int cy;
    int cx;
    int y;
    int x;
    LONG style;
    LPCWSTR lpszName;
    LPCWSTR lpszClass;
    DWORD dwExStyle;
  } CREATESTRUCTW,*LPCREATESTRUCTW;

  typedef CREATESTRUCTA CREATESTRUCT;
  typedef LPCREATESTRUCTA LPCREATESTRUCT;

  typedef struct tagWINDOWPLACEMENT {
    UINT length;
    UINT flags;
    UINT showCmd;
    POINT ptMinPosition;
    POINT ptMaxPosition;
    RECT rcNormalPosition;
  } WINDOWPLACEMENT;
  typedef WINDOWPLACEMENT *PWINDOWPLACEMENT,*LPWINDOWPLACEMENT;







  typedef struct tagNMHDR {
    HWND hwndFrom;
    UINT_PTR idFrom;
    UINT code;
  } NMHDR;



  typedef NMHDR *LPNMHDR;

  typedef struct tagSTYLESTRUCT {
    DWORD styleOld;
    DWORD styleNew;
  } STYLESTRUCT,*LPSTYLESTRUCT;
  typedef struct tagMEASUREITEMSTRUCT {
    UINT CtlType;
    UINT CtlID;
    UINT itemID;
    UINT itemWidth;
    UINT itemHeight;
    ULONG_PTR itemData;
  } MEASUREITEMSTRUCT,*PMEASUREITEMSTRUCT,*LPMEASUREITEMSTRUCT;

  typedef struct tagDRAWITEMSTRUCT {
    UINT CtlType;
    UINT CtlID;
    UINT itemID;
    UINT itemAction;
    UINT itemState;
    HWND hwndItem;
    HDC hDC;
    RECT rcItem;
    ULONG_PTR itemData;
  } DRAWITEMSTRUCT,*PDRAWITEMSTRUCT,*LPDRAWITEMSTRUCT;

  typedef struct tagDELETEITEMSTRUCT {
    UINT CtlType;
    UINT CtlID;
    UINT itemID;
    HWND hwndItem;
    ULONG_PTR itemData;
  } DELETEITEMSTRUCT,*PDELETEITEMSTRUCT,*LPDELETEITEMSTRUCT;

  typedef struct tagCOMPAREITEMSTRUCT {
    UINT CtlType;
    UINT CtlID;
    HWND hwndItem;
    UINT itemID1;
    ULONG_PTR itemData1;
    UINT itemID2;
    ULONG_PTR itemData2;
    DWORD dwLocaleId;
  } COMPAREITEMSTRUCT,*PCOMPAREITEMSTRUCT,*LPCOMPAREITEMSTRUCT;
  __attribute__((dllimport)) WINBOOL GetMessageA(LPMSG lpMsg,HWND hWnd,UINT wMsgFilterMin,UINT wMsgFilterMax);
  __attribute__((dllimport)) WINBOOL GetMessageW(LPMSG lpMsg,HWND hWnd,UINT wMsgFilterMin,UINT wMsgFilterMax);
  __attribute__((dllimport)) WINBOOL TranslateMessage(const MSG *lpMsg);
  __attribute__((dllimport)) LRESULT DispatchMessageA(const MSG *lpMsg);
  __attribute__((dllimport)) LRESULT DispatchMessageW(const MSG *lpMsg);
  __attribute__((dllimport)) WINBOOL SetMessageQueue(int cMessagesMax);
  __attribute__((dllimport)) WINBOOL PeekMessageA(LPMSG lpMsg,HWND hWnd,UINT wMsgFilterMin,UINT wMsgFilterMax,UINT wRemoveMsg);
  __attribute__((dllimport)) WINBOOL PeekMessageW(LPMSG lpMsg,HWND hWnd,UINT wMsgFilterMin,UINT wMsgFilterMax,UINT wRemoveMsg);
  __attribute__((dllimport)) WINBOOL RegisterHotKey(HWND hWnd,int id,UINT fsModifiers,UINT vk);
  __attribute__((dllimport)) WINBOOL UnregisterHotKey(HWND hWnd,int id);
  __attribute__((dllimport)) WINBOOL ExitWindowsEx(UINT uFlags,DWORD dwReason);
  __attribute__((dllimport)) WINBOOL SwapMouseButton(WINBOOL fSwap);
  __attribute__((dllimport)) DWORD GetMessagePos(void);
  __attribute__((dllimport)) LONG GetMessageTime(void);
  __attribute__((dllimport)) LPARAM GetMessageExtraInfo(void);



  __attribute__((dllimport)) WINBOOL IsWow64Message(void);
  __attribute__((dllimport)) LPARAM SetMessageExtraInfo(LPARAM lParam);
  __attribute__((dllimport)) LRESULT SendMessageA(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) LRESULT SendMessageW(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) LRESULT SendMessageTimeoutA(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam,UINT fuFlags,UINT uTimeout,PDWORD_PTR lpdwResult);
  __attribute__((dllimport)) LRESULT SendMessageTimeoutW(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam,UINT fuFlags,UINT uTimeout,PDWORD_PTR lpdwResult);
  __attribute__((dllimport)) WINBOOL SendNotifyMessageA(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL SendNotifyMessageW(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL SendMessageCallbackA(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam,SENDASYNCPROC lpResultCallBack,ULONG_PTR dwData);
  __attribute__((dllimport)) WINBOOL SendMessageCallbackW(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam,SENDASYNCPROC lpResultCallBack,ULONG_PTR dwData);

  typedef struct {
    UINT cbSize;
    HDESK hdesk;
    HWND hwnd;
    LUID luid;
  } BSMINFO,*PBSMINFO;




  __attribute__((dllimport)) long BroadcastSystemMessageExA(DWORD flags,LPDWORD lpInfo,UINT Msg,WPARAM wParam,LPARAM lParam,PBSMINFO pbsmInfo);
  __attribute__((dllimport)) long BroadcastSystemMessageExW(DWORD flags,LPDWORD lpInfo,UINT Msg,WPARAM wParam,LPARAM lParam,PBSMINFO pbsmInfo);
  __attribute__((dllimport)) long BroadcastSystemMessageA(DWORD flags,LPDWORD lpInfo,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) long BroadcastSystemMessageW(DWORD flags,LPDWORD lpInfo,UINT Msg,WPARAM wParam,LPARAM lParam);
  typedef PVOID HDEVNOTIFY;
  typedef HDEVNOTIFY *PHDEVNOTIFY;
  typedef HANDLE HPOWERNOTIFY;
  typedef HPOWERNOTIFY *PHPOWERNOTIFY;


  __attribute__((dllimport)) HPOWERNOTIFY RegisterPowerSettingNotification (HANDLE hRecipient, LPCGUID PowerSettingGuid, DWORD Flags);
  __attribute__((dllimport)) WINBOOL UnregisterPowerSettingNotification (HPOWERNOTIFY Handle);
  __attribute__((dllimport)) HPOWERNOTIFY RegisterSuspendResumeNotification (HANDLE hRecipient, DWORD Flags);
  __attribute__((dllimport)) WINBOOL UnregisterSuspendResumeNotification (HPOWERNOTIFY Handle);


  __attribute__((dllimport)) WINBOOL PostMessageA (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
  __attribute__((dllimport)) WINBOOL PostMessageW (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
  __attribute__((dllimport)) WINBOOL PostThreadMessageA (DWORD idThread, UINT Msg, WPARAM wParam, LPARAM lParam);
  __attribute__((dllimport)) WINBOOL PostThreadMessageW (DWORD idThread, UINT Msg, WPARAM wParam, LPARAM lParam);




  __attribute__((dllimport)) WINBOOL AttachThreadInput (DWORD idAttach, DWORD idAttachTo, WINBOOL fAttach);
  __attribute__((dllimport)) WINBOOL ReplyMessage (LRESULT lResult);
  __attribute__((dllimport)) WINBOOL WaitMessage (void);
  __attribute__((dllimport)) DWORD WaitForInputIdle (HANDLE hProcess, DWORD dwMilliseconds);
  __attribute__((dllimport)) LRESULT DefWindowProcA (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
  __attribute__((dllimport)) LRESULT DefWindowProcW (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
  __attribute__((dllimport)) void PostQuitMessage (int nExitCode);
  __attribute__((dllimport)) WINBOOL InSendMessage (void);
  __attribute__((dllimport)) DWORD InSendMessageEx (LPVOID lpReserved);
  __attribute__((dllimport)) UINT GetDoubleClickTime (void);
  __attribute__((dllimport)) WINBOOL SetDoubleClickTime (UINT);
  __attribute__((dllimport)) ATOM RegisterClassA (const WNDCLASSA *lpWndClass);
  __attribute__((dllimport)) ATOM RegisterClassW (const WNDCLASSW *lpWndClass);
  __attribute__((dllimport)) WINBOOL UnregisterClassA (LPCSTR lpClassName, HINSTANCE hInstance);
  __attribute__((dllimport)) WINBOOL UnregisterClassW (LPCWSTR lpClassName, HINSTANCE hInstance);
  __attribute__((dllimport)) WINBOOL GetClassInfoA (HINSTANCE hInstance, LPCSTR lpClassName, LPWNDCLASSA lpWndClass);
  __attribute__((dllimport)) WINBOOL GetClassInfoW (HINSTANCE hInstance, LPCWSTR lpClassName, LPWNDCLASSW lpWndClass);
  __attribute__((dllimport)) ATOM RegisterClassExA (const WNDCLASSEXA *);
  __attribute__((dllimport)) ATOM RegisterClassExW (const WNDCLASSEXW *);
  __attribute__((dllimport)) WINBOOL GetClassInfoExA (HINSTANCE hInstance, LPCSTR lpszClass, LPWNDCLASSEXA lpwcx);
  __attribute__((dllimport)) WINBOOL GetClassInfoExW (HINSTANCE hInstance, LPCWSTR lpszClass, LPWNDCLASSEXW lpwcx);


  __attribute__((dllimport)) LRESULT CallWindowProcA (WNDPROC lpPrevWndFunc, HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
  __attribute__((dllimport)) LRESULT CallWindowProcW (WNDPROC lpPrevWndFunc, HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
  extern const GUID GUID_POWERSCHEME_PERSONALITY;
  extern const GUID GUID_MIN_POWER_SAVINGS;
  extern const GUID GUID_MAX_POWER_SAVINGS;
  extern const GUID GUID_TYPICAL_POWER_SAVINGS;
  extern const GUID GUID_ACDC_POWER_SOURCE;
  extern const GUID GUID_BATTERY_PERCENTAGE_REMAINING;
  extern const GUID GUID_IDLE_BACKGROUND_TASK;
  extern const GUID GUID_SYSTEM_AWAYMODE;
  extern const GUID GUID_MONITOR_POWER_ON;



  __attribute__((dllimport)) HDEVNOTIFY RegisterDeviceNotificationA(HANDLE hRecipient,LPVOID NotificationFilter,DWORD Flags);
  __attribute__((dllimport)) HDEVNOTIFY RegisterDeviceNotificationW(HANDLE hRecipient,LPVOID NotificationFilter,DWORD Flags);
  __attribute__((dllimport)) WINBOOL UnregisterDeviceNotification(HDEVNOTIFY Handle);

  typedef BOOLEAN ( *PREGISTERCLASSNAMEW)(LPCWSTR);




  __attribute__((dllimport)) HWND CreateWindowExA(DWORD dwExStyle,LPCSTR lpClassName,LPCSTR lpWindowName,DWORD dwStyle,int X,int Y,int nWidth,int nHeight,HWND hWndParent,HMENU hMenu,HINSTANCE hInstance,LPVOID lpParam);
  __attribute__((dllimport)) HWND CreateWindowExW(DWORD dwExStyle,LPCWSTR lpClassName,LPCWSTR lpWindowName,DWORD dwStyle,int X,int Y,int nWidth,int nHeight,HWND hWndParent,HMENU hMenu,HINSTANCE hInstance,LPVOID lpParam);




  __attribute__((dllimport)) WINBOOL IsWindow(HWND hWnd);
  __attribute__((dllimport)) WINBOOL IsMenu(HMENU hMenu);
  __attribute__((dllimport)) WINBOOL IsChild(HWND hWndParent,HWND hWnd);
  __attribute__((dllimport)) WINBOOL DestroyWindow(HWND hWnd);
  __attribute__((dllimport)) WINBOOL ShowWindow(HWND hWnd,int nCmdShow);
  __attribute__((dllimport)) WINBOOL AnimateWindow(HWND hWnd,DWORD dwTime,DWORD dwFlags);




  __attribute__((dllimport)) WINBOOL UpdateLayeredWindow (HWND hWnd, HDC hdcDst, POINT *pptDst, SIZE *psize, HDC hdcSrc, POINT *pptSrc, COLORREF crKey, BLENDFUNCTION *pblend, DWORD dwFlags);

  typedef struct tagUPDATELAYEREDWINDOWINFO {
    DWORD cbSize;
    HDC hdcDst;
    const POINT *pptDst;
    const SIZE *psize;
    HDC hdcSrc;
    const POINT *pptSrc;
    COLORREF crKey;
    const BLENDFUNCTION *pblend;
    DWORD dwFlags;
    const RECT *prcDirty;
  } UPDATELAYEREDWINDOWINFO,*PUPDATELAYEREDWINDOWINFO;




  __attribute__((dllimport)) WINBOOL UpdateLayeredWindowIndirect (HWND hWnd, const UPDATELAYEREDWINDOWINFO *pULWInfo);




  __attribute__((dllimport)) WINBOOL GetLayeredWindowAttributes (HWND hwnd, COLORREF *pcrKey, BYTE *pbAlpha, DWORD *pdwFlags);



  __attribute__((dllimport)) WINBOOL PrintWindow (HWND hwnd, HDC hdcBlt, UINT nFlags);
  __attribute__((dllimport)) WINBOOL SetLayeredWindowAttributes (HWND hwnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
  typedef struct {
    UINT cbSize;
    HWND hwnd;
    DWORD dwFlags;
    UINT uCount;
    DWORD dwTimeout;
  } FLASHWINFO,*PFLASHWINFO;

  __attribute__((dllimport)) WINBOOL ShowWindowAsync (HWND hWnd, int nCmdShow);
  __attribute__((dllimport)) WINBOOL FlashWindow (HWND hWnd, WINBOOL bInvert);
  __attribute__((dllimport)) WINBOOL FlashWindowEx (PFLASHWINFO pfwi);
  __attribute__((dllimport)) WINBOOL ShowOwnedPopups (HWND hWnd, WINBOOL fShow);
  __attribute__((dllimport)) WINBOOL OpenIcon (HWND hWnd);
  __attribute__((dllimport)) WINBOOL CloseWindow (HWND hWnd);
  __attribute__((dllimport)) WINBOOL MoveWindow (HWND hWnd, int X, int Y, int nWidth, int nHeight, WINBOOL bRepaint);
  __attribute__((dllimport)) WINBOOL SetWindowPos (HWND hWnd, HWND hWndInsertAfter, int X, int Y, int cx, int cy, UINT uFlags);
  __attribute__((dllimport)) WINBOOL GetWindowPlacement (HWND hWnd, WINDOWPLACEMENT *lpwndpl);
  __attribute__((dllimport)) WINBOOL SetWindowPlacement (HWND hWnd, const WINDOWPLACEMENT *lpwndpl);
  __attribute__((dllimport)) HDWP BeginDeferWindowPos (int nNumWindows);
  __attribute__((dllimport)) HDWP DeferWindowPos (HDWP hWinPosInfo, HWND hWnd, HWND hWndInsertAfter, int x, int y, int cx, int cy, UINT uFlags);
  __attribute__((dllimport)) WINBOOL EndDeferWindowPos (HDWP hWinPosInfo);




  __attribute__((dllimport)) WINBOOL IsWindowVisible (HWND hWnd);
  __attribute__((dllimport)) WINBOOL IsIconic (HWND hWnd);
  __attribute__((dllimport)) WINBOOL AnyPopup (void);
  __attribute__((dllimport)) WINBOOL BringWindowToTop (HWND hWnd);
  __attribute__((dllimport)) WINBOOL IsZoomed (HWND hWnd);






#pragma pack(push,2)


  typedef struct {
    DWORD style;
    DWORD dwExtendedStyle;
    WORD cdit;
    short x;
    short y;
    short cx;
    short cy;
  } DLGTEMPLATE;



  typedef DLGTEMPLATE *LPDLGTEMPLATEA;
  typedef DLGTEMPLATE *LPDLGTEMPLATEW;

  typedef LPDLGTEMPLATEA LPDLGTEMPLATE;



  typedef const DLGTEMPLATE *LPCDLGTEMPLATEA;
  typedef const DLGTEMPLATE *LPCDLGTEMPLATEW;

  typedef LPCDLGTEMPLATEA LPCDLGTEMPLATE;



  typedef struct {
    DWORD style;
    DWORD dwExtendedStyle;
    short x;
    short y;
    short cx;
    short cy;
    WORD id;
  } DLGITEMTEMPLATE;

  typedef DLGITEMTEMPLATE *PDLGITEMTEMPLATEA;
  typedef DLGITEMTEMPLATE *PDLGITEMTEMPLATEW;

  typedef PDLGITEMTEMPLATEA PDLGITEMTEMPLATE;

  typedef DLGITEMTEMPLATE *LPDLGITEMTEMPLATEA;
  typedef DLGITEMTEMPLATE *LPDLGITEMTEMPLATEW;

  typedef LPDLGITEMTEMPLATEA LPDLGITEMTEMPLATE;









#pragma pack(pop)
  __attribute__((dllimport)) HWND CreateDialogParamA(HINSTANCE hInstance,LPCSTR lpTemplateName,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);
  __attribute__((dllimport)) HWND CreateDialogParamW(HINSTANCE hInstance,LPCWSTR lpTemplateName,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);
  __attribute__((dllimport)) HWND CreateDialogIndirectParamA(HINSTANCE hInstance,LPCDLGTEMPLATEA lpTemplate,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);
  __attribute__((dllimport)) HWND CreateDialogIndirectParamW(HINSTANCE hInstance,LPCDLGTEMPLATEW lpTemplate,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);






  __attribute__((dllimport)) INT_PTR DialogBoxParamA(HINSTANCE hInstance,LPCSTR lpTemplateName,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);
  __attribute__((dllimport)) INT_PTR DialogBoxParamW(HINSTANCE hInstance,LPCWSTR lpTemplateName,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);
  __attribute__((dllimport)) INT_PTR DialogBoxIndirectParamA(HINSTANCE hInstance,LPCDLGTEMPLATEA hDialogTemplate,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);
  __attribute__((dllimport)) INT_PTR DialogBoxIndirectParamW(HINSTANCE hInstance,LPCDLGTEMPLATEW hDialogTemplate,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);




  __attribute__((dllimport)) WINBOOL EndDialog(HWND hDlg,INT_PTR nResult);
  __attribute__((dllimport)) HWND GetDlgItem(HWND hDlg,int nIDDlgItem);
  __attribute__((dllimport)) WINBOOL SetDlgItemInt(HWND hDlg,int nIDDlgItem,UINT uValue,WINBOOL bSigned);
  __attribute__((dllimport)) UINT GetDlgItemInt(HWND hDlg,int nIDDlgItem,WINBOOL *lpTranslated,WINBOOL bSigned);
  __attribute__((dllimport)) WINBOOL SetDlgItemTextA(HWND hDlg,int nIDDlgItem,LPCSTR lpString);
  __attribute__((dllimport)) WINBOOL SetDlgItemTextW(HWND hDlg,int nIDDlgItem,LPCWSTR lpString);
  __attribute__((dllimport)) UINT GetDlgItemTextA(HWND hDlg,int nIDDlgItem,LPSTR lpString,int cchMax);
  __attribute__((dllimport)) UINT GetDlgItemTextW(HWND hDlg,int nIDDlgItem,LPWSTR lpString,int cchMax);
  __attribute__((dllimport)) WINBOOL CheckDlgButton(HWND hDlg,int nIDButton,UINT uCheck);
  __attribute__((dllimport)) WINBOOL CheckRadioButton(HWND hDlg,int nIDFirstButton,int nIDLastButton,int nIDCheckButton);
  __attribute__((dllimport)) UINT IsDlgButtonChecked(HWND hDlg,int nIDButton);
  __attribute__((dllimport)) LRESULT SendDlgItemMessageA(HWND hDlg,int nIDDlgItem,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) LRESULT SendDlgItemMessageW(HWND hDlg,int nIDDlgItem,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) HWND GetNextDlgGroupItem(HWND hDlg,HWND hCtl,WINBOOL bPrevious);
  __attribute__((dllimport)) HWND GetNextDlgTabItem(HWND hDlg,HWND hCtl,WINBOOL bPrevious);
  __attribute__((dllimport)) int GetDlgCtrlID(HWND hWnd);
  __attribute__((dllimport)) long GetDialogBaseUnits(void);
  __attribute__((dllimport)) LRESULT DefDlgProcA(HWND hDlg,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) LRESULT DefDlgProcW(HWND hDlg,UINT Msg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL CallMsgFilterA(LPMSG lpMsg,int nCode);
  __attribute__((dllimport)) WINBOOL CallMsgFilterW(LPMSG lpMsg,int nCode);
  __attribute__((dllimport)) WINBOOL OpenClipboard(HWND hWndNewOwner);
  __attribute__((dllimport)) WINBOOL CloseClipboard(void);
  __attribute__((dllimport)) DWORD GetClipboardSequenceNumber(void);
  __attribute__((dllimport)) HWND GetClipboardOwner(void);
  __attribute__((dllimport)) HWND SetClipboardViewer(HWND hWndNewViewer);
  __attribute__((dllimport)) HWND GetClipboardViewer(void);
  __attribute__((dllimport)) WINBOOL ChangeClipboardChain(HWND hWndRemove, HWND hWndNewNext);
  __attribute__((dllimport)) HANDLE SetClipboardData(UINT uFormat, HANDLE hMem);
  __attribute__((dllimport)) HANDLE GetClipboardData(UINT uFormat);
  __attribute__((dllimport)) UINT RegisterClipboardFormatA(LPCSTR lpszFormat);
  __attribute__((dllimport)) UINT RegisterClipboardFormatW(LPCWSTR lpszFormat);
  __attribute__((dllimport)) int CountClipboardFormats(void);
  __attribute__((dllimport)) UINT EnumClipboardFormats(UINT format);
  __attribute__((dllimport)) int GetClipboardFormatNameA(UINT format, LPSTR lpszFormatName, int cchMaxCount);
  __attribute__((dllimport)) int GetClipboardFormatNameW(UINT format, LPWSTR lpszFormatName, int cchMaxCount);
  __attribute__((dllimport)) WINBOOL EmptyClipboard(void);
  __attribute__((dllimport)) WINBOOL IsClipboardFormatAvailable(UINT format);
  __attribute__((dllimport)) int GetPriorityClipboardFormat(UINT *paFormatPriorityList, int cFormats);
  __attribute__((dllimport)) HWND GetOpenClipboardWindow(void);

  __attribute__((dllimport)) WINBOOL AddClipboardFormatListener (HWND hwnd);
  __attribute__((dllimport)) WINBOOL RemoveClipboardFormatListener (HWND hwnd);
  __attribute__((dllimport)) WINBOOL GetUpdatedClipboardFormats (PUINT lpuiFormats, UINT cFormats, PUINT pcFormatsOut);
  __attribute__((dllimport)) WINBOOL CharToOemA(LPCSTR lpszSrc,LPSTR lpszDst);
  __attribute__((dllimport)) WINBOOL CharToOemW(LPCWSTR lpszSrc,LPSTR lpszDst);
  __attribute__((dllimport)) WINBOOL OemToCharA(LPCSTR lpszSrc,LPSTR lpszDst);
  __attribute__((dllimport)) WINBOOL OemToCharW(LPCSTR lpszSrc,LPWSTR lpszDst);
  __attribute__((dllimport)) WINBOOL CharToOemBuffA(LPCSTR lpszSrc,LPSTR lpszDst,DWORD cchDstLength);
  __attribute__((dllimport)) WINBOOL CharToOemBuffW(LPCWSTR lpszSrc,LPSTR lpszDst,DWORD cchDstLength);
  __attribute__((dllimport)) WINBOOL OemToCharBuffA(LPCSTR lpszSrc,LPSTR lpszDst,DWORD cchDstLength);
  __attribute__((dllimport)) WINBOOL OemToCharBuffW(LPCSTR lpszSrc,LPWSTR lpszDst,DWORD cchDstLength);
  __attribute__((dllimport)) LPSTR CharUpperA(LPSTR lpsz);
  __attribute__((dllimport)) LPWSTR CharUpperW(LPWSTR lpsz);
  __attribute__((dllimport)) DWORD CharUpperBuffA(LPSTR lpsz,DWORD cchLength);
  __attribute__((dllimport)) DWORD CharUpperBuffW(LPWSTR lpsz,DWORD cchLength);
  __attribute__((dllimport)) LPSTR CharLowerA(LPSTR lpsz);
  __attribute__((dllimport)) LPWSTR CharLowerW(LPWSTR lpsz);
  __attribute__((dllimport)) DWORD CharLowerBuffA(LPSTR lpsz,DWORD cchLength);
  __attribute__((dllimport)) DWORD CharLowerBuffW(LPWSTR lpsz,DWORD cchLength);
  __attribute__((dllimport)) LPSTR CharNextA(LPCSTR lpsz);
  __attribute__((dllimport)) LPWSTR CharNextW(LPCWSTR lpsz);
  __attribute__((dllimport)) LPSTR CharPrevA(LPCSTR lpszStart,LPCSTR lpszCurrent);
  __attribute__((dllimport)) LPWSTR CharPrevW(LPCWSTR lpszStart,LPCWSTR lpszCurrent);
  __attribute__((dllimport)) LPSTR CharNextExA(WORD CodePage,LPCSTR lpCurrentChar,DWORD dwFlags);
  __attribute__((dllimport)) LPSTR CharPrevExA(WORD CodePage,LPCSTR lpStart,LPCSTR lpCurrentChar,DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL IsCharAlphaA(CHAR ch);
  __attribute__((dllimport)) WINBOOL IsCharAlphaW(WCHAR ch);
  __attribute__((dllimport)) WINBOOL IsCharAlphaNumericA(CHAR ch);
  __attribute__((dllimport)) WINBOOL IsCharAlphaNumericW(WCHAR ch);
  __attribute__((dllimport)) WINBOOL IsCharUpperA(CHAR ch);
  __attribute__((dllimport)) WINBOOL IsCharUpperW(WCHAR ch);
  __attribute__((dllimport)) WINBOOL IsCharLowerA(CHAR ch);
  __attribute__((dllimport)) WINBOOL IsCharLowerW(WCHAR ch);
  __attribute__((dllimport)) HWND SetFocus(HWND hWnd);
  __attribute__((dllimport)) HWND GetActiveWindow(void);
  __attribute__((dllimport)) HWND GetFocus(void);
  __attribute__((dllimport)) UINT GetKBCodePage(void);
  __attribute__((dllimport)) SHORT GetKeyState(int nVirtKey);
  __attribute__((dllimport)) SHORT GetAsyncKeyState(int vKey);
  __attribute__((dllimport)) WINBOOL GetKeyboardState(PBYTE lpKeyState);
  __attribute__((dllimport)) WINBOOL SetKeyboardState(LPBYTE lpKeyState);
  __attribute__((dllimport)) int GetKeyNameTextA(LONG lParam,LPSTR lpString,int cchSize);
  __attribute__((dllimport)) int GetKeyNameTextW(LONG lParam,LPWSTR lpString,int cchSize);
  __attribute__((dllimport)) int GetKeyboardType(int nTypeFlag);
  __attribute__((dllimport)) int ToAscii(UINT uVirtKey,UINT uScanCode,const BYTE *lpKeyState,LPWORD lpChar,UINT uFlags);
  __attribute__((dllimport)) int ToAsciiEx(UINT uVirtKey,UINT uScanCode,const BYTE *lpKeyState,LPWORD lpChar,UINT uFlags,HKL dwhkl);
  __attribute__((dllimport)) int ToUnicode(UINT wVirtKey,UINT wScanCode,const BYTE *lpKeyState,LPWSTR pwszBuff,int cchBuff,UINT wFlags);
  __attribute__((dllimport)) DWORD OemKeyScan(WORD wOemChar);
  __attribute__((dllimport)) SHORT VkKeyScanA(CHAR ch);
  __attribute__((dllimport)) SHORT VkKeyScanW(WCHAR ch);
  __attribute__((dllimport)) SHORT VkKeyScanExA(CHAR ch,HKL dwhkl);
  __attribute__((dllimport)) SHORT VkKeyScanExW(WCHAR ch,HKL dwhkl);
  __attribute__((dllimport)) void keybd_event(BYTE bVk,BYTE bScan,DWORD dwFlags,ULONG_PTR dwExtraInfo);
  __attribute__((dllimport)) void mouse_event(DWORD dwFlags,DWORD dx,DWORD dy,DWORD dwData,ULONG_PTR dwExtraInfo);

  typedef struct tagMOUSEINPUT {
    LONG dx;
    LONG dy;
    DWORD mouseData;
    DWORD dwFlags;
    DWORD time;
    ULONG_PTR dwExtraInfo;
  } MOUSEINPUT,*PMOUSEINPUT,*LPMOUSEINPUT;

  typedef struct tagKEYBDINPUT {
    WORD wVk;
    WORD wScan;
    DWORD dwFlags;
    DWORD time;
    ULONG_PTR dwExtraInfo;
  } KEYBDINPUT,*PKEYBDINPUT,*LPKEYBDINPUT;

  typedef struct tagHARDWAREINPUT {
    DWORD uMsg;
    WORD wParamL;
    WORD wParamH;
  } HARDWAREINPUT,*PHARDWAREINPUT,*LPHARDWAREINPUT;

  typedef struct tagINPUT {
    DWORD type;
    __extension__ union {
      MOUSEINPUT mi;
      KEYBDINPUT ki;
      HARDWAREINPUT hi;
    } ;
  } INPUT,*PINPUT,*LPINPUT;

  __attribute__((dllimport)) UINT SendInput(UINT cInputs,LPINPUT pInputs,int cbSize);
  typedef struct tagLASTINPUTINFO {
    UINT cbSize;
    DWORD dwTime;
  } LASTINPUTINFO,*PLASTINPUTINFO;




  __attribute__((dllimport)) WINBOOL GetLastInputInfo(PLASTINPUTINFO plii);
  __attribute__((dllimport)) UINT MapVirtualKeyA(UINT uCode,UINT uMapType);
  __attribute__((dllimport)) UINT MapVirtualKeyW(UINT uCode,UINT uMapType);
  __attribute__((dllimport)) UINT MapVirtualKeyExA(UINT uCode,UINT uMapType,HKL dwhkl);
  __attribute__((dllimport)) UINT MapVirtualKeyExW(UINT uCode,UINT uMapType,HKL dwhkl);
  __attribute__((dllimport)) WINBOOL GetInputState(void);
  __attribute__((dllimport)) DWORD GetQueueStatus(UINT flags);
  __attribute__((dllimport)) HWND GetCapture(void);
  __attribute__((dllimport)) HWND SetCapture(HWND hWnd);
  __attribute__((dllimport)) WINBOOL ReleaseCapture(void);
  __attribute__((dllimport)) DWORD MsgWaitForMultipleObjects(DWORD nCount,const HANDLE *pHandles,WINBOOL fWaitAll,DWORD dwMilliseconds,DWORD dwWakeMask);
  __attribute__((dllimport)) DWORD MsgWaitForMultipleObjectsEx(DWORD nCount,const HANDLE *pHandles,DWORD dwMilliseconds,DWORD dwWakeMask,DWORD dwFlags);
  __attribute__((dllimport)) UINT_PTR SetTimer(HWND hWnd,UINT_PTR nIDEvent,UINT uElapse,TIMERPROC lpTimerFunc);
  __attribute__((dllimport)) WINBOOL KillTimer(HWND hWnd,UINT_PTR uIDEvent);
  __attribute__((dllimport)) WINBOOL IsWindowUnicode(HWND hWnd);
  __attribute__((dllimport)) WINBOOL EnableWindow(HWND hWnd,WINBOOL bEnable);
  __attribute__((dllimport)) WINBOOL IsWindowEnabled(HWND hWnd);
  __attribute__((dllimport)) HACCEL LoadAcceleratorsA(HINSTANCE hInstance,LPCSTR lpTableName);
  __attribute__((dllimport)) HACCEL LoadAcceleratorsW(HINSTANCE hInstance,LPCWSTR lpTableName);
  __attribute__((dllimport)) HACCEL CreateAcceleratorTableA(LPACCEL paccel,int cAccel);
  __attribute__((dllimport)) HACCEL CreateAcceleratorTableW(LPACCEL paccel,int cAccel);
  __attribute__((dllimport)) WINBOOL DestroyAcceleratorTable(HACCEL hAccel);
  __attribute__((dllimport)) int CopyAcceleratorTableA(HACCEL hAccelSrc,LPACCEL lpAccelDst,int cAccelEntries);
  __attribute__((dllimport)) int CopyAcceleratorTableW(HACCEL hAccelSrc,LPACCEL lpAccelDst,int cAccelEntries);




  __attribute__((dllimport)) int TranslateAcceleratorA(HWND hWnd,HACCEL hAccTable,LPMSG lpMsg);
  __attribute__((dllimport)) int TranslateAcceleratorW(HWND hWnd,HACCEL hAccTable,LPMSG lpMsg);
  __attribute__((dllimport)) int GetSystemMetrics(int nIndex);
  __attribute__((dllimport)) HMENU LoadMenuA(HINSTANCE hInstance,LPCSTR lpMenuName);
  __attribute__((dllimport)) HMENU LoadMenuW(HINSTANCE hInstance,LPCWSTR lpMenuName);
  __attribute__((dllimport)) HMENU LoadMenuIndirectA(const MENUTEMPLATEA *lpMenuTemplate);
  __attribute__((dllimport)) HMENU LoadMenuIndirectW(const MENUTEMPLATEW *lpMenuTemplate);
  __attribute__((dllimport)) HMENU GetMenu(HWND hWnd);
  __attribute__((dllimport)) WINBOOL SetMenu(HWND hWnd,HMENU hMenu);
  __attribute__((dllimport)) WINBOOL ChangeMenuA(HMENU hMenu,UINT cmd,LPCSTR lpszNewItem,UINT cmdInsert,UINT flags);
  __attribute__((dllimport)) WINBOOL ChangeMenuW(HMENU hMenu,UINT cmd,LPCWSTR lpszNewItem,UINT cmdInsert,UINT flags);
  __attribute__((dllimport)) WINBOOL HiliteMenuItem(HWND hWnd,HMENU hMenu,UINT uIDHiliteItem,UINT uHilite);
  __attribute__((dllimport)) int GetMenuStringA(HMENU hMenu,UINT uIDItem,LPSTR lpString,int cchMax,UINT flags);
  __attribute__((dllimport)) int GetMenuStringW(HMENU hMenu,UINT uIDItem,LPWSTR lpString,int cchMax,UINT flags);
  __attribute__((dllimport)) UINT GetMenuState(HMENU hMenu,UINT uId,UINT uFlags);
  __attribute__((dllimport)) WINBOOL DrawMenuBar(HWND hWnd);

  __attribute__((dllimport)) HMENU GetSystemMenu(HWND hWnd,WINBOOL bRevert);
  __attribute__((dllimport)) HMENU CreateMenu(void);
  __attribute__((dllimport)) HMENU CreatePopupMenu(void);
  __attribute__((dllimport)) WINBOOL DestroyMenu(HMENU hMenu);
  __attribute__((dllimport)) DWORD CheckMenuItem(HMENU hMenu,UINT uIDCheckItem,UINT uCheck);
  __attribute__((dllimport)) WINBOOL EnableMenuItem(HMENU hMenu,UINT uIDEnableItem,UINT uEnable);
  __attribute__((dllimport)) HMENU GetSubMenu(HMENU hMenu,int nPos);
  __attribute__((dllimport)) UINT GetMenuItemID(HMENU hMenu,int nPos);
  __attribute__((dllimport)) int GetMenuItemCount(HMENU hMenu);
  __attribute__((dllimport)) WINBOOL InsertMenuA(HMENU hMenu,UINT uPosition,UINT uFlags,UINT_PTR uIDNewItem,LPCSTR lpNewItem);
  __attribute__((dllimport)) WINBOOL InsertMenuW(HMENU hMenu,UINT uPosition,UINT uFlags,UINT_PTR uIDNewItem,LPCWSTR lpNewItem);
  __attribute__((dllimport)) WINBOOL AppendMenuA(HMENU hMenu,UINT uFlags,UINT_PTR uIDNewItem,LPCSTR lpNewItem);
  __attribute__((dllimport)) WINBOOL AppendMenuW(HMENU hMenu,UINT uFlags,UINT_PTR uIDNewItem,LPCWSTR lpNewItem);
  __attribute__((dllimport)) WINBOOL ModifyMenuA(HMENU hMnu,UINT uPosition,UINT uFlags,UINT_PTR uIDNewItem,LPCSTR lpNewItem);
  __attribute__((dllimport)) WINBOOL ModifyMenuW(HMENU hMnu,UINT uPosition,UINT uFlags,UINT_PTR uIDNewItem,LPCWSTR lpNewItem);
  __attribute__((dllimport)) WINBOOL RemoveMenu(HMENU hMenu,UINT uPosition,UINT uFlags);
  __attribute__((dllimport)) WINBOOL DeleteMenu(HMENU hMenu,UINT uPosition,UINT uFlags);
  __attribute__((dllimport)) WINBOOL SetMenuItemBitmaps(HMENU hMenu,UINT uPosition,UINT uFlags,HBITMAP hBitmapUnchecked,HBITMAP hBitmapChecked);
  __attribute__((dllimport)) LONG GetMenuCheckMarkDimensions(void);
  __attribute__((dllimport)) WINBOOL TrackPopupMenu(HMENU hMenu,UINT uFlags,int x,int y,int nReserved,HWND hWnd,const RECT *prcRect);

  typedef struct tagTPMPARAMS {
    UINT cbSize;
    RECT rcExclude;
  } TPMPARAMS;

  typedef struct tagMENUINFO {
    DWORD cbSize;
    DWORD fMask;
    DWORD dwStyle;
    UINT cyMax;
    HBRUSH hbrBack;
    DWORD dwContextHelpID;
    ULONG_PTR dwMenuData;
  } MENUINFO,*LPMENUINFO;

  typedef TPMPARAMS *LPTPMPARAMS;
  typedef MENUINFO const *LPCMENUINFO;

  __attribute__((dllimport)) WINBOOL TrackPopupMenuEx(HMENU,UINT,int,int,HWND,LPTPMPARAMS);
  __attribute__((dllimport)) WINBOOL GetMenuInfo(HMENU,LPMENUINFO);
  __attribute__((dllimport)) WINBOOL SetMenuInfo(HMENU,LPCMENUINFO);
  __attribute__((dllimport)) WINBOOL EndMenu(void);




  typedef struct tagMENUGETOBJECTINFO {
    DWORD dwFlags;
    UINT uPos;
    HMENU hmenu;
    PVOID riid;
    PVOID pvObj;
  } MENUGETOBJECTINFO,*PMENUGETOBJECTINFO;

  typedef struct tagMENUITEMINFOA {
    UINT cbSize;
    UINT fMask;
    UINT fType;
    UINT fState;
    UINT wID;
    HMENU hSubMenu;
    HBITMAP hbmpChecked;
    HBITMAP hbmpUnchecked;
    ULONG_PTR dwItemData;
    LPSTR dwTypeData;
    UINT cch;
    HBITMAP hbmpItem;
  } MENUITEMINFOA,*LPMENUITEMINFOA;

  typedef struct tagMENUITEMINFOW {
    UINT cbSize;
    UINT fMask;
    UINT fType;
    UINT fState;
    UINT wID;
    HMENU hSubMenu;
    HBITMAP hbmpChecked;
    HBITMAP hbmpUnchecked;
    ULONG_PTR dwItemData;
    LPWSTR dwTypeData;
    UINT cch;
    HBITMAP hbmpItem;
  } MENUITEMINFOW,*LPMENUITEMINFOW;

  typedef MENUITEMINFOA MENUITEMINFO;
  typedef LPMENUITEMINFOA LPMENUITEMINFO;

  typedef MENUITEMINFOA const *LPCMENUITEMINFOA;
  typedef MENUITEMINFOW const *LPCMENUITEMINFOW;

  typedef LPCMENUITEMINFOA LPCMENUITEMINFO;





  __attribute__((dllimport)) WINBOOL InsertMenuItemA(HMENU hmenu,UINT item,WINBOOL fByPosition,LPCMENUITEMINFOA lpmi);
  __attribute__((dllimport)) WINBOOL InsertMenuItemW(HMENU hmenu,UINT item,WINBOOL fByPosition,LPCMENUITEMINFOW lpmi);
  __attribute__((dllimport)) WINBOOL GetMenuItemInfoA(HMENU hmenu,UINT item,WINBOOL fByPosition,LPMENUITEMINFOA lpmii);
  __attribute__((dllimport)) WINBOOL GetMenuItemInfoW(HMENU hmenu,UINT item,WINBOOL fByPosition,LPMENUITEMINFOW lpmii);
  __attribute__((dllimport)) WINBOOL SetMenuItemInfoA(HMENU hmenu,UINT item,WINBOOL fByPositon,LPCMENUITEMINFOA lpmii);
  __attribute__((dllimport)) WINBOOL SetMenuItemInfoW(HMENU hmenu,UINT item,WINBOOL fByPositon,LPCMENUITEMINFOW lpmii);




  __attribute__((dllimport)) UINT GetMenuDefaultItem(HMENU hMenu,UINT fByPos,UINT gmdiFlags);
  __attribute__((dllimport)) WINBOOL SetMenuDefaultItem(HMENU hMenu,UINT uItem,UINT fByPos);
  __attribute__((dllimport)) WINBOOL GetMenuItemRect(HWND hWnd,HMENU hMenu,UINT uItem,LPRECT lprcItem);
  __attribute__((dllimport)) int MenuItemFromPoint(HWND hWnd,HMENU hMenu,POINT ptScreen);
  typedef struct tagDROPSTRUCT {
    HWND hwndSource;
    HWND hwndSink;
    DWORD wFmt;
    ULONG_PTR dwData;
    POINT ptDrop;
    DWORD dwControlData;
  } DROPSTRUCT,*PDROPSTRUCT,*LPDROPSTRUCT;
  __attribute__((dllimport)) DWORD DragObject(HWND hwndParent,HWND hwndFrom,UINT fmt,ULONG_PTR data,HCURSOR hcur);
  __attribute__((dllimport)) WINBOOL DragDetect(HWND hwnd,POINT pt);
  __attribute__((dllimport)) WINBOOL DrawIcon(HDC hDC,int X,int Y,HICON hIcon);
  typedef struct tagDRAWTEXTPARAMS {
    UINT cbSize;
    int iTabLength;
    int iLeftMargin;
    int iRightMargin;
    UINT uiLengthDrawn;
  } DRAWTEXTPARAMS,*LPDRAWTEXTPARAMS;




  __attribute__((dllimport)) int DrawTextA(HDC hdc,LPCSTR lpchText,int cchText,LPRECT lprc,UINT format);
  __attribute__((dllimport)) int DrawTextW(HDC hdc,LPCWSTR lpchText,int cchText,LPRECT lprc,UINT format);
  __attribute__((dllimport)) int DrawTextExA(HDC hdc,LPSTR lpchText,int cchText,LPRECT lprc,UINT format,LPDRAWTEXTPARAMS lpdtp);
  __attribute__((dllimport)) int DrawTextExW(HDC hdc,LPWSTR lpchText,int cchText,LPRECT lprc,UINT format,LPDRAWTEXTPARAMS lpdtp);
  __attribute__((dllimport)) WINBOOL GrayStringA(HDC hDC,HBRUSH hBrush,GRAYSTRINGPROC lpOutputFunc,LPARAM lpData,int nCount,int X,int Y,int nWidth,int nHeight);
  __attribute__((dllimport)) WINBOOL GrayStringW(HDC hDC,HBRUSH hBrush,GRAYSTRINGPROC lpOutputFunc,LPARAM lpData,int nCount,int X,int Y,int nWidth,int nHeight);
  __attribute__((dllimport)) WINBOOL DrawStateA(HDC hdc,HBRUSH hbrFore,DRAWSTATEPROC qfnCallBack,LPARAM lData,WPARAM wData,int x,int y,int cx,int cy,UINT uFlags);
  __attribute__((dllimport)) WINBOOL DrawStateW(HDC hdc,HBRUSH hbrFore,DRAWSTATEPROC qfnCallBack,LPARAM lData,WPARAM wData,int x,int y,int cx,int cy,UINT uFlags);
  __attribute__((dllimport)) LONG TabbedTextOutA(HDC hdc,int x,int y,LPCSTR lpString,int chCount,int nTabPositions,const INT *lpnTabStopPositions,int nTabOrigin);
  __attribute__((dllimport)) LONG TabbedTextOutW(HDC hdc,int x,int y,LPCWSTR lpString,int chCount,int nTabPositions,const INT *lpnTabStopPositions,int nTabOrigin);
  __attribute__((dllimport)) DWORD GetTabbedTextExtentA(HDC hdc,LPCSTR lpString,int chCount,int nTabPositions,const INT *lpnTabStopPositions);
  __attribute__((dllimport)) DWORD GetTabbedTextExtentW(HDC hdc,LPCWSTR lpString,int chCount,int nTabPositions,const INT *lpnTabStopPositions);
  __attribute__((dllimport)) WINBOOL UpdateWindow(HWND hWnd);
  __attribute__((dllimport)) HWND SetActiveWindow(HWND hWnd);
  __attribute__((dllimport)) HWND GetForegroundWindow(void);
  __attribute__((dllimport)) WINBOOL PaintDesktop(HDC hdc);
  __attribute__((dllimport)) void SwitchToThisWindow(HWND hwnd,WINBOOL fUnknown);
  __attribute__((dllimport)) WINBOOL SetForegroundWindow(HWND hWnd);
  __attribute__((dllimport)) WINBOOL AllowSetForegroundWindow(DWORD dwProcessId);
  __attribute__((dllimport)) WINBOOL LockSetForegroundWindow(UINT uLockCode);
  __attribute__((dllimport)) HWND WindowFromDC(HDC hDC);
  __attribute__((dllimport)) HDC GetDC(HWND hWnd);
  __attribute__((dllimport)) HDC GetDCEx(HWND hWnd,HRGN hrgnClip,DWORD flags);
  __attribute__((dllimport)) HDC GetWindowDC(HWND hWnd);
  __attribute__((dllimport)) int ReleaseDC(HWND hWnd,HDC hDC);
  __attribute__((dllimport)) HDC BeginPaint(HWND hWnd,LPPAINTSTRUCT lpPaint);
  __attribute__((dllimport)) WINBOOL EndPaint(HWND hWnd,const PAINTSTRUCT *lpPaint);
  __attribute__((dllimport)) WINBOOL GetUpdateRect(HWND hWnd,LPRECT lpRect,WINBOOL bErase);
  __attribute__((dllimport)) int GetUpdateRgn(HWND hWnd,HRGN hRgn,WINBOOL bErase);
  __attribute__((dllimport)) int SetWindowRgn(HWND hWnd,HRGN hRgn,WINBOOL bRedraw);
  __attribute__((dllimport)) int GetWindowRgn(HWND hWnd,HRGN hRgn);
  __attribute__((dllimport)) int GetWindowRgnBox(HWND hWnd,LPRECT lprc);
  __attribute__((dllimport)) int ExcludeUpdateRgn(HDC hDC,HWND hWnd);
  __attribute__((dllimport)) WINBOOL InvalidateRect(HWND hWnd,const RECT *lpRect,WINBOOL bErase);
  __attribute__((dllimport)) WINBOOL ValidateRect(HWND hWnd,const RECT *lpRect);
  __attribute__((dllimport)) WINBOOL InvalidateRgn(HWND hWnd,HRGN hRgn,WINBOOL bErase);
  __attribute__((dllimport)) WINBOOL ValidateRgn(HWND hWnd,HRGN hRgn);
  __attribute__((dllimport)) WINBOOL RedrawWindow(HWND hWnd,const RECT *lprcUpdate,HRGN hrgnUpdate,UINT flags);
  __attribute__((dllimport)) WINBOOL LockWindowUpdate(HWND hWndLock);
  __attribute__((dllimport)) WINBOOL ScrollWindow(HWND hWnd,int XAmount,int YAmount,const RECT *lpRect,const RECT *lpClipRect);
  __attribute__((dllimport)) WINBOOL ScrollDC(HDC hDC,int dx,int dy,const RECT *lprcScroll,const RECT *lprcClip,HRGN hrgnUpdate,LPRECT lprcUpdate);
  __attribute__((dllimport)) int ScrollWindowEx(HWND hWnd,int dx,int dy,const RECT *prcScroll,const RECT *prcClip,HRGN hrgnUpdate,LPRECT prcUpdate,UINT flags);
  __attribute__((dllimport)) int SetScrollPos(HWND hWnd,int nBar,int nPos,WINBOOL bRedraw);
  __attribute__((dllimport)) int GetScrollPos(HWND hWnd,int nBar);
  __attribute__((dllimport)) WINBOOL SetScrollRange(HWND hWnd,int nBar,int nMinPos,int nMaxPos,WINBOOL bRedraw);
  __attribute__((dllimport)) WINBOOL GetScrollRange(HWND hWnd,int nBar,LPINT lpMinPos,LPINT lpMaxPos);
  __attribute__((dllimport)) WINBOOL ShowScrollBar(HWND hWnd,int wBar,WINBOOL bShow);
  __attribute__((dllimport)) WINBOOL EnableScrollBar(HWND hWnd,UINT wSBflags,UINT wArrows);
  __attribute__((dllimport)) WINBOOL SetPropA(HWND hWnd,LPCSTR lpString,HANDLE hData);
  __attribute__((dllimport)) WINBOOL SetPropW(HWND hWnd,LPCWSTR lpString,HANDLE hData);
  __attribute__((dllimport)) HANDLE GetPropA(HWND hWnd,LPCSTR lpString);
  __attribute__((dllimport)) HANDLE GetPropW(HWND hWnd,LPCWSTR lpString);
  __attribute__((dllimport)) HANDLE RemovePropA(HWND hWnd,LPCSTR lpString);
  __attribute__((dllimport)) HANDLE RemovePropW(HWND hWnd,LPCWSTR lpString);
  __attribute__((dllimport)) int EnumPropsExA(HWND hWnd,PROPENUMPROCEXA lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) int EnumPropsExW(HWND hWnd,PROPENUMPROCEXW lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) int EnumPropsA(HWND hWnd,PROPENUMPROCA lpEnumFunc);
  __attribute__((dllimport)) int EnumPropsW(HWND hWnd,PROPENUMPROCW lpEnumFunc);
  __attribute__((dllimport)) WINBOOL SetWindowTextA(HWND hWnd,LPCSTR lpString);
  __attribute__((dllimport)) WINBOOL SetWindowTextW(HWND hWnd,LPCWSTR lpString);
  __attribute__((dllimport)) int GetWindowTextA(HWND hWnd,LPSTR lpString,int nMaxCount);
  __attribute__((dllimport)) int GetWindowTextW(HWND hWnd,LPWSTR lpString,int nMaxCount);
  __attribute__((dllimport)) int GetWindowTextLengthA(HWND hWnd);
  __attribute__((dllimport)) int GetWindowTextLengthW(HWND hWnd);
  __attribute__((dllimport)) WINBOOL GetClientRect(HWND hWnd,LPRECT lpRect);
  __attribute__((dllimport)) WINBOOL GetWindowRect(HWND hWnd,LPRECT lpRect);
  __attribute__((dllimport)) WINBOOL AdjustWindowRect(LPRECT lpRect,DWORD dwStyle,WINBOOL bMenu);
  __attribute__((dllimport)) WINBOOL AdjustWindowRectEx(LPRECT lpRect,DWORD dwStyle,WINBOOL bMenu,DWORD dwExStyle);






  typedef struct tagHELPINFO {
    UINT cbSize;
    int iContextType;
    int iCtrlId;
    HANDLE hItemHandle;
    DWORD_PTR dwContextId;
    POINT MousePos;
  } HELPINFO,*LPHELPINFO;

  __attribute__((dllimport)) WINBOOL SetWindowContextHelpId(HWND,DWORD);
  __attribute__((dllimport)) DWORD GetWindowContextHelpId(HWND);
  __attribute__((dllimport)) WINBOOL SetMenuContextHelpId(HMENU,DWORD);
  __attribute__((dllimport)) DWORD GetMenuContextHelpId(HMENU);
  __attribute__((dllimport)) int MessageBoxA(HWND hWnd,LPCSTR lpText,LPCSTR lpCaption,UINT uType);
  __attribute__((dllimport)) int MessageBoxW(HWND hWnd,LPCWSTR lpText,LPCWSTR lpCaption,UINT uType);
  __attribute__((dllimport)) int MessageBoxExA(HWND hWnd,LPCSTR lpText,LPCSTR lpCaption,UINT uType,WORD wLanguageId);
  __attribute__((dllimport)) int MessageBoxExW(HWND hWnd,LPCWSTR lpText,LPCWSTR lpCaption,UINT uType,WORD wLanguageId);

  typedef void ( *MSGBOXCALLBACK)(LPHELPINFO lpHelpInfo);

  typedef struct tagMSGBOXPARAMSA {
    UINT cbSize;
    HWND hwndOwner;
    HINSTANCE hInstance;
    LPCSTR lpszText;
    LPCSTR lpszCaption;
    DWORD dwStyle;
    LPCSTR lpszIcon;
    DWORD_PTR dwContextHelpId;
    MSGBOXCALLBACK lpfnMsgBoxCallback;
    DWORD dwLanguageId;
  } MSGBOXPARAMSA,*PMSGBOXPARAMSA,*LPMSGBOXPARAMSA;

  typedef struct tagMSGBOXPARAMSW {
    UINT cbSize;
    HWND hwndOwner;
    HINSTANCE hInstance;
    LPCWSTR lpszText;
    LPCWSTR lpszCaption;
    DWORD dwStyle;
    LPCWSTR lpszIcon;
    DWORD_PTR dwContextHelpId;
    MSGBOXCALLBACK lpfnMsgBoxCallback;
    DWORD dwLanguageId;
  } MSGBOXPARAMSW,*PMSGBOXPARAMSW,*LPMSGBOXPARAMSW;

  typedef MSGBOXPARAMSA MSGBOXPARAMS;
  typedef PMSGBOXPARAMSA PMSGBOXPARAMS;
  typedef LPMSGBOXPARAMSA LPMSGBOXPARAMS;



  __attribute__((dllimport)) int MessageBoxIndirectA(const MSGBOXPARAMSA *lpmbp);
  __attribute__((dllimport)) int MessageBoxIndirectW(const MSGBOXPARAMSW *lpmbp);
  __attribute__((dllimport)) WINBOOL MessageBeep(UINT uType);




  __attribute__((dllimport)) int ShowCursor(WINBOOL bShow);
  __attribute__((dllimport)) WINBOOL SetCursorPos(int X,int Y);
  __attribute__((dllimport)) HCURSOR SetCursor(HCURSOR hCursor);
  __attribute__((dllimport)) WINBOOL GetCursorPos(LPPOINT lpPoint);
  __attribute__((dllimport)) WINBOOL ClipCursor(const RECT *lpRect);
  __attribute__((dllimport)) WINBOOL GetClipCursor(LPRECT lpRect);
  __attribute__((dllimport)) HCURSOR GetCursor(void);
  __attribute__((dllimport)) WINBOOL CreateCaret(HWND hWnd,HBITMAP hBitmap,int nWidth,int nHeight);
  __attribute__((dllimport)) UINT GetCaretBlinkTime(void);
  __attribute__((dllimport)) WINBOOL SetCaretBlinkTime(UINT uMSeconds);
  __attribute__((dllimport)) WINBOOL DestroyCaret(void);
  __attribute__((dllimport)) WINBOOL HideCaret(HWND hWnd);
  __attribute__((dllimport)) WINBOOL ShowCaret(HWND hWnd);
  __attribute__((dllimport)) WINBOOL SetCaretPos(int X,int Y);
  __attribute__((dllimport)) WINBOOL GetCaretPos(LPPOINT lpPoint);
  __attribute__((dllimport)) WINBOOL ClientToScreen(HWND hWnd,LPPOINT lpPoint);
  __attribute__((dllimport)) WINBOOL ScreenToClient(HWND hWnd,LPPOINT lpPoint);
  __attribute__((dllimport)) int MapWindowPoints(HWND hWndFrom,HWND hWndTo,LPPOINT lpPoints,UINT cPoints);
  __attribute__((dllimport)) HWND WindowFromPoint(POINT Point);
  __attribute__((dllimport)) HWND ChildWindowFromPoint(HWND hWndParent,POINT Point);
  __attribute__((dllimport)) HWND ChildWindowFromPointEx(HWND hwnd,POINT pt,UINT flags);

  __attribute__((dllimport)) WINBOOL SetPhysicalCursorPos (int X, int Y);
  __attribute__((dllimport)) WINBOOL GetPhysicalCursorPos (LPPOINT lpPoint);
  __attribute__((dllimport)) WINBOOL LogicalToPhysicalPoint (HWND hWnd, LPPOINT lpPoint);
  __attribute__((dllimport)) WINBOOL PhysicalToLogicalPoint (HWND hWnd, LPPOINT lpPoint);
  __attribute__((dllimport)) HWND WindowFromPhysicalPoint (POINT Point);
  __attribute__((dllimport)) DWORD GetSysColor(int nIndex);
  __attribute__((dllimport)) HBRUSH GetSysColorBrush(int nIndex);
  __attribute__((dllimport)) WINBOOL SetSysColors(int cElements,const INT *lpaElements,const COLORREF *lpaRgbValues);




  __attribute__((dllimport)) WINBOOL DrawFocusRect(HDC hDC,const RECT *lprc);
  __attribute__((dllimport)) int FillRect(HDC hDC,const RECT *lprc,HBRUSH hbr);
  __attribute__((dllimport)) int FrameRect(HDC hDC,const RECT *lprc,HBRUSH hbr);
  __attribute__((dllimport)) WINBOOL InvertRect(HDC hDC,const RECT *lprc);
  __attribute__((dllimport)) WINBOOL SetRect(LPRECT lprc,int xLeft,int yTop,int xRight,int yBottom);
  __attribute__((dllimport)) WINBOOL SetRectEmpty(LPRECT lprc);
  __attribute__((dllimport)) WINBOOL CopyRect(LPRECT lprcDst,const RECT *lprcSrc);
  __attribute__((dllimport)) WINBOOL InflateRect(LPRECT lprc,int dx,int dy);
  __attribute__((dllimport)) WINBOOL IntersectRect(LPRECT lprcDst,const RECT *lprcSrc1,const RECT *lprcSrc2);
  __attribute__((dllimport)) WINBOOL UnionRect(LPRECT lprcDst,const RECT *lprcSrc1,const RECT *lprcSrc2);
  __attribute__((dllimport)) WINBOOL SubtractRect(LPRECT lprcDst,const RECT *lprcSrc1,const RECT *lprcSrc2);
  __attribute__((dllimport)) WINBOOL OffsetRect(LPRECT lprc,int dx,int dy);
  __attribute__((dllimport)) WINBOOL IsRectEmpty(const RECT *lprc);
  __attribute__((dllimport)) WINBOOL EqualRect(const RECT *lprc1,const RECT *lprc2);
  __attribute__((dllimport)) WINBOOL PtInRect(const RECT *lprc,POINT pt);
  __attribute__((dllimport)) WORD GetWindowWord(HWND hWnd,int nIndex);
  __attribute__((dllimport)) WORD SetWindowWord(HWND hWnd,int nIndex,WORD wNewWord);
  __attribute__((dllimport)) LONG GetWindowLongA(HWND hWnd,int nIndex);
  __attribute__((dllimport)) LONG GetWindowLongW(HWND hWnd,int nIndex);
  __attribute__((dllimport)) LONG SetWindowLongA(HWND hWnd,int nIndex,LONG dwNewLong);
  __attribute__((dllimport)) LONG SetWindowLongW(HWND hWnd,int nIndex,LONG dwNewLong);
  __attribute__((dllimport)) WORD GetClassWord(HWND hWnd,int nIndex);
  __attribute__((dllimport)) WORD SetClassWord(HWND hWnd,int nIndex,WORD wNewWord);
  __attribute__((dllimport)) DWORD GetClassLongA(HWND hWnd,int nIndex);
  __attribute__((dllimport)) DWORD GetClassLongW(HWND hWnd,int nIndex);
  __attribute__((dllimport)) DWORD SetClassLongA(HWND hWnd,int nIndex,LONG dwNewLong);
  __attribute__((dllimport)) DWORD SetClassLongW(HWND hWnd,int nIndex,LONG dwNewLong);
  __attribute__((dllimport)) WINBOOL GetProcessDefaultLayout(DWORD *pdwDefaultLayout);
  __attribute__((dllimport)) WINBOOL SetProcessDefaultLayout(DWORD dwDefaultLayout);
  __attribute__((dllimport)) HWND GetDesktopWindow(void);
  __attribute__((dllimport)) HWND GetParent(HWND hWnd);
  __attribute__((dllimport)) HWND SetParent(HWND hWndChild,HWND hWndNewParent);
  __attribute__((dllimport)) WINBOOL EnumChildWindows(HWND hWndParent,WNDENUMPROC lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) HWND FindWindowA(LPCSTR lpClassName,LPCSTR lpWindowName);
  __attribute__((dllimport)) HWND FindWindowW(LPCWSTR lpClassName,LPCWSTR lpWindowName);
  __attribute__((dllimport)) HWND FindWindowExA(HWND hWndParent,HWND hWndChildAfter,LPCSTR lpszClass,LPCSTR lpszWindow);
  __attribute__((dllimport)) HWND FindWindowExW(HWND hWndParent,HWND hWndChildAfter,LPCWSTR lpszClass,LPCWSTR lpszWindow);
  __attribute__((dllimport)) HWND GetShellWindow(void);
  __attribute__((dllimport)) WINBOOL RegisterShellHookWindow(HWND hwnd);
  __attribute__((dllimport)) WINBOOL DeregisterShellHookWindow(HWND hwnd);
  __attribute__((dllimport)) WINBOOL EnumWindows(WNDENUMPROC lpEnumFunc,LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EnumThreadWindows(DWORD dwThreadId,WNDENUMPROC lpfn,LPARAM lParam);



  __attribute__((dllimport)) int GetClassNameA(HWND hWnd,LPSTR lpClassName,int nMaxCount);
  __attribute__((dllimport)) int GetClassNameW(HWND hWnd,LPWSTR lpClassName,int nMaxCount);
  __attribute__((dllimport)) HWND GetTopWindow(HWND hWnd);





  __attribute__((dllimport)) DWORD GetWindowThreadProcessId(HWND hWnd,LPDWORD lpdwProcessId);
  __attribute__((dllimport)) WINBOOL IsGUIThread(WINBOOL bConvert);



  __attribute__((dllimport)) HWND GetLastActivePopup(HWND hWnd);
  __attribute__((dllimport)) HWND GetWindow(HWND hWnd,UINT uCmd);






  __attribute__((dllimport)) HHOOK SetWindowsHookA (int nFilterType, HOOKPROC pfnFilterProc);
  __attribute__((dllimport)) HHOOK SetWindowsHookW (int nFilterType, HOOKPROC pfnFilterProc);
  __attribute__((dllimport)) WINBOOL UnhookWindowsHook (int nCode, HOOKPROC pfnFilterProc);
  __attribute__((dllimport)) HHOOK SetWindowsHookExA (int idHook, HOOKPROC lpfn, HINSTANCE hmod, DWORD dwThreadId);
  __attribute__((dllimport)) HHOOK SetWindowsHookExW (int idHook, HOOKPROC lpfn, HINSTANCE hmod, DWORD dwThreadId);
  __attribute__((dllimport)) WINBOOL UnhookWindowsHookEx (HHOOK hhk);
  __attribute__((dllimport)) LRESULT CallNextHookEx (HHOOK hhk, int nCode, WPARAM wParam, LPARAM lParam);
  __attribute__((dllimport)) WINBOOL CheckMenuRadioItem(HMENU hmenu,UINT first,UINT last,UINT check,UINT flags);

  typedef struct {
    WORD versionNumber;
    WORD offset;
  } MENUITEMTEMPLATEHEADER,*PMENUITEMTEMPLATEHEADER;

  typedef struct {
    WORD mtOption;
    WORD mtID;
    WCHAR mtString[1];
  } MENUITEMTEMPLATE,*PMENUITEMTEMPLATE;
  __attribute__((dllimport)) HBITMAP LoadBitmapA(HINSTANCE hInstance,LPCSTR lpBitmapName);
  __attribute__((dllimport)) HBITMAP LoadBitmapW(HINSTANCE hInstance,LPCWSTR lpBitmapName);
  __attribute__((dllimport)) HCURSOR LoadCursorA(HINSTANCE hInstance,LPCSTR lpCursorName);
  __attribute__((dllimport)) HCURSOR LoadCursorW(HINSTANCE hInstance,LPCWSTR lpCursorName);
  __attribute__((dllimport)) HCURSOR LoadCursorFromFileA(LPCSTR lpFileName);
  __attribute__((dllimport)) HCURSOR LoadCursorFromFileW(LPCWSTR lpFileName);
  __attribute__((dllimport)) HCURSOR CreateCursor(HINSTANCE hInst,int xHotSpot,int yHotSpot,int nWidth,int nHeight,const void *pvANDPlane,const void *pvXORPlane);
  __attribute__((dllimport)) WINBOOL DestroyCursor(HCURSOR hCursor);
  typedef struct _ICONINFO {
    WINBOOL fIcon;
    DWORD xHotspot;
    DWORD yHotspot;
    HBITMAP hbmMask;
    HBITMAP hbmColor;
  } ICONINFO;
  typedef ICONINFO *PICONINFO;




  __attribute__((dllimport)) WINBOOL SetSystemCursor(HCURSOR hcur,DWORD id);
  __attribute__((dllimport)) HICON LoadIconA(HINSTANCE hInstance,LPCSTR lpIconName);
  __attribute__((dllimport)) HICON LoadIconW(HINSTANCE hInstance,LPCWSTR lpIconName);
  __attribute__((dllimport)) UINT PrivateExtractIconsA(LPCSTR szFileName,int nIconIndex,int cxIcon,int cyIcon,HICON *phicon,UINT *piconid,UINT nIcons,UINT flags);
  __attribute__((dllimport)) UINT PrivateExtractIconsW(LPCWSTR szFileName,int nIconIndex,int cxIcon,int cyIcon,HICON *phicon,UINT *piconid,UINT nIcons,UINT flags);
  __attribute__((dllimport)) HICON CreateIcon(HINSTANCE hInstance,int nWidth,int nHeight,BYTE cPlanes,BYTE cBitsPixel,const BYTE *lpbANDbits,const BYTE *lpbXORbits);
  __attribute__((dllimport)) WINBOOL DestroyIcon(HICON hIcon);
  __attribute__((dllimport)) int LookupIconIdFromDirectory(PBYTE presbits,WINBOOL fIcon);
  __attribute__((dllimport)) int LookupIconIdFromDirectoryEx(PBYTE presbits,WINBOOL fIcon,int cxDesired,int cyDesired,UINT Flags);
  __attribute__((dllimport)) HICON CreateIconFromResource(PBYTE presbits,DWORD dwResSize,WINBOOL fIcon,DWORD dwVer);
  __attribute__((dllimport)) HICON CreateIconFromResourceEx(PBYTE presbits,DWORD dwResSize,WINBOOL fIcon,DWORD dwVer,int cxDesired,int cyDesired,UINT Flags);

  typedef struct tagCURSORSHAPE {
    int xHotSpot;
    int yHotSpot;
    int cx;
    int cy;
    int cbWidth;
    BYTE Planes;
    BYTE BitsPixel;
  } CURSORSHAPE,*LPCURSORSHAPE;
  __attribute__((dllimport)) HANDLE LoadImageA(HINSTANCE hInst,LPCSTR name,UINT type,int cx,int cy,UINT fuLoad);
  __attribute__((dllimport)) HANDLE LoadImageW(HINSTANCE hInst,LPCWSTR name,UINT type,int cx,int cy,UINT fuLoad);
  __attribute__((dllimport)) HANDLE CopyImage(HANDLE h,UINT type,int cx,int cy,UINT flags);
  __attribute__((dllimport)) WINBOOL DrawIconEx(HDC hdc,int xLeft,int yTop,HICON hIcon,int cxWidth,int cyWidth,UINT istepIfAniCur,HBRUSH hbrFlickerFreeDraw,UINT diFlags);
  __attribute__((dllimport)) HICON CreateIconIndirect(PICONINFO piconinfo);
  __attribute__((dllimport)) HICON CopyIcon(HICON hIcon);
  __attribute__((dllimport)) WINBOOL GetIconInfo(HICON hIcon,PICONINFO piconinfo);


  typedef struct _ICONINFOEXA {
    DWORD cbSize;
    WINBOOL fIcon;
    DWORD xHotspot;
    DWORD yHotspot;
    HBITMAP hbmMask;
    HBITMAP hbmColor;
    WORD wResID;
    CHAR szModName[260];
    CHAR szResName[260];
  } ICONINFOEXA,*PICONINFOEXA;

  typedef struct _ICONINFOEXW {
    DWORD cbSize;
    WINBOOL fIcon;
    DWORD xHotspot;
    DWORD yHotspot;
    HBITMAP hbmMask;
    HBITMAP hbmColor;
    WORD wResID;
    WCHAR szModName[260];
    WCHAR szResName[260];
  } ICONINFOEXW,*PICONINFOEXW;

  typedef ICONINFOEXA ICONINFOEX;;
  typedef PICONINFOEXA PICONINFOEX;;



  __attribute__((dllimport)) WINBOOL GetIconInfoExA (HICON hicon, PICONINFOEXA piconinfo);
  __attribute__((dllimport)) WINBOOL GetIconInfoExW (HICON hicon, PICONINFOEXW piconinfo);
  __attribute__((dllimport)) WINBOOL IsDialogMessageA(HWND hDlg,LPMSG lpMsg);
  __attribute__((dllimport)) WINBOOL IsDialogMessageW(HWND hDlg,LPMSG lpMsg);







  __attribute__((dllimport)) WINBOOL MapDialogRect(HWND hDlg,LPRECT lpRect);
  __attribute__((dllimport)) int DlgDirListA(HWND hDlg,LPSTR lpPathSpec,int nIDListBox,int nIDStaticPath,UINT uFileType);
  __attribute__((dllimport)) int DlgDirListW(HWND hDlg,LPWSTR lpPathSpec,int nIDListBox,int nIDStaticPath,UINT uFileType);
  __attribute__((dllimport)) WINBOOL DlgDirSelectExA(HWND hwndDlg,LPSTR lpString,int chCount,int idListBox);
  __attribute__((dllimport)) WINBOOL DlgDirSelectExW(HWND hwndDlg,LPWSTR lpString,int chCount,int idListBox);
  __attribute__((dllimport)) int DlgDirListComboBoxA(HWND hDlg,LPSTR lpPathSpec,int nIDComboBox,int nIDStaticPath,UINT uFiletype);
  __attribute__((dllimport)) int DlgDirListComboBoxW(HWND hDlg,LPWSTR lpPathSpec,int nIDComboBox,int nIDStaticPath,UINT uFiletype);
  __attribute__((dllimport)) WINBOOL DlgDirSelectComboBoxExA(HWND hwndDlg,LPSTR lpString,int cchOut,int idComboBox);
  __attribute__((dllimport)) WINBOOL DlgDirSelectComboBoxExW(HWND hwndDlg,LPWSTR lpString,int cchOut,int idComboBox);
  typedef struct tagSCROLLINFO {
    UINT cbSize;
    UINT fMask;
    int nMin;
    int nMax;
    UINT nPage;
    int nPos;
    int nTrackPos;
  } SCROLLINFO,*LPSCROLLINFO;
  typedef SCROLLINFO const *LPCSCROLLINFO;

  __attribute__((dllimport)) int SetScrollInfo(HWND hwnd,int nBar,LPCSCROLLINFO lpsi,WINBOOL redraw);
  __attribute__((dllimport)) WINBOOL GetScrollInfo(HWND hwnd,int nBar,LPSCROLLINFO lpsi);
  typedef struct tagMDICREATESTRUCTA {
    LPCSTR szClass;
    LPCSTR szTitle;
    HANDLE hOwner;
    int x;
    int y;
    int cx;
    int cy;
    DWORD style;
    LPARAM lParam;
  } MDICREATESTRUCTA,*LPMDICREATESTRUCTA;

  typedef struct tagMDICREATESTRUCTW {
    LPCWSTR szClass;
    LPCWSTR szTitle;
    HANDLE hOwner;
    int x;
    int y;
    int cx;
    int cy;
    DWORD style;
    LPARAM lParam;
  } MDICREATESTRUCTW,*LPMDICREATESTRUCTW;

  typedef MDICREATESTRUCTA MDICREATESTRUCT;
  typedef LPMDICREATESTRUCTA LPMDICREATESTRUCT;

  typedef struct tagCLIENTCREATESTRUCT {
    HANDLE hWindowMenu;
    UINT idFirstChild;
  } CLIENTCREATESTRUCT,*LPCLIENTCREATESTRUCT;





  __attribute__((dllimport)) LRESULT DefFrameProcA(HWND hWnd,HWND hWndMDIClient,UINT uMsg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) LRESULT DefFrameProcW(HWND hWnd,HWND hWndMDIClient,UINT uMsg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) LRESULT DefMDIChildProcA(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
  __attribute__((dllimport)) LRESULT DefMDIChildProcW(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);


  __attribute__((dllimport)) WINBOOL TranslateMDISysAccel(HWND hWndClient,LPMSG lpMsg);


  __attribute__((dllimport)) UINT ArrangeIconicWindows(HWND hWnd);
  __attribute__((dllimport)) HWND CreateMDIWindowA(LPCSTR lpClassName,LPCSTR lpWindowName,DWORD dwStyle,int X,int Y,int nWidth,int nHeight,HWND hWndParent,HINSTANCE hInstance,LPARAM lParam);
  __attribute__((dllimport)) HWND CreateMDIWindowW(LPCWSTR lpClassName,LPCWSTR lpWindowName,DWORD dwStyle,int X,int Y,int nWidth,int nHeight,HWND hWndParent,HINSTANCE hInstance,LPARAM lParam);
  __attribute__((dllimport)) WORD TileWindows(HWND hwndParent,UINT wHow,const RECT *lpRect,UINT cKids,const HWND *lpKids);
  __attribute__((dllimport)) WORD CascadeWindows(HWND hwndParent,UINT wHow,const RECT *lpRect,UINT cKids,const HWND *lpKids);






  typedef DWORD HELPPOLY;

  typedef struct tagMULTIKEYHELPA {
    DWORD mkSize;
    CHAR mkKeylist;
    CHAR szKeyphrase[1];
  } MULTIKEYHELPA,*PMULTIKEYHELPA,*LPMULTIKEYHELPA;

  typedef struct tagMULTIKEYHELPW {
    DWORD mkSize;
    WCHAR mkKeylist;
    WCHAR szKeyphrase[1];
  } MULTIKEYHELPW,*PMULTIKEYHELPW,*LPMULTIKEYHELPW;

  typedef MULTIKEYHELPA MULTIKEYHELP;
  typedef PMULTIKEYHELPA PMULTIKEYHELP;
  typedef LPMULTIKEYHELPA LPMULTIKEYHELP;

  typedef struct tagHELPWININFOA {
    int wStructSize;
    int x;
    int y;
    int dx;
    int dy;
    int wMax;
    CHAR rgchMember[2];
  } HELPWININFOA,*PHELPWININFOA,*LPHELPWININFOA;

  typedef struct tagHELPWININFOW {
    int wStructSize;
    int x;
    int y;
    int dx;
    int dy;
    int wMax;
    WCHAR rgchMember[2];
  } HELPWININFOW,*PHELPWININFOW,*LPHELPWININFOW;

  typedef HELPWININFOA HELPWININFO;
  typedef PHELPWININFOA PHELPWININFO;
  typedef LPHELPWININFOA LPHELPWININFO;



  __attribute__((dllimport)) WINBOOL WinHelpA(HWND hWndMain,LPCSTR lpszHelp,UINT uCommand,ULONG_PTR dwData);
  __attribute__((dllimport)) WINBOOL WinHelpW(HWND hWndMain,LPCWSTR lpszHelp,UINT uCommand,ULONG_PTR dwData);
  __attribute__((dllimport)) DWORD GetGuiResources(HANDLE hProcess,DWORD uiFlags);
  typedef struct tagNONCLIENTMETRICSA {
    UINT cbSize;
    int iBorderWidth;
    int iScrollWidth;
    int iScrollHeight;
    int iCaptionWidth;
    int iCaptionHeight;
    LOGFONTA lfCaptionFont;
    int iSmCaptionWidth;
    int iSmCaptionHeight;
    LOGFONTA lfSmCaptionFont;
    int iMenuWidth;
    int iMenuHeight;
    LOGFONTA lfMenuFont;
    LOGFONTA lfStatusFont;
    LOGFONTA lfMessageFont;

    int iPaddedBorderWidth;

  } NONCLIENTMETRICSA,*PNONCLIENTMETRICSA,*LPNONCLIENTMETRICSA;

  typedef struct tagNONCLIENTMETRICSW {
    UINT cbSize;
    int iBorderWidth;
    int iScrollWidth;
    int iScrollHeight;
    int iCaptionWidth;
    int iCaptionHeight;
    LOGFONTW lfCaptionFont;
    int iSmCaptionWidth;
    int iSmCaptionHeight;
    LOGFONTW lfSmCaptionFont;
    int iMenuWidth;
    int iMenuHeight;
    LOGFONTW lfMenuFont;
    LOGFONTW lfStatusFont;
    LOGFONTW lfMessageFont;

    int iPaddedBorderWidth;

  } NONCLIENTMETRICSW,*PNONCLIENTMETRICSW,*LPNONCLIENTMETRICSW;

  typedef NONCLIENTMETRICSA NONCLIENTMETRICS;
  typedef PNONCLIENTMETRICSA PNONCLIENTMETRICS;
  typedef LPNONCLIENTMETRICSA LPNONCLIENTMETRICS;
  typedef struct tagMINIMIZEDMETRICS {
    UINT cbSize;
    int iWidth;
    int iHorzGap;
    int iVertGap;
    int iArrange;
  } MINIMIZEDMETRICS,*PMINIMIZEDMETRICS,*LPMINIMIZEDMETRICS;



  typedef struct tagICONMETRICSA {
    UINT cbSize;
    int iHorzSpacing;
    int iVertSpacing;
    int iTitleWrap;
    LOGFONTA lfFont;
  } ICONMETRICSA,*PICONMETRICSA,*LPICONMETRICSA;

  typedef struct tagICONMETRICSW {
    UINT cbSize;
    int iHorzSpacing;
    int iVertSpacing;
    int iTitleWrap;
    LOGFONTW lfFont;
  } ICONMETRICSW,*PICONMETRICSW,*LPICONMETRICSW;

  typedef ICONMETRICSA ICONMETRICS;
  typedef PICONMETRICSA PICONMETRICS;
  typedef LPICONMETRICSA LPICONMETRICS;



  typedef struct tagANIMATIONINFO {
    UINT cbSize;
    int iMinAnimate;
  } ANIMATIONINFO,*LPANIMATIONINFO;

  typedef struct tagSERIALKEYSA {
    UINT cbSize;
    DWORD dwFlags;
    LPSTR lpszActivePort;
    LPSTR lpszPort;
    UINT iBaudRate;
    UINT iPortState;
    UINT iActive;
  } SERIALKEYSA,*LPSERIALKEYSA;

  typedef struct tagSERIALKEYSW {
    UINT cbSize;
    DWORD dwFlags;
    LPWSTR lpszActivePort;
    LPWSTR lpszPort;
    UINT iBaudRate;
    UINT iPortState;
    UINT iActive;
  } SERIALKEYSW,*LPSERIALKEYSW;

  typedef SERIALKEYSA SERIALKEYS;
  typedef LPSERIALKEYSA LPSERIALKEYS;

  typedef struct tagHIGHCONTRASTA {
    UINT cbSize;
    DWORD dwFlags;
    LPSTR lpszDefaultScheme;
  } HIGHCONTRASTA,*LPHIGHCONTRASTA;

  typedef struct tagHIGHCONTRASTW {
    UINT cbSize;
    DWORD dwFlags;
    LPWSTR lpszDefaultScheme;
  } HIGHCONTRASTW,*LPHIGHCONTRASTW;

  typedef HIGHCONTRASTA HIGHCONTRAST;
  typedef LPHIGHCONTRASTA LPHIGHCONTRAST;









typedef struct _VIDEOPARAMETERS {
  GUID Guid;
  ULONG dwOffset;
  ULONG dwCommand;
  ULONG dwFlags;
  ULONG dwMode;
  ULONG dwTVStandard;
  ULONG dwAvailableModes;
  ULONG dwAvailableTVStandard;
  ULONG dwFlickerFilter;
  ULONG dwOverScanX;
  ULONG dwOverScanY;
  ULONG dwMaxUnscaledX;
  ULONG dwMaxUnscaledY;
  ULONG dwPositionX;
  ULONG dwPositionY;
  ULONG dwBrightness;
  ULONG dwContrast;
  ULONG dwCPType;
  ULONG dwCPCommand;
  ULONG dwCPStandard;
  ULONG dwCPKey;
  ULONG bCP_APSTriggerBits;
  UCHAR bOEMCopyProtection[256];
} VIDEOPARAMETERS,*PVIDEOPARAMETERS,*LPVIDEOPARAMETERS;
  __attribute__((dllimport)) LONG ChangeDisplaySettingsA(LPDEVMODEA lpDevMode,DWORD dwFlags);
  __attribute__((dllimport)) LONG ChangeDisplaySettingsW(LPDEVMODEW lpDevMode,DWORD dwFlags);
  __attribute__((dllimport)) LONG ChangeDisplaySettingsExA(LPCSTR lpszDeviceName,LPDEVMODEA lpDevMode,HWND hwnd,DWORD dwflags,LPVOID lParam);
  __attribute__((dllimport)) LONG ChangeDisplaySettingsExW(LPCWSTR lpszDeviceName,LPDEVMODEW lpDevMode,HWND hwnd,DWORD dwflags,LPVOID lParam);




  __attribute__((dllimport)) WINBOOL EnumDisplaySettingsA(LPCSTR lpszDeviceName,DWORD iModeNum,LPDEVMODEA lpDevMode);
  __attribute__((dllimport)) WINBOOL EnumDisplaySettingsW(LPCWSTR lpszDeviceName,DWORD iModeNum,LPDEVMODEW lpDevMode);
  __attribute__((dllimport)) WINBOOL EnumDisplaySettingsExA(LPCSTR lpszDeviceName,DWORD iModeNum,LPDEVMODEA lpDevMode,DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumDisplaySettingsExW(LPCWSTR lpszDeviceName,DWORD iModeNum,LPDEVMODEW lpDevMode,DWORD dwFlags);



  __attribute__((dllimport)) WINBOOL EnumDisplayDevicesA(LPCSTR lpDevice,DWORD iDevNum,PDISPLAY_DEVICEA lpDisplayDevice,DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumDisplayDevicesW(LPCWSTR lpDevice,DWORD iDevNum,PDISPLAY_DEVICEW lpDisplayDevice,DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL SystemParametersInfoA(UINT uiAction,UINT uiParam,PVOID pvParam,UINT fWinIni);
  __attribute__((dllimport)) WINBOOL SystemParametersInfoW(UINT uiAction,UINT uiParam,PVOID pvParam,UINT fWinIni);




  typedef struct tagFILTERKEYS {
    UINT cbSize;
    DWORD dwFlags;
    DWORD iWaitMSec;
    DWORD iDelayMSec;
    DWORD iRepeatMSec;
    DWORD iBounceMSec;
  } FILTERKEYS,*LPFILTERKEYS;
  typedef struct tagSTICKYKEYS {
    UINT cbSize;
    DWORD dwFlags;
  } STICKYKEYS,*LPSTICKYKEYS;
  typedef struct tagMOUSEKEYS {
    UINT cbSize;
    DWORD dwFlags;
    DWORD iMaxSpeed;
    DWORD iTimeToMaxSpeed;
    DWORD iCtrlSpeed;
    DWORD dwReserved1;
    DWORD dwReserved2;
  } MOUSEKEYS,*LPMOUSEKEYS;
  typedef struct tagACCESSTIMEOUT {
    UINT cbSize;
    DWORD dwFlags;
    DWORD iTimeOutMSec;
  } ACCESSTIMEOUT,*LPACCESSTIMEOUT;
  typedef struct tagSOUNDSENTRYA {
    UINT cbSize;
    DWORD dwFlags;
    DWORD iFSTextEffect;
    DWORD iFSTextEffectMSec;
    DWORD iFSTextEffectColorBits;
    DWORD iFSGrafEffect;
    DWORD iFSGrafEffectMSec;
    DWORD iFSGrafEffectColor;
    DWORD iWindowsEffect;
    DWORD iWindowsEffectMSec;
    LPSTR lpszWindowsEffectDLL;
    DWORD iWindowsEffectOrdinal;
  } SOUNDSENTRYA,*LPSOUNDSENTRYA;

  typedef struct tagSOUNDSENTRYW {
    UINT cbSize;
    DWORD dwFlags;
    DWORD iFSTextEffect;
    DWORD iFSTextEffectMSec;
    DWORD iFSTextEffectColorBits;
    DWORD iFSGrafEffect;
    DWORD iFSGrafEffectMSec;
    DWORD iFSGrafEffectColor;
    DWORD iWindowsEffect;
    DWORD iWindowsEffectMSec;
    LPWSTR lpszWindowsEffectDLL;
    DWORD iWindowsEffectOrdinal;
  } SOUNDSENTRYW,*LPSOUNDSENTRYW;

  typedef SOUNDSENTRYA SOUNDSENTRY;
  typedef LPSOUNDSENTRYA LPSOUNDSENTRY;
  typedef struct tagTOGGLEKEYS {
    UINT cbSize;
    DWORD dwFlags;
  } TOGGLEKEYS,*LPTOGGLEKEYS;

  typedef struct tagMONITORINFO {
    DWORD cbSize;
    RECT rcMonitor;
    RECT rcWork;
    DWORD dwFlags;
  } MONITORINFO,*LPMONITORINFO;


  typedef struct tagAUDIODESCRIPTION {
    UINT cbSize;
    WINBOOL Enabled;
    LCID Locale;
  } AUDIODESCRIPTION,*LPAUDIODESCRIPTION;
  typedef struct tagMONITORINFOEXA {
    __extension__ struct {
      DWORD cbSize;
      RECT rcMonitor;
      RECT rcWork;
      DWORD dwFlags;
    };
    CHAR szDevice[32];
  } MONITORINFOEXA,*LPMONITORINFOEXA;

  typedef struct tagMONITORINFOEXW {
    __extension__ struct {
      DWORD cbSize;
      RECT rcMonitor;
      RECT rcWork;
      DWORD dwFlags;
    };
    WCHAR szDevice[32];
  } MONITORINFOEXW,*LPMONITORINFOEXW;

  typedef MONITORINFOEXA MONITORINFOEX;
  typedef LPMONITORINFOEXA LPMONITORINFOEX;


  typedef WINBOOL ( *MONITORENUMPROC)(HMONITOR,HDC,LPRECT,LPARAM);

  __attribute__((dllimport)) void SetDebugErrorLevel (DWORD dwLevel);
  __attribute__((dllimport)) void SetLastErrorEx (DWORD dwErrCode, DWORD dwType);
  __attribute__((dllimport)) int InternalGetWindowText (HWND hWnd, LPWSTR pString, int cchMaxCount);
  __attribute__((dllimport)) WINBOOL CancelShutdown (void);
  __attribute__((dllimport)) HMONITOR MonitorFromPoint(POINT pt,DWORD dwFlags);
  __attribute__((dllimport)) HMONITOR MonitorFromRect(LPCRECT lprc,DWORD dwFlags);
  __attribute__((dllimport)) HMONITOR MonitorFromWindow(HWND hwnd,DWORD dwFlags);

  __attribute__((dllimport)) WINBOOL EndTask (HWND hWnd, WINBOOL fShutDown, WINBOOL fForce);


  __attribute__((dllimport)) WINBOOL SoundSentry (void);




  __attribute__((dllimport)) WINBOOL GetMonitorInfoA(HMONITOR hMonitor,LPMONITORINFO lpmi);
  __attribute__((dllimport)) WINBOOL GetMonitorInfoW(HMONITOR hMonitor,LPMONITORINFO lpmi);
  __attribute__((dllimport)) WINBOOL EnumDisplayMonitors(HDC hdc,LPCRECT lprcClip,MONITORENUMPROC lpfnEnum,LPARAM dwData);
  typedef void ( *WINEVENTPROC)(HWINEVENTHOOK hWinEventHook,DWORD event,HWND hwnd,LONG idObject,LONG idChild,DWORD idEventThread,DWORD dwmsEventTime);

  __attribute__((dllimport)) void NotifyWinEvent(DWORD event,HWND hwnd,LONG idObject,LONG idChild);
  __attribute__((dllimport)) HWINEVENTHOOK SetWinEventHook(DWORD eventMin,DWORD eventMax,HMODULE hmodWinEventProc,WINEVENTPROC pfnWinEventProc,DWORD idProcess,DWORD idThread,DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL IsWinEventHookInstalled(DWORD event);
  __attribute__((dllimport)) WINBOOL UnhookWinEvent(HWINEVENTHOOK hWinEventHook);
  typedef struct tagGUITHREADINFO {
    DWORD cbSize;
    DWORD flags;
    HWND hwndActive;
    HWND hwndFocus;
    HWND hwndCapture;
    HWND hwndMenuOwner;
    HWND hwndMoveSize;
    HWND hwndCaret;
    RECT rcCaret;
  } GUITHREADINFO,*PGUITHREADINFO,*LPGUITHREADINFO;
  __attribute__((dllimport)) WINBOOL GetGUIThreadInfo(DWORD idThread,PGUITHREADINFO pgui);
  __attribute__((dllimport)) WINBOOL BlockInput (WINBOOL fBlockIt);
  __attribute__((dllimport)) UINT GetWindowModuleFileNameA(HWND hwnd,LPSTR pszFileName,UINT cchFileNameMax);
  __attribute__((dllimport)) UINT GetWindowModuleFileNameW(HWND hwnd,LPWSTR pszFileName,UINT cchFileNameMax);



  __attribute__((dllimport)) WINBOOL SetProcessDPIAware (void);
  __attribute__((dllimport)) WINBOOL IsProcessDPIAware (void);
  typedef struct tagCURSORINFO {
    DWORD cbSize;
    DWORD flags;
    HCURSOR hCursor;
    POINT ptScreenPos;
  } CURSORINFO,*PCURSORINFO,*LPCURSORINFO;






  __attribute__((dllimport)) WINBOOL GetCursorInfo(PCURSORINFO pci);

  typedef struct tagWINDOWINFO {
    DWORD cbSize;
    RECT rcWindow;
    RECT rcClient;
    DWORD dwStyle;
    DWORD dwExStyle;
    DWORD dwWindowStatus;
    UINT cxWindowBorders;
    UINT cyWindowBorders;
    ATOM atomWindowType;
    WORD wCreatorVersion;
  } WINDOWINFO,*PWINDOWINFO,*LPWINDOWINFO;



  __attribute__((dllimport)) WINBOOL GetWindowInfo(HWND hwnd,PWINDOWINFO pwi);

  typedef struct tagTITLEBARINFO {
    DWORD cbSize;
    RECT rcTitleBar;
    DWORD rgstate[5 + 1];
  } TITLEBARINFO,*PTITLEBARINFO,*LPTITLEBARINFO;

  __attribute__((dllimport)) WINBOOL GetTitleBarInfo(HWND hwnd,PTITLEBARINFO pti);


  typedef struct tagTITLEBARINFOEX {
    DWORD cbSize;
    RECT rcTitleBar;
    DWORD rgstate[5 + 1];
    RECT rgrect[5 + 1];
  } TITLEBARINFOEX,*PTITLEBARINFOEX,*LPTITLEBARINFOEX;


  typedef struct tagMENUBARINFO {
    DWORD cbSize;
    RECT rcBar;
    HMENU hMenu;
    HWND hwndMenu;
    WINBOOL fBarFocused:1;
    WINBOOL fFocused:1;
  } MENUBARINFO,*PMENUBARINFO,*LPMENUBARINFO;

  __attribute__((dllimport)) WINBOOL GetMenuBarInfo(HWND hwnd,LONG idObject,LONG idItem,PMENUBARINFO pmbi);

  typedef struct tagSCROLLBARINFO {
    DWORD cbSize;
    RECT rcScrollBar;
    int dxyLineButton;
    int xyThumbTop;
    int xyThumbBottom;
    int reserved;
    DWORD rgstate[5 + 1];
  } SCROLLBARINFO,*PSCROLLBARINFO,*LPSCROLLBARINFO;

  __attribute__((dllimport)) WINBOOL GetScrollBarInfo(HWND hwnd,LONG idObject,PSCROLLBARINFO psbi);

  typedef struct tagCOMBOBOXINFO {
    DWORD cbSize;
    RECT rcItem;
    RECT rcButton;
    DWORD stateButton;
    HWND hwndCombo;
    HWND hwndItem;
    HWND hwndList;
  } COMBOBOXINFO,*PCOMBOBOXINFO,*LPCOMBOBOXINFO;

  __attribute__((dllimport)) WINBOOL GetComboBoxInfo(HWND hwndCombo,PCOMBOBOXINFO pcbi);
  __attribute__((dllimport)) HWND GetAncestor(HWND hwnd,UINT gaFlags);
  __attribute__((dllimport)) HWND RealChildWindowFromPoint(HWND hwndParent,POINT ptParentClientCoords);
  __attribute__((dllimport)) UINT RealGetWindowClassA(HWND hwnd,LPSTR ptszClassName,UINT cchClassNameMax);
  __attribute__((dllimport)) UINT RealGetWindowClassW(HWND hwnd,LPWSTR ptszClassName,UINT cchClassNameMax);

  typedef struct tagALTTABINFO {
    DWORD cbSize;
    int cItems;
    int cColumns;
    int cRows;
    int iColFocus;
    int iRowFocus;
    int cxItem;
    int cyItem;
    POINT ptStart;
  } ALTTABINFO,*PALTTABINFO,*LPALTTABINFO;



  __attribute__((dllimport)) WINBOOL GetAltTabInfoA(HWND hwnd,int iItem,PALTTABINFO pati,LPSTR pszItemText,UINT cchItemText);
  __attribute__((dllimport)) WINBOOL GetAltTabInfoW(HWND hwnd,int iItem,PALTTABINFO pati,LPWSTR pszItemText,UINT cchItemText);
  __attribute__((dllimport)) DWORD GetListBoxInfo(HWND hwnd);




  __attribute__((dllimport)) WINBOOL LockWorkStation(void);
  __attribute__((dllimport)) WINBOOL UserHandleGrantAccess(HANDLE hUserHandle,HANDLE hJob,WINBOOL bGrant);

  struct HRAWINPUT__ { int unused; }; typedef struct HRAWINPUT__ *HRAWINPUT;
  typedef struct tagRAWINPUTHEADER {
    DWORD dwType;
    DWORD dwSize;
    HANDLE hDevice;
    WPARAM wParam;
  } RAWINPUTHEADER,*PRAWINPUTHEADER,*LPRAWINPUTHEADER;







  typedef struct tagRAWMOUSE {
    USHORT usFlags;
    __extension__ union {
      ULONG ulButtons;
      __extension__ struct {
 USHORT usButtonFlags;
 USHORT usButtonData;
      };
    };
    ULONG ulRawButtons;
    LONG lLastX;
    LONG lLastY;
    ULONG ulExtraInformation;
  } RAWMOUSE,*PRAWMOUSE,*LPRAWMOUSE;
  typedef struct tagRAWKEYBOARD {
    USHORT MakeCode;
    USHORT Flags;
    USHORT Reserved;
    USHORT VKey;
    UINT Message;
    ULONG ExtraInformation;
  } RAWKEYBOARD,*PRAWKEYBOARD,*LPRAWKEYBOARD;
  typedef struct tagRAWHID {
    DWORD dwSizeHid;
    DWORD dwCount;
    BYTE bRawData[1];
  } RAWHID,*PRAWHID,*LPRAWHID;

  typedef struct tagRAWINPUT {
    RAWINPUTHEADER header;
    union {
      RAWMOUSE mouse;
      RAWKEYBOARD keyboard;
      RAWHID hid;
    } data;
  } RAWINPUT,*PRAWINPUT,*LPRAWINPUT;
  __attribute__((dllimport)) UINT GetRawInputData(HRAWINPUT hRawInput,UINT uiCommand,LPVOID pData,PUINT pcbSize,UINT cbSizeHeader);







  typedef struct tagRID_DEVICE_INFO_MOUSE {
    DWORD dwId;
    DWORD dwNumberOfButtons;
    DWORD dwSampleRate;
    WINBOOL fHasHorizontalWheel;
  } RID_DEVICE_INFO_MOUSE,*PRID_DEVICE_INFO_MOUSE;

  typedef struct tagRID_DEVICE_INFO_KEYBOARD {
    DWORD dwType;
    DWORD dwSubType;
    DWORD dwKeyboardMode;
    DWORD dwNumberOfFunctionKeys;
    DWORD dwNumberOfIndicators;
    DWORD dwNumberOfKeysTotal;
  } RID_DEVICE_INFO_KEYBOARD,*PRID_DEVICE_INFO_KEYBOARD;

  typedef struct tagRID_DEVICE_INFO_HID {
    DWORD dwVendorId;
    DWORD dwProductId;
    DWORD dwVersionNumber;
    USHORT usUsagePage;
    USHORT usUsage;
  } RID_DEVICE_INFO_HID,*PRID_DEVICE_INFO_HID;

  typedef struct tagRID_DEVICE_INFO {
    DWORD cbSize;
    DWORD dwType;
    __extension__ union {
      RID_DEVICE_INFO_MOUSE mouse;
      RID_DEVICE_INFO_KEYBOARD keyboard;
      RID_DEVICE_INFO_HID hid;
    } ;
  } RID_DEVICE_INFO,*PRID_DEVICE_INFO,*LPRID_DEVICE_INFO;



  __attribute__((dllimport)) UINT GetRawInputDeviceInfoA(HANDLE hDevice,UINT uiCommand,LPVOID pData,PUINT pcbSize);
  __attribute__((dllimport)) UINT GetRawInputDeviceInfoW(HANDLE hDevice,UINT uiCommand,LPVOID pData,PUINT pcbSize);
  __attribute__((dllimport)) UINT GetRawInputBuffer(PRAWINPUT pData,PUINT pcbSize,UINT cbSizeHeader);

  typedef struct tagRAWINPUTDEVICE {
    USHORT usUsagePage;
    USHORT usUsage;
    DWORD dwFlags;
    HWND hwndTarget;
  } RAWINPUTDEVICE,*PRAWINPUTDEVICE,*LPRAWINPUTDEVICE;

  typedef const RAWINPUTDEVICE *PCRAWINPUTDEVICE;
  typedef struct tagRAWINPUTDEVICELIST {
    HANDLE hDevice;
    DWORD dwType;
  } RAWINPUTDEVICELIST,*PRAWINPUTDEVICELIST;

  __attribute__((dllimport)) WINBOOL RegisterRawInputDevices (PCRAWINPUTDEVICE pRawInputDevices, UINT uiNumDevices, UINT cbSize);
  __attribute__((dllimport)) UINT GetRegisteredRawInputDevices (PRAWINPUTDEVICE pRawInputDevices, PUINT puiNumDevices, UINT cbSize);
  __attribute__((dllimport)) UINT GetRawInputDeviceList (PRAWINPUTDEVICELIST pRawInputDeviceList, PUINT puiNumDevices, UINT cbSize);
  __attribute__((dllimport)) LRESULT DefRawInputProc (PRAWINPUT *paRawInput, INT nInput, UINT cbSizeHeader);
  __attribute__((dllimport)) WINBOOL ChangeWindowMessageFilter (UINT message, DWORD dwFlag);
  __attribute__((dllimport)) WINBOOL ShutdownBlockReasonCreate (HWND hWnd, LPCWSTR pwszReason);
  __attribute__((dllimport)) WINBOOL ShutdownBlockReasonQuery (HWND hWnd, LPWSTR pwszBuff, DWORD *pcchBuff);
  __attribute__((dllimport)) WINBOOL ShutdownBlockReasonDestroy (HWND hWnd);
  __attribute__((dllimport)) int GetTimeFormatEx (LPCWSTR lpLocaleName, DWORD dwFlags, const SYSTEMTIME *lpTime, LPCWSTR lpFormat, LPWSTR lpTimeStr, int cchTime);
  __attribute__((dllimport)) int GetDateFormatEx (LPCWSTR lpLocaleName, DWORD dwFlags, const SYSTEMTIME *lpDate, LPCWSTR lpFormat, LPWSTR lpDateStr, int cchDate, LPCWSTR lpCalendar);



  __attribute__((dllimport)) int GetDateFormatA (LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpDate, LPCSTR lpFormat, LPSTR lpDateStr, int cchDate);
  __attribute__((dllimport)) int GetDateFormatW (LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpDate, LPCWSTR lpFormat, LPWSTR lpDateStr, int cchDate);
  __attribute__((dllimport)) int GetTimeFormatA (LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpTime, LPCSTR lpFormat, LPSTR lpTimeStr, int cchTime);
  __attribute__((dllimport)) int GetTimeFormatW (LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpTime, LPCWSTR lpFormat, LPWSTR lpTimeStr, int cchTime);
  typedef DWORD LGRPID;
  typedef DWORD LCTYPE;
  typedef DWORD CALTYPE;
  typedef DWORD CALID;

  typedef struct _cpinfo {
    UINT MaxCharSize;
    BYTE DefaultChar[2];
    BYTE LeadByte[12];
  } CPINFO,*LPCPINFO;
  typedef struct _cpinfoexA {
    UINT MaxCharSize;
    BYTE DefaultChar[2];
    BYTE LeadByte[12];
    WCHAR UnicodeDefaultChar;
    UINT CodePage;
    CHAR CodePageName[260];
  } CPINFOEXA,*LPCPINFOEXA;

  typedef struct _cpinfoexW {
    UINT MaxCharSize;
    BYTE DefaultChar[2];
    BYTE LeadByte[12];
    WCHAR UnicodeDefaultChar;
    UINT CodePage;
    WCHAR CodePageName[260];
  } CPINFOEXW,*LPCPINFOEXW;

  typedef CPINFOEXA CPINFOEX;
  typedef LPCPINFOEXA LPCPINFOEX;

  typedef struct _numberfmtA {
    UINT NumDigits;
    UINT LeadingZero;
    UINT Grouping;
    LPSTR lpDecimalSep;
    LPSTR lpThousandSep;
    UINT NegativeOrder;
  } NUMBERFMTA,*LPNUMBERFMTA;
  typedef struct _numberfmtW {
    UINT NumDigits;
    UINT LeadingZero;
    UINT Grouping;
    LPWSTR lpDecimalSep;
    LPWSTR lpThousandSep;
    UINT NegativeOrder;
  } NUMBERFMTW,*LPNUMBERFMTW;

  typedef NUMBERFMTA NUMBERFMT;
  typedef LPNUMBERFMTA LPNUMBERFMT;

  typedef struct _currencyfmtA {
    UINT NumDigits;
    UINT LeadingZero;
    UINT Grouping;
    LPSTR lpDecimalSep;
    LPSTR lpThousandSep;
    UINT NegativeOrder;
    UINT PositiveOrder;
    LPSTR lpCurrencySymbol;
  } CURRENCYFMTA,*LPCURRENCYFMTA;

  typedef struct _currencyfmtW {
    UINT NumDigits;
    UINT LeadingZero;
    UINT Grouping;
    LPWSTR lpDecimalSep;
    LPWSTR lpThousandSep;
    UINT NegativeOrder;
    UINT PositiveOrder;
    LPWSTR lpCurrencySymbol;
  } CURRENCYFMTW,*LPCURRENCYFMTW;

  typedef CURRENCYFMTA CURRENCYFMT;
  typedef LPCURRENCYFMTA LPCURRENCYFMT;

  enum SYSNLS_FUNCTION {
    COMPARE_STRING = 0x1
  };

  typedef DWORD NLS_FUNCTION;
  typedef struct _nlsversioninfo {
    DWORD dwNLSVersionInfoSize;
    DWORD dwNLSVersion;
    DWORD dwDefinedVersion;
  } NLSVERSIONINFO,*LPNLSVERSIONINFO;


  typedef struct _nlsversioninfoex {
    DWORD dwNLSVersionInfoSize;
    DWORD dwNLSVersion;
    DWORD dwDefinedVersion;
    DWORD dwEffectiveId;
    GUID guidCustomVersion;
  } NLSVERSIONINFOEX,*LPNLSVERSIONINFOEX;

  typedef LONG GEOID;
  typedef DWORD GEOTYPE;
  typedef DWORD GEOCLASS;



  enum SYSGEOTYPE {
    GEO_NATION = 0x0001,
    GEO_LATITUDE = 0x0002,
    GEO_LONGITUDE = 0x0003,
    GEO_ISO2 = 0x0004,
    GEO_ISO3 = 0x0005,
    GEO_RFC1766 = 0x0006,
    GEO_LCID = 0x0007,
    GEO_FRIENDLYNAME= 0x0008,
    GEO_OFFICIALNAME= 0x0009,
    GEO_TIMEZONES = 0x000a,
    GEO_OFFICIALLANGUAGES = 0x000b,
    GEO_ISO_UN_NUMBER = 0x000c,
    GEO_PARENT = 0x000d
  };

  enum SYSGEOCLASS {
    GEOCLASS_NATION = 16,
    GEOCLASS_REGION = 14,
    GEOCLASS_ALL = 0
  };


  typedef enum _NORM_FORM {
    NormalizationOther = 0,
    NormalizationC = 0x1,
    NormalizationD = 0x2,
    NormalizationKC = 0x5,
    NormalizationKD = 0x6
  } NORM_FORM;
  typedef WINBOOL ( *LANGUAGEGROUP_ENUMPROCA) (LGRPID, LPSTR, LPSTR, DWORD, LONG_PTR);
  typedef WINBOOL ( *LANGGROUPLOCALE_ENUMPROCA) (LGRPID, LCID, LPSTR, LONG_PTR);
  typedef WINBOOL ( *UILANGUAGE_ENUMPROCA) (LPSTR, LONG_PTR);
  typedef WINBOOL ( *CODEPAGE_ENUMPROCA) (LPSTR);
  typedef WINBOOL ( *DATEFMT_ENUMPROCA) (LPSTR);
  typedef WINBOOL ( *DATEFMT_ENUMPROCEXA) (LPSTR, CALID);
  typedef WINBOOL ( *TIMEFMT_ENUMPROCA) (LPSTR);
  typedef WINBOOL ( *CALINFO_ENUMPROCA) (LPSTR);
  typedef WINBOOL ( *CALINFO_ENUMPROCEXA) (LPSTR, CALID);
  typedef WINBOOL ( *LOCALE_ENUMPROCA) (LPSTR);
  typedef WINBOOL ( *LOCALE_ENUMPROCW) (LPWSTR);
  typedef WINBOOL ( *LANGUAGEGROUP_ENUMPROCW) (LGRPID, LPWSTR, LPWSTR, DWORD, LONG_PTR);
  typedef WINBOOL ( *LANGGROUPLOCALE_ENUMPROCW) (LGRPID, LCID, LPWSTR, LONG_PTR);
  typedef WINBOOL ( *UILANGUAGE_ENUMPROCW) (LPWSTR, LONG_PTR);
  typedef WINBOOL ( *CODEPAGE_ENUMPROCW) (LPWSTR);
  typedef WINBOOL ( *DATEFMT_ENUMPROCW) (LPWSTR);
  typedef WINBOOL ( *DATEFMT_ENUMPROCEXW) (LPWSTR, CALID);
  typedef WINBOOL ( *TIMEFMT_ENUMPROCW) (LPWSTR);
  typedef WINBOOL ( *CALINFO_ENUMPROCW) (LPWSTR);
  typedef WINBOOL ( *CALINFO_ENUMPROCEXW) (LPWSTR, CALID);
  typedef WINBOOL ( *GEO_ENUMPROC) (GEOID);
  typedef struct _FILEMUIINFO {
    DWORD dwSize;
    DWORD dwVersion;
    DWORD dwFileType;
    BYTE pChecksum[16];
    BYTE pServiceChecksum[16];
    DWORD dwLanguageNameOffset;
    DWORD dwTypeIDMainSize;
    DWORD dwTypeIDMainOffset;
    DWORD dwTypeNameMainOffset;
    DWORD dwTypeIDMUISize;
    DWORD dwTypeIDMUIOffset;
    DWORD dwTypeNameMUIOffset;
    BYTE abBuffer[8];
  } FILEMUIINFO,*PFILEMUIINFO;









  __attribute__((dllimport)) int CompareStringW (LCID Locale, DWORD dwCmpFlags, PCNZWCH lpString1, int cchCount1, PCNZWCH lpString2, int cchCount2);
  __attribute__((dllimport)) int FoldStringW (DWORD dwMapFlags, LPCWCH lpSrcStr, int cchSrc, LPWSTR lpDestStr, int cchDest);
  __attribute__((dllimport)) WINBOOL GetStringTypeExW (LCID Locale, DWORD dwInfoType, LPCWCH lpSrcStr, int cchSrc, LPWORD lpCharType);

  __attribute__((dllimport)) int CompareStringEx (LPCWSTR lpLocaleName, DWORD dwCmpFlags, LPCWCH lpString1, int cchCount1, LPCWCH lpString2, int cchCount2, LPNLSVERSIONINFO lpVersionInformation, LPVOID lpReserved, LPARAM lParam);
  __attribute__((dllimport)) int CompareStringOrdinal (LPCWCH lpString1, int cchCount1, LPCWCH lpString2, int cchCount2, WINBOOL bIgnoreCase);






  __attribute__((dllimport)) WINBOOL GetStringTypeW (DWORD dwInfoType, LPCWCH lpSrcStr, int cchSrc, LPWORD lpCharType);
  __attribute__((dllimport)) int MultiByteToWideChar (UINT CodePage, DWORD dwFlags, LPCCH lpMultiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int cchWideChar);
  __attribute__((dllimport)) int WideCharToMultiByte (UINT CodePage, DWORD dwFlags, LPCWCH lpWideCharStr, int cchWideChar, LPSTR lpMultiByteStr, int cbMultiByte, LPCCH lpDefaultChar, LPBOOL lpUsedDefaultChar);
  __attribute__((dllimport)) WINBOOL IsValidCodePage (UINT CodePage);



  __attribute__((dllimport)) UINT GetACP (void);
  __attribute__((dllimport)) WINBOOL IsDBCSLeadByteEx (UINT CodePage, BYTE TestChar);



  __attribute__((dllimport)) UINT GetOEMCP (void);
  __attribute__((dllimport)) int CompareStringA (LCID Locale, DWORD dwCmpFlags, PCNZCH lpString1, int cchCount1, PCNZCH lpString2, int cchCount2);
  __attribute__((dllimport)) int LCMapStringW (LCID Locale, DWORD dwMapFlags, LPCWSTR lpSrcStr, int cchSrc, LPWSTR lpDestStr, int cchDest);
  __attribute__((dllimport)) int LCMapStringA (LCID Locale, DWORD dwMapFlags, LPCSTR lpSrcStr, int cchSrc, LPSTR lpDestStr, int cchDest);
  __attribute__((dllimport)) int GetLocaleInfoW (LCID Locale, LCTYPE LCType, LPWSTR lpLCData, int cchData);
  __attribute__((dllimport)) int GetLocaleInfoA (LCID Locale, LCTYPE LCType, LPSTR lpLCData, int cchData);
  __attribute__((dllimport)) WINBOOL IsDBCSLeadByte (BYTE TestChar);
  __attribute__((dllimport)) int GetNumberFormatA (LCID Locale, DWORD dwFlags, LPCSTR lpValue, const NUMBERFMTA *lpFormat, LPSTR lpNumberStr, int cchNumber);
  __attribute__((dllimport)) int GetNumberFormatW (LCID Locale, DWORD dwFlags, LPCWSTR lpValue, const NUMBERFMTW *lpFormat, LPWSTR lpNumberStr, int cchNumber);
  __attribute__((dllimport)) int GetCurrencyFormatA (LCID Locale, DWORD dwFlags, LPCSTR lpValue, const CURRENCYFMTA *lpFormat, LPSTR lpCurrencyStr, int cchCurrency);
  __attribute__((dllimport)) int GetCurrencyFormatW (LCID Locale, DWORD dwFlags, LPCWSTR lpValue, const CURRENCYFMTW *lpFormat, LPWSTR lpCurrencyStr, int cchCurrency);
  __attribute__((dllimport)) WINBOOL EnumCalendarInfoA (CALINFO_ENUMPROCA lpCalInfoEnumProc, LCID Locale, CALID Calendar, CALTYPE CalType);
  __attribute__((dllimport)) WINBOOL EnumCalendarInfoW (CALINFO_ENUMPROCW lpCalInfoEnumProc, LCID Locale, CALID Calendar, CALTYPE CalType);
  __attribute__((dllimport)) WINBOOL EnumCalendarInfoExA (CALINFO_ENUMPROCEXA lpCalInfoEnumProcEx, LCID Locale, CALID Calendar, CALTYPE CalType);
  __attribute__((dllimport)) WINBOOL EnumCalendarInfoExW (CALINFO_ENUMPROCEXW lpCalInfoEnumProcEx, LCID Locale, CALID Calendar, CALTYPE CalType);
  __attribute__((dllimport)) WINBOOL EnumTimeFormatsA (TIMEFMT_ENUMPROCA lpTimeFmtEnumProc, LCID Locale, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumTimeFormatsW (TIMEFMT_ENUMPROCW lpTimeFmtEnumProc, LCID Locale, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumDateFormatsA (DATEFMT_ENUMPROCA lpDateFmtEnumProc, LCID Locale, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumDateFormatsW (DATEFMT_ENUMPROCW lpDateFmtEnumProc, LCID Locale, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumDateFormatsExA (DATEFMT_ENUMPROCEXA lpDateFmtEnumProcEx, LCID Locale, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumDateFormatsExW (DATEFMT_ENUMPROCEXW lpDateFmtEnumProcEx, LCID Locale, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL IsValidLanguageGroup (LGRPID LanguageGroup, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL GetNLSVersion (NLS_FUNCTION Function, LCID Locale, LPNLSVERSIONINFO lpVersionInformation);
  __attribute__((dllimport)) WINBOOL IsNLSDefinedString (NLS_FUNCTION Function, DWORD dwFlags, LPNLSVERSIONINFO lpVersionInformation, LPCWSTR lpString, INT cchStr);
  __attribute__((dllimport)) WINBOOL IsValidLocale (LCID Locale, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL SetLocaleInfoA (LCID Locale, LCTYPE LCType, LPCSTR lpLCData);
  __attribute__((dllimport)) WINBOOL SetLocaleInfoW (LCID Locale, LCTYPE LCType, LPCWSTR lpLCData);
  __attribute__((dllimport)) int GetCalendarInfoA (LCID Locale, CALID Calendar, CALTYPE CalType, LPSTR lpCalData, int cchData, LPDWORD lpValue);
  __attribute__((dllimport)) int GetCalendarInfoW (LCID Locale, CALID Calendar, CALTYPE CalType, LPWSTR lpCalData, int cchData, LPDWORD lpValue);
  __attribute__((dllimport)) WINBOOL SetCalendarInfoA (LCID Locale, CALID Calendar, CALTYPE CalType, LPCSTR lpCalData);
  __attribute__((dllimport)) WINBOOL SetCalendarInfoW (LCID Locale, CALID Calendar, CALTYPE CalType, LPCWSTR lpCalData);

  __attribute__((dllimport)) int GetDurationFormat (LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpDuration, ULONGLONG ullDuration, LPCWSTR lpFormat, LPWSTR lpDurationStr, int cchDuration);
  __attribute__((dllimport)) int FindNLSString (LCID Locale, DWORD dwFindNLSStringFlags, LPCWSTR lpStringSource, int cchSource, LPCWSTR lpStringValue, int cchValue, LPINT pcchFound);
  __attribute__((dllimport)) int GetGeoInfoA (GEOID Location, GEOTYPE GeoType, LPSTR lpGeoData, int cchData, LANGID LangId);
  __attribute__((dllimport)) int GetGeoInfoW (GEOID Location, GEOTYPE GeoType, LPWSTR lpGeoData, int cchData, LANGID LangId);
  __attribute__((dllimport)) WINBOOL EnumSystemGeoID (GEOCLASS GeoClass, GEOID ParentGeoId, GEO_ENUMPROC lpGeoEnumProc);
  __attribute__((dllimport)) GEOID GetUserGeoID (GEOCLASS GeoClass);
  __attribute__((dllimport)) WINBOOL GetCPInfo (UINT CodePage, LPCPINFO lpCPInfo);
  __attribute__((dllimport)) WINBOOL GetCPInfoExA (UINT CodePage, DWORD dwFlags, LPCPINFOEXA lpCPInfoEx);
  __attribute__((dllimport)) WINBOOL GetCPInfoExW (UINT CodePage, DWORD dwFlags, LPCPINFOEXW lpCPInfoEx);


  __attribute__((dllimport)) int LCIDToLocaleName (LCID Locale, LPWSTR lpName, int cchName, DWORD dwFlags);
  __attribute__((dllimport)) LCID LocaleNameToLCID (LPCWSTR lpName, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL SetUserGeoID (GEOID GeoId);
  __attribute__((dllimport)) LCID ConvertDefaultLocale (LCID Locale);
  __attribute__((dllimport)) LCID GetThreadLocale (void);
  __attribute__((dllimport)) WINBOOL SetThreadLocale (LCID Locale);
  __attribute__((dllimport)) LANGID GetSystemDefaultUILanguage (void);
  __attribute__((dllimport)) LANGID GetUserDefaultUILanguage (void);
  __attribute__((dllimport)) LANGID GetSystemDefaultLangID (void);
  __attribute__((dllimport)) LANGID GetUserDefaultLangID (void);
  __attribute__((dllimport)) LCID GetSystemDefaultLCID (void);
  __attribute__((dllimport)) LCID GetUserDefaultLCID (void);
  __attribute__((dllimport)) LANGID SetThreadUILanguage (LANGID LangId);
  __attribute__((dllimport)) WINBOOL GetStringTypeExA (LCID Locale, DWORD dwInfoType, LPCSTR lpSrcStr, int cchSrc, LPWORD lpCharType);
  __attribute__((dllimport)) WINBOOL GetStringTypeA (LCID Locale, DWORD dwInfoType, LPCSTR lpSrcStr, int cchSrc, LPWORD lpCharType);
  __attribute__((dllimport)) int FoldStringA (DWORD dwMapFlags, LPCSTR lpSrcStr, int cchSrc, LPSTR lpDestStr, int cchDest);
  __attribute__((dllimport)) WINBOOL EnumSystemLocalesA (LOCALE_ENUMPROCA lpLocaleEnumProc, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumSystemLocalesW (LOCALE_ENUMPROCW lpLocaleEnumProc, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumSystemLanguageGroupsA (LANGUAGEGROUP_ENUMPROCA lpLanguageGroupEnumProc, DWORD dwFlags, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumSystemLanguageGroupsW (LANGUAGEGROUP_ENUMPROCW lpLanguageGroupEnumProc, DWORD dwFlags, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumLanguageGroupLocalesA (LANGGROUPLOCALE_ENUMPROCA lpLangGroupLocaleEnumProc, LGRPID LanguageGroup, DWORD dwFlags, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumLanguageGroupLocalesW (LANGGROUPLOCALE_ENUMPROCW lpLangGroupLocaleEnumProc, LGRPID LanguageGroup, DWORD dwFlags, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumUILanguagesA (UILANGUAGE_ENUMPROCA lpUILanguageEnumProc, DWORD dwFlags, LONG_PTR lParam);
  __attribute__((dllimport)) WINBOOL EnumUILanguagesW (UILANGUAGE_ENUMPROCW lpUILanguageEnumProc, DWORD dwFlags, LONG_PTR lParam);

  __attribute__((dllimport)) LANGID GetThreadUILanguage (void);
  __attribute__((dllimport)) WINBOOL GetProcessPreferredUILanguages (DWORD dwFlags, PULONG pulNumLanguages, PZZWSTR pwszLanguagesBuffer, PULONG pcchLanguagesBuffer);
  __attribute__((dllimport)) WINBOOL SetProcessPreferredUILanguages (DWORD dwFlags, PCZZWSTR pwszLanguagesBuffer, PULONG pulNumLanguages);
  __attribute__((dllimport)) WINBOOL GetUserPreferredUILanguages (DWORD dwFlags, PULONG pulNumLanguages, PZZWSTR pwszLanguagesBuffer, PULONG pcchLanguagesBuffer);
  __attribute__((dllimport)) WINBOOL GetSystemPreferredUILanguages (DWORD dwFlags, PULONG pulNumLanguages, PZZWSTR pwszLanguagesBuffer, PULONG pcchLanguagesBuffer);
  __attribute__((dllimport)) WINBOOL GetThreadPreferredUILanguages (DWORD dwFlags, PULONG pulNumLanguages, PZZWSTR pwszLanguagesBuffer, PULONG pcchLanguagesBuffer);
  __attribute__((dllimport)) WINBOOL SetThreadPreferredUILanguages (DWORD dwFlags, PCZZWSTR pwszLanguagesBuffer, PULONG pulNumLanguages);
  __attribute__((dllimport)) WINBOOL GetFileMUIInfo (DWORD dwFlags, PCWSTR pcwszFilePath, PFILEMUIINFO pFileMUIInfo, DWORD *pcbFileMUIInfo);
  __attribute__((dllimport)) WINBOOL GetFileMUIPath (DWORD dwFlags, PCWSTR pcwszFilePath, PWSTR pwszLanguage, PULONG pcchLanguage, PWSTR pwszFileMUIPath, PULONG pcchFileMUIPath, PULONGLONG pululEnumerator);
  __attribute__((dllimport)) WINBOOL GetUILanguageInfo (DWORD dwFlags, PCZZWSTR pwmszLanguage, PZZWSTR pwszFallbackLanguages, PDWORD pcchFallbackLanguages, PDWORD pAttributes);
  __attribute__((dllimport)) WINBOOL NotifyUILanguageChange (DWORD dwFlags, PCWSTR pcwstrNewLanguage, PCWSTR pcwstrPreviousLanguage, DWORD dwReserved, PDWORD pdwStatusRtrn);
  __attribute__((dllimport)) WINBOOL EnumSystemCodePagesA (CODEPAGE_ENUMPROCA lpCodePageEnumProc, DWORD dwFlags);
  __attribute__((dllimport)) WINBOOL EnumSystemCodePagesW (CODEPAGE_ENUMPROCW lpCodePageEnumProc, DWORD dwFlags);
  typedef WINBOOL ( *CALINFO_ENUMPROCEXEX) (LPWSTR, CALID, LPWSTR, LPARAM);
  typedef WINBOOL ( *DATEFMT_ENUMPROCEXEX) (LPWSTR, CALID, LPARAM);
  typedef WINBOOL ( *TIMEFMT_ENUMPROCEX) (LPWSTR, LPARAM);
  typedef WINBOOL ( *LOCALE_ENUMPROCEX) (LPWSTR, DWORD, LPARAM);

  __attribute__((dllimport)) int NormalizeString (NORM_FORM NormForm, LPCWSTR lpSrcString, int cwSrcLength, LPWSTR lpDstString, int cwDstLength);
  __attribute__((dllimport)) WINBOOL IsNormalizedString (NORM_FORM NormForm, LPCWSTR lpString, int cwLength);
  __attribute__((dllimport)) int IdnToAscii (DWORD dwFlags, LPCWSTR lpUnicodeCharStr, int cchUnicodeChar, LPWSTR lpASCIICharStr, int cchASCIIChar);
  __attribute__((dllimport)) int IdnToNameprepUnicode (DWORD dwFlags, LPCWSTR lpUnicodeCharStr, int cchUnicodeChar, LPWSTR lpNameprepCharStr, int cchNameprepChar);
  __attribute__((dllimport)) int IdnToUnicode (DWORD dwFlags, LPCWSTR lpASCIICharStr, int cchASCIIChar, LPWSTR lpUnicodeCharStr, int cchUnicodeChar);

  __attribute__((dllimport)) WINBOOL VerifyScripts (DWORD dwFlags, LPCWSTR lpLocaleScripts, int cchLocaleScripts, LPCWSTR lpTestScripts, int cchTestScripts);
  __attribute__((dllimport)) int GetStringScripts (DWORD dwFlags, LPCWSTR lpString, int cchString, LPWSTR lpScripts, int cchScripts);
  __attribute__((dllimport)) int GetLocaleInfoEx (LPCWSTR lpLocaleName, LCTYPE LCType, LPWSTR lpLCData, int cchData);
  __attribute__((dllimport)) int GetCalendarInfoEx (LPCWSTR lpLocaleName, CALID Calendar, LPCWSTR lpReserved, CALTYPE CalType, LPWSTR lpCalData, int cchData, LPDWORD lpValue);
  __attribute__((dllimport)) int GetDurationFormatEx (LPCWSTR lpLocaleName, DWORD dwFlags, const SYSTEMTIME *lpDuration, ULONGLONG ullDuration, LPCWSTR lpFormat, LPWSTR lpDurationStr, int cchDuration);
  __attribute__((dllimport)) int GetNumberFormatEx (LPCWSTR lpLocaleName, DWORD dwFlags, LPCWSTR lpValue, const NUMBERFMTW *lpFormat, LPWSTR lpNumberStr, int cchNumber);
  __attribute__((dllimport)) int GetCurrencyFormatEx (LPCWSTR lpLocaleName, DWORD dwFlags, LPCWSTR lpValue, const CURRENCYFMTW *lpFormat, LPWSTR lpCurrencyStr, int cchCurrency);
  __attribute__((dllimport)) int GetUserDefaultLocaleName (LPWSTR lpLocaleName, int cchLocaleName);
  __attribute__((dllimport)) int GetSystemDefaultLocaleName (LPWSTR lpLocaleName, int cchLocaleName);
  __attribute__((dllimport)) WINBOOL GetNLSVersionEx (NLS_FUNCTION function, LPCWSTR lpLocaleName, LPNLSVERSIONINFOEX lpVersionInformation);
  __attribute__((dllimport)) int FindNLSStringEx (LPCWSTR lpLocaleName, DWORD dwFindNLSStringFlags, LPCWSTR lpStringSource, int cchSource, LPCWSTR lpStringValue, int cchValue, LPINT pcchFound, LPNLSVERSIONINFO lpVersionInformation, LPVOID lpReserved, LPARAM sortHandle);
  __attribute__((dllimport)) int LCMapStringEx (LPCWSTR lpLocaleName, DWORD dwMapFlags, LPCWSTR lpSrcStr, int cchSrc, LPWSTR lpDestStr, int cchDest, LPNLSVERSIONINFO lpVersionInformation, LPVOID lpReserved, LPARAM sortHandle);
  __attribute__((dllimport)) WINBOOL IsValidLocaleName (LPCWSTR lpLocaleName);
  __attribute__((dllimport)) WINBOOL EnumCalendarInfoExEx (CALINFO_ENUMPROCEXEX pCalInfoEnumProcExEx, LPCWSTR lpLocaleName, CALID Calendar, LPCWSTR lpReserved, CALTYPE CalType, LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EnumDateFormatsExEx (DATEFMT_ENUMPROCEXEX lpDateFmtEnumProcExEx, LPCWSTR lpLocaleName, DWORD dwFlags, LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EnumTimeFormatsEx (TIMEFMT_ENUMPROCEX lpTimeFmtEnumProcEx, LPCWSTR lpLocaleName, DWORD dwFlags, LPARAM lParam);
  __attribute__((dllimport)) WINBOOL EnumSystemLocalesEx (LOCALE_ENUMPROCEX lpLocaleEnumProcEx, DWORD dwFlags, LPARAM lParam, LPVOID lpReserved);
  typedef struct _COORD {
    SHORT X;
    SHORT Y;
  } COORD,*PCOORD;

  typedef struct _SMALL_RECT {
    SHORT Left;
    SHORT Top;
    SHORT Right;
    SHORT Bottom;
  } SMALL_RECT,*PSMALL_RECT;

  typedef struct _KEY_EVENT_RECORD {
    WINBOOL bKeyDown;
    WORD wRepeatCount;
    WORD wVirtualKeyCode;
    WORD wVirtualScanCode;
    union {
      WCHAR UnicodeChar;
      CHAR AsciiChar;
    } uChar;
    DWORD dwControlKeyState;
  } KEY_EVENT_RECORD,*PKEY_EVENT_RECORD;
  typedef struct _MOUSE_EVENT_RECORD {
    COORD dwMousePosition;
    DWORD dwButtonState;
    DWORD dwControlKeyState;
    DWORD dwEventFlags;
  } MOUSE_EVENT_RECORD,*PMOUSE_EVENT_RECORD;
  typedef struct _WINDOW_BUFFER_SIZE_RECORD {
    COORD dwSize;
  } WINDOW_BUFFER_SIZE_RECORD,*PWINDOW_BUFFER_SIZE_RECORD;

  typedef struct _MENU_EVENT_RECORD {
    UINT dwCommandId;
  } MENU_EVENT_RECORD,*PMENU_EVENT_RECORD;

  typedef struct _FOCUS_EVENT_RECORD {
    WINBOOL bSetFocus;
  } FOCUS_EVENT_RECORD,*PFOCUS_EVENT_RECORD;

  typedef struct _INPUT_RECORD {
    WORD EventType;
    union {
      KEY_EVENT_RECORD KeyEvent;
      MOUSE_EVENT_RECORD MouseEvent;
      WINDOW_BUFFER_SIZE_RECORD WindowBufferSizeEvent;
      MENU_EVENT_RECORD MenuEvent;
      FOCUS_EVENT_RECORD FocusEvent;
    } Event;
  } INPUT_RECORD,*PINPUT_RECORD;







  typedef struct _CHAR_INFO {
    union {
      WCHAR UnicodeChar;
      CHAR AsciiChar;
    } Char;
    WORD Attributes;
  } CHAR_INFO,*PCHAR_INFO;
  typedef struct _CONSOLE_SCREEN_BUFFER_INFO {
    COORD dwSize;
    COORD dwCursorPosition;
    WORD wAttributes;
    SMALL_RECT srWindow;
    COORD dwMaximumWindowSize;
  } CONSOLE_SCREEN_BUFFER_INFO,*PCONSOLE_SCREEN_BUFFER_INFO;

  typedef struct _CONSOLE_CURSOR_INFO {
    DWORD dwSize;
    WINBOOL bVisible;
  } CONSOLE_CURSOR_INFO,*PCONSOLE_CURSOR_INFO;

  typedef struct _CONSOLE_FONT_INFO {
    DWORD nFont;
    COORD dwFontSize;
  } CONSOLE_FONT_INFO,*PCONSOLE_FONT_INFO;

  typedef struct _CONSOLE_SELECTION_INFO {
    DWORD dwFlags;
    COORD dwSelectionAnchor;
    SMALL_RECT srSelection;
  } CONSOLE_SELECTION_INFO,*PCONSOLE_SELECTION_INFO;







  typedef WINBOOL ( *PHANDLER_ROUTINE)(DWORD CtrlType);
  __attribute__((dllimport)) WINBOOL PeekConsoleInputA(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  __attribute__((dllimport)) WINBOOL PeekConsoleInputW(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  __attribute__((dllimport)) WINBOOL ReadConsoleInputA(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  __attribute__((dllimport)) WINBOOL ReadConsoleInputW(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  __attribute__((dllimport)) WINBOOL WriteConsoleInputA(HANDLE hConsoleInput,const INPUT_RECORD *lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsWritten);
  __attribute__((dllimport)) WINBOOL WriteConsoleInputW(HANDLE hConsoleInput,const INPUT_RECORD *lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsWritten);
  __attribute__((dllimport)) WINBOOL ReadConsoleOutputA(HANDLE hConsoleOutput,PCHAR_INFO lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpReadRegion);
  __attribute__((dllimport)) WINBOOL ReadConsoleOutputW(HANDLE hConsoleOutput,PCHAR_INFO lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpReadRegion);
  __attribute__((dllimport)) WINBOOL WriteConsoleOutputA(HANDLE hConsoleOutput,const CHAR_INFO *lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpWriteRegion);
  __attribute__((dllimport)) WINBOOL WriteConsoleOutputW(HANDLE hConsoleOutput,const CHAR_INFO *lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpWriteRegion);
  __attribute__((dllimport)) WINBOOL ReadConsoleOutputCharacterA(HANDLE hConsoleOutput,LPSTR lpCharacter,DWORD nLength,COORD dwReadCoord,LPDWORD lpNumberOfCharsRead);
  __attribute__((dllimport)) WINBOOL ReadConsoleOutputCharacterW(HANDLE hConsoleOutput,LPWSTR lpCharacter,DWORD nLength,COORD dwReadCoord,LPDWORD lpNumberOfCharsRead);
  __attribute__((dllimport)) WINBOOL ReadConsoleOutputAttribute(HANDLE hConsoleOutput,LPWORD lpAttribute,DWORD nLength,COORD dwReadCoord,LPDWORD lpNumberOfAttrsRead);
  __attribute__((dllimport)) WINBOOL WriteConsoleOutputCharacterA(HANDLE hConsoleOutput,LPCSTR lpCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  __attribute__((dllimport)) WINBOOL WriteConsoleOutputCharacterW(HANDLE hConsoleOutput,LPCWSTR lpCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  __attribute__((dllimport)) WINBOOL WriteConsoleOutputAttribute(HANDLE hConsoleOutput,const WORD *lpAttribute,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfAttrsWritten);
  __attribute__((dllimport)) WINBOOL FillConsoleOutputCharacterA(HANDLE hConsoleOutput,CHAR cCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  __attribute__((dllimport)) WINBOOL FillConsoleOutputCharacterW(HANDLE hConsoleOutput,WCHAR cCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  __attribute__((dllimport)) WINBOOL FillConsoleOutputAttribute(HANDLE hConsoleOutput,WORD wAttribute,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfAttrsWritten);
  __attribute__((dllimport)) WINBOOL GetConsoleMode(HANDLE hConsoleHandle,LPDWORD lpMode);
  __attribute__((dllimport)) WINBOOL GetNumberOfConsoleInputEvents(HANDLE hConsoleInput,LPDWORD lpNumberOfEvents);
  __attribute__((dllimport)) WINBOOL GetConsoleScreenBufferInfo(HANDLE hConsoleOutput,PCONSOLE_SCREEN_BUFFER_INFO lpConsoleScreenBufferInfo);
  __attribute__((dllimport)) COORD GetLargestConsoleWindowSize(HANDLE hConsoleOutput);
  __attribute__((dllimport)) WINBOOL GetConsoleCursorInfo(HANDLE hConsoleOutput,PCONSOLE_CURSOR_INFO lpConsoleCursorInfo);
  __attribute__((dllimport)) WINBOOL GetCurrentConsoleFont(HANDLE hConsoleOutput,WINBOOL bMaximumWindow,PCONSOLE_FONT_INFO lpConsoleCurrentFont);
  __attribute__((dllimport)) COORD GetConsoleFontSize(HANDLE hConsoleOutput,DWORD nFont);
  __attribute__((dllimport)) WINBOOL GetConsoleSelectionInfo(PCONSOLE_SELECTION_INFO lpConsoleSelectionInfo);
  __attribute__((dllimport)) WINBOOL GetNumberOfConsoleMouseButtons(LPDWORD lpNumberOfMouseButtons);
  __attribute__((dllimport)) WINBOOL SetConsoleMode(HANDLE hConsoleHandle,DWORD dwMode);
  __attribute__((dllimport)) WINBOOL SetConsoleActiveScreenBuffer(HANDLE hConsoleOutput);
  __attribute__((dllimport)) WINBOOL FlushConsoleInputBuffer(HANDLE hConsoleInput);
  __attribute__((dllimport)) WINBOOL SetConsoleScreenBufferSize(HANDLE hConsoleOutput,COORD dwSize);
  __attribute__((dllimport)) WINBOOL SetConsoleCursorPosition(HANDLE hConsoleOutput,COORD dwCursorPosition);
  __attribute__((dllimport)) WINBOOL SetConsoleCursorInfo(HANDLE hConsoleOutput,const CONSOLE_CURSOR_INFO *lpConsoleCursorInfo);
  __attribute__((dllimport)) WINBOOL ScrollConsoleScreenBufferA(HANDLE hConsoleOutput,const SMALL_RECT *lpScrollRectangle,const SMALL_RECT *lpClipRectangle,COORD dwDestinationOrigin,const CHAR_INFO *lpFill);
  __attribute__((dllimport)) WINBOOL ScrollConsoleScreenBufferW(HANDLE hConsoleOutput,const SMALL_RECT *lpScrollRectangle,const SMALL_RECT *lpClipRectangle,COORD dwDestinationOrigin,const CHAR_INFO *lpFill);
  __attribute__((dllimport)) WINBOOL SetConsoleWindowInfo(HANDLE hConsoleOutput,WINBOOL bAbsolute,const SMALL_RECT *lpConsoleWindow);
  __attribute__((dllimport)) WINBOOL SetConsoleTextAttribute(HANDLE hConsoleOutput,WORD wAttributes);
  __attribute__((dllimport)) WINBOOL SetConsoleCtrlHandler(PHANDLER_ROUTINE HandlerRoutine,WINBOOL Add);
  __attribute__((dllimport)) WINBOOL GenerateConsoleCtrlEvent(DWORD dwCtrlEvent,DWORD dwProcessGroupId);
  __attribute__((dllimport)) WINBOOL AllocConsole(void);
  __attribute__((dllimport)) WINBOOL FreeConsole(void);
  __attribute__((dllimport)) WINBOOL AttachConsole(DWORD dwProcessId);



  __attribute__((dllimport)) DWORD GetConsoleTitleA(LPSTR lpConsoleTitle,DWORD nSize);
  __attribute__((dllimport)) DWORD GetConsoleTitleW(LPWSTR lpConsoleTitle,DWORD nSize);
  __attribute__((dllimport)) WINBOOL SetConsoleTitleA(LPCSTR lpConsoleTitle);
  __attribute__((dllimport)) WINBOOL SetConsoleTitleW(LPCWSTR lpConsoleTitle);
  __attribute__((dllimport)) WINBOOL ReadConsoleA(HANDLE hConsoleInput,LPVOID lpBuffer,DWORD nNumberOfCharsToRead,LPDWORD lpNumberOfCharsRead,LPVOID lpReserved);
  __attribute__((dllimport)) WINBOOL ReadConsoleW(HANDLE hConsoleInput,LPVOID lpBuffer,DWORD nNumberOfCharsToRead,LPDWORD lpNumberOfCharsRead,LPVOID lpReserved);
  __attribute__((dllimport)) WINBOOL WriteConsoleA(HANDLE hConsoleOutput,const void *lpBuffer,DWORD nNumberOfCharsToWrite,LPDWORD lpNumberOfCharsWritten,LPVOID lpReserved);
  __attribute__((dllimport)) WINBOOL WriteConsoleW(HANDLE hConsoleOutput,const void *lpBuffer,DWORD nNumberOfCharsToWrite,LPDWORD lpNumberOfCharsWritten,LPVOID lpReserved);



  __attribute__((dllimport)) HANDLE CreateConsoleScreenBuffer(DWORD dwDesiredAccess,DWORD dwShareMode,const SECURITY_ATTRIBUTES *lpSecurityAttributes,DWORD dwFlags,LPVOID lpScreenBufferData);
  __attribute__((dllimport)) UINT GetConsoleCP(void);
  __attribute__((dllimport)) WINBOOL SetConsoleCP(UINT wCodePageID);
  __attribute__((dllimport)) UINT GetConsoleOutputCP(void);
  __attribute__((dllimport)) WINBOOL SetConsoleOutputCP(UINT wCodePageID);



  __attribute__((dllimport)) WINBOOL GetConsoleDisplayMode(LPDWORD lpModeFlags);



  __attribute__((dllimport)) WINBOOL SetConsoleDisplayMode(HANDLE hConsoleOutput, DWORD dwFlags, PCOORD lpNewScreenBufferDimensions);

  __attribute__((dllimport)) HWND GetConsoleWindow(void);
  __attribute__((dllimport)) DWORD GetConsoleProcessList(LPDWORD lpdwProcessList,DWORD dwProcessCount);
  __attribute__((dllimport)) WINBOOL AddConsoleAliasA(LPSTR Source,LPSTR Target,LPSTR ExeName);
  __attribute__((dllimport)) WINBOOL AddConsoleAliasW(LPWSTR Source,LPWSTR Target,LPWSTR ExeName);
  __attribute__((dllimport)) DWORD GetConsoleAliasA(LPSTR Source,LPSTR TargetBuffer,DWORD TargetBufferLength,LPSTR ExeName);
  __attribute__((dllimport)) DWORD GetConsoleAliasW(LPWSTR Source,LPWSTR TargetBuffer,DWORD TargetBufferLength,LPWSTR ExeName);
  __attribute__((dllimport)) DWORD GetConsoleAliasesLengthA(LPSTR ExeName);
  __attribute__((dllimport)) DWORD GetConsoleAliasesLengthW(LPWSTR ExeName);
  __attribute__((dllimport)) DWORD GetConsoleAliasExesLengthA(void);
  __attribute__((dllimport)) DWORD GetConsoleAliasExesLengthW(void);
  __attribute__((dllimport)) DWORD GetConsoleAliasesA(LPSTR AliasBuffer,DWORD AliasBufferLength,LPSTR ExeName);
  __attribute__((dllimport)) DWORD GetConsoleAliasesW(LPWSTR AliasBuffer,DWORD AliasBufferLength,LPWSTR ExeName);
  __attribute__((dllimport)) DWORD GetConsoleAliasExesA(LPSTR ExeNameBuffer,DWORD ExeNameBufferLength);
  __attribute__((dllimport)) DWORD GetConsoleAliasExesW(LPWSTR ExeNameBuffer,DWORD ExeNameBufferLength);





typedef struct _CONSOLE_FONT_INFOEX {
  ULONG cbSize;
  DWORD nFont;
  COORD dwFontSize;
  UINT FontFamily;
  UINT FontWeight;
  WCHAR FaceName[32];
} CONSOLE_FONT_INFOEX, *PCONSOLE_FONT_INFOEX;

typedef struct _CONSOLE_HISTORY_INFO {
  UINT cbSize;
  UINT HistoryBufferSize;
  UINT NumberOfHistoryBuffers;
  DWORD dwFlags;
} CONSOLE_HISTORY_INFO, *PCONSOLE_HISTORY_INFO;

typedef struct _CONSOLE_READCONSOLE_CONTROL {
  ULONG nLength;
  ULONG nInitialChars;
  ULONG dwCtrlWakeupMask;
  ULONG dwControlKeyState;
} CONSOLE_READCONSOLE_CONTROL, *PCONSOLE_READCONSOLE_CONTROL;

typedef struct _CONSOLE_SCREEN_BUFFER_INFOEX {
  ULONG cbSize;
  COORD dwSize;
  COORD dwCursorPosition;
  WORD wAttributes;
  SMALL_RECT srWindow;
  COORD dwMaximumWindowSize;
  WORD wPopupAttributes;
  WINBOOL bFullscreenSupported;
  COLORREF ColorTable[16];
} CONSOLE_SCREEN_BUFFER_INFOEX, *PCONSOLE_SCREEN_BUFFER_INFOEX;

WINBOOL GetConsoleHistoryInfo(
  PCONSOLE_HISTORY_INFO lpConsoleHistoryInfo
);




__attribute__((dllimport)) DWORD GetConsoleOriginalTitleA(
  LPSTR lpConsoleTitle,
  DWORD nSize
);

__attribute__((dllimport)) DWORD GetConsoleOriginalTitleW(
  LPWSTR lpConsoleTitle,
  DWORD nSize
);


__attribute__((dllimport)) WINBOOL GetConsoleScreenBufferInfoEx(
  HANDLE hConsoleOutput,
  PCONSOLE_SCREEN_BUFFER_INFOEX lpConsoleScreenBufferInfoEx
);

__attribute__((dllimport)) WINBOOL GetCurrentConsoleFontEx(
  HANDLE hConsoleOutput,
  WINBOOL bMaximumWindow,
  PCONSOLE_FONT_INFOEX lpConsoleCurrentFontEx
);

__attribute__((dllimport)) WINBOOL SetConsoleHistoryInfo(
  PCONSOLE_HISTORY_INFO lpConsoleHistoryInfo
);

__attribute__((dllimport)) WINBOOL SetConsoleScreenBufferInfoEx(
  HANDLE hConsoleOutput,
  PCONSOLE_SCREEN_BUFFER_INFOEX lpConsoleScreenBufferInfoEx
);

__attribute__((dllimport)) WINBOOL SetCurrentConsoleFontEx(
  HANDLE hConsoleOutput,
  WINBOOL bMaximumWindow,
  PCONSOLE_FONT_INFOEX lpConsoleCurrentFontEx
);








  typedef struct tagVS_FIXEDFILEINFO
  {
    DWORD dwSignature;
    DWORD dwStrucVersion;
    DWORD dwFileVersionMS;
    DWORD dwFileVersionLS;
    DWORD dwProductVersionMS;
    DWORD dwProductVersionLS;
    DWORD dwFileFlagsMask;
    DWORD dwFileFlags;
    DWORD dwFileOS;
    DWORD dwFileType;
    DWORD dwFileSubtype;
    DWORD dwFileDateMS;
    DWORD dwFileDateLS;
  } VS_FIXEDFILEINFO;
  DWORD VerFindFileA(DWORD uFlags,LPSTR szFileName,LPSTR szWinDir,LPSTR szAppDir,LPSTR szCurDir,PUINT lpuCurDirLen,LPSTR szDestDir,PUINT lpuDestDirLen);
  DWORD VerFindFileW(DWORD uFlags,LPWSTR szFileName,LPWSTR szWinDir,LPWSTR szAppDir,LPWSTR szCurDir,PUINT lpuCurDirLen,LPWSTR szDestDir,PUINT lpuDestDirLen);
  DWORD VerInstallFileA(DWORD uFlags,LPSTR szSrcFileName,LPSTR szDestFileName,LPSTR szSrcDir,LPSTR szDestDir,LPSTR szCurDir,LPSTR szTmpFile,PUINT lpuTmpFileLen);
  DWORD VerInstallFileW(DWORD uFlags,LPWSTR szSrcFileName,LPWSTR szDestFileName,LPWSTR szSrcDir,LPWSTR szDestDir,LPWSTR szCurDir,LPWSTR szTmpFile,PUINT lpuTmpFileLen);
  DWORD GetFileVersionInfoSizeA(LPCSTR lptstrFilename,LPDWORD lpdwHandle);
  DWORD GetFileVersionInfoSizeW(LPCWSTR lptstrFilename,LPDWORD lpdwHandle);
  WINBOOL GetFileVersionInfoA(LPCSTR lptstrFilename,DWORD dwHandle,DWORD dwLen,LPVOID lpData);
  WINBOOL GetFileVersionInfoW(LPCWSTR lptstrFilename,DWORD dwHandle,DWORD dwLen,LPVOID lpData);
  DWORD VerLanguageNameA(DWORD wLang,LPSTR szLang,DWORD nSize);
  DWORD VerLanguageNameW(DWORD wLang,LPWSTR szLang,DWORD nSize);
  WINBOOL VerQueryValueA(LPCVOID pBlock,LPCSTR lpSubBlock,LPVOID *lplpBuffer,PUINT puLen);
  WINBOOL VerQueryValueW(LPCVOID pBlock,LPCWSTR lpSubBlock,LPVOID *lplpBuffer,PUINT puLen);
  typedef ACCESS_MASK REGSAM;
  typedef LONG LSTATUS;
  struct val_context {
    int valuelen;
    LPVOID value_context;
    LPVOID val_buff_ptr;
  };

  typedef struct val_context *PVALCONTEXT;

  typedef struct pvalueA {
    LPSTR pv_valuename;
    int pv_valuelen;
    LPVOID pv_value_context;
    DWORD pv_type;
  }PVALUEA,*PPVALUEA;

  typedef struct pvalueW {
    LPWSTR pv_valuename;
    int pv_valuelen;
    LPVOID pv_value_context;
    DWORD pv_type;
  }PVALUEW,*PPVALUEW;

  typedef PVALUEA PVALUE;
  typedef PPVALUEA PPVALUE;

  typedef DWORD __attribute__((__cdecl__)) QUERYHANDLER(LPVOID keycontext,PVALCONTEXT val_list,DWORD num_vals,LPVOID outputbuffer,DWORD *total_outlen,DWORD input_blen);

  typedef QUERYHANDLER *PQUERYHANDLER;

  typedef struct provider_info {
    PQUERYHANDLER pi_R0_1val;
    PQUERYHANDLER pi_R0_allvals;
    PQUERYHANDLER pi_R3_1val;
    PQUERYHANDLER pi_R3_allvals;
    DWORD pi_flags;
    LPVOID pi_key_context;
  } REG_PROVIDER;

  typedef struct provider_info *PPROVIDER;

  typedef struct value_entA {
    LPSTR ve_valuename;
    DWORD ve_valuelen;
    DWORD_PTR ve_valueptr;
    DWORD ve_type;
  } VALENTA,*PVALENTA;

  typedef struct value_entW {
    LPWSTR ve_valuename;
    DWORD ve_valuelen;
    DWORD_PTR ve_valueptr;
    DWORD ve_type;
  } VALENTW,*PVALENTW;

  typedef VALENTA VALENT;
  typedef PVALENTA PVALENT;
  __attribute__((dllimport)) LONG RegCloseKey(HKEY hKey);
  __attribute__((dllimport)) LONG RegOverridePredefKey(HKEY hKey,HKEY hNewHKey);
  __attribute__((dllimport)) LONG RegOpenUserClassesRoot(HANDLE hToken,DWORD dwOptions,REGSAM samDesired,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegOpenCurrentUser(REGSAM samDesired,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegDisablePredefinedCache(void);
  __attribute__((dllimport)) LONG RegConnectRegistryA(LPCSTR lpMachineName,HKEY hKey,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegConnectRegistryW(LPCWSTR lpMachineName,HKEY hKey,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegConnectRegistryExA(LPCSTR lpMachineName,HKEY hKey,ULONG Flags,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegConnectRegistryExW(LPCWSTR lpMachineName,HKEY hKey,ULONG Flags,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegCreateKeyA(HKEY hKey,LPCSTR lpSubKey,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegCreateKeyW(HKEY hKey,LPCWSTR lpSubKey,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegCreateKeyExA(HKEY hKey,LPCSTR lpSubKey,DWORD Reserved,LPSTR lpClass,DWORD dwOptions,REGSAM samDesired,LPSECURITY_ATTRIBUTES lpSecurityAttributes,PHKEY phkResult,LPDWORD lpdwDisposition);
  __attribute__((dllimport)) LONG RegCreateKeyExW(HKEY hKey,LPCWSTR lpSubKey,DWORD Reserved,LPWSTR lpClass,DWORD dwOptions,REGSAM samDesired,LPSECURITY_ATTRIBUTES lpSecurityAttributes,PHKEY phkResult,LPDWORD lpdwDisposition);
  __attribute__((dllimport)) LONG RegDeleteKeyA(HKEY hKey,LPCSTR lpSubKey);
  __attribute__((dllimport)) LONG RegDeleteKeyW(HKEY hKey,LPCWSTR lpSubKey);
  __attribute__((dllimport)) LONG RegDeleteKeyExA(HKEY hKey,LPCSTR lpSubKey,REGSAM samDesired,DWORD Reserved);
  __attribute__((dllimport)) LONG RegDeleteKeyExW(HKEY hKey,LPCWSTR lpSubKey,REGSAM samDesired,DWORD Reserved);
  __attribute__((dllimport)) LONG RegDisableReflectionKey(HKEY hBase);
  __attribute__((dllimport)) LONG RegEnableReflectionKey(HKEY hBase);
  __attribute__((dllimport)) LONG RegQueryReflectionKey(HKEY hBase,WINBOOL *bIsReflectionDisabled);
  __attribute__((dllimport)) LONG RegDeleteValueA(HKEY hKey,LPCSTR lpValueName);
  __attribute__((dllimport)) LONG RegDeleteValueW(HKEY hKey,LPCWSTR lpValueName);
  __attribute__((dllimport)) LONG RegEnumKeyA(HKEY hKey,DWORD dwIndex,LPSTR lpName,DWORD cchName);
  __attribute__((dllimport)) LONG RegEnumKeyW(HKEY hKey,DWORD dwIndex,LPWSTR lpName,DWORD cchName);
  __attribute__((dllimport)) LONG RegEnumKeyExA(HKEY hKey,DWORD dwIndex,LPSTR lpName,LPDWORD lpcchName,LPDWORD lpReserved,LPSTR lpClass,LPDWORD lpcchClass,PFILETIME lpftLastWriteTime);
  __attribute__((dllimport)) LONG RegEnumKeyExW(HKEY hKey,DWORD dwIndex,LPWSTR lpName,LPDWORD lpcchName,LPDWORD lpReserved,LPWSTR lpClass,LPDWORD lpcchClass,PFILETIME lpftLastWriteTime);
  __attribute__((dllimport)) LONG RegEnumValueA(HKEY hKey,DWORD dwIndex,LPSTR lpValueName,LPDWORD lpcchValueName,LPDWORD lpReserved,LPDWORD lpType,LPBYTE lpData,LPDWORD lpcbData);
  __attribute__((dllimport)) LONG RegEnumValueW(HKEY hKey,DWORD dwIndex,LPWSTR lpValueName,LPDWORD lpcchValueName,LPDWORD lpReserved,LPDWORD lpType,LPBYTE lpData,LPDWORD lpcbData);
  __attribute__((dllimport)) LONG RegFlushKey(HKEY hKey);
  __attribute__((dllimport)) LONG RegGetKeySecurity(HKEY hKey,SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR pSecurityDescriptor,LPDWORD lpcbSecurityDescriptor);
  __attribute__((dllimport)) LONG RegLoadKeyA(HKEY hKey,LPCSTR lpSubKey,LPCSTR lpFile);
  __attribute__((dllimport)) LONG RegLoadKeyW(HKEY hKey,LPCWSTR lpSubKey,LPCWSTR lpFile);
  __attribute__((dllimport)) LONG RegNotifyChangeKeyValue(HKEY hKey,WINBOOL bWatchSubtree,DWORD dwNotifyFilter,HANDLE hEvent,WINBOOL fAsynchronous);
  __attribute__((dllimport)) LONG RegOpenKeyA(HKEY hKey,LPCSTR lpSubKey,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegOpenKeyW(HKEY hKey,LPCWSTR lpSubKey,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegOpenKeyExA(HKEY hKey,LPCSTR lpSubKey,DWORD ulOptions,REGSAM samDesired,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegOpenKeyExW(HKEY hKey,LPCWSTR lpSubKey,DWORD ulOptions,REGSAM samDesired,PHKEY phkResult);
  __attribute__((dllimport)) LONG RegQueryInfoKeyA(HKEY hKey,LPSTR lpClass,LPDWORD lpcchClass,LPDWORD lpReserved,LPDWORD lpcSubKeys,LPDWORD lpcbMaxSubKeyLen,LPDWORD lpcbMaxClassLen,LPDWORD lpcValues,LPDWORD lpcbMaxValueNameLen,LPDWORD lpcbMaxValueLen,LPDWORD lpcbSecurityDescriptor,PFILETIME lpftLastWriteTime);
  __attribute__((dllimport)) LONG RegQueryInfoKeyW(HKEY hKey,LPWSTR lpClass,LPDWORD lpcchClass,LPDWORD lpReserved,LPDWORD lpcSubKeys,LPDWORD lpcbMaxSubKeyLen,LPDWORD lpcbMaxClassLen,LPDWORD lpcValues,LPDWORD lpcbMaxValueNameLen,LPDWORD lpcbMaxValueLen,LPDWORD lpcbSecurityDescriptor,PFILETIME lpftLastWriteTime);
  __attribute__((dllimport)) LONG RegQueryValueA(HKEY hKey,LPCSTR lpSubKey,LPSTR lpData,PLONG lpcbData);
  __attribute__((dllimport)) LONG RegQueryValueW(HKEY hKey,LPCWSTR lpSubKey,LPWSTR lpData,PLONG lpcbData);
  __attribute__((dllimport)) LONG RegQueryMultipleValuesA(HKEY hKey,PVALENTA val_list,DWORD num_vals,LPSTR lpValueBuf,LPDWORD ldwTotsize);
  __attribute__((dllimport)) LONG RegQueryMultipleValuesW(HKEY hKey,PVALENTW val_list,DWORD num_vals,LPWSTR lpValueBuf,LPDWORD ldwTotsize);
  __attribute__((dllimport)) LONG RegQueryValueExA(HKEY hKey,LPCSTR lpValueName,LPDWORD lpReserved,LPDWORD lpType,LPBYTE lpData,LPDWORD lpcbData);
  __attribute__((dllimport)) LONG RegQueryValueExW(HKEY hKey,LPCWSTR lpValueName,LPDWORD lpReserved,LPDWORD lpType,LPBYTE lpData,LPDWORD lpcbData);
  __attribute__((dllimport)) LONG RegReplaceKeyA(HKEY hKey,LPCSTR lpSubKey,LPCSTR lpNewFile,LPCSTR lpOldFile);
  __attribute__((dllimport)) LONG RegReplaceKeyW(HKEY hKey,LPCWSTR lpSubKey,LPCWSTR lpNewFile,LPCWSTR lpOldFile);
  __attribute__((dllimport)) LONG RegRestoreKeyA(HKEY hKey,LPCSTR lpFile,DWORD dwFlags);
  __attribute__((dllimport)) LONG RegRestoreKeyW(HKEY hKey,LPCWSTR lpFile,DWORD dwFlags);
  __attribute__((dllimport)) LONG RegSaveKeyA(HKEY hKey,LPCSTR lpFile,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) LONG RegSaveKeyW(HKEY hKey,LPCWSTR lpFile,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  __attribute__((dllimport)) LONG RegSetKeySecurity(HKEY hKey,SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR pSecurityDescriptor);
  __attribute__((dllimport)) LONG RegSetValueA(HKEY hKey,LPCSTR lpSubKey,DWORD dwType,LPCSTR lpData,DWORD cbData);
  __attribute__((dllimport)) LONG RegSetValueW(HKEY hKey,LPCWSTR lpSubKey,DWORD dwType,LPCWSTR lpData,DWORD cbData);
  __attribute__((dllimport)) LONG RegSetValueExA(HKEY hKey,LPCSTR lpValueName,DWORD Reserved,DWORD dwType,const BYTE *lpData,DWORD cbData);
  __attribute__((dllimport)) LONG RegSetValueExW(HKEY hKey,LPCWSTR lpValueName,DWORD Reserved,DWORD dwType,const BYTE *lpData,DWORD cbData);
  __attribute__((dllimport)) LONG RegUnLoadKeyA(HKEY hKey,LPCSTR lpSubKey);
  __attribute__((dllimport)) LONG RegUnLoadKeyW(HKEY hKey,LPCWSTR lpSubKey);
  __attribute__((dllimport)) LONG RegGetValueA(HKEY hkey,LPCSTR lpSubKey,LPCSTR lpValue,DWORD dwFlags,LPDWORD pdwType,PVOID pvData,LPDWORD pcbData);
  __attribute__((dllimport)) LONG RegGetValueW(HKEY hkey,LPCWSTR lpSubKey,LPCWSTR lpValue,DWORD dwFlags,LPDWORD pdwType,PVOID pvData,LPDWORD pcbData);
  __attribute__((dllimport)) WINBOOL InitiateSystemShutdownA(LPSTR lpMachineName,LPSTR lpMessage,DWORD dwTimeout,WINBOOL bForceAppsClosed,WINBOOL bRebootAfterShutdown);
  __attribute__((dllimport)) WINBOOL InitiateSystemShutdownW(LPWSTR lpMachineName,LPWSTR lpMessage,DWORD dwTimeout,WINBOOL bForceAppsClosed,WINBOOL bRebootAfterShutdown);
  __attribute__((dllimport)) WINBOOL AbortSystemShutdownA(LPSTR lpMachineName);
  __attribute__((dllimport)) WINBOOL AbortSystemShutdownW(LPWSTR lpMachineName);


  __attribute__((dllimport)) WINBOOL InitiateSystemShutdownExA(LPSTR lpMachineName,LPSTR lpMessage,DWORD dwTimeout,WINBOOL bForceAppsClosed,WINBOOL bRebootAfterShutdown,DWORD dwReason);
  __attribute__((dllimport)) WINBOOL InitiateSystemShutdownExW(LPWSTR lpMachineName,LPWSTR lpMessage,DWORD dwTimeout,WINBOOL bForceAppsClosed,WINBOOL bRebootAfterShutdown,DWORD dwReason);
  __attribute__((dllimport)) LONG RegSaveKeyExA(HKEY hKey,LPCSTR lpFile,LPSECURITY_ATTRIBUTES lpSecurityAttributes,DWORD Flags);
  __attribute__((dllimport)) LONG RegSaveKeyExW(HKEY hKey,LPCWSTR lpFile,LPSECURITY_ATTRIBUTES lpSecurityAttributes,DWORD Flags);
  __attribute__((dllimport)) LONG Wow64Win32ApiEntry (DWORD dwFuncNumber,DWORD dwFlag,DWORD dwRes);




__attribute__((dllimport)) LONG RegCopyTreeA(
  HKEY hKeySrc,
  LPCSTR lpSubKey,
  HKEY hKeyDest
);

__attribute__((dllimport)) LONG RegCopyTreeW(
  HKEY hKeySrc,
  LPCWSTR lpSubKey,
  HKEY hKeyDest
);


__attribute__((dllimport)) LONG RegCreateKeyTransactedA(
  HKEY hKey,
  LPCSTR lpSubKey,
  DWORD Reserved,
  LPSTR lpClass,
  DWORD dwOptions,
  REGSAM samDesired,
  const LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  PHKEY phkResult,
  LPDWORD lpdwDisposition,
  HANDLE hTransaction,
  PVOID pExtendedParemeter
);

__attribute__((dllimport)) LONG RegCreateKeyTransactedW(
  HKEY hKey,
  LPCWSTR lpSubKey,
  DWORD Reserved,
  LPWSTR lpClass,
  DWORD dwOptions,
  REGSAM samDesired,
  const LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  PHKEY phkResult,
  LPDWORD lpdwDisposition,
  HANDLE hTransaction,
  PVOID pExtendedParemeter
);


__attribute__((dllimport)) LONG RegDeleteKeyTransactedA(
  HKEY hKey,
  LPCSTR lpSubKey,
  REGSAM samDesired,
  DWORD Reserved,
  HANDLE hTransaction,
  PVOID pExtendedParameter
);

__attribute__((dllimport)) LONG RegDeleteKeyTransactedW(
  HKEY hKey,
  LPCWSTR lpSubKey,
  REGSAM samDesired,
  DWORD Reserved,
  HANDLE hTransaction,
  PVOID pExtendedParameter
);


__attribute__((dllimport)) LONG RegDeleteKeyValueA(
  HKEY hKey,
  LPCSTR lpSubKey,
  LPCSTR lpValueName
);

__attribute__((dllimport)) LONG RegDeleteKeyValueW(
  HKEY hKey,
  LPCWSTR lpSubKey,
  LPCWSTR lpValueName
);


__attribute__((dllimport)) LONG RegDeleteTreeA(
  HKEY hKey,
  LPCSTR lpSubKey
);

__attribute__((dllimport)) LONG RegDeleteTreeW(
  HKEY hKey,
  LPCWSTR lpSubKey
);

__attribute__((dllimport)) LONG RegDisablePredefinedCacheEx(void);

__attribute__((dllimport)) LONG RegLoadAppKeyA(
  LPCSTR lpFile,
  PHKEY phkResult,
  REGSAM samDesired,
  DWORD dwOptions,
  DWORD Reserved
);

__attribute__((dllimport)) LONG RegLoadAppKeyW(
  LPCWSTR lpFile,
  PHKEY phkResult,
  REGSAM samDesired,
  DWORD dwOptions,
  DWORD Reserved
);



__attribute__((dllimport)) LONG RegLoadMUIStringA(HKEY hKey, LPCSTR pszValue, LPSTR pszOutBuf, DWORD cbOutBuf, LPDWORD pcbData, DWORD Flags, LPCSTR pszDirectory);
__attribute__((dllimport)) LONG RegLoadMUIStringW(HKEY hKey, LPCWSTR pszValue, LPWSTR pszOutBuf, DWORD cbOutBuf, LPDWORD pcbData, DWORD Flags, LPCWSTR pszDirectory);



__attribute__((dllimport)) LONG RegOpenKeyTransactedA(
  HKEY hKey,
  LPCSTR lpSubKey,
  DWORD ulOptions,
  REGSAM samDesired,
  PHKEY phkResult,
  HANDLE hTransaction,
  PVOID pExtendedParameter
);

__attribute__((dllimport)) LONG RegOpenKeyTransactedW(
  HKEY hKey,
  LPCWSTR lpSubKey,
  DWORD ulOptions,
  REGSAM samDesired,
  PHKEY phkResult,
  HANDLE hTransaction,
  PVOID pExtendedParameter
);



__attribute__((dllimport)) LONG RegSetKeyValueA(
  HKEY hKey,
  LPCSTR lpSubKey,
  LPCSTR lpValueName,
  DWORD dwType,
  LPCVOID lpData,
  DWORD cbData
);

__attribute__((dllimport)) LONG RegSetKeyValueW(
  HKEY hKey,
  LPCWSTR lpSubKey,
  LPCWSTR lpValueName,
  DWORD dwType,
  LPCVOID lpData,
  DWORD cbData
);
__attribute__((dllimport)) DWORD InitiateShutdownA(
  LPSTR lpMachineName,
  LPSTR lpMessage,
  DWORD dwGracePeriod,
  DWORD dwShutdownFlags,
  DWORD dwReason
);

__attribute__((dllimport)) DWORD InitiateShutdownW(
  LPWSTR lpMachineName,
  LPWSTR lpMessage,
  DWORD dwGracePeriod,
  DWORD dwShutdownFlags,
  DWORD dwReason
);
  typedef struct _NETRESOURCEA {
    DWORD dwScope;
    DWORD dwType;
    DWORD dwDisplayType;
    DWORD dwUsage;
    LPSTR lpLocalName;
    LPSTR lpRemoteName;
    LPSTR lpComment;
    LPSTR lpProvider;
  } NETRESOURCEA,*LPNETRESOURCEA;
  typedef struct _NETRESOURCEW {
    DWORD dwScope;
    DWORD dwType;
    DWORD dwDisplayType;
    DWORD dwUsage;
    LPWSTR lpLocalName;
    LPWSTR lpRemoteName;
    LPWSTR lpComment;
    LPWSTR lpProvider;
  } NETRESOURCEW,*LPNETRESOURCEW;

  typedef NETRESOURCEA NETRESOURCE;
  typedef LPNETRESOURCEA LPNETRESOURCE;
  DWORD WNetAddConnectionA(LPCSTR lpRemoteName,LPCSTR lpPassword,LPCSTR lpLocalName);
  DWORD WNetAddConnectionW(LPCWSTR lpRemoteName,LPCWSTR lpPassword,LPCWSTR lpLocalName);
  DWORD WNetAddConnection2A(LPNETRESOURCEA lpNetResource,LPCSTR lpPassword,LPCSTR lpUserName,DWORD dwFlags);
  DWORD WNetAddConnection2W(LPNETRESOURCEW lpNetResource,LPCWSTR lpPassword,LPCWSTR lpUserName,DWORD dwFlags);
  DWORD WNetAddConnection3A(HWND hwndOwner,LPNETRESOURCEA lpNetResource,LPCSTR lpPassword,LPCSTR lpUserName,DWORD dwFlags);
  DWORD WNetAddConnection3W(HWND hwndOwner,LPNETRESOURCEW lpNetResource,LPCWSTR lpPassword,LPCWSTR lpUserName,DWORD dwFlags);
  DWORD WNetCancelConnectionA(LPCSTR lpName,WINBOOL fForce);
  DWORD WNetCancelConnectionW(LPCWSTR lpName,WINBOOL fForce);
  DWORD WNetCancelConnection2A(LPCSTR lpName,DWORD dwFlags,WINBOOL fForce);
  DWORD WNetCancelConnection2W(LPCWSTR lpName,DWORD dwFlags,WINBOOL fForce);
  DWORD WNetGetConnectionA(LPCSTR lpLocalName,LPSTR lpRemoteName,LPDWORD lpnLength);
  DWORD WNetGetConnectionW(LPCWSTR lpLocalName,LPWSTR lpRemoteName,LPDWORD lpnLength);
  DWORD WNetRestoreConnectionA(HWND hwndParent,LPCSTR lpDevice);
  DWORD WNetUseConnectionA(HWND hwndOwner,LPNETRESOURCEA lpNetResource,LPCSTR lpPassword,LPCSTR lpUserID,DWORD dwFlags,LPSTR lpAccessName,LPDWORD lpBufferSize,LPDWORD lpResult);
  DWORD WNetUseConnectionW(HWND hwndOwner,LPNETRESOURCEW lpNetResource,LPCWSTR lpPassword,LPCWSTR lpUserID,DWORD dwFlags,LPWSTR lpAccessName,LPDWORD lpBufferSize,LPDWORD lpResult);
  DWORD WNetConnectionDialog(HWND hwnd,DWORD dwType);
  DWORD WNetDisconnectDialog(HWND hwnd,DWORD dwType);

  DWORD WNetRestoreSingleConnectionW(HWND hwndParent, LPCWSTR lpDevice, BOOL fUseUI);




  typedef struct _CONNECTDLGSTRUCTA {
    DWORD cbStructure;
    HWND hwndOwner;
    LPNETRESOURCEA lpConnRes;
    DWORD dwFlags;
    DWORD dwDevNum;
  } CONNECTDLGSTRUCTA,*LPCONNECTDLGSTRUCTA;

  typedef struct _CONNECTDLGSTRUCTW {
    DWORD cbStructure;
    HWND hwndOwner;
    LPNETRESOURCEW lpConnRes;
    DWORD dwFlags;
    DWORD dwDevNum;
  } CONNECTDLGSTRUCTW,*LPCONNECTDLGSTRUCTW;

  typedef CONNECTDLGSTRUCTA CONNECTDLGSTRUCT;
  typedef LPCONNECTDLGSTRUCTA LPCONNECTDLGSTRUCT;
  DWORD WNetConnectionDialog1A(LPCONNECTDLGSTRUCTA lpConnDlgStruct);
  DWORD WNetConnectionDialog1W(LPCONNECTDLGSTRUCTW lpConnDlgStruct);

  typedef struct _DISCDLGSTRUCTA {
    DWORD cbStructure;
    HWND hwndOwner;
    LPSTR lpLocalName;
    LPSTR lpRemoteName;
    DWORD dwFlags;
  } DISCDLGSTRUCTA,*LPDISCDLGSTRUCTA;

  typedef struct _DISCDLGSTRUCTW {
    DWORD cbStructure;
    HWND hwndOwner;
    LPWSTR lpLocalName;
    LPWSTR lpRemoteName;
    DWORD dwFlags;
  } DISCDLGSTRUCTW,*LPDISCDLGSTRUCTW;

  typedef DISCDLGSTRUCTA DISCDLGSTRUCT;
  typedef LPDISCDLGSTRUCTA LPDISCDLGSTRUCT;
  DWORD WNetDisconnectDialog1A(LPDISCDLGSTRUCTA lpConnDlgStruct);
  DWORD WNetDisconnectDialog1W(LPDISCDLGSTRUCTW lpConnDlgStruct);
  DWORD WNetOpenEnumA(DWORD dwScope,DWORD dwType,DWORD dwUsage,LPNETRESOURCEA lpNetResource,LPHANDLE lphEnum);
  DWORD WNetOpenEnumW(DWORD dwScope,DWORD dwType,DWORD dwUsage,LPNETRESOURCEW lpNetResource,LPHANDLE lphEnum);
  DWORD WNetEnumResourceA(HANDLE hEnum,LPDWORD lpcCount,LPVOID lpBuffer,LPDWORD lpBufferSize);
  DWORD WNetEnumResourceW(HANDLE hEnum,LPDWORD lpcCount,LPVOID lpBuffer,LPDWORD lpBufferSize);
  DWORD WNetCloseEnum(HANDLE hEnum);
  DWORD WNetGetResourceParentA(LPNETRESOURCEA lpNetResource,LPVOID lpBuffer,LPDWORD lpcbBuffer);
  DWORD WNetGetResourceParentW(LPNETRESOURCEW lpNetResource,LPVOID lpBuffer,LPDWORD lpcbBuffer);
  DWORD WNetGetResourceInformationA(LPNETRESOURCEA lpNetResource,LPVOID lpBuffer,LPDWORD lpcbBuffer,LPSTR *lplpSystem);
  DWORD WNetGetResourceInformationW(LPNETRESOURCEW lpNetResource,LPVOID lpBuffer,LPDWORD lpcbBuffer,LPWSTR *lplpSystem);




  typedef struct _UNIVERSAL_NAME_INFOA {
    LPSTR lpUniversalName;
  } UNIVERSAL_NAME_INFOA,*LPUNIVERSAL_NAME_INFOA;

  typedef struct _UNIVERSAL_NAME_INFOW {
    LPWSTR lpUniversalName;
  } UNIVERSAL_NAME_INFOW,*LPUNIVERSAL_NAME_INFOW;

  typedef UNIVERSAL_NAME_INFOA UNIVERSAL_NAME_INFO;
  typedef LPUNIVERSAL_NAME_INFOA LPUNIVERSAL_NAME_INFO;

  typedef struct _REMOTE_NAME_INFOA {
    LPSTR lpUniversalName;
    LPSTR lpConnectionName;
    LPSTR lpRemainingPath;
  } REMOTE_NAME_INFOA,*LPREMOTE_NAME_INFOA;

  typedef struct _REMOTE_NAME_INFOW {
    LPWSTR lpUniversalName;
    LPWSTR lpConnectionName;
    LPWSTR lpRemainingPath;
  } REMOTE_NAME_INFOW,*LPREMOTE_NAME_INFOW;

  typedef REMOTE_NAME_INFOA REMOTE_NAME_INFO;
  typedef LPREMOTE_NAME_INFOA LPREMOTE_NAME_INFO;





  DWORD WNetGetUniversalNameA(LPCSTR lpLocalPath,DWORD dwInfoLevel,LPVOID lpBuffer,LPDWORD lpBufferSize);
  DWORD WNetGetUniversalNameW(LPCWSTR lpLocalPath,DWORD dwInfoLevel,LPVOID lpBuffer,LPDWORD lpBufferSize);
  DWORD WNetGetUserA(LPCSTR lpName,LPSTR lpUserName,LPDWORD lpnLength);
  DWORD WNetGetUserW(LPCWSTR lpName,LPWSTR lpUserName,LPDWORD lpnLength);






  DWORD WNetGetProviderNameA(DWORD dwNetType,LPSTR lpProviderName,LPDWORD lpBufferSize);
  DWORD WNetGetProviderNameW(DWORD dwNetType,LPWSTR lpProviderName,LPDWORD lpBufferSize);

  typedef struct _NETINFOSTRUCT {
    DWORD cbStructure;
    DWORD dwProviderVersion;
    DWORD dwStatus;
    DWORD dwCharacteristics;
    ULONG_PTR dwHandle;
    WORD wNetType;
    DWORD dwPrinters;
    DWORD dwDrives;
  } NETINFOSTRUCT,*LPNETINFOSTRUCT;







  DWORD WNetGetNetworkInformationA(LPCSTR lpProvider,LPNETINFOSTRUCT lpNetInfoStruct);
  DWORD WNetGetNetworkInformationW(LPCWSTR lpProvider,LPNETINFOSTRUCT lpNetInfoStruct);

  typedef UINT ( *PFNGETPROFILEPATHA) (LPCSTR pszUsername,LPSTR pszBuffer,UINT cbBuffer);
  typedef UINT ( *PFNGETPROFILEPATHW) (LPCWSTR pszUsername,LPWSTR pszBuffer,UINT cbBuffer);



  typedef UINT ( *PFNRECONCILEPROFILEA) (LPCSTR pszCentralFile,LPCSTR pszLocalFile,DWORD dwFlags);
  typedef UINT ( *PFNRECONCILEPROFILEW) (LPCWSTR pszCentralFile,LPCWSTR pszLocalFile,DWORD dwFlags);






  typedef WINBOOL ( *PFNPROCESSPOLICIESA) (HWND hwnd,LPCSTR pszPath,LPCSTR pszUsername,LPCSTR pszComputerName,DWORD dwFlags);
  typedef WINBOOL ( *PFNPROCESSPOLICIESW) (HWND hwnd,LPCWSTR pszPath,LPCWSTR pszUsername,LPCWSTR pszComputerName,DWORD dwFlags);







  DWORD WNetGetLastErrorA(LPDWORD lpError,LPSTR lpErrorBuf,DWORD nErrorBufSize,LPSTR lpNameBuf,DWORD nNameBufSize);
  DWORD WNetGetLastErrorW(LPDWORD lpError,LPWSTR lpErrorBuf,DWORD nErrorBufSize,LPWSTR lpNameBuf,DWORD nNameBufSize);
  typedef struct _NETCONNECTINFOSTRUCT {
    DWORD cbStructure;
    DWORD dwFlags;
    DWORD dwSpeed;
    DWORD dwDelay;
    DWORD dwOptDataSize;
  } NETCONNECTINFOSTRUCT,*LPNETCONNECTINFOSTRUCT;
  DWORD MultinetGetConnectionPerformanceA(LPNETRESOURCEA lpNetResource,LPNETCONNECTINFOSTRUCT lpNetConnectInfoStruct);
  DWORD MultinetGetConnectionPerformanceW(LPNETRESOURCEW lpNetResource,LPNETCONNECTINFOSTRUCT lpNetConnectInfoStruct);
  LPUWSTR uaw_CharUpperW(LPUWSTR String);
  int uaw_lstrcmpW(PCUWSTR String1,PCUWSTR String2);
  int uaw_lstrcmpiW(PCUWSTR String1,PCUWSTR String2);
  int uaw_lstrlenW(LPCUWSTR String);
  PUWSTR __attribute__((__cdecl__)) uaw_wcschr(PCUWSTR String,WCHAR Character);
  PUWSTR __attribute__((__cdecl__)) uaw_wcscpy(PUWSTR Destination,PCUWSTR Source);
  int __attribute__((__cdecl__)) uaw_wcsicmp(PCUWSTR String1,PCUWSTR String2);
  size_t __attribute__((__cdecl__)) uaw_wcslen(PCUWSTR String);
  PUWSTR __attribute__((__cdecl__)) uaw_wcsrchr(PCUWSTR String,WCHAR Character);

  LPUWSTR ua_CharUpperW(LPUWSTR String);

  extern __inline __attribute__((__gnu_inline__)) LPUWSTR ua_CharUpperW(LPUWSTR String) {
    if(1) return CharUpperW((PWSTR)String);
    return uaw_CharUpperW(String);
  }




  int ua_lstrcmpW(LPCUWSTR String1,LPCUWSTR String2);


  int ua_lstrcmpiW(LPCUWSTR String1,LPCUWSTR String2);


  int ua_lstrlenW(LPCUWSTR String);




  extern __inline __attribute__((__gnu_inline__)) int ua_lstrcmpW(LPCUWSTR String1,LPCUWSTR String2) {
    if(1 && 1)
      return lstrcmpW((LPCWSTR)String1,(LPCWSTR)String2);
    return uaw_lstrcmpW(String1,String2);
  }



  extern __inline __attribute__((__gnu_inline__)) int ua_lstrcmpiW(LPCUWSTR String1,LPCUWSTR String2) {
    if(1 && 1)
      return lstrcmpiW((LPCWSTR)String1,(LPCWSTR)String2);
    return uaw_lstrcmpiW(String1,String2);
  }



  extern __inline __attribute__((__gnu_inline__)) int ua_lstrlenW(LPCUWSTR String) {
    if(1) return lstrlenW((PCWSTR)String);
    return uaw_lstrlenW(String);
  }





  typedef WCHAR *PUWSTR_C;




  PUWSTR_C ua_wcschr(PCUWSTR String,WCHAR Character);
  PUWSTR_C ua_wcsrchr(PCUWSTR String,WCHAR Character);




  PUWSTR ua_wcscpy(PUWSTR Destination,PCUWSTR Source);
  size_t ua_wcslen(PCUWSTR String);


  extern __inline __attribute__((__gnu_inline__)) PUWSTR_C ua_wcschr(PCUWSTR String,WCHAR Character) {
    if(1) return (PUWSTR_C)wcschr((PCWSTR)String,Character);
    return (PUWSTR_C)uaw_wcschr(String,Character);
  }
  extern __inline __attribute__((__gnu_inline__)) PUWSTR_C ua_wcsrchr(PCUWSTR String,WCHAR Character) {
    if(1) return (PUWSTR_C)wcsrchr((PCWSTR)String,Character);
    return (PUWSTR_C)uaw_wcsrchr(String,Character);
  }
  extern __inline __attribute__((__gnu_inline__)) PUWSTR ua_wcscpy(PUWSTR Destination,PCUWSTR Source) {
    if(1 && 1)
      return wcscpy((PWSTR)Destination,(PCWSTR)Source);
    return uaw_wcscpy(Destination,Source);
  }
  extern __inline __attribute__((__gnu_inline__)) size_t ua_wcslen(PCUWSTR String) {
    if(1) return wcslen((PCWSTR)String);
    return uaw_wcslen(String);
  }


  int ua_wcsicmp(LPCUWSTR String1,LPCUWSTR String2);


  extern __inline __attribute__((__gnu_inline__)) int ua_wcsicmp(LPCUWSTR String1,LPCUWSTR String2) {
    if(1 && 1)
      return _wcsicmp((LPCWSTR)String1,(LPCWSTR)String2);
    return uaw_wcsicmp(String1,String2);
  }























  typedef struct _SERVICE_DESCRIPTIONA {
    LPSTR lpDescription;
  } SERVICE_DESCRIPTIONA,*LPSERVICE_DESCRIPTIONA;

  typedef struct _SERVICE_DESCRIPTIONW {
    LPWSTR lpDescription;
  } SERVICE_DESCRIPTIONW,*LPSERVICE_DESCRIPTIONW;

  typedef SERVICE_DESCRIPTIONA SERVICE_DESCRIPTION;
  typedef LPSERVICE_DESCRIPTIONA LPSERVICE_DESCRIPTION;

  typedef enum _SC_ACTION_TYPE {
    SC_ACTION_NONE = 0,SC_ACTION_RESTART = 1,SC_ACTION_REBOOT = 2,SC_ACTION_RUN_COMMAND = 3
  } SC_ACTION_TYPE;

  typedef struct _SC_ACTION {
    SC_ACTION_TYPE Type;
    DWORD Delay;
  } SC_ACTION,*LPSC_ACTION;

  typedef struct _SERVICE_FAILURE_ACTIONSA {
    DWORD dwResetPeriod;
    LPSTR lpRebootMsg;
    LPSTR lpCommand;
    DWORD cActions;
    SC_ACTION *lpsaActions;
  } SERVICE_FAILURE_ACTIONSA,*LPSERVICE_FAILURE_ACTIONSA;

  typedef struct _SERVICE_FAILURE_ACTIONSW {
    DWORD dwResetPeriod;
    LPWSTR lpRebootMsg;
    LPWSTR lpCommand;
    DWORD cActions;
    SC_ACTION *lpsaActions;
  } SERVICE_FAILURE_ACTIONSW,*LPSERVICE_FAILURE_ACTIONSW;

  typedef SERVICE_FAILURE_ACTIONSA SERVICE_FAILURE_ACTIONS;
  typedef LPSERVICE_FAILURE_ACTIONSA LPSERVICE_FAILURE_ACTIONS;

  struct SC_HANDLE__ { int unused; }; typedef struct SC_HANDLE__ *SC_HANDLE;
  typedef SC_HANDLE *LPSC_HANDLE;

  struct SERVICE_STATUS_HANDLE__ { int unused; }; typedef struct SERVICE_STATUS_HANDLE__ *SERVICE_STATUS_HANDLE;

  typedef enum _SC_STATUS_TYPE {
    SC_STATUS_PROCESS_INFO = 0
  } SC_STATUS_TYPE;

  typedef enum _SC_ENUM_TYPE {
    SC_ENUM_PROCESS_INFO = 0
  } SC_ENUM_TYPE;

  typedef struct _SERVICE_STATUS {
    DWORD dwServiceType;
    DWORD dwCurrentState;
    DWORD dwControlsAccepted;
    DWORD dwWin32ExitCode;
    DWORD dwServiceSpecificExitCode;
    DWORD dwCheckPoint;
    DWORD dwWaitHint;
  } SERVICE_STATUS,*LPSERVICE_STATUS;

  typedef struct _SERVICE_STATUS_PROCESS {
    DWORD dwServiceType;
    DWORD dwCurrentState;
    DWORD dwControlsAccepted;
    DWORD dwWin32ExitCode;
    DWORD dwServiceSpecificExitCode;
    DWORD dwCheckPoint;
    DWORD dwWaitHint;
    DWORD dwProcessId;
    DWORD dwServiceFlags;
  } SERVICE_STATUS_PROCESS,*LPSERVICE_STATUS_PROCESS;

  typedef struct _ENUM_SERVICE_STATUSA {
    LPSTR lpServiceName;
    LPSTR lpDisplayName;
    SERVICE_STATUS ServiceStatus;
  } ENUM_SERVICE_STATUSA,*LPENUM_SERVICE_STATUSA;

  typedef struct _ENUM_SERVICE_STATUSW {
    LPWSTR lpServiceName;
    LPWSTR lpDisplayName;
    SERVICE_STATUS ServiceStatus;
  } ENUM_SERVICE_STATUSW,*LPENUM_SERVICE_STATUSW;

  typedef ENUM_SERVICE_STATUSA ENUM_SERVICE_STATUS;
  typedef LPENUM_SERVICE_STATUSA LPENUM_SERVICE_STATUS;

  typedef struct _ENUM_SERVICE_STATUS_PROCESSA {
    LPSTR lpServiceName;
    LPSTR lpDisplayName;
    SERVICE_STATUS_PROCESS ServiceStatusProcess;
  } ENUM_SERVICE_STATUS_PROCESSA,*LPENUM_SERVICE_STATUS_PROCESSA;

  typedef struct _ENUM_SERVICE_STATUS_PROCESSW {
    LPWSTR lpServiceName;
    LPWSTR lpDisplayName;
    SERVICE_STATUS_PROCESS ServiceStatusProcess;
  } ENUM_SERVICE_STATUS_PROCESSW,*LPENUM_SERVICE_STATUS_PROCESSW;

  typedef ENUM_SERVICE_STATUS_PROCESSA ENUM_SERVICE_STATUS_PROCESS;
  typedef LPENUM_SERVICE_STATUS_PROCESSA LPENUM_SERVICE_STATUS_PROCESS;

  typedef LPVOID SC_LOCK;

  typedef struct _QUERY_SERVICE_LOCK_STATUSA {
    DWORD fIsLocked;
    LPSTR lpLockOwner;
    DWORD dwLockDuration;
  } QUERY_SERVICE_LOCK_STATUSA,*LPQUERY_SERVICE_LOCK_STATUSA;

  typedef struct _QUERY_SERVICE_LOCK_STATUSW {
    DWORD fIsLocked;
    LPWSTR lpLockOwner;
    DWORD dwLockDuration;
  } QUERY_SERVICE_LOCK_STATUSW,*LPQUERY_SERVICE_LOCK_STATUSW;

  typedef QUERY_SERVICE_LOCK_STATUSA QUERY_SERVICE_LOCK_STATUS;
  typedef LPQUERY_SERVICE_LOCK_STATUSA LPQUERY_SERVICE_LOCK_STATUS;

  typedef struct _QUERY_SERVICE_CONFIGA {
    DWORD dwServiceType;
    DWORD dwStartType;
    DWORD dwErrorControl;
    LPSTR lpBinaryPathName;
    LPSTR lpLoadOrderGroup;
    DWORD dwTagId;
    LPSTR lpDependencies;
    LPSTR lpServiceStartName;
    LPSTR lpDisplayName;
  } QUERY_SERVICE_CONFIGA,*LPQUERY_SERVICE_CONFIGA;

  typedef struct _QUERY_SERVICE_CONFIGW {
    DWORD dwServiceType;
    DWORD dwStartType;
    DWORD dwErrorControl;
    LPWSTR lpBinaryPathName;
    LPWSTR lpLoadOrderGroup;
    DWORD dwTagId;
    LPWSTR lpDependencies;
    LPWSTR lpServiceStartName;
    LPWSTR lpDisplayName;
  } QUERY_SERVICE_CONFIGW,*LPQUERY_SERVICE_CONFIGW;

  typedef QUERY_SERVICE_CONFIGA QUERY_SERVICE_CONFIG;
  typedef LPQUERY_SERVICE_CONFIGA LPQUERY_SERVICE_CONFIG;

  typedef void ( *LPSERVICE_MAIN_FUNCTIONW)(DWORD dwNumServicesArgs,LPWSTR *lpServiceArgVectors);
  typedef void ( *LPSERVICE_MAIN_FUNCTIONA)(DWORD dwNumServicesArgs,LPSTR *lpServiceArgVectors);



  typedef struct _SERVICE_TABLE_ENTRYA {
    LPSTR lpServiceName;
    LPSERVICE_MAIN_FUNCTIONA lpServiceProc;
  } SERVICE_TABLE_ENTRYA,*LPSERVICE_TABLE_ENTRYA;

  typedef struct _SERVICE_TABLE_ENTRYW {
    LPWSTR lpServiceName;
    LPSERVICE_MAIN_FUNCTIONW lpServiceProc;
  } SERVICE_TABLE_ENTRYW,*LPSERVICE_TABLE_ENTRYW;

  typedef SERVICE_TABLE_ENTRYA SERVICE_TABLE_ENTRY;
  typedef LPSERVICE_TABLE_ENTRYA LPSERVICE_TABLE_ENTRY;

  typedef void ( *LPHANDLER_FUNCTION)(DWORD dwControl);
  typedef DWORD ( *LPHANDLER_FUNCTION_EX)(DWORD dwControl,DWORD dwEventType,LPVOID lpEventData,LPVOID lpContext);
  __attribute__((dllimport)) WINBOOL ChangeServiceConfigA(SC_HANDLE hService,DWORD dwServiceType,DWORD dwStartType,DWORD dwErrorControl,LPCSTR lpBinaryPathName,LPCSTR lpLoadOrderGroup,LPDWORD lpdwTagId,LPCSTR lpDependencies,LPCSTR lpServiceStartName,LPCSTR lpPassword,LPCSTR lpDisplayName);
  __attribute__((dllimport)) WINBOOL ChangeServiceConfigW(SC_HANDLE hService,DWORD dwServiceType,DWORD dwStartType,DWORD dwErrorControl,LPCWSTR lpBinaryPathName,LPCWSTR lpLoadOrderGroup,LPDWORD lpdwTagId,LPCWSTR lpDependencies,LPCWSTR lpServiceStartName,LPCWSTR lpPassword,LPCWSTR lpDisplayName);
  __attribute__((dllimport)) WINBOOL ChangeServiceConfig2A(SC_HANDLE hService,DWORD dwInfoLevel,LPVOID lpInfo);
  __attribute__((dllimport)) WINBOOL ChangeServiceConfig2W(SC_HANDLE hService,DWORD dwInfoLevel,LPVOID lpInfo);
  __attribute__((dllimport)) WINBOOL CloseServiceHandle(SC_HANDLE hSCObject);
  __attribute__((dllimport)) WINBOOL ControlService(SC_HANDLE hService,DWORD dwControl,LPSERVICE_STATUS lpServiceStatus);
  __attribute__((dllimport)) SC_HANDLE CreateServiceA(SC_HANDLE hSCManager,LPCSTR lpServiceName,LPCSTR lpDisplayName,DWORD dwDesiredAccess,DWORD dwServiceType,DWORD dwStartType,DWORD dwErrorControl,LPCSTR lpBinaryPathName,LPCSTR lpLoadOrderGroup,LPDWORD lpdwTagId,LPCSTR lpDependencies,LPCSTR lpServiceStartName,LPCSTR lpPassword);
  __attribute__((dllimport)) SC_HANDLE CreateServiceW(SC_HANDLE hSCManager,LPCWSTR lpServiceName,LPCWSTR lpDisplayName,DWORD dwDesiredAccess,DWORD dwServiceType,DWORD dwStartType,DWORD dwErrorControl,LPCWSTR lpBinaryPathName,LPCWSTR lpLoadOrderGroup,LPDWORD lpdwTagId,LPCWSTR lpDependencies,LPCWSTR lpServiceStartName,LPCWSTR lpPassword);
  __attribute__((dllimport)) WINBOOL DeleteService(SC_HANDLE hService);
  __attribute__((dllimport)) WINBOOL EnumDependentServicesA(SC_HANDLE hService,DWORD dwServiceState,LPENUM_SERVICE_STATUSA lpServices,DWORD cbBufSize,LPDWORD pcbBytesNeeded,LPDWORD lpServicesReturned);
  __attribute__((dllimport)) WINBOOL EnumDependentServicesW(SC_HANDLE hService,DWORD dwServiceState,LPENUM_SERVICE_STATUSW lpServices,DWORD cbBufSize,LPDWORD pcbBytesNeeded,LPDWORD lpServicesReturned);
  __attribute__((dllimport)) WINBOOL EnumServicesStatusA(SC_HANDLE hSCManager,DWORD dwServiceType,DWORD dwServiceState,LPENUM_SERVICE_STATUSA lpServices,DWORD cbBufSize,LPDWORD pcbBytesNeeded,LPDWORD lpServicesReturned,LPDWORD lpResumeHandle);
  __attribute__((dllimport)) WINBOOL EnumServicesStatusW(SC_HANDLE hSCManager,DWORD dwServiceType,DWORD dwServiceState,LPENUM_SERVICE_STATUSW lpServices,DWORD cbBufSize,LPDWORD pcbBytesNeeded,LPDWORD lpServicesReturned,LPDWORD lpResumeHandle);
  __attribute__((dllimport)) WINBOOL EnumServicesStatusExA(SC_HANDLE hSCManager,SC_ENUM_TYPE InfoLevel,DWORD dwServiceType,DWORD dwServiceState,LPBYTE lpServices,DWORD cbBufSize,LPDWORD pcbBytesNeeded,LPDWORD lpServicesReturned,LPDWORD lpResumeHandle,LPCSTR pszGroupName);
  __attribute__((dllimport)) WINBOOL EnumServicesStatusExW(SC_HANDLE hSCManager,SC_ENUM_TYPE InfoLevel,DWORD dwServiceType,DWORD dwServiceState,LPBYTE lpServices,DWORD cbBufSize,LPDWORD pcbBytesNeeded,LPDWORD lpServicesReturned,LPDWORD lpResumeHandle,LPCWSTR pszGroupName);
  __attribute__((dllimport)) WINBOOL GetServiceKeyNameA(SC_HANDLE hSCManager,LPCSTR lpDisplayName,LPSTR lpServiceName,LPDWORD lpcchBuffer);
  __attribute__((dllimport)) WINBOOL GetServiceKeyNameW(SC_HANDLE hSCManager,LPCWSTR lpDisplayName,LPWSTR lpServiceName,LPDWORD lpcchBuffer);
  __attribute__((dllimport)) WINBOOL GetServiceDisplayNameA(SC_HANDLE hSCManager,LPCSTR lpServiceName,LPSTR lpDisplayName,LPDWORD lpcchBuffer);
  __attribute__((dllimport)) WINBOOL GetServiceDisplayNameW(SC_HANDLE hSCManager,LPCWSTR lpServiceName,LPWSTR lpDisplayName,LPDWORD lpcchBuffer);
  __attribute__((dllimport)) SC_LOCK LockServiceDatabase(SC_HANDLE hSCManager);
  __attribute__((dllimport)) WINBOOL NotifyBootConfigStatus(WINBOOL BootAcceptable);
  __attribute__((dllimport)) SC_HANDLE OpenSCManagerA(LPCSTR lpMachineName,LPCSTR lpDatabaseName,DWORD dwDesiredAccess);
  __attribute__((dllimport)) SC_HANDLE OpenSCManagerW(LPCWSTR lpMachineName,LPCWSTR lpDatabaseName,DWORD dwDesiredAccess);
  __attribute__((dllimport)) SC_HANDLE OpenServiceA(SC_HANDLE hSCManager,LPCSTR lpServiceName,DWORD dwDesiredAccess);
  __attribute__((dllimport)) SC_HANDLE OpenServiceW(SC_HANDLE hSCManager,LPCWSTR lpServiceName,DWORD dwDesiredAccess);
  __attribute__((dllimport)) WINBOOL QueryServiceConfigA(SC_HANDLE hService,LPQUERY_SERVICE_CONFIGA lpServiceConfig,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL QueryServiceConfigW(SC_HANDLE hService,LPQUERY_SERVICE_CONFIGW lpServiceConfig,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL QueryServiceConfig2A(SC_HANDLE hService,DWORD dwInfoLevel,LPBYTE lpBuffer,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL QueryServiceConfig2W(SC_HANDLE hService,DWORD dwInfoLevel,LPBYTE lpBuffer,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL QueryServiceLockStatusA(SC_HANDLE hSCManager,LPQUERY_SERVICE_LOCK_STATUSA lpLockStatus,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL QueryServiceLockStatusW(SC_HANDLE hSCManager,LPQUERY_SERVICE_LOCK_STATUSW lpLockStatus,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL QueryServiceObjectSecurity(SC_HANDLE hService,SECURITY_INFORMATION dwSecurityInformation,PSECURITY_DESCRIPTOR lpSecurityDescriptor,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) WINBOOL QueryServiceStatus(SC_HANDLE hService,LPSERVICE_STATUS lpServiceStatus);
  __attribute__((dllimport)) WINBOOL QueryServiceStatusEx(SC_HANDLE hService,SC_STATUS_TYPE InfoLevel,LPBYTE lpBuffer,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  __attribute__((dllimport)) SERVICE_STATUS_HANDLE RegisterServiceCtrlHandlerA(LPCSTR lpServiceName,LPHANDLER_FUNCTION lpHandlerProc);
  __attribute__((dllimport)) SERVICE_STATUS_HANDLE RegisterServiceCtrlHandlerW(LPCWSTR lpServiceName,LPHANDLER_FUNCTION lpHandlerProc);
  __attribute__((dllimport)) SERVICE_STATUS_HANDLE RegisterServiceCtrlHandlerExA(LPCSTR lpServiceName,LPHANDLER_FUNCTION_EX lpHandlerProc,LPVOID lpContext);
  __attribute__((dllimport)) SERVICE_STATUS_HANDLE RegisterServiceCtrlHandlerExW(LPCWSTR lpServiceName,LPHANDLER_FUNCTION_EX lpHandlerProc,LPVOID lpContext);
  __attribute__((dllimport)) WINBOOL SetServiceObjectSecurity(SC_HANDLE hService,SECURITY_INFORMATION dwSecurityInformation,PSECURITY_DESCRIPTOR lpSecurityDescriptor);
  __attribute__((dllimport)) WINBOOL SetServiceStatus(SERVICE_STATUS_HANDLE hServiceStatus,LPSERVICE_STATUS lpServiceStatus);
  __attribute__((dllimport)) WINBOOL StartServiceCtrlDispatcherA(const SERVICE_TABLE_ENTRYA *lpServiceStartTable);
  __attribute__((dllimport)) WINBOOL StartServiceCtrlDispatcherW(const SERVICE_TABLE_ENTRYW *lpServiceStartTable);
  __attribute__((dllimport)) WINBOOL StartServiceA(SC_HANDLE hService,DWORD dwNumServiceArgs,LPCSTR *lpServiceArgVectors);
  __attribute__((dllimport)) WINBOOL StartServiceW(SC_HANDLE hService,DWORD dwNumServiceArgs,LPCWSTR *lpServiceArgVectors);
  __attribute__((dllimport)) WINBOOL UnlockServiceDatabase(SC_LOCK ScLock);



typedef void( * PFN_SC_NOTIFY_CALLBACK ) (
  PVOID pParameter
);

typedef struct _SERVICE_CONTROL_STATUS_REASON_PARAMSA {
  DWORD dwReason;
  LPSTR pszComment;
  SERVICE_STATUS_PROCESS ServiceStatus;
} SERVICE_CONTROL_STATUS_REASON_PARAMSA, *PSERVICE_CONTROL_STATUS_REASON_PARAMSA;

typedef struct _SERVICE_CONTROL_STATUS_REASON_PARAMSW {
  DWORD dwReason;
  LPWSTR pszComment;
  SERVICE_STATUS_PROCESS ServiceStatus;
} SERVICE_CONTROL_STATUS_REASON_PARAMSW, *PSERVICE_CONTROL_STATUS_REASON_PARAMSW;

typedef SERVICE_CONTROL_STATUS_REASON_PARAMSA SERVICE_CONTROL_STATUS_REASON_PARAMS;
typedef PSERVICE_CONTROL_STATUS_REASON_PARAMSA PSERVICE_CONTROL_STATUS_REASON_PARAMS;
typedef struct _SERVICE_NOTIFYA {
  DWORD dwVersion;
  PFN_SC_NOTIFY_CALLBACK pfnNotifyCallback;
  PVOID pContext;
  DWORD dwNotificationStatus;
  SERVICE_STATUS_PROCESS ServiceStatus;
  DWORD dwNotificationTriggered;
  LPSTR pszServiceNames;
} SERVICE_NOTIFYA, *PSERVICE_NOTIFYA;

typedef struct _SERVICE_NOTIFYW {
  DWORD dwVersion;
  PFN_SC_NOTIFY_CALLBACK pfnNotifyCallback;
  PVOID pContext;
  DWORD dwNotificationStatus;
  SERVICE_STATUS_PROCESS ServiceStatus;
  DWORD dwNotificationTriggered;
  LPWSTR pszServiceNames;
} SERVICE_NOTIFYW, *PSERVICE_NOTIFYW;

typedef SERVICE_NOTIFYA SERVICE_NOTIFY;
typedef PSERVICE_NOTIFYA PSERVICE_NOTIFY;







typedef struct _SERVICE_DELAYED_AUTO_START_INFO {
  WINBOOL fDelayedAutostart;
} SERVICE_DELAYED_AUTO_START_INFO, *LPSERVICE_DELAYED_AUTO_START_INFO;

typedef struct _SERVICE_FAILURE_ACTIONS_FLAG {
  WINBOOL fFailureActionsOnNonCrashFailures;
} SERVICE_FAILURE_ACTIONS_FLAG, *LPSERVICE_FAILURE_ACTIONS_FLAG;

typedef struct _SERVICE_PRESHUTDOWN_INFO {
  DWORD dwPreshutdownTimeout;
} SERVICE_PRESHUTDOWN_INFO, *LPSERVICE_PRESHUTDOWN_INFO;

typedef struct _SERVICE_REQUIRED_PRIVILEGES_INFOA {
  LPSTR pmszRequiredPrivileges;
} SERVICE_REQUIRED_PRIVILEGES_INFOA, *LPSERVICE_REQUIRED_PRIVILEGES_INFOA;

typedef struct _SERVICE_REQUIRED_PRIVILEGES_INFOW {
  LPWSTR pmszRequiredPrivileges;
} SERVICE_REQUIRED_PRIVILEGES_INFOW, *LPSERVICE_REQUIRED_PRIVILEGES_INFOW;

typedef SERVICE_REQUIRED_PRIVILEGES_INFOA SERVICE_REQUIRED_PRIVILEGES_INFO;





typedef struct _SERVICE_SID_INFO {
  DWORD dwServiceSidType;
} SERVICE_SID_INFO, *LPSERVICE_SID_INFO;

__attribute__((dllimport)) WINBOOL ControlServiceExA(
  SC_HANDLE hService,
  DWORD dwControl,
  DWORD dwInfoLevel,
  PVOID pControlParams
);

__attribute__((dllimport)) WINBOOL ControlServiceExW(
  SC_HANDLE hService,
  DWORD dwControl,
  DWORD dwInfoLevel,
  PVOID pControlParams
);





DWORD NotifyServiceStatusChangeA(
  SC_HANDLE hService,
  DWORD dwNotifyMask,
  PSERVICE_NOTIFYA pNotifyBuffer
);

DWORD NotifyServiceStatusChangeW(
  SC_HANDLE hService,
  DWORD dwNotifyMask,
  PSERVICE_NOTIFYW pNotifyBuffer
);











typedef struct _MODEMDEVCAPS {
  DWORD dwActualSize;
  DWORD dwRequiredSize;
  DWORD dwDevSpecificOffset;
  DWORD dwDevSpecificSize;
  DWORD dwModemProviderVersion;
  DWORD dwModemManufacturerOffset;
  DWORD dwModemManufacturerSize;
  DWORD dwModemModelOffset;
  DWORD dwModemModelSize;
  DWORD dwModemVersionOffset;
  DWORD dwModemVersionSize;
  DWORD dwDialOptions;
  DWORD dwCallSetupFailTimer;
  DWORD dwInactivityTimeout;
  DWORD dwSpeakerVolume;
  DWORD dwSpeakerMode;
  DWORD dwModemOptions;
  DWORD dwMaxDTERate;
  DWORD dwMaxDCERate;
  BYTE abVariablePortion[1];
} MODEMDEVCAPS,*PMODEMDEVCAPS,*LPMODEMDEVCAPS;

typedef struct _MODEMSETTINGS {
  DWORD dwActualSize;
  DWORD dwRequiredSize;
  DWORD dwDevSpecificOffset;
  DWORD dwDevSpecificSize;
  DWORD dwCallSetupFailTimer;
  DWORD dwInactivityTimeout;
  DWORD dwSpeakerVolume;
  DWORD dwSpeakerMode;
  DWORD dwPreferredModemOptions;
  DWORD dwNegotiatedModemOptions;
  DWORD dwNegotiatedDCERate;
  BYTE abVariablePortion [1];
} MODEMSETTINGS,*PMODEMSETTINGS,*LPMODEMSETTINGS;



  struct HIMC__ { int unused; }; typedef struct HIMC__ *HIMC;
  struct HIMCC__ { int unused; }; typedef struct HIMCC__ *HIMCC;

  typedef HKL *LPHKL;


  typedef UINT *LPUINT;


  typedef struct tagCOMPOSITIONFORM {
    DWORD dwStyle;
    POINT ptCurrentPos;
    RECT rcArea;
  } COMPOSITIONFORM,*PCOMPOSITIONFORM,*NPCOMPOSITIONFORM,*LPCOMPOSITIONFORM;

  typedef struct tagCANDIDATEFORM {
    DWORD dwIndex;
    DWORD dwStyle;
    POINT ptCurrentPos;
    RECT rcArea;
  } CANDIDATEFORM,*PCANDIDATEFORM,*NPCANDIDATEFORM,*LPCANDIDATEFORM;

  typedef struct tagCANDIDATELIST {
    DWORD dwSize;
    DWORD dwStyle;
    DWORD dwCount;
    DWORD dwSelection;
    DWORD dwPageStart;
    DWORD dwPageSize;
    DWORD dwOffset[1];
  } CANDIDATELIST,*PCANDIDATELIST,*NPCANDIDATELIST,*LPCANDIDATELIST;

  typedef struct tagREGISTERWORDA {
    LPSTR lpReading;
    LPSTR lpWord;
  } REGISTERWORDA,*PREGISTERWORDA,*NPREGISTERWORDA,*LPREGISTERWORDA;

  typedef struct tagREGISTERWORDW {
    LPWSTR lpReading;
    LPWSTR lpWord;
  } REGISTERWORDW,*PREGISTERWORDW,*NPREGISTERWORDW,*LPREGISTERWORDW;

  typedef REGISTERWORDA REGISTERWORD;
  typedef PREGISTERWORDA PREGISTERWORD;
  typedef NPREGISTERWORDA NPREGISTERWORD;
  typedef LPREGISTERWORDA LPREGISTERWORD;

  typedef struct tagRECONVERTSTRING {
    DWORD dwSize;
    DWORD dwVersion;
    DWORD dwStrLen;
    DWORD dwStrOffset;
    DWORD dwCompStrLen;
    DWORD dwCompStrOffset;
    DWORD dwTargetStrLen;
    DWORD dwTargetStrOffset;
  } RECONVERTSTRING,*PRECONVERTSTRING,*NPRECONVERTSTRING,*LPRECONVERTSTRING;



  typedef struct tagSTYLEBUFA {
    DWORD dwStyle;
    CHAR szDescription[32];
  } STYLEBUFA,*PSTYLEBUFA,*NPSTYLEBUFA,*LPSTYLEBUFA;

  typedef struct tagSTYLEBUFW {
    DWORD dwStyle;
    WCHAR szDescription[32];
  } STYLEBUFW,*PSTYLEBUFW,*NPSTYLEBUFW,*LPSTYLEBUFW;

  typedef STYLEBUFA STYLEBUF;
  typedef PSTYLEBUFA PSTYLEBUF;
  typedef NPSTYLEBUFA NPSTYLEBUF;
  typedef LPSTYLEBUFA LPSTYLEBUF;



  typedef struct tagIMEMENUITEMINFOA {
    UINT cbSize;
    UINT fType;
    UINT fState;
    UINT wID;
    HBITMAP hbmpChecked;
    HBITMAP hbmpUnchecked;
    DWORD dwItemData;
    CHAR szString[80];
    HBITMAP hbmpItem;
  } IMEMENUITEMINFOA,*PIMEMENUITEMINFOA,*NPIMEMENUITEMINFOA,*LPIMEMENUITEMINFOA;

  typedef struct tagIMEMENUITEMINFOW {
    UINT cbSize;
    UINT fType;
    UINT fState;
    UINT wID;
    HBITMAP hbmpChecked;
    HBITMAP hbmpUnchecked;
    DWORD dwItemData;
    WCHAR szString[80];
    HBITMAP hbmpItem;
  } IMEMENUITEMINFOW,*PIMEMENUITEMINFOW,*NPIMEMENUITEMINFOW,*LPIMEMENUITEMINFOW;

  typedef IMEMENUITEMINFOA IMEMENUITEMINFO;
  typedef PIMEMENUITEMINFOA PIMEMENUITEMINFO;
  typedef NPIMEMENUITEMINFOA NPIMEMENUITEMINFO;
  typedef LPIMEMENUITEMINFOA LPIMEMENUITEMINFO;

  typedef struct tagIMECHARPOSITION {
    DWORD dwSize;
    DWORD dwCharPos;
    POINT pt;
    UINT cLineHeight;
    RECT rcDocument;
  } IMECHARPOSITION,*PIMECHARPOSITION,*NPIMECHARPOSITION,*LPIMECHARPOSITION;

  typedef WINBOOL ( *IMCENUMPROC)(HIMC,LPARAM);
  HKL ImmInstallIMEA(LPCSTR lpszIMEFileName,LPCSTR lpszLayoutText);
  HKL ImmInstallIMEW(LPCWSTR lpszIMEFileName,LPCWSTR lpszLayoutText);
  HWND ImmGetDefaultIMEWnd(HWND);
  UINT ImmGetDescriptionA(HKL,LPSTR,UINT uBufLen);
  UINT ImmGetDescriptionW(HKL,LPWSTR,UINT uBufLen);
  UINT ImmGetIMEFileNameA(HKL,LPSTR,UINT uBufLen);
  UINT ImmGetIMEFileNameW(HKL,LPWSTR,UINT uBufLen);
  DWORD ImmGetProperty(HKL,DWORD);
  WINBOOL ImmIsIME(HKL);
  WINBOOL ImmSimulateHotKey(HWND,DWORD);
  HIMC ImmCreateContext(void);
  WINBOOL ImmDestroyContext(HIMC);
  HIMC ImmGetContext(HWND);
  WINBOOL ImmReleaseContext(HWND,HIMC);
  HIMC ImmAssociateContext(HWND,HIMC);
  WINBOOL ImmAssociateContextEx(HWND,HIMC,DWORD);
  LONG ImmGetCompositionStringA(HIMC,DWORD,LPVOID,DWORD);
  LONG ImmGetCompositionStringW(HIMC,DWORD,LPVOID,DWORD);
  WINBOOL ImmSetCompositionStringA(HIMC,DWORD dwIndex,LPVOID lpComp,DWORD,LPVOID lpRead,DWORD);
  WINBOOL ImmSetCompositionStringW(HIMC,DWORD dwIndex,LPVOID lpComp,DWORD,LPVOID lpRead,DWORD);
  DWORD ImmGetCandidateListCountA(HIMC,LPDWORD lpdwListCount);
  DWORD ImmGetCandidateListCountW(HIMC,LPDWORD lpdwListCount);
  DWORD ImmGetCandidateListA(HIMC,DWORD deIndex,LPCANDIDATELIST,DWORD dwBufLen);
  DWORD ImmGetCandidateListW(HIMC,DWORD deIndex,LPCANDIDATELIST,DWORD dwBufLen);
  DWORD ImmGetGuideLineA(HIMC,DWORD dwIndex,LPSTR,DWORD dwBufLen);
  DWORD ImmGetGuideLineW(HIMC,DWORD dwIndex,LPWSTR,DWORD dwBufLen);
  WINBOOL ImmGetConversionStatus(HIMC,LPDWORD,LPDWORD);
  WINBOOL ImmSetConversionStatus(HIMC,DWORD,DWORD);
  WINBOOL ImmGetOpenStatus(HIMC);
  WINBOOL ImmSetOpenStatus(HIMC,WINBOOL);






  WINBOOL ImmGetCompositionFontA(HIMC,LPLOGFONTA);
  WINBOOL ImmGetCompositionFontW(HIMC,LPLOGFONTW);
  WINBOOL ImmSetCompositionFontA(HIMC,LPLOGFONTA);
  WINBOOL ImmSetCompositionFontW(HIMC,LPLOGFONTW);


  typedef int ( *REGISTERWORDENUMPROCA)(LPCSTR,DWORD,LPCSTR,LPVOID);
  typedef int ( *REGISTERWORDENUMPROCW)(LPCWSTR,DWORD,LPCWSTR,LPVOID);
  WINBOOL ImmConfigureIMEA(HKL,HWND,DWORD,LPVOID);
  WINBOOL ImmConfigureIMEW(HKL,HWND,DWORD,LPVOID);
  LRESULT ImmEscapeA(HKL,HIMC,UINT,LPVOID);
  LRESULT ImmEscapeW(HKL,HIMC,UINT,LPVOID);
  DWORD ImmGetConversionListA(HKL,HIMC,LPCSTR,LPCANDIDATELIST,DWORD dwBufLen,UINT uFlag);
  DWORD ImmGetConversionListW(HKL,HIMC,LPCWSTR,LPCANDIDATELIST,DWORD dwBufLen,UINT uFlag);
  WINBOOL ImmNotifyIME(HIMC,DWORD dwAction,DWORD dwIndex,DWORD dwValue);
  WINBOOL ImmGetStatusWindowPos(HIMC,LPPOINT);
  WINBOOL ImmSetStatusWindowPos(HIMC,LPPOINT);
  WINBOOL ImmGetCompositionWindow(HIMC,LPCOMPOSITIONFORM);
  WINBOOL ImmSetCompositionWindow(HIMC,LPCOMPOSITIONFORM);
  WINBOOL ImmGetCandidateWindow(HIMC,DWORD,LPCANDIDATEFORM);
  WINBOOL ImmSetCandidateWindow(HIMC,LPCANDIDATEFORM);
  WINBOOL ImmIsUIMessageA(HWND,UINT,WPARAM,LPARAM);
  WINBOOL ImmIsUIMessageW(HWND,UINT,WPARAM,LPARAM);
  UINT ImmGetVirtualKey(HWND);
  WINBOOL ImmRegisterWordA(HKL,LPCSTR lpszReading,DWORD,LPCSTR lpszRegister);
  WINBOOL ImmRegisterWordW(HKL,LPCWSTR lpszReading,DWORD,LPCWSTR lpszRegister);
  WINBOOL ImmUnregisterWordA(HKL,LPCSTR lpszReading,DWORD,LPCSTR lpszUnregister);
  WINBOOL ImmUnregisterWordW(HKL,LPCWSTR lpszReading,DWORD,LPCWSTR lpszUnregister);
  UINT ImmGetRegisterWordStyleA(HKL,UINT nItem,LPSTYLEBUFA);
  UINT ImmGetRegisterWordStyleW(HKL,UINT nItem,LPSTYLEBUFW);
  UINT ImmEnumRegisterWordA(HKL,REGISTERWORDENUMPROCA,LPCSTR lpszReading,DWORD,LPCSTR lpszRegister,LPVOID);
  UINT ImmEnumRegisterWordW(HKL,REGISTERWORDENUMPROCW,LPCWSTR lpszReading,DWORD,LPCWSTR lpszRegister,LPVOID);
  WINBOOL ImmDisableIME(DWORD);
  WINBOOL ImmEnumInputContext(DWORD idThread,IMCENUMPROC lpfn,LPARAM lParam);
  DWORD ImmGetImeMenuItemsA(HIMC,DWORD,DWORD,LPIMEMENUITEMINFOA,LPIMEMENUITEMINFOA,DWORD);
  DWORD ImmGetImeMenuItemsW(HIMC,DWORD,DWORD,LPIMEMENUITEMINFOW,LPIMEMENUITEMINFOW,DWORD);
  WINBOOL ImmDisableTextFrameService(DWORD idThread);
__attribute__ ((__dllimport__)) unsigned int __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) _controlfp (unsigned int unNew, unsigned int unMask) ;
__attribute__((dllimport)) errno_t __attribute__((__cdecl__)) _controlfp_s(unsigned int *_CurrentState, unsigned int _NewValue, unsigned int _Mask);
__attribute__ ((__dllimport__)) unsigned int __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) _control87 (unsigned int unNew, unsigned int unMask);


__attribute__ ((__dllimport__)) unsigned int __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) _clearfp (void);
__attribute__ ((__dllimport__)) unsigned int __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) _statusfp (void);
void __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) _fpreset (void);
void __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) fpreset (void);


__attribute__ ((__dllimport__)) int * __attribute__((__cdecl__)) __attribute__ ((__nothrow__)) __fpecode(void);
typedef double FLOAT8;
typedef FLOAT sample_t;
enum MPEGChannelMode
{ MPG_MD_LR_LR = 0
, MPG_MD_LR_I = 1
, MPG_MD_MS_LR = 2
, MPG_MD_MS_I = 3
};



struct lame_internal_flags;
typedef struct lame_internal_flags lame_internal_flags;


int lame_encode_mp3_frame(lame_internal_flags * gfc,
                              sample_t const *inbuf_l,
                              sample_t const *inbuf_r, unsigned char *mp3buf, int mp3buf_size);
typedef struct {
    int l[1 + 22];
    int s[1 + 13];
    int psfb21[1 + 6];
    int psfb12[1 + 6];
} scalefac_struct;


typedef struct {
    FLOAT l[22];
    FLOAT s[13][3];
} III_psy_xmin;

typedef struct {
    III_psy_xmin thm;
    III_psy_xmin en;
} III_psy_ratio;

typedef struct {
    FLOAT xr[576];
    int l3_enc[576];
    int scalefac[(13*3)];
    FLOAT xrpow_max;

    int part2_3_length;
    int big_values;
    int count1;
    int global_gain;
    int scalefac_compress;
    int block_type;
    int mixed_block_flag;
    int table_select[3];
    int subblock_gain[3 + 1];
    int region0_count;
    int region1_count;
    int preflag;
    int scalefac_scale;
    int count1table_select;

    int part2_length;
    int sfb_lmax;
    int sfb_smin;
    int psy_lmax;
    int sfbmax;
    int psymax;
    int sfbdivide;
    int width[(13*3)];
    int window[(13*3)];
    int count1bits;

    const int *sfb_partition_table;
    int slen[4];

    int max_nonzero_coeff;
    char energy_above_cutoff[(13*3)];
} gr_info;

typedef struct {
    gr_info tt[2][2];
    int main_data_begin;
    int private_bits;
    int resvDrain_pre;
    int resvDrain_post;
    int scfsi[2][4];
} III_side_info_t;
enum {
    MIMETYPE_NONE = 0,
    MIMETYPE_JPEG,
    MIMETYPE_PNG,
    MIMETYPE_GIF,
};

typedef struct FrameDataNode {
    struct FrameDataNode *nxt;
    uint32_t fid;
    char lng[4];
    struct {
        union {
            char *l;
            unsigned short *u;
            unsigned char *b;
        } ptr;
        size_t dim;
        int enc;
    } dsc , txt;
} FrameDataNode;


typedef struct id3tag_spec {

    unsigned int flags;
    int year;
    char *title;
    char *artist;
    char *album;
    char *comment;
    int track_id3v1;
    int genre_id3v1;
    unsigned char *albumart;
    unsigned int albumart_size;
    unsigned int padding_size;
    int albumart_mimetype;
    FrameDataNode *v2_head, *v2_tail;
} id3tag_spec;



extern int id3tag_write_v2(lame_global_flags * gfp);
extern int id3tag_write_v1(lame_global_flags * gfp);
typedef enum short_block_e {
    short_block_not_set = -1,
    short_block_allowed = 0,
    short_block_coupled,
    short_block_dispensed,
    short_block_forced
} short_block_t;
struct lame_global_struct {
    unsigned int class_id;


    unsigned long num_samples;
    int num_channels;
    int samplerate_in;
    int samplerate_out;



    float scale;

    float scale_left;

    float scale_right;



    int analysis;
    int write_lame_tag;
    int decode_only;
    int quality;
    MPEG_mode mode;

    int force_ms;
    int free_format;
    int findReplayGain;
    int decode_on_the_fly;
    int write_id3tag_automatic;

    int nogap_total;
    int nogap_current;

    int substep_shaping;
    int noise_shaping;
    int subblock_gain;
    int use_best_huffman;






    int brate;
    float compression_ratio;



    int copyright;
    int original;
    int extension;

    int emphasis;






    int error_protection;

    int strict_ISO;

    int disable_reservoir;


    int quant_comp;
    int quant_comp_short;
    int experimentalY;
    int experimentalZ;
    int exp_nspsytune;

    int preset;


    vbr_mode VBR;
    float VBR_q_frac;
    int VBR_q;
    int VBR_mean_bitrate_kbps;
    int VBR_min_bitrate_kbps;
    int VBR_max_bitrate_kbps;
    int VBR_hard_min;





    int lowpassfreq;

    int highpassfreq;

    int lowpasswidth;

    int highpasswidth;
    float maskingadjust;
    float maskingadjust_short;
    int ATHonly;
    int ATHshort;
    int noATH;
    int ATHtype;
    float ATHcurve;
    float ATH_lower_db;
    int athaa_type;
    float athaa_sensitivity;
    short_block_t short_blocks;
    int useTemporal;
    float interChRatio;
    float msfix;

    int tune;
    float tune_value_a;

    float attackthre;
    float attackthre_s;


    struct {
        void (*msgf) (const char *format, va_list ap);
        void (*debugf) (const char *format, va_list ap);
        void (*errorf) (const char *format, va_list ap);
    } report;






    int lame_allocated_gfp;







    lame_internal_flags *internal_flags;


    struct {
        int mmx;
        int amd3dnow;
        int sse;

    } asm_optimizations;
};

int is_lame_global_flags_valid(const lame_global_flags * gfp);
    struct replaygain_data;


    typedef struct replaygain_data replaygain_t;

    struct plotting_data;


    typedef struct plotting_data plotting_data;
    typedef struct {
        void *aligned;
        void *pointer;
    } aligned_pointer_t;

    void malloc_aligned(aligned_pointer_t * ptr, unsigned int size, unsigned int bytes);
    void free_aligned(aligned_pointer_t * ptr);


    typedef void (*iteration_loop_t) (lame_internal_flags * gfc, const FLOAT pe[2][2],
                                      const FLOAT ms_ratio[2], const III_psy_ratio ratio[2][2]);




    typedef struct bit_stream_struc {
        unsigned char *buf;
        int buf_size;
        int totbit;
        int buf_byte_idx;
        int buf_bit_idx;


    } Bit_stream_struc;



    typedef struct {
        int sum;
        int seen;
        int want;
        int pos;
        int size;
        int *bag;
        unsigned int nVbrNumFrames;
        unsigned long nBytesWritten;

        unsigned int TotalFrameSize;
    } VBR_seek_info_t;






    typedef struct {
        int use_adjust;
        FLOAT aa_sensitivity_p;


        FLOAT adjust_factor;
        FLOAT adjust_limit;
        FLOAT decay;
        FLOAT floor;
        FLOAT l[22];
        FLOAT s[13];
        FLOAT psfb21[6];
        FLOAT psfb12[6];
        FLOAT cb_l[64];
        FLOAT cb_s[64];
        FLOAT eql_w[1024 / 2];
    } ATH_t;





    typedef struct {
        FLOAT masking_lower[64];
        FLOAT minval[64];
        FLOAT rnumlines[64];
        FLOAT mld_cb[64];
        FLOAT mld[((22) > (13) ? (22) : (13))];
        FLOAT bo_weight[((22) > (13) ? (22) : (13))];
        FLOAT attack_threshold;
        int s3ind[64][2];
        int numlines[64];
        int bm[((22) > (13) ? (22) : (13))];
        int bo[((22) > (13) ? (22) : (13))];
        int npart;
        int n_sb;
        FLOAT *s3;
    } PsyConst_CB2SB_t;





    typedef struct {
        PsyConst_CB2SB_t l;
        PsyConst_CB2SB_t s;
        PsyConst_CB2SB_t l_to_s;
        FLOAT attack_threshold[4];
        FLOAT decay;
        int force_short_block_calc;
    } PsyConst_t;


    typedef struct {

        FLOAT nb_l1[4][64], nb_l2[4][64];
        FLOAT nb_s1[4][64], nb_s2[4][64];

        III_psy_xmin thm[4];
        III_psy_xmin en[4];


        FLOAT loudness_sq_save[2];

        FLOAT tot_ener[4];

        FLOAT last_en_subshort[4][9];
        int last_attacks[4];

        int blocktype_old[2];
    } PsyStateVar_t;


    typedef struct {

        FLOAT loudness_sq[2][2];
    } PsyResult_t;



    typedef struct {

        FLOAT sb_sample[2][2][18][32];
        FLOAT amp_filter[32];




        double itime[2];
        sample_t *inbuf_old[2];
        sample_t *blackfilt[2 * 320 + 1];

        FLOAT pefirbuf[19];


        int frac_SpF;
        int slot_lag;
        struct {
            int write_timing;
            int ptr;
            char buf[40];
        } header[256];

        int h_ptr;
        int w_ptr;
        int ancillary_flag;


        int ResvSize;
        int ResvMax;

        int in_buffer_nsamples;
        sample_t *in_buffer_0;
        sample_t *in_buffer_1;




        sample_t mfbuf[2][( 3*1152 + 576 - 48 )];

        int mf_samples_to_encode;
        int mf_size;

    } EncStateVar_t;


    typedef struct {

        int bitrate_channelmode_hist[16][4 + 1];
        int bitrate_blocktype_hist[16][4 + 1 + 1];

        int bitrate_index;
        int frame_number;
        int padding;
        int mode_ext;
        int encoder_delay;
        int encoder_padding;
    } EncResult_t;



    typedef struct {

        FLOAT longfact[22];
        FLOAT shortfact[13];
        FLOAT masking_lower;
        FLOAT mask_adjust;
        FLOAT mask_adjust_short;
        int OldValue[2];
        int CurrentStep[2];
        int pseudohalf[(13*3)];
        int sfb21_extra;
        int substep_shaping;







        char bv_scf[576];
    } QntStateVar_t;


    typedef struct {
        replaygain_t *rgdata;

    } RpgStateVar_t;


    typedef struct {
        FLOAT noclipScale;
        sample_t PeakSample;
        int RadioGain;
        int noclipGainChange;
    } RpgResult_t;


    typedef struct {
        int version;
        int samplerate_index;
        int sideinfo_len;

        int noise_shaping;




        int subblock_gain;
        int use_best_huffman;
        int noise_shaping_amp;





        int noise_shaping_stop;







        int full_outer_loop;

        int lowpassfreq;
        int highpassfreq;
        int samplerate_in;
        int samplerate_out;
        int channels_in;
        int channels_out;
        int mode_gr;
        int force_ms;

        int quant_comp;
        int quant_comp_short;

        int use_temporal_masking_effect;
        int use_safe_joint_stereo;

        int preset;

        vbr_mode vbr;
        int vbr_avg_bitrate_kbps;
        int vbr_min_bitrate_index;
        int vbr_max_bitrate_index;
        int avg_bitrate;
        int enforce_min_bitrate;

        int findReplayGain;
        int findPeakSample;
        int decode_on_the_fly;
        int analysis;
        int disable_reservoir;
        int buffer_constraint;
        int free_format;
        int write_lame_tag;

        int error_protection;
        int copyright;
        int original;
        int extension;
        int emphasis;
        MPEG_mode mode;
        short_block_t short_blocks;

        float interChRatio;
        float msfix;
        float ATH_offset_db;
        float ATH_offset_factor;
        float ATHcurve;
        int ATHtype;
        int ATHonly;
        int ATHshort;
        int noATH;

        float ATHfixpoint;

        float adjust_alto_db;
        float adjust_bass_db;
        float adjust_treble_db;
        float adjust_sfb21_db;

        float compression_ratio;


        FLOAT lowpass1, lowpass2;
        FLOAT highpass1, highpass2;


        FLOAT pcm_transform[2][2];

        FLOAT minval;
    } SessionConfig_t;


    struct lame_internal_flags {
        unsigned long class_id;

        int lame_encode_frame_init;
        int iteration_init_init;
        int fill_buffer_resample_init;

        SessionConfig_t cfg;


        Bit_stream_struc bs;
        III_side_info_t l3_side;

        scalefac_struct scalefac_band;

        PsyStateVar_t sv_psy;
        PsyResult_t ov_psy;
        EncStateVar_t sv_enc;
        EncResult_t ov_enc;
        QntStateVar_t sv_qnt;

        RpgStateVar_t sv_rpg;
        RpgResult_t ov_rpg;


        struct id3tag_spec tag_spec;
        uint16_t nMusicCRC;

        uint16_t _unused;


        struct {
            unsigned int MMX:1;

            unsigned int AMD_3DNow:1;
            unsigned int SSE:1;
            unsigned int SSE2:1;
            unsigned int _unused:28;
        } CPU_features;


        VBR_seek_info_t VBR_seek_table;

        ATH_t *ATH;

        PsyConst_t *cd_psy;


        plotting_data *pinfo;
        hip_t hip;

        iteration_loop_t iteration_loop;


        int (*choose_table) (const int *ix, const int *const end, int *const s);
        void (*fft_fht) (FLOAT *, int);
        void (*init_xrpow_core) (gr_info * const cod_info, FLOAT xrpow[576], int upper,
                                    FLOAT * sum);

        lame_report_function report_msg;
        lame_report_function report_dbg;
        lame_report_function report_err;
    };
    void freegfc(lame_internal_flags * const gfc);
    void free_id3tag(lame_internal_flags * const gfc);
    extern int BitrateIndex(int, int, int);
    extern int FindNearestBitrate(int, int, int);
    extern int map2MP3Frequency(int freq);
    extern int SmpFrqIndex(int, int *const);
    extern int nearestBitrateFullIndex(uint16_t brate);
    extern FLOAT ATHformula(SessionConfig_t const *cfg, FLOAT freq);
    extern FLOAT freq2bark(FLOAT freq);
    void disable_FPE(void);


    extern void init_log_table(void);
    extern ieee754_float32_t fast_log2(ieee754_float32_t x);

    int isResamplingNecessary(SessionConfig_t const* cfg);

    void fill_buffer(lame_internal_flags * gfc,
                        sample_t *const mfbuf[2],
                        sample_t const *const in_buffer[2], int nsamples, int *n_in, int *n_out);






    int hip_decode1_unclipped(hip_t hip, unsigned char *mp3buf,
                                   size_t len, sample_t pcm_l[], sample_t pcm_r[]);


    extern int has_MMX(void);
    extern int has_3DNow(void);
    extern int has_SSE(void);
    extern int has_SSE2(void);
    extern void lame_report_def(const char* format, va_list args);
    extern void lame_report_fnc(lame_report_function print_f, const char *, ...);
    extern void lame_errorf(const lame_internal_flags * gfc, const char *, ...);
    extern void lame_debugf(const lame_internal_flags * gfc, const char *, ...);
    extern void lame_msgf(const lame_internal_flags * gfc, const char *, ...);




    int is_lame_internal_flags_valid(const lame_internal_flags * gfp);

    extern void hip_set_pinfo(hip_t hip, plotting_data* pinfo);
int getframebits(const lame_internal_flags * gfc);

int format_bitstream(lame_internal_flags * gfc);

void flush_bitstream(lame_internal_flags * gfc);
void add_dummy_byte(lame_internal_flags * gfc, unsigned char val, unsigned int n);

int copy_buffer(lame_internal_flags * gfc, unsigned char *buffer, int buffer_size,
                    int update_crc);
void init_bit_stream_w(lame_internal_flags * gfc);
void CRC_writeheader(lame_internal_flags const *gfc, char *buffer);
int compute_flushbits(const lame_internal_flags * gfp, int *nbytes);

int get_max_frame_buffer_size_by_constraint(SessionConfig_t const * cfg, int constraint);
typedef struct {
    int h_id;
    int samprate;
    int flags;
    int frames;
    int bytes;
    int vbr_scale;
    unsigned char toc[100];
    int headersize;
    int enc_delay;
    int enc_padding;
} VBRTAGDATA;

int GetVbrTag(VBRTAGDATA * pTagData, const unsigned char *buf);

int InitVbrTag(lame_global_flags * gfp);
int PutVbrTag(lame_global_flags const *gfp, FILE * fid);
void AddVbrFrame(lame_internal_flags * gfc);
void UpdateMusicCRC(uint16_t * crc, const unsigned char *buffer, int size);

struct huffcodetab {
    const unsigned int xlen;
    const unsigned int linmax;
    const uint16_t *table;
    const uint8_t *hlen;
};

extern const struct huffcodetab ht[34];





extern const uint8_t t32l[];
extern const uint8_t t33l[];

extern const uint32_t largetbl[16 * 16];
extern const uint32_t table23[3 * 3];
extern const uint32_t table56[4 * 4];

extern const int scfsi_band[5];

extern const int bitrate_table [3][16];
extern const int samplerate_table [3][ 4];
extern const char* get_lame_tag_encoder_short_version(void);

static const char VBRTag0[] = { "Xing" };
static const char VBRTag1[] = { "Info" };
static const unsigned int crc16_lookup[256] = {
    0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
    0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
    0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
    0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
    0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
    0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
    0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
    0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
    0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
    0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
    0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
    0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
    0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
    0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
    0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
    0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
    0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
    0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
    0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
    0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
    0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
    0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
    0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
    0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
    0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
    0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
    0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,
    0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
    0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
    0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
    0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
    0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040
};
static void
addVbr(VBR_seek_info_t * v, int bitrate)
{
    int i;

    v->nVbrNumFrames++;
    v->sum += bitrate;
    v->seen++;

    if (v->seen < v->want) {
        return;
    }

    if (v->pos < v->size) {
        v->bag[v->pos] = v->sum;
        v->pos++;
        v->seen = 0;
    }
    if (v->pos == v->size) {
        for (i = 1; i < v->size; i += 2) {
            v->bag[i / 2] = v->bag[i];
        }
        v->want *= 2;
        v->pos /= 2;
    }
}

static void
Xing_seek_table(VBR_seek_info_t const* v, unsigned char *t)
{
    int i, indx;
    int seek_point;

    if (v->pos <= 0)
        return;

    for (i = 1; i < 100; ++i) {
        float j = i / (float) 100, act, sum;
        indx = (int) (floor(j * v->pos));
        if (indx > v->pos - 1)
            indx = v->pos - 1;
        act = v->bag[indx];
        sum = v->sum;
        seek_point = (int) (256. * act / sum);
        if (seek_point > 255)
            seek_point = 255;
        t[i] = seek_point;
    }
}
void
AddVbrFrame(lame_internal_flags * gfc)
{
    int kbps = bitrate_table[gfc->cfg.version][gfc->ov_enc.bitrate_index];
    ((void)0);
    addVbr(&gfc->VBR_seek_table, kbps);
}



static int
ExtractI4(const unsigned char *buf)
{
    int x;

    x = buf[0];
    x <<= 8;
    x |= buf[1];
    x <<= 8;
    x |= buf[2];
    x <<= 8;
    x |= buf[3];
    return x;
}

static void
CreateI4(unsigned char *buf, uint32_t nValue)
{

    buf[0] = (nValue >> 24) & 0xff;
    buf[1] = (nValue >> 16) & 0xff;
    buf[2] = (nValue >> 8) & 0xff;
    buf[3] = (nValue) & 0xff;
}



static void
CreateI2(unsigned char *buf, int nValue)
{

    buf[0] = (nValue >> 8) & 0xff;
    buf[1] = (nValue) & 0xff;
}


static int
IsVbrTag(const unsigned char *buf)
{
    int isTag0, isTag1;

    isTag0 = ((buf[0] == VBRTag0[0]) && (buf[1] == VBRTag0[1]) && (buf[2] == VBRTag0[2])
              && (buf[3] == VBRTag0[3]));
    isTag1 = ((buf[0] == VBRTag1[0]) && (buf[1] == VBRTag1[1]) && (buf[2] == VBRTag1[2])
              && (buf[3] == VBRTag1[3]));

    return (isTag0 || isTag1);
}



static void
setLameTagFrameHeader(lame_internal_flags const *gfc, unsigned char *buffer)
{
    SessionConfig_t const *const cfg = &gfc->cfg;
    EncResult_t const *const eov = &gfc->ov_enc;
    char abyte, bbyte;

    ( buffer[0] = (buffer[0] << (8u)) | ( (0xffu) & ~(-1 << (8u)) ) );

    ( buffer[1] = (buffer[1] << (3u)) | ( (7) & ~(-1 << (3u)) ) );
    ( buffer[1] = (buffer[1] << (1u)) | ( ((cfg->samplerate_out < 16000) ? 0 : 1) & ~(-1 << (1u)) ) );
    ( buffer[1] = (buffer[1] << (1u)) | ( (cfg->version) & ~(-1 << (1u)) ) );
    ( buffer[1] = (buffer[1] << (2u)) | ( (4 - 3) & ~(-1 << (2u)) ) );
    ( buffer[1] = (buffer[1] << (1u)) | ( ((!cfg->error_protection) ? 1 : 0) & ~(-1 << (1u)) ) );

    ( buffer[2] = (buffer[2] << (4u)) | ( (eov->bitrate_index) & ~(-1 << (4u)) ) );
    ( buffer[2] = (buffer[2] << (2u)) | ( (cfg->samplerate_index) & ~(-1 << (2u)) ) );
    ( buffer[2] = (buffer[2] << (1u)) | ( (0) & ~(-1 << (1u)) ) );
    ( buffer[2] = (buffer[2] << (1u)) | ( (cfg->extension) & ~(-1 << (1u)) ) );

    ( buffer[3] = (buffer[3] << (2u)) | ( (cfg->mode) & ~(-1 << (2u)) ) );
    ( buffer[3] = (buffer[3] << (2u)) | ( (eov->mode_ext) & ~(-1 << (2u)) ) );
    ( buffer[3] = (buffer[3] << (1u)) | ( (cfg->copyright) & ~(-1 << (1u)) ) );
    ( buffer[3] = (buffer[3] << (1u)) | ( (cfg->original) & ~(-1 << (1u)) ) );
    ( buffer[3] = (buffer[3] << (2u)) | ( (cfg->emphasis) & ~(-1 << (2u)) ) );




    buffer[0] = (uint8_t) 0xff;
    abyte = (buffer[1] & (unsigned char) 0xf1);
    {
        int bitrate;
        if (1 == cfg->version) {
            bitrate = 128;
        }
        else {
            if (cfg->samplerate_out < 16000)
                bitrate = 32;
            else
                bitrate = 64;
        }

        if (cfg->vbr == vbr_off)
            bitrate = cfg->avg_bitrate;

        if (cfg->free_format)
            bbyte = 0x00;
        else
            bbyte = 16 * BitrateIndex(bitrate, cfg->version, cfg->samplerate_out);
    }




    if (cfg->version == 1) {

        buffer[1] = abyte | (char) 0x0a;
        abyte = buffer[2] & (char) 0x0d;
        buffer[2] = (char) bbyte | abyte;
    }
    else {

        buffer[1] = abyte | (char) 0x02;
        abyte = buffer[2] & (char) 0x0d;
        buffer[2] = (char) bbyte | abyte;
    }
}
int
GetVbrTag(VBRTAGDATA * pTagData, const unsigned char *buf)
{
    int i, head_flags;
    int h_bitrate, h_id, h_mode, h_sr_index, h_layer;
    int enc_delay, enc_padding;


    pTagData->flags = 0;


    h_layer = (buf[1] >> 1) & 3;
    if ( h_layer != 0x01 ) {

        return 0;
    }
    h_id = (buf[1] >> 3) & 1;
    h_sr_index = (buf[2] >> 2) & 3;
    h_mode = (buf[3] >> 6) & 3;
    h_bitrate = ((buf[2] >> 4) & 0xf);
    h_bitrate = bitrate_table[h_id][h_bitrate];


    if ((buf[1] >> 4) == 0xE)
        pTagData->samprate = samplerate_table[2][h_sr_index];
    else
        pTagData->samprate = samplerate_table[h_id][h_sr_index];






    if (h_id) {

        if (h_mode != 3)
            buf += (32 + 4);
        else
            buf += (17 + 4);
    }
    else {

        if (h_mode != 3)
            buf += (17 + 4);
        else
            buf += (9 + 4);
    }

    if (!IsVbrTag(buf))
        return 0;

    buf += 4;

    pTagData->h_id = h_id;

    head_flags = pTagData->flags = ExtractI4(buf);
    buf += 4;

    if (head_flags & 0x0001) {
        pTagData->frames = ExtractI4(buf);
        buf += 4;
    }

    if (head_flags & 0x0002) {
        pTagData->bytes = ExtractI4(buf);
        buf += 4;
    }

    if (head_flags & 0x0004) {
        if (pTagData->toc != ((void*)0)) {
            for (i = 0; i < 100; i++)
                pTagData->toc[i] = buf[i];
        }
        buf += 100;
    }

    pTagData->vbr_scale = -1;

    if (head_flags & 0x0008) {
        pTagData->vbr_scale = ExtractI4(buf);
        buf += 4;
    }

    pTagData->headersize = ((h_id + 1) * 72000 * h_bitrate) / pTagData->samprate;

    buf += 21;
    enc_delay = buf[0] << 4;
    enc_delay += buf[1] >> 4;
    enc_padding = (buf[1] & 0x0F) << 8;
    enc_padding += buf[2];


    if (enc_delay < 0 || enc_delay > 3000)
        enc_delay = -1;
    if (enc_padding < 0 || enc_padding > 3000)
        enc_padding = -1;

    pTagData->enc_delay = enc_delay;
    pTagData->enc_padding = enc_padding;
    return 1;
}
int
InitVbrTag(lame_global_flags * gfp)
{
    lame_internal_flags *gfc = gfp->internal_flags;
    SessionConfig_t const *const cfg = &gfc->cfg;
    int kbps_header;
    if (1 == cfg->version) {
        kbps_header = 128;
    }
    else {
        if (cfg->samplerate_out < 16000)
            kbps_header = 32;
        else
            kbps_header = 64;
    }

    if (cfg->vbr == vbr_off)
        kbps_header = cfg->avg_bitrate;



    {
        int total_frame_size = ((cfg->version + 1) * 72000 * kbps_header) / cfg->samplerate_out;
        int header_size = (cfg->sideinfo_len + ((100 +4+4+4+4+4) + 9 + 1 + 1 + 8 + 1 + 1 + 3 + 1 + 1 + 2 + 4 + 2 + 2));
        gfc->VBR_seek_table.TotalFrameSize = total_frame_size;
        if (total_frame_size < header_size || total_frame_size > 2880) {

            gfc->cfg.write_lame_tag = 0;
            return 0;
        }
    }

    gfc->VBR_seek_table.nVbrNumFrames = 0;
    gfc->VBR_seek_table.nBytesWritten = 0;
    gfc->VBR_seek_table.sum = 0;

    gfc->VBR_seek_table.seen = 0;
    gfc->VBR_seek_table.want = 1;
    gfc->VBR_seek_table.pos = 0;

    if (gfc->VBR_seek_table.bag == ((void*)0)) {
        gfc->VBR_seek_table.bag = malloc(400 * sizeof(int));
        if (gfc->VBR_seek_table.bag != ((void*)0)) {
            gfc->VBR_seek_table.size = 400;
        }
        else {
            gfc->VBR_seek_table.size = 0;
            lame_errorf(gfc, "Error: can't allocate VbrFrames buffer\n");
            gfc->cfg.write_lame_tag = 0;
            return -1;
        }
    }


    {
        uint8_t buffer[2880];
        size_t i, n;

        memset(buffer, 0, sizeof(buffer));
        setLameTagFrameHeader(gfc, buffer);
        n = gfc->VBR_seek_table.TotalFrameSize;
        for (i = 0; i < n; ++i) {
            add_dummy_byte(gfc, buffer[i], 1);
        }
    }

    return 0;
}




static uint16_t
CRC_update_lookup(uint16_t value, uint16_t crc)
{
    uint16_t tmp;
    tmp = crc ^ value;
    crc = (crc >> 8) ^ crc16_lookup[tmp & 0xff];
    return crc;
}

void
UpdateMusicCRC(uint16_t * crc, unsigned char const *buffer, int size)
{
    int i;
    for (i = 0; i < size; ++i)
        *crc = CRC_update_lookup(buffer[i], *crc);
}
static int
PutLameVBR(lame_global_flags const *gfp, size_t nMusicLength, uint8_t * pbtStreamBuffer, uint16_t crc)
{
    lame_internal_flags const *gfc = gfp->internal_flags;
    SessionConfig_t const *const cfg = &gfc->cfg;

    int nBytesWritten = 0;
    int i;

    int enc_delay = gfc->ov_enc.encoder_delay;
    int enc_padding = gfc->ov_enc.encoder_padding;




    int nQuality = (100 - 10 * gfp->VBR_q - gfp->quality);
    const char *szVersion = get_lame_tag_encoder_short_version();
    uint8_t nVBR;
    uint8_t nRevision = 0x00;
    uint8_t nRevMethod;
    uint8_t vbr_type_translator[] = { 1, 5, 3, 2, 4, 0, 3 };

    uint8_t nLowpass =
        (((cfg->lowpassfreq / 100.0) + .5) > 255 ? 255 : (cfg->lowpassfreq / 100.0) + .5);

    uint32_t nPeakSignalAmplitude = 0;

    uint16_t nRadioReplayGain = 0;
    uint16_t nAudiophileReplayGain = 0;

    uint8_t nNoiseShaping = cfg->noise_shaping;
    uint8_t nStereoMode = 0;
    int bNonOptimal = 0;
    uint8_t nSourceFreq = 0;
    uint8_t nMisc = 0;
    uint16_t nMusicCRC = 0;


    unsigned char bExpNPsyTune = 1;
    unsigned char bSafeJoint = (cfg->use_safe_joint_stereo) != 0;

    unsigned char bNoGapMore = 0;
    unsigned char bNoGapPrevious = 0;

    int nNoGapCount = gfp->nogap_total;
    int nNoGapCurr = gfp->nogap_current;


    uint8_t nAthType = cfg->ATHtype;

    uint8_t nFlags = 0;


    int nABRBitrate;
    switch (cfg->vbr) {
    case vbr_abr:{
            nABRBitrate = cfg->vbr_avg_bitrate_kbps;
            break;
        }
    case vbr_off:{
            nABRBitrate = cfg->avg_bitrate;
            break;
        }
    default:{
            nABRBitrate = bitrate_table[cfg->version][cfg->vbr_min_bitrate_index];;
        }
    }



    if (cfg->vbr < sizeof(vbr_type_translator))
        nVBR = vbr_type_translator[cfg->vbr];
    else
        nVBR = 0x00;

    nRevMethod = 0x10 * nRevision + nVBR;



    if (cfg->findReplayGain) {
        int RadioGain = gfc->ov_rpg.RadioGain;
        if (RadioGain > 0x1FE)
            RadioGain = 0x1FE;
        if (RadioGain < -0x1FE)
            RadioGain = -0x1FE;

        nRadioReplayGain = 0x2000;
        nRadioReplayGain |= 0xC00;

        if (RadioGain >= 0)
            nRadioReplayGain |= RadioGain;
        else {
            nRadioReplayGain |= 0x200;
            nRadioReplayGain |= -RadioGain;
        }
    }


    if (cfg->findPeakSample)
        nPeakSignalAmplitude =
            abs((int) ((((FLOAT) gfc->ov_rpg.PeakSample) / 32767.0) * pow(2, 23) + .5));


    if (nNoGapCount != -1) {
        if (nNoGapCurr > 0)
            bNoGapPrevious = 1;

        if (nNoGapCurr < nNoGapCount - 1)
            bNoGapMore = 1;
    }



    nFlags = nAthType + (bExpNPsyTune << 4)
        + (bSafeJoint << 5)
        + (bNoGapMore << 6)
        + (bNoGapPrevious << 7);


    if (nQuality < 0)
        nQuality = 0;



    switch (cfg->mode) {
    case MONO:
        nStereoMode = 0;
        break;
    case STEREO:
        nStereoMode = 1;
        break;
    case DUAL_CHANNEL:
        nStereoMode = 2;
        break;
    case JOINT_STEREO:
        if (cfg->force_ms)
            nStereoMode = 4;
        else
            nStereoMode = 3;
        break;
    case NOT_SET:

    default:
        nStereoMode = 7;
        break;
    }



    if (cfg->samplerate_in <= 32000)
        nSourceFreq = 0x00;
    else if (cfg->samplerate_in == 48000)
        nSourceFreq = 0x02;
    else if (cfg->samplerate_in > 48000)
        nSourceFreq = 0x03;
    else
        nSourceFreq = 0x01;




    if (cfg->short_blocks == short_block_forced || cfg->short_blocks == short_block_dispensed || ((cfg->lowpassfreq == -1) && (cfg->highpassfreq == -1)) ||
        (cfg->disable_reservoir && cfg->avg_bitrate < 320) ||
        cfg->noATH || cfg->ATHonly || (nAthType == 0) || cfg->samplerate_in <= 32000)
        bNonOptimal = 1;

    nMisc = nNoiseShaping + (nStereoMode << 2)
        + (bNonOptimal << 5)
        + (nSourceFreq << 6);


    nMusicCRC = gfc->nMusicCRC;



    CreateI4(&pbtStreamBuffer[nBytesWritten], nQuality);
    nBytesWritten += 4;

    strncpy((char *) &pbtStreamBuffer[nBytesWritten], szVersion, 9);
    nBytesWritten += 9;

    pbtStreamBuffer[nBytesWritten] = nRevMethod;
    nBytesWritten++;

    pbtStreamBuffer[nBytesWritten] = nLowpass;
    nBytesWritten++;

    CreateI4(&pbtStreamBuffer[nBytesWritten], nPeakSignalAmplitude);
    nBytesWritten += 4;

    CreateI2(&pbtStreamBuffer[nBytesWritten], nRadioReplayGain);
    nBytesWritten += 2;

    CreateI2(&pbtStreamBuffer[nBytesWritten], nAudiophileReplayGain);
    nBytesWritten += 2;

    pbtStreamBuffer[nBytesWritten] = nFlags;
    nBytesWritten++;

    if (nABRBitrate >= 255)
        pbtStreamBuffer[nBytesWritten] = 0xFF;
    else
        pbtStreamBuffer[nBytesWritten] = nABRBitrate;
    nBytesWritten++;

    pbtStreamBuffer[nBytesWritten] = enc_delay >> 4;
    pbtStreamBuffer[nBytesWritten + 1] = (enc_delay << 4) + (enc_padding >> 8);
    pbtStreamBuffer[nBytesWritten + 2] = enc_padding;

    nBytesWritten += 3;

    pbtStreamBuffer[nBytesWritten] = nMisc;
    nBytesWritten++;


    pbtStreamBuffer[nBytesWritten++] = 0;

    CreateI2(&pbtStreamBuffer[nBytesWritten], cfg->preset);
    nBytesWritten += 2;

    CreateI4(&pbtStreamBuffer[nBytesWritten], (int) nMusicLength);
    nBytesWritten += 4;

    CreateI2(&pbtStreamBuffer[nBytesWritten], nMusicCRC);
    nBytesWritten += 2;




    for (i = 0; i < nBytesWritten; i++)
        crc = CRC_update_lookup(pbtStreamBuffer[i], crc);

    CreateI2(&pbtStreamBuffer[nBytesWritten], crc);
    nBytesWritten += 2;

    return nBytesWritten;
}

static long
skipId3v2(FILE * fpStream)
{
    size_t nbytes;
    long id3v2TagSize;
    unsigned char id3v2Header[10];


    if (fseek(fpStream, 0, 0) != 0) {
        return -2;
    }

    nbytes = fread(id3v2Header, 1, sizeof(id3v2Header), fpStream);
    if (nbytes != sizeof(id3v2Header)) {
        return -3;
    }

    if (!strncmp((char *) id3v2Header, "ID3", 3)) {


        id3v2TagSize = (((id3v2Header[6] & 0x7f) << 21)
                        | ((id3v2Header[7] & 0x7f) << 14)
                        | ((id3v2Header[8] & 0x7f) << 7)
                        | (id3v2Header[9] & 0x7f))
            + sizeof id3v2Header;
    }
    else {

        id3v2TagSize = 0;
    }
    return id3v2TagSize;
}



size_t
lame_get_lametag_frame(lame_global_flags const *gfp, unsigned char *buffer, size_t size)
{
    lame_internal_flags *gfc;
    SessionConfig_t const *cfg;
    unsigned long stream_size;
    unsigned int nStreamIndex;
    uint8_t btToc[100];

    if (gfp == 0) {
        return 0;
    }
    gfc = gfp->internal_flags;
    if (gfc == 0) {
        return 0;
    }
    if (gfc->class_id != 0xFFF88E3B) {
        return 0;
    }
    cfg = &gfc->cfg;
    if (cfg->write_lame_tag == 0) {
        return 0;
    }
    if (gfc->VBR_seek_table.pos <= 0) {
        return 0;
    }
    if (size < gfc->VBR_seek_table.TotalFrameSize) {
        return gfc->VBR_seek_table.TotalFrameSize;
    }
    if (buffer == 0) {
        return 0;
    }

    memset(buffer, 0, gfc->VBR_seek_table.TotalFrameSize);



    setLameTagFrameHeader(gfc, buffer);


    memset(btToc, 0, sizeof(btToc));

    if (cfg->free_format) {
        int i;
        for (i = 1; i < 100; ++i)
            btToc[i] = 255 * i / 100;
    }
    else {
        Xing_seek_table(&gfc->VBR_seek_table, btToc);
    }





    nStreamIndex = cfg->sideinfo_len;





    if (cfg->error_protection)
        nStreamIndex -= 2;


    if (cfg->vbr == vbr_off) {
        buffer[nStreamIndex++] = VBRTag1[0];
        buffer[nStreamIndex++] = VBRTag1[1];
        buffer[nStreamIndex++] = VBRTag1[2];
        buffer[nStreamIndex++] = VBRTag1[3];

    }
    else {
        buffer[nStreamIndex++] = VBRTag0[0];
        buffer[nStreamIndex++] = VBRTag0[1];
        buffer[nStreamIndex++] = VBRTag0[2];
        buffer[nStreamIndex++] = VBRTag0[3];
    }


    CreateI4(&buffer[nStreamIndex], 0x0001 + 0x0002 + 0x0004 + 0x0008);
    nStreamIndex += 4;


    CreateI4(&buffer[nStreamIndex], gfc->VBR_seek_table.nVbrNumFrames);
    nStreamIndex += 4;


    stream_size = gfc->VBR_seek_table.nBytesWritten + gfc->VBR_seek_table.TotalFrameSize;
    CreateI4(&buffer[nStreamIndex], stream_size);
    nStreamIndex += 4;


    memcpy(&buffer[nStreamIndex], btToc, sizeof(btToc));
    nStreamIndex += sizeof(btToc);


    if (cfg->error_protection) {

        CRC_writeheader(gfc, (char *) buffer);
    }
    {

        uint16_t crc = 0x00;
        unsigned int i;
        for (i = 0; i < nStreamIndex; i++)
            crc = CRC_update_lookup(buffer[i], crc);

        nStreamIndex += PutLameVBR(gfp, stream_size, buffer + nStreamIndex, crc);
    }
    return gfc->VBR_seek_table.TotalFrameSize;
}
int
PutVbrTag(lame_global_flags const *gfp, FILE * fpStream)
{
    lame_internal_flags *gfc = gfp->internal_flags;

    long lFileSize;
    long id3v2TagSize;
    size_t nbytes;
    uint8_t buffer[2880];

    if (gfc->VBR_seek_table.pos <= 0)
        return -1;


    fseek(fpStream, 0, 2);


    lFileSize = ftell(fpStream);


    if (lFileSize == 0)
        return -1;







    id3v2TagSize = skipId3v2(fpStream);

    if (id3v2TagSize < 0) {
        return id3v2TagSize;
    }


    fseek(fpStream, id3v2TagSize, 0);

    nbytes = lame_get_lametag_frame(gfp, buffer, sizeof(buffer));
    if (nbytes > sizeof(buffer)) {
        return -1;
    }

    if (nbytes < 1) {
        return 0;
    }


    if (fwrite(buffer, nbytes, 1, fpStream) != 1) {
        return -1;
    }

    return 0;
}

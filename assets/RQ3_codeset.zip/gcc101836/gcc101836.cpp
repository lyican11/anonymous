struct trailing_array {
    int a;
    int b;
    unsigned char c[16];
};

struct middle_array {
    int a;
    unsigned char c[16];
    int b;
};

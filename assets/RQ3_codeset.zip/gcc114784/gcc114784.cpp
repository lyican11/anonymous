template <typename Base>
struct VariantConstructors {
    __attribute__((always_inline)) VariantConstructors(int t) {
        base().set(t, {});
    }
    __attribute__((always_inline)) VariantConstructors(long long t) {
        base().set(t, {});
    }
    Base base();
};

struct Variant : VariantConstructors<Variant> {
    using VariantConstructors<Variant>::VariantConstructors;

    __attribute__((always_inline)) Variant(long long v) : VariantConstructors(v) {}

    template <typename T> void set(T &&, int);
    char m_data;
};

struct ErrorOr {
    ErrorOr(int v) : a(v) { }
    ErrorOr(long long v) : a(v) { }
    Variant a;
};
static ErrorOr run() {
    ErrorOr x(0); // compiles with this line removed
    ErrorOr y(0LL);
    return 0;
}
int serenity_main() {
    run();
}
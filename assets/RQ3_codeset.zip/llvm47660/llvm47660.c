struct c {
    unsigned char b;
    char d;
    char blue;
};
double e;
c f(c g) {
    c a;
    a.b = g.b * e;
    return a;
}
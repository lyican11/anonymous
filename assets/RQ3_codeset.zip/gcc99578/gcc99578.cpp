struct sharpsl_param_info {
    unsigned int comadj_keyword;
};
extern struct sharpsl_param_info sharpsl_param;
typedef unsigned long __kernel_size_t;
extern void * memcpy(void *, const void *, __kernel_size_t);
void sharpsl_save_param(void)
{
    memcpy(&sharpsl_param, (void *)(0xe8ffc000), sizeof(struct sharpsl_param_info));
}
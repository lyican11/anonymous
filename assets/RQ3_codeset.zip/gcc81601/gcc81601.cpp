typedef unsigned int u32;
typedef unsigned char u8;

struct tcp_sock {
    u32	chrono_start;	/* Start time in jiffies of a TCP chrono */
    u32	chrono_stat[3];	/* Time in jiffies for chrono_stat stats */
    u8	chrono_type:2,	/* current chronograph type */
    unused:6;
};

enum tcp_chrono {
    TCP_CHRONO_UNSPEC,
    TCP_CHRONO_BUSY,
    TCP_CHRONO_RWND_LIMITED, /* Stalled by insufficient receive window */
    TCP_CHRONO_SNDBUF_LIMITED, /* Stalled by insufficient send buffer */
    __TCP_CHRONO_MAX,
};

extern u32 tcp_jiffies32;
static void tcp_chrono_set(struct tcp_sock *tp, const enum tcp_chrono new)
{
const u32 now = tcp_jiffies32;

if (tp->chrono_type > TCP_CHRONO_UNSPEC)
tp->chrono_stat[tp->chrono_type - 1] += now - tp->chrono_start;
tp->chrono_start = now;
tp->chrono_type = new;
}

static void tcp_chrono_start(struct tcp_sock *tp, const enum tcp_chrono type)
{
    if (type > tp->chrono_type)
        tcp_chrono_set(tp, type);
}

void tcp_add_write_queue_tail(struct tcp_sock *tp)
{
    tcp_chrono_start(tp, TCP_CHRONO_BUSY);
}
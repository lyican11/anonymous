/* pr44631v2.c */
#include <stdio.h>

void __attribute__((noinline)) lltod(const long long *ll, double *d)
{
    *d = (double)*ll;
}

void __attribute__((noinline)) dtoll(const double *d, long long *ll)
{
    *ll = (long long)*d;
}

const long long tests[] = {
        97979797979797980LL,
        72057594037927936LL,
        72057594037927935LL, /* precision loss, but fxtod and libcall match */
        0x0020000000000001LL, /* ditto */
        0x0020000000000000LL, /* from here down to 0 the conversions are exact */
        0x001fffffffffffffLL,
};

int main(void)
{
    unsigned int i;
    union {
        double d;
        unsigned long long ull;
    } res1;
    long long res2;
    unsigned int fsr0, fsr1;

    for (i = 0; i < sizeof(tests)/sizeof(tests[0]); ++i) {
        lltod(&tests[i], &res1.d);
        dtoll(&res1.d, &res2);
        printf("0x%016llx -> %#5g (0x%016llx) -> 0x%016llx, diff %lld\n",
               tests[i], res1.d, res1.ull, res2, res2 - tests[i]);
    }
    return 0;
}
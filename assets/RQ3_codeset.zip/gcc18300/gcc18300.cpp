struct Base1 { };
struct Base2 { };
struct Base3 { };

struct Derived : Base1, Base2, Base3 { };

void foo(Derived);

int main()
{
    foo(Derived());
}
void _dev_warn(const void *dev, ...);

struct xe_uc {
    int guc;
};

struct xe_gt {
    struct xe_tile *tile;
    struct pf_queue {
        unsigned int data[128];
        unsigned int tail;
    } pf_queue[4];
    struct xe_uc uc;
};
#define container_of(ptr, type, member) ({                              \
        void *__mptr = (void *)(ptr);                                   \
        ((type *)(__mptr - __builtin_offsetof(type, member))); })


void xe_guc_pagefault_handler(struct xe_uc *uc, int asid, void *msg, int len)
{
    struct xe_gt *gt = container_of(uc, struct xe_gt, uc);
    void *xe = gt->tile;
    struct pf_queue *pf_queue;
    if (len != 4)
        return;
    pf_queue = &gt->pf_queue[asid % 4];
    __builtin_memcpy(pf_queue->data + pf_queue->tail,
                     msg, len * sizeof(unsigned int));

    _dev_warn(xe);
}

extern void f_multiple(unsigned char *arg, unsigned long count);
static inline void f_single(unsigned char arg)
{
    f_multiple(&arg, 1);
}
void g(void)
{
    f_single(0);
    f_single(1);
    f_single(2);
    /* ... */
    f_single(100);
}

template<class T>
Object::method(void (*callback)(T*))
{
    if (dynamic_cast<T*>(this) == nullptr)
        throw Exception("Bad callback");
    registerCallback(callback);
}
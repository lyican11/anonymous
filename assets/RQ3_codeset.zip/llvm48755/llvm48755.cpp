struct foo {
    const struct {
        int bar;
    };
} my_foo;

struct foo2 {
    const struct {
        int bar;
    } named;
} my_foo2;

void baz (void) {
    my_foo.bar = 42; // GCC errors, clang does not
    my_foo2.named.bar = 42; // GCC and Clang error
}
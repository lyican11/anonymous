int* f (int);

__attribute__ ((alloc_size (1), noinline)) int*
f0 (int n) { return f (n); }

void h0 (void)
{
    int *p = f0 (3);
    __builtin_memset (p, 0, 3 * sizeof p);   // warning (good)
}

__attribute__ ((alloc_size (1))) int*
f1 (int n) { return f (n); }

void h1 (void)
{
    int *p = f1 (3);
    __builtin_memset (p, 0, 3 * sizeof p);   // missing warning
}

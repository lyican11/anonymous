struct S { char a[64]; };

int
foo (void)
{
    struct S s, t;
    asm goto ("" : "=g" (s) : : : l);
    t = s;
    asm goto ("" : "=g" (s) : : : l);
    return s.a[0] + t.a[63];
    l:
    return -1;
}
#ifndef NOPRAGMA
#define do_pragma(_pragma) _Pragma (_pragma)
#else
#define do_pragma(_pragma)
#endif

#define do_inc(_pragma) ({ \
  do_pragma ("GCC diagnostic push") \
  do_pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"") \
  ++n; \
  do_pragma ("GCC diagnostic pop") \
  n; })

#define do_expect(_x, _n) __builtin_expect((_x), _n)
#define if_expected(_x, _n) if (do_expect(_x, _n))

void havoc(void)
{
    int n;

#line 100
    if (__builtin_expect(do_inc(), 1)) ++n;
#line 200
    if (do_expect(do_inc(), 3)) ++n;
#line 300
    if_expected (do_inc(), 5) ++n;
}
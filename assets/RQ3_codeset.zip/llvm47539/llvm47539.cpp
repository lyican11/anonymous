void foo(int x) {
    switch (x) {
                __attribute__((__fallthrough__));
    }
}
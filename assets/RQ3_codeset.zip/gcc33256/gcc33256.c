extern unsigned long a[];
int b(int x);

int c()
{
    return b(a[0]);
}
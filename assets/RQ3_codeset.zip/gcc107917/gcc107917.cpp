enum {
    A = 1 <<31,
    B = 0xffffffff,
} e;

int s1 = sizeof(A);
int s2 = sizeof(B);
int s3 = sizeof(e);

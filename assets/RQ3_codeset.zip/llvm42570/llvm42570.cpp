int a __attribute__((__section__(".data..ro_after_init")));
static int b[4] __attribute__((__section__(".data..ro_after_init")));
int c;
int fn1(void);
void fn2() { c = b[fn1()]; }
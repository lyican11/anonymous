/*
gcc -O2 \
	-Warray-bounds \
	-fno-strict-aliasing \
	-fno-strict-overflow \
	-fsanitize=shift \
	-fsanitize-coverage=trace-pc \
	-c -o /dev/null test.c
*/

#define ELEMENTS 2

typedef unsigned int u32;

struct object {
    char setting : 1;
};
struct many_objects {
    struct object array[ELEMENTS];
};

extern u32  pick(int num);
extern void capture(u32 mask);

static int work(struct many_objects *instance, unsigned int irq,
                int level)
{
    struct object entry;
    u32 mask = 1 << irq;

    entry = instance->array[irq];

    capture(mask);

    if (level || irq == 1 || entry.setting)
        return 0;

    return 1;
}


void bounds_check_work(struct many_objects *instance, int irq, int level)
{
    u32 idx;

    if (irq < 0 || irq >= ELEMENTS)
        return;

    work(instance, irq, level);

    for (idx = pick(0);
         idx >= 0 && idx < ELEMENTS;
         idx = pick(0))
        work(instance, idx, level);
}
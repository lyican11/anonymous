struct a {
    int b;
    char c[100];
};
unsigned long d(long e) { return __builtin_offsetof(a, c[e]); }
struct i2c_adapter {
    char name[48];
    int a[1000];
} hexium_attach_hexium;
void hexium_attach(void) {
    hexium_attach_hexium = (struct i2c_adapter){"hexium gemini"};
}
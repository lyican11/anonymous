int main() {
    int array[3];
    int (*ptr)[];
    struct { int (*ptr)[]; } st;

    ptr = &array;     // fine
    st.ptr = &array;  // warning: assignment from incompatible pointer type
}
int a;
static void invoke_syscall() {
    char b = __builtin_alloca(a);
    asm("" : "=o"(b));
}
void c(void) { invoke_syscall(); }

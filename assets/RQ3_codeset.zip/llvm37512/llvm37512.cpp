From the linux 4.14.41 source, the relevant code is:

========

arch/x86/include/asm/paravirt_types.h:

/*
 * Wrapper type for pointers to code which uses the non-standard
 * calling convention.  See PV_CALL_SAVE_REGS_THUNK below.
 */
struct paravirt_callee_save {
    void *func;
};

struct pv_irq_ops {
    /*
     * Get/set interrupt state.  save_fl and restore_fl are only
     * expected to use X86_EFLAGS_IF; all other bits
     * returned from save_fl are undefined, and may be ignored by
     * restore_fl.
     *
     * NOTE: These functions callers expect the callee to preserve
     * more registers than the standard C calling convention.
     */
    struct paravirt_callee_save save_fl;
    struct paravirt_callee_save restore_fl;
    struct paravirt_callee_save irq_disable;
    struct paravirt_callee_save irq_enable;

    void (*safe_halt)(void);
    void (*halt)(void);

} __no_randomize_layout;


arch/x86/include/asm/paravirt.h:

/* Promise that "func" already uses the right calling convention */
#define __PV_IS_CALLEE_SAVE(func)                       \
        ((struct paravirt_callee_save) { func })

arch/x86/kernel/paravirt.c:

__visible struct pv_irq_ops pv_irq_ops = {
        .save_fl = __PV_IS_CALLEE_SAVE(native_save_fl),
        .restore_fl = __PV_IS_CALLEE_SAVE(native_restore_fl),
        .irq_disable = __PV_IS_CALLEE_SAVE(native_irq_disable),
        .irq_enable = __PV_IS_CALLEE_SAVE(native_irq_enable),
        .safe_halt = native_safe_halt,
        .halt = native_halt,
};

arch/x86/include/asm/irqflags.h:

static inline unsigned long native_save_fl(void)
{
    unsigned long flags;

    /*
     * "=rm" is safe here, because "pop" adjusts the stack before
     * it evaluates its effective address -- this is part of the
     * documented behavior of the "pop" instruction.
     */
    asm volatile("# __raw_save_flags\n\t"
                 "pushf ; pop %0"
            : "=rm" (flags)
            : /* no input */
            : "memory");

    return flags;
}

========



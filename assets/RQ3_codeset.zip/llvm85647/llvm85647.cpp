struct {
    short hci_handledev_class[3];
} sco_sock_getsockopt_old_cinfo;
typeof(__builtin_choose_expr(
        sizeof(char), 0,
        __builtin_choose_expr(
                sizeof(short), 0,
                __builtin_choose_expr(sizeof(int), 0,
                                      __builtin_choose_expr(sizeof(long), 0, 0)))))
        sco_sock_getsockopt_old___val_gu;
void kmsan_unpoison_memory(void *address) {}
void __attribute__((__error__("copy source size is too small")))
__bad_copy_from();
long copy_to_user(void *from, long n) {
    void *addr = from;
    long bytes = n;
    int sz = __builtin_object_size(addr, 0);
    if (__builtin_expect(sz >= 0 && sz < bytes, 0))
        __bad_copy_from();
    return 0;
}
int sco_sock_getsockopt_old() {
    int len;
    long __tmp = sco_sock_getsockopt_old___val_gu;
    kmsan_unpoison_memory(&__tmp);
    len = __tmp;
    len = __builtin_choose_expr(
            0, 0, ({
                typeof(0) __UNIQUE_ID___x1646 = len;
                unsigned __UNIQUE_ID___y1647 = sizeof(sco_sock_getsockopt_old_cinfo);
                __UNIQUE_ID___x1646 < __UNIQUE_ID___y1647 ? __UNIQUE_ID___x1646 : 0;
            }));
    copy_to_user(&sco_sock_getsockopt_old_cinfo, len);
    return 0;
}
long modeisar_ch_0_1;
int modeisar_ch_0_2, modeisar_bprotocol;
void fn1() {
    if (modeisar_ch_0_2)
        switch (modeisar_bprotocol)
            case 33:
            case 34:
                if (modeisar_bprotocol == 34)
                    fn2(3, &modeisar_ch_0_1);
                else
                    fn2(2, &modeisar_ch_0_1);
    _Bool branch;
    int *key = 0;
    asm goto("" ::"i"(&key[branch])::l_yes);
    l_yes:;
}
static int t;
void g(void);

void f(void)
{
    int  __gu_val;
    asm goto(""
    : "=&r"(__gu_val)
    :
    :
    : Efault);
    t = __gu_val;
    g();
    Efault:
}
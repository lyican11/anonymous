#include <byteswap.h>

short
b1 (short x)
{
    return  __bswap_16 (x);
}

short
b2 (short x)
{
    return  __builtin_bswap32 (x << 16);
}
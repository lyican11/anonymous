#include <float.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    long double d = 0.5L;
    printf("%a\n", (double)(1.0L + DBL_EPSILON * d));
    return (0);
}

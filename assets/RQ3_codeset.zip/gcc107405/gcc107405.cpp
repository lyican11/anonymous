#include <stdio.h>
enum { A = 0xffffffff, B = 1 << 31, };
int main() { printf("%lx %x %zu\n", A, B, sizeof(B)); }
short a;
int **b() {
    int c = 1;
    int d = a & 128;
    if (d)
        c++;
    return (int **)0 - c;
}
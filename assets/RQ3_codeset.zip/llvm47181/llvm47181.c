void add(const UnwindInfoSections *UIS) {
     CacheEntry *Current = nullptr;

     if (Unused != nullptr) {
        Current = Unused;
       Unused = Unused->Next;
     } else {
       Current = MostRecentlyUsed;
       CacheEntry *Previous = nullptr;
       while (Current->Next != nullptr) {
         Previous = Current;
         Current = Current->Next;
       }
        Previous->Next = nullptr;
       _LIBUNWIND_FRAMEHEADERCACHE_TRACE("FrameHeaderCache evict [%lx - %lx)",Current->LowPC(), Current->HighPC());
    }
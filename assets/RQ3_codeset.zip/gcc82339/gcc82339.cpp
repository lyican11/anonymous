__attribute__((noinline, noclone)) unsigned long long int
foo (int x)
{
    asm volatile ("" : : : "memory");
    return 1ULL << (63 - x);
}

__attribute__((noinline, noclone)) unsigned long long int
bar (int x)
{
    asm volatile ("" : : : "memory");
    return (1ULL << 63) >> x;
}

__attribute__((noinline, noclone)) unsigned long long int
baz (int x)
{
    unsigned long long int y = 1;
    asm volatile ("" : "+r" (y) : : "memory");
    return (y << 63) >> x;
}

int
main (int argc, const char **argv) {
    int i;
    if (argc == 1)
        for (i = 0; i < 1000000000; i++)
            asm volatile ("" : : "r" (foo(13)));
    else if (argc == 2)
        for (i = 0; i < 1000000000; i++)
            asm volatile ("" : : "r" (bar(13)));
    else if (argc == 3)
        for (i = 0; i < 1000000000; i++)
            asm volatile ("" : : "r" (baz(13)));
    return 0;
}
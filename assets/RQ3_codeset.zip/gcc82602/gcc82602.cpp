typedef unsigned char uint8_t;
typedef unsigned char uint_fast8_t;
typedef unsigned int uint32_t;

/*! Private QS data to keep track of the filters and the trace buffer. */
typedef struct {
    uint8_t glbFilter[16]; /*!< global on/off QS filter */
    void const *locFilter[16]; /*!< local QS filters */
    //...
} QSPriv;

extern QSPriv QS_priv_;
extern void *QS_obj_;

void foo(void); /* prototype */

void bug_test(void) {
    uint8_t i;
    for(i = 0; i < 10; i++) {
        if ((((uint_fast8_t)QS_priv_.glbFilter[(uint8_t)(123) >> 3]
              & (uint_fast8_t)((uint_fast8_t)1 << ((uint8_t)(123) & (uint8_t)7)))
             != (uint_fast8_t)0)
            && ((QS_priv_.locFilter[3] == (void *)0)
                || (QS_priv_.locFilter[3] == (QS_obj_))))
        {
            uint32_t status;

            /* save the PRIMASK into 'status' */
            __asm volatile ("mrs %0,PRIMASK" : "=r" (status) :: );

            /* set PRIMASK to disable interrupts */
            __asm volatile ("cpsid i");

            foo(); /* call a function */

            /* restore PRIMASK from 'status' */
            __asm volatile ("msr PRIMASK,%0" :: "r" (status) : );
        }
    }
}
struct a {
    char b[50];
};
struct c {
    short action;
    struct a d;
};
struct f {
    short command;
    struct c e;
};
void i(struct f *f, int *g, unsigned h) {
    struct c *j = &f->e;
    j->action = 0;
    __builtin_memcpy(&j->d.b[h], g, 16);

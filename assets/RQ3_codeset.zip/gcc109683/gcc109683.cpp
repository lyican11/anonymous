template <typename T, typename>
struct VariantConstructors {
    VariantConstructors(T&& t)
    requires(requires { T(t); });
};

template <typename... Ts>
struct InheritFromEntries : Ts... {};

template <typename... Ps>
struct InheritFromPack: InheritFromEntries<Ps>... {
    using InheritFromEntries<Ps>::InheritFromEntries...;
};

template <typename... Ts>
struct Variant : InheritFromPack<VariantConstructors<Ts, Variant<Ts...>>...> {};

template <typename T>
class Outer;
struct Inner {
    Inner(Outer<int>);
};
template<typename T>
class Outer {
    Variant<T, Inner> value_;
};

struct Empty {};
void fn(Outer<Empty> x) {}
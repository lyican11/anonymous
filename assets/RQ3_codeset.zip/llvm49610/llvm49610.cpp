struct hv_guest_state {
    int vcpu_token;
    long pcr;
    long amor;
    long dpdes;
    long hfscr;
    long tb_offset;
    long srr0;
    long srr1;
    long sprg[4];
    long pidr;
    long cfar;
    long ppr;
    long dawr1;
    long dawrx1;
} kvmhv_write_guest_state_and_regs_l2_hv;
struct pt_regs {
    struct {
        struct {
            long gpr[32];
            long nip;
            long msr;
            long orig_gpr3;
            long ctr;
            long link;
            long xer;
            long ccr;
            long softe;
            long trap;
            long dar;
            long dsisr;
            long result;
        };
        long __pad[4];
    };
} __srcu_read_unlock();
struct kvm_vcpu_arch {
    struct pt_regs regs;
    struct kvmppc_vcore *vcore;
    int trap;
};
struct kvmppc_vcore {
    long tb_offset;
    long pcr;
};
struct kvm_nested_guest {
    long l1_gr_to_hr;
};
int kvm_vcpu_read_guest();
static void kvmhv_update_ptbl_cache(struct kvm_nested_guest *gp) {
    struct kvm_nested_guest __trans_tmp_14 = *gp;
    __srcu_read_unlock(__trans_tmp_14);
}
void byteswap_pt_regs(struct pt_regs *regs) {
    unsigned long *addr = (long *)regs;
    for (; addr < (unsigned long *)(regs + 1); addr++)
        *addr = __builtin_bswap64(*addr);
}
int kvmhv_read_guest_state_and_regs(struct hv_guest_state *l2_hv,
                                    struct pt_regs *l2_regs) {
    return kvm_vcpu_read_guest(l2_hv) || kvm_vcpu_read_guest(l2_regs);
}
long kvmhv_enter_nested_guest(struct kvm_vcpu_arch *vcpu) {
    struct kvm_nested_guest *l2;
    struct pt_regs l2_regs, saved_l1_regs;
    struct hv_guest_state l2_hv;
    struct kvmppc_vcore *vc = vcpu->vcore;
    long regs_ptr = kvmhv_read_guest_state_and_regs(&l2_hv, &l2_regs);
    byteswap_pt_regs(&l2_regs);
    if (!l2->l1_gr_to_hr)
        kvmhv_update_ptbl_cache(l2);
    saved_l1_regs = vcpu->regs;
    vc->tb_offset += l2_hv.tb_offset;
    vcpu->regs = saved_l1_regs;
    vc = vcpu->vcore;
    vc->pcr = 0;
    struct hv_guest_state *hr = 0;
    hr->pidr = hr->dawr1 = __builtin_bswap64(hr->dawr1);
    hr->dawrx1 = __builtin_bswap64(hr->dawrx1);
    byteswap_pt_regs(&l2_regs);
    kvm_vcpu_read_guest(kvmhv_write_guest_state_and_regs_l2_hv, regs_ptr);
    return vcpu->trap;
}
int alpha () { return 0; }
int beta ()  { return 0; }
int gamma () { return 0; }

int main ()
{
    alpha ();
    beta ();
    gamma ();
    return 0;
}
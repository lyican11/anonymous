extern void h(int *t);
extern int g(void);
void f(int *t, int b)
{
    int ts;
    g();
    *t = ts;

    switch (b) {
        case 0:
            h(&ts);
    };
}
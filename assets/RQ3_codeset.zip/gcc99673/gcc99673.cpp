typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef _Bool bool;
#define true 1
#define false  0

#define NL80211_VHT_NSS_MAX		8

enum wmi_phy_mode {
    MODE_11A        = 0,   /* 11a Mode */
    MODE_UNKNOWN    = 16,
    MODE_MAX        = 16
};

enum nl80211_band {
    NL80211_BAND_2GHZ,
    NL80211_BAND_5GHZ,
    NUM_NL80211_BANDS,
};

struct cfg80211_bitrate_mask {
    struct {
        u16 vht_mcs[NL80211_VHT_NSS_MAX];
    } control[NUM_NL80211_BANDS];
};

struct ath11k_vif {
    u32 vdev_id;
    struct cfg80211_bitrate_mask bitrate_mask;
};

struct ieee80211_vif {
    u32 type;
    u8 drv_priv[];
};

struct peer_assoc_params {
    u32 vdev_id;
    u32 peer_vht_caps;
    u32 peer_phymode;
};

struct ieee80211_sta_vht_cap {
    u32 cap;
};

static inline bool
ath11k_peer_assoc_h_vht_masked(const u16 vht_mcs_mask[NL80211_VHT_NSS_MAX])
{
    int nss;
    for (nss = 0; nss < NL80211_VHT_NSS_MAX; nss++)
        if (vht_mcs_mask[nss])
            return false;
    return true;
}

static void ath11k_peer_assoc_h_vht(struct ieee80211_vif *vif,
                                    const struct ieee80211_sta_vht_cap *vht_cap,
                                    struct peer_assoc_params *arg,
                                    enum nl80211_band band)
{
    struct ath11k_vif *arvif = (void *)vif->drv_priv;
    const u16 *vht_mcs_mask = arvif->bitrate_mask.control[band].vht_mcs;

    if (ath11k_peer_assoc_h_vht_masked(vht_mcs_mask))
        return;

    arg->peer_vht_caps = vht_cap->cap;
}

void ath11k_peer_assoc_h_phymode(struct ieee80211_vif *vif,
                                 struct peer_assoc_params *arg,
                                 enum nl80211_band band)
{
    struct ath11k_vif *arvif = (void *)vif->drv_priv;
    const u16 *vht_mcs_mask = arvif->bitrate_mask.control[band].vht_mcs;

    if (ath11k_peer_assoc_h_vht_masked(vht_mcs_mask))
        return;

    arg->peer_phymode = MODE_UNKNOWN;
}

void ath11k_peer_assoc_prepare(struct ieee80211_vif *vif,
                               const struct ieee80211_sta_vht_cap *vht_cap,
                               struct peer_assoc_params *arg,
                               enum nl80211_band band)
{
    struct ath11k_vif *arvif = (void *)vif->drv_priv;
    arg->vdev_id = arvif->vdev_id;
    ath11k_peer_assoc_h_vht(vif, vht_cap, arg, band);
    ath11k_peer_assoc_h_phymode(vif, arg, band);
}
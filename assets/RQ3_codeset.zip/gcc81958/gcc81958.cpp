__attribute__ ((__cold__)) int printk();
struct lpfc_queue {
    int queue_id;
    struct lpfc_queue *hba_eq;
} *cq_phba;
void lpfc_debug_dump_all_queues(unsigned maxidx)
{
    struct lpfc_queue *eq;
    unsigned eqidx;
    printk();
    for (eqidx = 0; eqidx < maxidx; eqidx++) {
        eq = &cq_phba->hba_eq[eqidx];
        if (eq->queue_id)
            break;
    }
    if (eqidx == maxidx)
        eq = &cq_phba->hba_eq[0];
    printk(eq);
}
struct nlmsg {
    __u32           nlmsg_len;
    __u16           nlmsg_type;
    __u16           nlmsg_flags;
    __u32           nlmsg_seq;
    __u32           nlmsg_pid;
    __u8            nlmsg_content[];
};

struct wrapper {
    __u8 a;
    __u8 b;
    struct nlmsg msg;
};

struct foo {
    int a;
    union {
        int a;
        double b;
    };
};

int main(void)
{
    struct foo f;
    f.a = 123;
    return 0;
}